#!/bin/sh
# Auto-update old NekoJB rootful files to palera1n 2.4 on boot.
APP=`dirname "$0"`/..
VER="$APP/palera1n-VERSION"
NEED=1
if [ -f "$VER" ]; then
	grep -q "2.4" "$VER" && NEED=0
	grep -q "palera1n-3" "$VER" && NEED=0
fi
if [ "$NEED" = "1" ]; then
	echo 2.4 > "$VER"
	export PALERA1N_FLAG=-f
	export PALERA1N_ROOTFUL_FLAG=--rootful
fi
exec /bin/sh "$APP/createFakeFS.sh"
