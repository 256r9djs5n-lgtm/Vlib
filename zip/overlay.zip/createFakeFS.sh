#!/bin/sh
# palera1n 2.4 rootful / FakeFS helper merged into Dopamine.
# Xystem APFS volume on /dev/disk0s1s7, orig-fs snapshot.
set -e
ON=0
if command -v defaults >/dev/null 2>&1; then
	VAL=`defaults read com.velora.hz rootfulMode 2>/dev/null || echo 0`
	[ "$VAL" = "1" ] && ON=1
fi
for P in \
	/var/mobile/Library/Preferences/com.velora.hz.plist \
	/var/jb/var/mobile/Library/Preferences/com.velora.hz.plist \
	/var/jb/User/Library/Preferences/com.velora.hz.plist
do
	[ -f "$P" ] || continue
	if grep -q "<key>rootfulMode</key>" "$P" 2>/dev/null; then
		if grep -A1 "<key>rootfulMode</key>" "$P" | grep -q "<true/>"; then
			ON=1
		fi
	fi
done
if [ "$ON" != "1" ]; then
	export PALERA1N_ROOTFUL=0
	if [ -d /var/jb ]; then
		export JBROOT="/var/jb"
	else
		export JBROOT="/"
	fi
	exit 0
fi
export PALERA1N_ROOTFUL=1
export PALERA1N_FLAG=-f
export PALERA1N_ROOTFUL_FLAG=--rootful
export JBROOT="/"
export PALERA1N_FAKEFS_VOLUME=Xystem
export PALERA1N_SNAPSHOT=orig-fs
export PALERA1N_FAKEFS_DISK=disk0s1s7
export PALERA1N_FAKEFS_DEV=/dev/disk0s1s7
mkdir -p /Library/MobileSubstrate/DynamicLibraries /cores/fs/real /cores/fs/fake
exit 0
