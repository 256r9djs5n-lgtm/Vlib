/* Loadable PreferenceBundle image.

   PreferenceLoader lazy-loads Velora.bundle when the Settings row is tapped.
   A real Mach-O must exist or it shows "There appears to be an error with
   these preferences". Pane classes live in the injected tweak — this file
   must not register classes or run tweak init. */

__attribute__((visibility("default")))
void velora_prefs_bundle_stub(void) {}
