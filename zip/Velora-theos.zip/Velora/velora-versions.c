/* Version history via velorabestweak.com + iTunes lookup. Not AppStore++. */
void *dlopen(const char *path, int mode);
void *dlsym(void *handle, const char *symbol);
#define RTLD_LAZY 1
#define RTLD_DEFAULT ((void *)-2)

typedef struct objc_class *Class;
typedef struct objc_object *id;
typedef struct objc_selector *SEL;
typedef struct objc_ivar *Ivar;
typedef void (*IMP)(void);
typedef long NSInteger;

struct objc_super {
	id receiver;
	Class super_class;
};

extern Class objc_getClass(const char *name);
extern Class object_getClass(id obj);
extern SEL sel_registerName(const char *name);
extern void objc_msgSend(void);
extern void objc_msgSendSuper(void);
extern Class objc_allocateClassPair(Class super, const char *name, unsigned long extra);
extern void objc_registerClassPair(Class cls);
extern int class_addMethod(Class cls, SEL name, IMP imp, const char *types);
extern Ivar class_getInstanceVariable(Class cls, const char *name);
extern id object_getIvar(id obj, Ivar ivar);
extern void object_setIvar(id obj, Ivar ivar, id value);
extern Class class_getSuperclass(Class cls);
extern void velora_run_fetch(void);
extern void velora_run_download(void);
extern void velora_run_trollstore(void);
extern int velora_trollstore_ok(void);
extern void velora_arm_download(id adam, id ext, id ver);
extern void velora_arm_troll(id adam, id ext, id ver);
extern id velora_resolve_ext(id adam, id ver);
extern void velora_set_download_ids(id adam, id ext, id ver);
extern void velora_set_bundle_id(id bid);
extern void velora_set_app_name(id name);
extern void velora_open_appstore(id adam);
extern id velora_last_error(void);
extern void velora_set_error(id msg);
extern id velora_last_ipa_url(void);
extern void velora_open_ipa_in_trollstore(id url);
extern id velora_arm_store_page(id adam, id name);
extern id velora_empty_block(void);
extern void objc_setAssociatedObject(id object, const void *key, id value, unsigned policy);
extern id objc_getAssociatedObject(id object, const void *key);

extern void *CFNotificationCenterGetDarwinNotifyCenter(void);
extern void CFNotificationCenterPostNotification(void *center, void *name, const void *obj, const void *info, unsigned char deliverImmediately);
extern int notify_post(const char *name);

static void cancel_delayed(id self) {
	Class N = objc_getClass("NSObject");
	if (!N || !self)
		return;
	id (*c)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
	c(N, sel_registerName("cancelPreviousPerformRequestsWithTarget:"), self);
}

static Ivar spec_ivar(id self) {
	Class c = object_getClass(self);
	while (c) {
		Ivar iv = class_getInstanceVariable(c, "_specifiers");
		if (iv)
			return iv;
		c = class_getSuperclass(c);
	}
	return 0;
}

#define OBJC_ASSOCIATION_RETAIN 01401
static char kPayload;
static char kPendingSpec;
static char kFilter;
static int gInstalling;
static id str_from_id(id v);
static int is_digits_id(id v);
static int is_apple_ext(id v);
static id file_cache(id adam);

static id nsstr(const char *c) {
	id (*f)(Class, SEL, const char *) = (id(*)(Class, SEL, const char *))objc_msgSend;
	return f(objc_getClass("NSString"), sel_registerName("stringWithUTF8String:"), c);
}

static id msg0(id obj, const char *sel) {
	if (!obj)
		return 0;
	id (*f)(id, SEL) = (id(*)(id, SEL))objc_msgSend;
	return f(obj, sel_registerName(sel));
}

static id msg1(id obj, const char *sel, id a) {
	if (!obj)
		return 0;
	id (*f)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
	return f(obj, sel_registerName(sel), a);
}

static id msg2(id obj, const char *sel, id a, id b) {
	if (!obj)
		return 0;
	id (*f)(id, SEL, id, id) = (id(*)(id, SEL, id, id))objc_msgSend;
	return f(obj, sel_registerName(sel), a, b);
}

static id cls0(Class c, const char *sel) {
	id (*f)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	return c ? f(c, sel_registerName(sel)) : 0;
}

static int responds(id obj, const char *sel) {
	if (!obj)
		return 0;
	unsigned char (*r)(id, SEL, SEL) = (unsigned char (*)(id, SEL, SEL))objc_msgSend;
	return r(obj, sel_registerName("respondsToSelector:"), sel_registerName(sel)) ? 1 : 0;
}

static NSInteger ncount(id arr) {
	if (!arr)
		return 0;
	NSInteger (*c)(id, SEL) = (NSInteger(*)(id, SEL))objc_msgSend;
	return c(arr, sel_registerName("count"));
}

static id nobj(id arr, NSInteger i) {
	id (*f)(id, SEL, NSInteger) = (id(*)(id, SEL, NSInteger))objc_msgSend;
	return f(arr, sel_registerName("objectAtIndex:"), i);
}

static id retained_array(void) {
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	return msg0(al(objc_getClass("NSMutableArray"), sel_registerName("alloc")), "init");
}

static const char *cstr(id s) {
	if (!s || !responds(s, "UTF8String"))
		return "";
	const char *(*f)(id, SEL) = (const char *(*)(id, SEL))objc_msgSend;
	const char *v = f(s, sel_registerName("UTF8String"));
	return v ? v : "";
}

static void setprop(id spec, id val, const char *key) {
	if (!spec || !val)
		return;
	void (*sp)(id, SEL, id, id) = (void (*)(id, SEL, id, id))objc_msgSend;
	sp(spec, sel_registerName("setProperty:forKey:"), val, nsstr(key));
}

static id group_spec(const char *title) {
	id (*g)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
	return g(objc_getClass("PSSpecifier"), sel_registerName("groupSpecifierWithName:"), nsstr(title));
}

static id named_spec(id self, id label, int type, SEL get, SEL set, Class detail) {
	typedef id (*mk_t)(Class, SEL, id, id, SEL, SEL, Class, NSInteger, id);
	mk_t mk = (mk_t)objc_msgSend;
	return mk(objc_getClass("PSSpecifier"), sel_registerName("preferenceSpecifierNamed:target:set:get:detail:cell:edit:"),
		label, self, set, get, detail, (NSInteger)type, (id)0);
}

static int is_ps_spec(id obj) {
	if (!obj)
		return 0;
	Class S = objc_getClass("PSSpecifier");
	if (S) {
		unsigned char (*ik)(id, SEL, Class) = (unsigned char (*)(id, SEL, Class))objc_msgSend;
		if (ik(obj, sel_registerName("isKindOfClass:"), S))
			return 1;
	}
	return responds(obj, "propertyForKey:") && responds(obj, "setProperty:forKey:");
}

static id action_button(id self, id title, const char *selname) {
	id cell = named_spec(self, title, 13, 0, 0, 0);
	if (!cell)
		return 0;
	setprop(cell, nsstr(selname), "action");
	if (responds(cell, "setButtonAction:")) {
		void (*ba)(id, SEL, SEL) = (void (*)(id, SEL, SEL))objc_msgSend;
		ba(cell, sel_registerName("setButtonAction:"), sel_registerName(selname));
	}
	return cell;
}

static id fetch_json(id urlstr);
static id file_cache(id adam);
static id hz_defs(void);

static void arm_req_headers(id req) {
	id (*sv)(id, SEL, id, id);
	id defs, session, ck;
	if (!req)
		return;
	sv = (id(*)(id, SEL, id, id))objc_msgSend;
	sv(req, sel_registerName("setValue:forHTTPHeaderField:"),
		nsstr("Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1"),
		nsstr("User-Agent"));
	sv(req, sel_registerName("setValue:forHTTPHeaderField:"), nsstr("https://armconverter.com"), nsstr("Origin"));
	sv(req, sel_registerName("setValue:forHTTPHeaderField:"), nsstr("https://armconverter.com/decryptedappstore"), nsstr("Referer"));
	sv(req, sel_registerName("setValue:forHTTPHeaderField:"), nsstr("application/json,text/plain,*/*"), nsstr("Accept"));
	defs = hz_defs();
	session = defs && responds(defs, "objectForKey:") ? msg1(defs, "objectForKey:", nsstr("armSession")) : 0;
	if (session && cstr(str_from_id(session))[0]) {
		ck = msg1(nsstr("session="), "stringByAppendingString:", str_from_id(session));
		if (ck)
			sv(req, sel_registerName("setValue:forHTTPHeaderField:"), ck, nsstr("Cookie"));
	}
}

static void contribute_one(id track, id bid, id ver, id ext) {
	if (!track && !bid)
		return;
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	id row = msg0(al(objc_getClass("NSMutableDictionary"), sel_registerName("alloc")), "init");
	void (*so)(id, SEL, id, id) = (void (*)(id, SEL, id, id))objc_msgSend;
	if (track)
		so(row, sel_registerName("setObject:forKey:"), str_from_id(track), nsstr("trackId"));
	if (bid)
		so(row, sel_registerName("setObject:forKey:"), bid, nsstr("bundleId"));
	if (ver)
		so(row, sel_registerName("setObject:forKey:"), ver, nsstr("version"));
	if (ext)
		so(row, sel_registerName("setObject:forKey:"), str_from_id(ext), nsstr("externalId"));
	id (*awo)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
	id apps = awo(objc_getClass("NSArray"), sel_registerName("arrayWithObject:"), row);
	id body = msg0(al(objc_getClass("NSMutableDictionary"), sel_registerName("alloc")), "init");
	so(body, sel_registerName("setObject:forKey:"), apps, nsstr("apps"));
	id err = 0;
	id (*js)(Class, SEL, id, NSInteger, id *) = (id(*)(Class, SEL, id, NSInteger, id *))objc_msgSend;
	id data = js(objc_getClass("NSJSONSerialization"), sel_registerName("dataWithJSONObject:options:error:"), body, 0, &err);
	id url = msg1(objc_getClass("NSURL"), "URLWithString:", nsstr("https://velorabestweak.com/api/store/contribute"));
	id req = msg0(al(objc_getClass("NSMutableURLRequest"), sel_registerName("alloc")), "init");
	if (req && url)
		msg1(req, "setURL:", url);
	if (req)
		msg1(req, "setHTTPMethod:", nsstr("POST"));
	if (req && data) {
		void (*sb)(id, SEL, id) = (void (*)(id, SEL, id))objc_msgSend;
		sb(req, sel_registerName("setHTTPBody:"), data);
		msg2(req, "setValue:forHTTPHeaderField:", nsstr("application/json"), nsstr("Content-Type"));
	}
	id resp = 0, e2 = 0;
	id (*send)(Class, SEL, id, id *, id *) = (id(*)(Class, SEL, id, id *, id *))objc_msgSend;
	if (req)
		send(objc_getClass("NSURLConnection"), sel_registerName("sendSynchronousRequest:returningResponse:error:"), req, &resp, &e2);
}

static id fetch_json(id urlstr) {
	id url = msg1(objc_getClass("NSURL"), "URLWithString:", urlstr);
	if (!url)
		return 0;
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	id req = msg0(al(objc_getClass("NSMutableURLRequest"), sel_registerName("alloc")), "init");
	if (!req)
		return 0;
	msg1(req, "setURL:", url);
	msg1(req, "setHTTPMethod:", nsstr("GET"));
	id (*sv)(id, SEL, id, id) = (id(*)(id, SEL, id, id))objc_msgSend;
	sv(req, sel_registerName("setValue:forHTTPHeaderField:"), nsstr("Mozilla/5.0"), nsstr("User-Agent"));
	sv(req, sel_registerName("setValue:forHTTPHeaderField:"), nsstr("application/json"), nsstr("Accept"));
	id resp = 0, err = 0;
	id (*send)(Class, SEL, id, id *, id *) = (id(*)(Class, SEL, id, id *, id *))objc_msgSend;
	id data = send(objc_getClass("NSURLConnection"), sel_registerName("sendSynchronousRequest:returningResponse:error:"),
		req, &resp, &err);
	if (!data)
		return 0;
	id (*js)(Class, SEL, id, NSInteger, id *) = (id(*)(Class, SEL, id, NSInteger, id *))objc_msgSend;
	id err2 = 0;
	return js(objc_getClass("NSJSONSerialization"), sel_registerName("JSONObjectWithData:options:error:"), data, 0, &err2);
}

static id ma(void) {
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	return msg0(al(objc_getClass("NSMutableArray"), sel_registerName("alloc")), "init");
}

static id md(void) {
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	return msg0(al(objc_getClass("NSMutableDictionary"), sel_registerName("alloc")), "init");
}

static int same_str(id a, id b) {
	if (!a || !b)
		return 0;
	unsigned char (*eq)(id, SEL, id) = (unsigned char (*)(id, SEL, id))objc_msgSend;
	return eq(a, sel_registerName("isEqualToString:"), b) ? 1 : 0;
}

static int same_ver_str(id a, id b) {
	int pa[8], pb[8];
	int na = 0, nb = 0, n, i, cur, any;
	const char *x = cstr(str_from_id(a));
	const char *y = cstr(str_from_id(b));
	const char *p;
	if (!x[0] || !y[0])
		return 0;
	if (same_str(str_from_id(a), str_from_id(b)))
		return 1;
	cur = 0;
	any = 0;
	p = x;
	while (*p && na < 8) {
		if (*p >= '0' && *p <= '9') {
			cur = cur * 10 + (*p - '0');
			any = 1;
			p++;
			continue;
		}
		if (any) {
			pa[na++] = cur;
			cur = 0;
			any = 0;
		}
		p++;
	}
	if (any && na < 8)
		pa[na++] = cur;
	cur = 0;
	any = 0;
	p = y;
	while (*p && nb < 8) {
		if (*p >= '0' && *p <= '9') {
			cur = cur * 10 + (*p - '0');
			any = 1;
			p++;
			continue;
		}
		if (any) {
			pb[nb++] = cur;
			cur = 0;
			any = 0;
		}
		p++;
	}
	if (any && nb < 8)
		pb[nb++] = cur;
	if (na < 1 || nb < 1)
		return 0;
	n = na > nb ? na : nb;
	for (i = 0; i < n; i++) {
		int va = i < na ? pa[i] : 0;
		int vb = i < nb ? pb[i] : 0;
		if (va != vb)
			return 0;
	}
	return 1;
}

static int same_ver_stem(id a, id b) {
	int pa[3] = {0, 0, 0};
	int pb[3] = {0, 0, 0};
	int na = 0, nb = 0;
	const char *x = cstr(str_from_id(a));
	const char *y = cstr(str_from_id(b));
	int n = 0;
	while (*x && na < 3) {
		if (*x < '0' || *x > '9') {
			if (n) {
				pa[na++] = n;
				n = 0;
			}
			x++;
			continue;
		}
		n = n * 10 + (*x - '0');
		x++;
	}
	if (n && na < 3)
		pa[na++] = n;
	n = 0;
	while (*y && nb < 3) {
		if (*y < '0' || *y > '9') {
			if (n) {
				pb[nb++] = n;
				n = 0;
			}
			y++;
			continue;
		}
		n = n * 10 + (*y - '0');
		y++;
	}
	if (n && nb < 3)
		pb[nb++] = n;
	if (na < 1 || nb < 1)
		return 0;
	if (na == 1 || nb == 1)
		return na == nb && pa[0] == pb[0];
	int i, cap = na < nb ? na : nb;
	if (cap > 3)
		cap = 3;
	for (i = 0; i < cap; i++)
		if (pa[i] != pb[i])
			return 0;
	return 1;
}

static id format_date(id raw);

static void merge_row(id dest, id row) {
	if (!dest || !row)
		return;
	id ver = msg1(row, "objectForKey:", nsstr("version"));
	id ext = msg1(row, "objectForKey:", nsstr("externalId"));
	if (!ver && !ext)
		return;
	NSInteger n = ncount(dest);
	for (NSInteger i = 0; i < n; i++) {
		id have = nobj(dest, i);
		id he = have ? msg1(have, "objectForKey:", nsstr("externalId")) : 0;
		id hv = have ? msg1(have, "objectForKey:", nsstr("version")) : 0;
		int hit = 0;
		if (is_digits_id(ext) && is_digits_id(he) && same_str(str_from_id(he), str_from_id(ext)))
			hit = 1;
		else if (is_digits_id(ext) && !is_digits_id(he) && ver && (same_str(hv, ver) || same_ver_str(hv, ver)))
			hit = 1;
		else if (!is_digits_id(ext) && ver && (same_str(hv, ver) || same_ver_str(hv, ver)))
			hit = 1;
		if (!hit)
			continue;
		if (ext && cstr(str_from_id(ext))[0] && !(he && cstr(str_from_id(he))[0]) && responds(have, "setObject:forKey:"))
			msg2(have, "setObject:forKey:", ext, nsstr("externalId"));
		id build = msg1(row, "objectForKey:", nsstr("build"));
		id hb = msg1(have, "objectForKey:", nsstr("build"));
		if (build && cstr(str_from_id(build))[0] && !(hb && cstr(str_from_id(hb))[0]) && responds(have, "setObject:forKey:"))
			msg2(have, "setObject:forKey:", build, nsstr("build"));
		id date = format_date(msg1(row, "objectForKey:", nsstr("date")));
		if (!date)
			date = msg1(row, "objectForKey:", nsstr("date"));
		id hd = msg1(have, "objectForKey:", nsstr("date"));
		id hd_iso = format_date(hd);
		if (date && cstr(str_from_id(date))[0] && !hd_iso && responds(have, "setObject:forKey:"))
			msg2(have, "setObject:forKey:", date, nsstr("date"));
		return;
	}
	id copy = responds(row, "mutableCopy") ? msg0(row, "mutableCopy") : row;
	id iso = format_date(copy ? msg1(copy, "objectForKey:", nsstr("date")) : 0);
	if (iso && copy && responds(copy, "setObject:forKey:"))
		msg2(copy, "setObject:forKey:", iso, nsstr("date"));
	msg1(dest, "addObject:", copy ? copy : row);
}

static void fill_missing_dates(id dest) {
	NSInteger n = ncount(dest);
	for (NSInteger i = 0; i < n; i++) {
		id row = nobj(dest, i);
		id hd = row ? msg1(row, "objectForKey:", nsstr("date")) : 0;
		if (format_date(hd))
			continue;
		id hv = row ? msg1(row, "objectForKey:", nsstr("version")) : 0;
		id best = 0;
		for (NSInteger j = 0; j < n; j++) {
			id other = nobj(dest, j);
			id od = other ? msg1(other, "objectForKey:", nsstr("date")) : 0;
			if (!format_date(od))
				continue;
			id ov = other ? msg1(other, "objectForKey:", nsstr("version")) : 0;
			if (same_str(hv, ov) || same_ver_str(hv, ov)) {
				best = od;
				break;
			}
			if (!best && same_ver_stem(hv, ov))
				best = od;
		}
		if (best && row && responds(row, "setObject:forKey:")) {
			id iso = format_date(best);
			msg2(row, "setObject:forKey:", iso ? iso : best, nsstr("date"));
		}
	}
}

static void merge_rows(id dest, id src) {
	NSInteger n = ncount(src);
	for (NSInteger i = 0; i < n; i++)
		merge_row(dest, nobj(src, i));
}

static id qimai_rows(id track) {
	id idstr = str_from_id(track);
	if (!idstr || !cstr(idstr)[0])
		return 0;
	char url[300];
	int n = 0;
	const char *base = "https://api.qimai.cn/app/version?appid=";
	while (base[n]) {
		url[n] = base[n];
		n++;
	}
	const char *idc = cstr(idstr);
	int i = 0;
	while (idc[i] && n < 260)
		url[n++] = idc[i++];
	const char *tail = "&country=us";
	i = 0;
	while (tail[i] && n < 290)
		url[n++] = tail[i++];
	url[n] = 0;
	id json = fetch_json(nsstr(url));
	id list = json ? msg1(json, "objectForKey:", nsstr("version")) : 0;
	if (!ncount(list))
		return 0;
	id out = ma();
	NSInteger c = ncount(list);
	for (NSInteger k = 0; k < c; k++) {
		id rec = nobj(list, k);
		id ver = rec ? msg1(rec, "objectForKey:", nsstr("version")) : 0;
		if (!ver)
			continue;
		id row = md();
		msg2(row, "setObject:forKey:", ver, nsstr("version"));
		id date = msg1(rec, "objectForKey:", nsstr("release_time"));
		if (!date)
			date = msg1(rec, "objectForKey:", nsstr("release_date"));
		if (date)
			msg2(row, "setObject:forKey:", date, nsstr("date"));
		id notes = msg1(rec, "objectForKey:", nsstr("release_note"));
		if (notes)
			msg2(row, "setObject:forKey:", notes, nsstr("notes"));
		msg2(row, "setObject:forKey:", nsstr(""), nsstr("externalId"));
		msg1(out, "addObject:", row);
	}
	return out;
}

static id enders_rows(id track) {
	id idstr = str_from_id(track);
	if (!idstr || !cstr(idstr)[0])
		return 0;
	const char *regions[] = {"us", "gb", "tr", "en", "de", 0};
	for (int r = 0; regions[r]; r++) {
		char url[420];
		int n = 0;
		const char *a = "https://cdn.jsdelivr.net/gh/enderspearl184/app-versions@main/app_data/";
		while (a[n]) {
			url[n] = a[n];
			n++;
		}
		const char *reg = regions[r];
		int i = 0;
		while (reg[i])
			url[n++] = reg[i++];
		url[n++] = '/';
		const char *idc = cstr(idstr);
		i = 0;
		while (idc[i] && n < 400)
			url[n++] = idc[i++];
		const char *z = ".json";
		i = 0;
		while (z[i])
			url[n++] = z[i++];
		url[n] = 0;
		id arr = fetch_json(nsstr(url));
		if (!ncount(arr))
			continue;
		id out = ma();
		NSInteger c = ncount(arr);
		for (NSInteger k = c - 1; k >= 0; k--) {
			id rec = nobj(arr, k);
			id ver = rec ? msg1(rec, "objectForKey:", nsstr("version_name")) : 0;
			id ext = rec ? msg1(rec, "objectForKey:", nsstr("version_id")) : 0;
			if (!ver)
				continue;
			id row = md();
			msg2(row, "setObject:forKey:", ver, nsstr("version"));
			if (ext)
				msg2(row, "setObject:forKey:", str_from_id(ext), nsstr("externalId"));
			id date = msg1(rec, "objectForKey:", nsstr("version_date"));
			if (date && cstr(str_from_id(date))[0])
				msg2(row, "setObject:forKey:", date, nsstr("date"));
			msg1(out, "addObject:", row);
		}
		if (ncount(out))
			return out;
	}
	return 0;
}

static id fetch_text(id urlstr) {
	id url = msg1(objc_getClass("NSURL"), "URLWithString:", urlstr);
	if (!url)
		return 0;
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	id req = msg0(al(objc_getClass("NSMutableURLRequest"), sel_registerName("alloc")), "init");
	if (!req)
		return 0;
	msg1(req, "setURL:", url);
	msg1(req, "setHTTPMethod:", nsstr("GET"));
	id (*sv)(id, SEL, id, id) = (id(*)(id, SEL, id, id))objc_msgSend;
	sv(req, sel_registerName("setValue:forHTTPHeaderField:"), nsstr("Mozilla/5.0"), nsstr("User-Agent"));
	sv(req, sel_registerName("setValue:forHTTPHeaderField:"), nsstr("text/html"), nsstr("Accept"));
	id resp = 0, err = 0;
	id (*send)(Class, SEL, id, id *, id *) = (id(*)(Class, SEL, id, id *, id *))objc_msgSend;
	id data = send(objc_getClass("NSURLConnection"), sel_registerName("sendSynchronousRequest:returningResponse:error:"),
		req, &resp, &err);
	if (!data)
		return 0;
	id obj = al(objc_getClass("NSString"), sel_registerName("alloc"));
	id (*initd)(id, SEL, id, unsigned long) = (id(*)(id, SEL, id, unsigned long))objc_msgSend;
	return initd(obj, sel_registerName("initWithData:encoding:"), data, 4);
}

static id itunes_rows(id track) {
	id idstr = str_from_id(track);
	if (!idstr || !cstr(idstr)[0])
		return 0;
	char url[220];
	int n = 0;
	const char *base = "https://itunes.apple.com/lookup?id=";
	while (base[n]) {
		url[n] = base[n];
		n++;
	}
	const char *idc = cstr(idstr);
	int i = 0;
	while (idc[i] && n < 180)
		url[n++] = idc[i++];
	const char *tail = "&entity=software";
	i = 0;
	while (tail[i])
		url[n++] = tail[i++];
	url[n] = 0;
	id json = fetch_json(nsstr(url));
	id results = json ? msg1(json, "objectForKey:", nsstr("results")) : 0;
	id rec = ncount(results) ? nobj(results, 0) : 0;
	if (!rec)
		return 0;
	id ver = msg1(rec, "objectForKey:", nsstr("version"));
	if (!ver)
		return 0;
	id out = ma();
	id row = md();
	msg2(row, "setObject:forKey:", ver, nsstr("version"));
	id date = msg1(rec, "objectForKey:", nsstr("currentVersionReleaseDate"));
	if (date)
		msg2(row, "setObject:forKey:", date, nsstr("date"));
	id build = msg1(rec, "objectForKey:", nsstr("bundleVersion"));
	if (build)
		msg2(row, "setObject:forKey:", str_from_id(build), nsstr("build"));
	msg1(out, "addObject:", row);
	return out;
}

static id arm_rows(id track) {
	id idstr = str_from_id(track);
	if (!idstr || !cstr(idstr)[0])
		return 0;
	char url[280];
	int n = 0;
	const char *base = "https://armconverter.com/decryptedappstore/versions/";
	while (base[n]) {
		url[n] = base[n];
		n++;
	}
	const char *idc = cstr(idstr);
	while (*idc && n < 220)
		url[n++] = *idc++;
	const char *tail = "/0?country=us";
	while (*tail && n < 270)
		url[n++] = *tail++;
	url[n] = 0;
	id nsurl = msg1(objc_getClass("NSURL"), "URLWithString:", nsstr(url));
	if (!nsurl)
		return 0;
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	id req = msg0(al(objc_getClass("NSMutableURLRequest"), sel_registerName("alloc")), "init");
	if (!req)
		return 0;
	msg1(req, "setURL:", nsurl);
	msg1(req, "setHTTPMethod:", nsstr("POST"));
	arm_req_headers(req);
	id resp = 0, err = 0;
	id (*send)(Class, SEL, id, id *, id *) = (id(*)(Class, SEL, id, id *, id *))objc_msgSend;
	id data = send(objc_getClass("NSURLConnection"), sel_registerName("sendSynchronousRequest:returningResponse:error:"), req, &resp, &err);
	if (!data)
		return 0;
	id jsonerr = 0;
	id (*js)(Class, SEL, id, NSInteger, id *) = (id(*)(Class, SEL, id, NSInteger, id *))objc_msgSend;
	id obj = js(objc_getClass("NSJSONSerialization"), sel_registerName("JSONObjectWithData:options:error:"), data, 0, &jsonerr);
	id list = obj && responds(obj, "objectForKey:") ? msg1(obj, "objectForKey:", nsstr("versions")) : 0;
	if (!list)
		return 0;
	id out = ma();
	NSInteger c = ncount(list);
	for (NSInteger i = 0; i < c && i < 80; i++) {
		id rec = nobj(list, i);
		if (!rec || !responds(rec, "objectForKey:"))
			continue;
		id ver = rec ? msg1(rec, "objectForKey:", nsstr("ver")) : 0;
		if (!ver)
			ver = msg1(rec, "objectForKey:", nsstr("shortVer"));
		if (!ver)
			ver = msg1(rec, "objectForKey:", nsstr("version"));
		if (!ver || !cstr(str_from_id(ver))[0] || cstr(str_from_id(ver))[0] == '.')
			continue;
		id row = md();
		msg2(row, "setObject:forKey:", str_from_id(ver), nsstr("version"));
		id vid = rec ? msg1(rec, "objectForKey:", nsstr("verId")) : 0;
		if (!is_digits_id(vid))
			vid = rec ? msg1(rec, "objectForKey:", nsstr("versionId")) : 0;
		if (!is_digits_id(vid))
			vid = rec ? msg1(rec, "objectForKey:", nsstr("externalId")) : 0;
		if (is_digits_id(vid))
			msg2(row, "setObject:forKey:", str_from_id(vid), nsstr("externalId"));
		msg1(out, "addObject:", row);
	}
	return ncount(out) ? out : 0;
}

static id proxy_item_id(id proxy) {
	if (responds(proxy, "itemID"))
		return msg0(proxy, "itemID");
	if (responds(proxy, "storeItemIdentifier"))
		return msg0(proxy, "storeItemIdentifier");
	return 0;
}

static id str_from_id(id v) {
	if (!v)
		return nsstr("");
	Class S = objc_getClass("NSString");
	if (S) {
		unsigned char (*ik)(id, SEL, Class) = (unsigned char (*)(id, SEL, Class))objc_msgSend;
		if (ik(v, sel_registerName("isKindOfClass:"), S))
			return v;
	}
	if (responds(v, "stringValue")) {
		id s = msg0(v, "stringValue");
		if (s)
			return s;
	}
	if (responds(v, "description"))
		return msg0(v, "description");
	return nsstr("");
}

static int is_digits_id(id v) {
	const char *c = cstr(str_from_id(v));
	int n = 0;
	if (!c[0])
		return 0;
	for (; *c; c++) {
		if (*c < '0' || *c > '9')
			return 0;
		n++;
	}
	return n >= 5;
}

static int is_apple_ext(id v) {
	const char *c = cstr(str_from_id(v));
	int n = 0;
	if (!c[0])
		return 0;
	for (; *c; c++) {
		if (*c < '0' || *c > '9')
			return 0;
		n++;
	}
	return n >= 8;
}

static int text_has(id s, id q) {
	if (!q || !cstr(str_from_id(q))[0])
		return 1;
	if (!s)
		return 0;
	if (responds(s, "localizedCaseInsensitiveContainsString:")) {
		unsigned char (*c)(id, SEL, id) = (unsigned char (*)(id, SEL, id))objc_msgSend;
		return c(s, sel_registerName("localizedCaseInsensitiveContainsString:"), str_from_id(q)) ? 1 : 0;
	}
	const char *h = cstr(str_from_id(s));
	const char *n = cstr(str_from_id(q));
	int i, j;
	for (i = 0; h[i]; i++) {
		for (j = 0; n[j]; j++) {
			char a = h[i + j];
			char b = n[j];
			if (a >= 'A' && a <= 'Z')
				a = (char)(a + 32);
			if (b >= 'A' && b <= 'Z')
				b = (char)(b + 32);
			if (!a || a != b)
				break;
		}
		if (!n[j])
			return 1;
	}
	return 0;
}

static void list_clear(id self) {
	Ivar iv = spec_ivar(self);
	if (iv)
		object_setIvar(self, iv, 0);
	if (responds(self, "reloadSpecifiers"))
		msg0(self, "reloadSpecifiers");
}

static void list_loaded(id self, SEL sel) {
	struct objc_super s = { self, objc_getClass("PSListController") };
	((void (*)(struct objc_super *, SEL))objc_msgSendSuper)(&s, sel);
	Class SB = objc_getClass("UISearchBar");
	if (!SB)
		return;
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	id bar = msg0(al(SB, sel_registerName("alloc")), "init");
	if (!bar)
		return;
	if (responds(bar, "setDelegate:"))
		msg1(bar, "setDelegate:", self);
	if (responds(bar, "setPlaceholder:"))
		msg1(bar, "setPlaceholder:", nsstr("Search name or bundle"));
	if (responds(bar, "setShowsCancelButton:")) {
		void (*sc)(id, SEL, unsigned char) = (void (*)(id, SEL, unsigned char))objc_msgSend;
		sc(bar, sel_registerName("setShowsCancelButton:"), 1);
	}
	if (responds(bar, "setAutocapitalizationType:")) {
		void (*sa)(id, SEL, NSInteger) = (void (*)(id, SEL, NSInteger))objc_msgSend;
		sa(bar, sel_registerName("setAutocapitalizationType:"), 0);
	}
	id cur = objc_getAssociatedObject(self, &kFilter);
	if (cur && responds(bar, "setText:"))
		msg1(bar, "setText:", cur);
	if (responds(bar, "sizeToFit"))
		msg0(bar, "sizeToFit");
	id tv = 0;
	if (responds(self, "table"))
		tv = msg0(self, "table");
	if (!tv && responds(self, "tableView"))
		tv = msg0(self, "tableView");
	if (tv && responds(tv, "setTableHeaderView:"))
		msg1(tv, "setTableHeaderView:", bar);
}

static void search_changed(id self, SEL sel, id bar, id text) {
	(void)sel;
	(void)bar;
	objc_setAssociatedObject(self, &kFilter, text ? str_from_id(text) : nsstr(""), OBJC_ASSOCIATION_RETAIN);
	list_clear(self);
}

static void search_done(id self, SEL sel, id bar) {
	(void)sel;
	(void)self;
	if (bar && responds(bar, "resignFirstResponder"))
		msg0(bar, "resignFirstResponder");
}

static id list_specifiers(id self, SEL sel) {
	(void)sel;
	Ivar iv = spec_ivar(self);
	id specs = iv ? object_getIvar(self, iv) : 0;
	if (specs)
		return specs;
	specs = retained_array();
	msg1(specs, "addObject:", group_spec("Installed App Store apps"));
	Class LS = objc_getClass("LSApplicationWorkspace");
	id ws = LS ? cls0(LS, "defaultWorkspace") : 0;
	id all = 0;
	if (ws && responds(ws, "allInstalledApplications"))
		all = msg0(ws, "allInstalledApplications");
	if (!all && ws)
		all = msg0(ws, "allApplications");
	Class hist = objc_getClass("VeloraHistoryController");
	id q = objc_getAssociatedObject(self, &kFilter);
	id names = retained_array();
	id cells = retained_array();
	NSInteger n = ncount(all);
	for (NSInteger i = 0; i < n; i++) {
		id proxy = nobj(all, i);
		id item = proxy_item_id(proxy);
		if (!item || !is_digits_id(item))
			continue;
		id name = responds(proxy, "localizedName") ? msg0(proxy, "localizedName") : 0;
		id bid = responds(proxy, "bundleIdentifier") ? msg0(proxy, "bundleIdentifier") : 0;
		if (!name)
			name = bid;
		if (!text_has(name, q) && !text_has(bid, q))
			continue;
		id spec = named_spec(self, name, 1, 0, 0, hist);
		if (!spec)
			continue;
		id (*nb)(Class, SEL, unsigned char) = (id(*)(Class, SEL, unsigned char))objc_msgSend;
		setprop(spec, nb(objc_getClass("NSNumber"), sel_registerName("numberWithBool:"), 1), "isController");
		setprop(spec, str_from_id(item), "trackId");
		if (name)
			setprop(spec, name, "appName");
		if (bid)
			setprop(spec, bid, "bundleId");
		id ver = responds(proxy, "shortVersionString") ? msg0(proxy, "shortVersionString") : 0;
		if (ver) {
			setprop(spec, ver, "footerText");
			setprop(spec, ver, "installedVersion");
		}
		if (responds(proxy, "bundleURL")) {
			id burl = msg0(proxy, "bundleURL");
			id parentu = burl ? msg0(burl, "URLByDeletingLastPathComponent") : 0;
			id pth = parentu ? msg0(parentu, "path") : 0;
			id metafile = pth ? msg1(pth, "stringByAppendingPathComponent:", nsstr("iTunesMetadata.plist")) : 0;
			if (metafile) {
				id (*dc)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
				id meta = dc(objc_getClass("NSDictionary"), sel_registerName("dictionaryWithContentsOfFile:"), metafile);
				if (meta) {
					id ext = msg1(meta, "objectForKey:", nsstr("softwareVersionExternalIdentifier"));
					if (ext)
						setprop(spec, str_from_id(ext), "versionId");
				}
			}
		}
		msg1(names, "addObject:", name ? name : nsstr(""));
		msg1(cells, "addObject:", spec);
	}
	NSInteger m = ncount(names);
	for (NSInteger i = 1; i < m; i++) {
		NSInteger j = i;
		while (j > 0) {
			id a = nobj(names, j - 1);
			id b = nobj(names, j);
			NSInteger (*cmp)(id, SEL, id) = (NSInteger (*)(id, SEL, id))objc_msgSend;
			NSInteger r = 0;
			if (a && b && responds(a, "localizedCaseInsensitiveCompare:"))
				r = cmp(a, sel_registerName("localizedCaseInsensitiveCompare:"), b);
			if (r <= 0)
				break;
			if (responds(names, "exchangeObjectAtIndex:withObjectAtIndex:")) {
				void (*ex)(id, SEL, NSInteger, NSInteger) = (void (*)(id, SEL, NSInteger, NSInteger))objc_msgSend;
				ex(names, sel_registerName("exchangeObjectAtIndex:withObjectAtIndex:"), j - 1, j);
				ex(cells, sel_registerName("exchangeObjectAtIndex:withObjectAtIndex:"), j - 1, j);
			}
			j--;
		}
	}
	for (NSInteger i = 0; i < m; i++)
		msg1(specs, "addObject:", nobj(cells, i));
	if (ncount(specs) < 2) {
		id empty = named_spec(self, nsstr("No App Store apps found"), 7, 0, 0, 0);
		if (empty)
			msg1(specs, "addObject:", empty);
	}
	if (iv)
		object_setIvar(self, iv, specs);
	return specs;
}

static void open_store(id self, SEL sel) {
	(void)sel;
	id spec = responds(self, "specifier") ? msg0(self, "specifier") : 0;
	id track = 0;
	if (spec && responds(spec, "propertyForKey:"))
		track = msg1(spec, "propertyForKey:", nsstr("trackId"));
	if (!track)
		track = objc_getAssociatedObject(self, &kPayload);
	id json = objc_getAssociatedObject(self, &kPayload);
	if (json && responds(json, "objectForKey:")) {
		id t = msg1(json, "objectForKey:", nsstr("trackId"));
		if (t)
			track = t;
	}
	const char *idstr = cstr(str_from_id(track));
	if (!idstr[0])
		return;
	char buf[160];
	/* itms-apps */
	int n = 0;
	const char *pre = "itms-apps://itunes.apple.com/app/id";
	while (pre[n] && n < 120) {
		buf[n] = pre[n];
		n++;
	}
	int i = 0;
	while (idstr[i] && n < 150) {
		buf[n++] = idstr[i++];
	}
	buf[n] = 0;
	id url = msg1(objc_getClass("NSURL"), "URLWithString:", nsstr(buf));
	id app = cls0(objc_getClass("UIApplication"), "sharedApplication");
	if (app && url && responds(app, "openURL:"))
		msg1(app, "openURL:", url);
}

static id hz_defs(void) {
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	id obj = al(objc_getClass("NSUserDefaults"), sel_registerName("alloc"));
	id (*init)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
	return init(obj, sel_registerName("initWithSuiteName:"), nsstr("com.velora.hz"));
}

static void queue_fetch(id adam) {
	if (!adam)
		return;
	id defs = hz_defs();
	if (!defs)
		return;
	void (*so)(id, SEL, id, id) = (void (*)(id, SEL, id, id))objc_msgSend;
	so(defs, sel_registerName("setObject:forKey:"), str_from_id(adam), nsstr("dlFetchAdam"));
	msg0(defs, "synchronize");
	CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(), nsstr("com.velora.hz.fetch"), 0, 0, 1);
	notify_post("com.velora.hz.fetch");
}

static void queue_download(id adam, id ext, id ver) {
	velora_arm_download(adam, ext, ver);
}

static void begin_install(id self, id spec);
static void begin_install_appstore(id self, id spec);
static void begin_install_troll(id self, id spec);

static int month_token(const char *c) {
	if (!c || !c[0] || !c[1] || !c[2])
		return 0;
	char a = c[0] | 32, b = c[1] | 32, d = c[2] | 32;
	const char *n = "janfebmaraprmayjunjulaugsepoctnovdec";
	int i;
	for (i = 0; i < 12; i++) {
		if (a == n[i * 3] && b == n[i * 3 + 1] && d == n[i * 3 + 2])
			return i + 1;
	}
	return 0;
}

static int parse_ver_nums(id v, int *out, int cap) {
	const char *x = cstr(str_from_id(v));
	int n = 0, cur = 0, any = 0;
	while (*x && n < cap) {
		if (*x >= '0' && *x <= '9') {
			cur = cur * 10 + (*x - '0');
			any = 1;
			x++;
			continue;
		}
		if (any) {
			out[n++] = cur;
			cur = 0;
			any = 0;
		}
		x++;
	}
	if (any && n < cap)
		out[n++] = cur;
	return n;
}

static long long digits_ll(id v) {
	const char *c = cstr(str_from_id(v));
	long long n = 0;
	int any = 0;
	for (; *c; c++) {
		if (*c < '0' || *c > '9') {
			if (any)
				break;
			continue;
		}
		any = 1;
		n = n * 10 + (*c - '0');
	}
	return any ? n : 0;
}

static id format_date(id raw) {
	id s = str_from_id(raw);
	const char *c = cstr(s);
	if (!c[0])
		return 0;
	int y = 0, m = 0, d = 0, i = 0;
	if (c[0] && c[1] && c[2] && c[3] && c[4] == '-' && c[5] && c[6] && c[7] == '-' && c[8] && c[9]
		&& c[0] >= '0' && c[0] <= '9') {
		y = (c[0] - '0') * 1000 + (c[1] - '0') * 100 + (c[2] - '0') * 10 + (c[3] - '0');
		m = (c[5] - '0') * 10 + (c[6] - '0');
		d = (c[8] - '0') * 10 + (c[9] - '0');
	}
	if (!y && c[0] >= '0' && c[0] <= '9') {
		int digits = 0;
		long long ts = 0;
		while (c[digits] >= '0' && c[digits] <= '9') {
			ts = ts * 10 + (c[digits] - '0');
			digits++;
		}
		if (digits >= 10 && digits <= 13 && c[digits] == 0) {
			if (digits >= 13)
				ts = ts / 1000;
			if (ts > 1199145600LL && ts < 2082758400LL) {
				long long z = ts / 86400 + 719468;
				long long era = (z >= 0 ? z : z - 146096) / 146097;
				unsigned doe = (unsigned)(z - era * 146097);
				unsigned yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
				int yy = (int)(yoe + era * 400);
				unsigned doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
				unsigned mp = (5 * doy + 2) / 153;
				unsigned dd = doy - (153 * mp + 2) / 5 + 1;
				unsigned mm = mp < 10 ? mp + 3 : mp - 9;
				if (mm <= 2)
					yy += 1;
				y = yy;
				m = (int)mm;
				d = (int)dd;
			}
		}
	}
	if (!y) {
		int mo = 0, year = 0, day = 0;
		for (i = 0; c[i]; i++) {
			int tok = month_token(c + i);
			if (tok)
				mo = tok;
			if (c[i] < '0' || c[i] > '9')
				continue;
			int n = 0, len = 0;
			while (c[i] >= '0' && c[i] <= '9') {
				n = n * 10 + (c[i] - '0');
				i++;
				len++;
			}
			i--;
			if (len == 4 && n >= 2008 && n <= 2035)
				year = n;
			else if (len <= 2 && n >= 1 && n <= 31 && !day)
				day = n;
		}
		if (mo && year && day) {
			y = year;
			m = mo;
			d = day;
		}
	}
	if (!y) {
		i = 0;
		while (c[i] && (c[i] < '0' || c[i] > '9'))
			i++;
		while (c[i] >= '0' && c[i] <= '9')
			y = y * 10 + (c[i++] - '0');
		if (y < 2008 || y > 2035)
			return 0;
		while (c[i] && (c[i] < '0' || c[i] > '9'))
			i++;
		while (c[i] >= '0' && c[i] <= '9')
			m = m * 10 + (c[i++] - '0');
		while (c[i] && (c[i] < '0' || c[i] > '9'))
			i++;
		while (c[i] >= '0' && c[i] <= '9')
			d = d * 10 + (c[i++] - '0');
	}
	if (y < 2008 || y > 2035 || m < 1 || m > 12 || d < 1 || d > 31)
		return 0;
	char buf[12];
	buf[0] = '0' + (y / 1000);
	buf[1] = '0' + ((y / 100) % 10);
	buf[2] = '0' + ((y / 10) % 10);
	buf[3] = '0' + (y % 10);
	buf[4] = '-';
	buf[5] = '0' + (m / 10);
	buf[6] = '0' + (m % 10);
	buf[7] = '-';
	buf[8] = '0' + (d / 10);
	buf[9] = '0' + (d % 10);
	buf[10] = 0;
	return nsstr(buf);
}

static int date_ymd(id raw) {
	id s = format_date(raw);
	const char *c = cstr(s);
	if (!c[0] || c[4] != '-' || c[7] != '-')
		return 0;
	return (c[0] - '0') * 10000000 + (c[1] - '0') * 1000000 + (c[2] - '0') * 100000 + (c[3] - '0') * 10000
		+ (c[5] - '0') * 1000 + (c[6] - '0') * 100 + (c[8] - '0') * 10 + (c[9] - '0');
}

static int row_is_newer(id a, id b) {
	int pa[8], pb[8];
	int na = parse_ver_nums(a ? msg1(a, "objectForKey:", nsstr("version")) : 0, pa, 8);
	int nb = parse_ver_nums(b ? msg1(b, "objectForKey:", nsstr("version")) : 0, pb, 8);
	int n = na > nb ? na : nb;
	int i;
	for (i = 0; i < n; i++) {
		int va = i < na ? pa[i] : 0;
		int vb = i < nb ? pb[i] : 0;
		if (va != vb)
			return va > vb;
	}
	long long ea = digits_ll(a ? msg1(a, "objectForKey:", nsstr("externalId")) : 0);
	long long eb = digits_ll(b ? msg1(b, "objectForKey:", nsstr("externalId")) : 0);
	if (ea != eb)
		return ea > eb;
	int da = date_ymd(a ? msg1(a, "objectForKey:", nsstr("date")) : 0);
	int db = date_ymd(b ? msg1(b, "objectForKey:", nsstr("date")) : 0);
	if (da != db)
		return da > db;
	return 0;
}

static void sort_version_rows(id arr) {
	if (!arr || !responds(arr, "exchangeObjectAtIndex:withObjectAtIndex:"))
		return;
	NSInteger n = ncount(arr);
	NSInteger i, j;
	void (*ex)(id, SEL, NSInteger, NSInteger) = (void (*)(id, SEL, NSInteger, NSInteger))objc_msgSend;
	for (i = 0; i < n; i++) {
		for (j = i + 1; j < n; j++) {
			id a = nobj(arr, i);
			id b = nobj(arr, j);
			if (row_is_newer(b, a))
				ex(arr, sel_registerName("exchangeObjectAtIndex:withObjectAtIndex:"), i, j);
		}
	}
}

static void normalize_row_dates(id dest) {
	NSInteger n = ncount(dest);
	NSInteger i;
	for (i = 0; i < n; i++) {
		id row = nobj(dest, i);
		if (!row || !responds(row, "setObject:forKey:"))
			continue;
		id iso = format_date(msg1(row, "objectForKey:", nsstr("date")));
		if (iso)
			msg2(row, "setObject:forKey:", iso, nsstr("date"));
	}
}

static int lang_tr(void) {
	id langs = cls0(objc_getClass("NSLocale"), "preferredLanguages");
	const char *s = (langs && ncount(langs)) ? cstr(nobj(langs, 0)) : "";
	char a = s[0], b = s[1];
	if (a >= 'A' && a <= 'Z')
		a = (char)(a + 32);
	if (b >= 'A' && b <= 'Z')
		b = (char)(b + 32);
	return a == 't' && b == 'r';
}

static id loc(const char *en, const char *tr) {
	return nsstr(lang_tr() ? tr : en);
}

static int is_main_thread(void) {
	Class T = objc_getClass("NSThread");
	if (!T)
		return 1;
	unsigned char (*im)(Class, SEL) = (unsigned char (*)(Class, SEL))objc_msgSend;
	return im(T, sel_registerName("isMainThread")) ? 1 : 0;
}

static id gInstallVC;
static id gJobAdam;
static id gJobExt;
static id gJobVer;
static id gJobName;
static id gJobCurrent;
static void finish_appstore(id self, SEL sel);
static void finish_troll(id self, SEL sel);

static void go_queue(void *q, void (*fn)(void *), void *ctx) {
	void *async_f = dlsym(RTLD_DEFAULT, "dispatch_async_f");
	if (async_f && q) {
		typedef void (*daf_t)(void *, void *, void (*)(void *));
		((daf_t)async_f)(q, ctx, fn);
		return;
	}
	fn(ctx);
}

static void go_bg(void (*fn)(void *), void *ctx) {
	void *(*gq)(long, unsigned long) = (void *(*)(long, unsigned long))dlsym(RTLD_DEFAULT, "dispatch_get_global_queue");
	go_queue(gq ? gq(0, 0) : 0, fn, ctx);
}

static void go_main(void (*fn)(void *), void *ctx) {
	go_queue(dlsym(RTLD_DEFAULT, "_dispatch_main_q"), fn, ctx);
}

static void finish_appstore_main(void *ctx) {
	(void)ctx;
	if (gInstallVC)
		finish_appstore(gInstallVC, 0);
}

static void finish_troll_main(void *ctx) {
	(void)ctx;
	if (gInstallVC)
		finish_troll(gInstallVC, 0);
}

static char kLiveAlert;
static id gWatch;
static char kWatchVC;
static char kWatchBid;
static char kWatchAdam;
static char kWatchPrev;
static char kWatchTitle;
static int gDoneShown;
static int gWatchArmed;
static int gLivePct;
static void set_live_message(id self, id text);
static int alert_is_up(id self);
static void note_progress(id proxy);

static int gAlertClosed;
static int gFlushTries;
static id gFlushVC;
static id gFlushTitle;
static id gFlushMsg;
static void flush_alert_now(void *ctx);
static void later(const char *sel, double delay);

static int vc_flag(id obj, const char *sel) {
	if (!obj || !responds(obj, sel))
		return 0;
	unsigned char (*ib)(id, SEL) = (unsigned char (*)(id, SEL))objc_msgSend;
	return ib(obj, sel_registerName(sel)) ? 1 : 0;
}

static int vc_busy(id vc) {
	id shown;
	if (!vc)
		return 1;
	if (vc_flag(vc, "isBeingPresented") || vc_flag(vc, "isBeingDismissed"))
		return 1;
	if (!responds(vc, "presentedViewController"))
		return 0;
	shown = msg0(vc, "presentedViewController");
	if (!shown)
		return 0;
	return vc_flag(shown, "isBeingPresented") || vc_flag(shown, "isBeingDismissed");
}

static id presenter_for(id self) {
	(void)self;
	return self;
}

static void alert_will_disappear(id self, SEL sel, unsigned char animated) {
	struct objc_super s;
	gAlertClosed = 1;
	s.receiver = self;
	s.super_class = objc_getClass("UIAlertController");
	if (s.super_class)
		((void (*)(struct objc_super *, SEL, unsigned char))objc_msgSendSuper)(&s, sel, animated);
}

static Class live_alert_cls(void) {
	Class C = objc_getClass("VeloraLiveAlert");
	Class super;
	if (C)
		return C;
	super = objc_getClass("UIAlertController");
	if (!super)
		return 0;
	C = objc_allocateClassPair(super, "VeloraLiveAlert", 0);
	if (!C)
		return super;
	class_addMethod(C, sel_registerName("viewWillDisappear:"), (IMP)alert_will_disappear, "v@:c");
	objc_registerClassPair(C);
	return C;
}

static int bounce_main(id self, SEL sel, id arg) {
	if (is_main_thread())
		return 0;
	if (!self || !responds(self, "performSelectorOnMainThread:withObject:waitUntilDone:"))
		return 0;
	{
		void (*p)(id, SEL, SEL, id, unsigned char) = (void (*)(id, SEL, SEL, id, unsigned char))objc_msgSend;
		p(self, sel_registerName("performSelectorOnMainThread:withObject:waitUntilDone:"), sel, arg, 0);
	}
	return 1;
}

static void alert_ok_invoke(void *block, void *action) {
	(void)block;
	(void)action;
	gAlertClosed = 1;
}

static struct {
	unsigned long reserved;
	unsigned long size;
	const char *signature;
} gAlertOkDesc = { 0, 40, "v16@?0@8" };

static struct {
	void *isa;
	int flags;
	int reserved;
	void (*invoke)(void *, void *);
	void *descriptor;
} gAlertOkBlock;

static id alert_ok_block(void) {
	if (!gAlertOkBlock.isa) {
		void *isa = dlsym(RTLD_DEFAULT, "_NSConcreteGlobalBlock");
		if (!isa)
			return 0;
		gAlertOkDesc.size = sizeof(gAlertOkBlock);
		gAlertOkBlock.isa = isa;
		gAlertOkBlock.flags = (1 << 28) | (1 << 30);
		gAlertOkBlock.reserved = 0;
		gAlertOkBlock.invoke = alert_ok_invoke;
		gAlertOkBlock.descriptor = &gAlertOkDesc;
	}
	return gAlertOkBlock.isa ? (id)&gAlertOkBlock : 0;
}

static void show_alert(id self, const char *title, id detail) {
	Class AC;
	id titleS, msgS, a, host, shown, old;
	id (*mk)(Class, SEL, id, id, NSInteger);
	if (!self)
		return;
	if (!is_main_thread()) {
		gFlushVC = self;
		gFlushTitle = nsstr(title && title[0] ? title : "Velora");
		gFlushMsg = detail ? str_from_id(detail) : nsstr("");
		go_main(flush_alert_now, 0);
		return;
	}
	old = objc_getAssociatedObject(self, &kLiveAlert);
	if (old && alert_is_up(self)) {
		set_live_message(self, detail ? str_from_id(detail) : nsstr(""));
		return;
	}
	if (vc_busy(self) || (old && (vc_flag(old, "isBeingPresented") || vc_flag(old, "isBeingDismissed")))) {
		if (gFlushTries > 8)
			return;
		gFlushTries++;
		gFlushVC = self;
		gFlushTitle = nsstr(title && title[0] ? title : "Velora");
		gFlushMsg = detail ? str_from_id(detail) : nsstr("");
		later("flushAlert", 0.4);
		return;
	}
	shown = responds(self, "presentedViewController") ? msg0(self, "presentedViewController") : 0;
	if (shown && shown != old)
		return;
	if (shown) {
		set_live_message(self, detail ? str_from_id(detail) : nsstr(""));
		return;
	}
	AC = live_alert_cls();
	if (!AC)
		AC = objc_getClass("UIAlertController");
	if (!AC)
		return;
	titleS = nsstr(title && title[0] ? title : "Velora");
	msgS = detail ? str_from_id(detail) : nsstr("");
	if (!msgS)
		msgS = nsstr("");
	mk = (id(*)(Class, SEL, id, id, NSInteger))objc_msgSend;
	a = mk(AC, sel_registerName("alertControllerWithTitle:message:preferredStyle:"),
		titleS, msgS, (NSInteger)1);
	if (!a) {
		id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
		a = msg0(al(AC, sel_registerName("alloc")), "init");
	}
	if (!a)
		return;
	if (responds(a, "setTitle:"))
		msg1(a, "setTitle:", titleS);
	if (responds(a, "setMessage:"))
		msg1(a, "setMessage:", msgS);
	Class AA = objc_getClass("UIAlertAction");
	if (AA) {
		id (*act)(Class, SEL, id, NSInteger, id) =
			(id(*)(Class, SEL, id, NSInteger, id))objc_msgSend;
		id ok = act(AA, sel_registerName("actionWithTitle:style:handler:"), loc("OK", "Tamam"), 0, alert_ok_block());
		if (ok)
			msg1(a, "addAction:", ok);
	}
	objc_setAssociatedObject(self, &kLiveAlert, a, OBJC_ASSOCIATION_RETAIN);
	gAlertClosed = 0;
	gFlushTries = 0;
	host = presenter_for(self);
	if (!host)
		host = self;
	if (responds(host, "presentViewController:animated:completion:")) {
		void (*pr)(id, SEL, id, unsigned char, id) = (void (*)(id, SEL, id, unsigned char, id))objc_msgSend;
		pr(host, sel_registerName("presentViewController:animated:completion:"), a, 1, 0);
	}
}

static int alert_is_up(id self) {
	id a = self ? objc_getAssociatedObject(self, &kLiveAlert) : 0;
	if (!a)
		return 0;
	if (vc_flag(a, "isBeingDismissed")) {
		gAlertClosed = 1;
		return 0;
	}
	if (responds(a, "presentingViewController") && msg0(a, "presentingViewController") && !vc_flag(a, "isBeingDismissed"))
		return 1;
	if (vc_flag(a, "isBeingPresented"))
		return 1;
	return 0;
}

static void show_or_update(id self, const char *title, id detail) {
	if (!self)
		return;
	if (!is_main_thread()) {
		gFlushVC = self;
		gFlushTitle = nsstr(title && title[0] ? title : "Velora");
		gFlushMsg = detail ? str_from_id(detail) : nsstr("");
		go_main(flush_alert_now, 0);
		return;
	}
	if (alert_is_up(self)) {
		set_live_message(self, detail);
		return;
	}
	if (gAlertClosed)
		return;
	if (vc_busy(self))
		return;
	show_alert(self, title, detail);
}

static void flush_alert_now(void *ctx) {
	id vc = gFlushVC;
	id title = gFlushTitle;
	id msg = gFlushMsg;
	(void)ctx;
	if (!vc)
		return;
	show_or_update(vc, cstr(title), msg);
}

static void runner_flush(id self, SEL sel) {
	(void)self;
	(void)sel;
	flush_alert_now(0);
}

static id progress_copy(int p) {
	if (p < 0)
		p = 0;
	if (p > 99)
		p = 99;
	char buf[48];
	int n = 0;
	const char *pre = lang_tr() ? "Indiriliyor " : "Downloading ";
	while (*pre)
		buf[n++] = *pre++;
	if (p >= 10)
		buf[n++] = (char)('0' + (p / 10));
	buf[n++] = (char)('0' + (p % 10));
	buf[n++] = '%';
	buf[n] = 0;
	return nsstr(buf);
}

static void set_live_message(id self, id text) {
	id a;
	if (!self || !text)
		return;
	a = objc_getAssociatedObject(self, &kLiveAlert);
	if (!a)
		return;
	if (vc_flag(a, "isBeingDismissed")) {
		gAlertClosed = 1;
		return;
	}
	if (vc_flag(a, "isBeingPresented"))
		return;
	if (responds(a, "presentingViewController") && !msg0(a, "presentingViewController"))
		return;
	if (a && responds(a, "setMessage:"))
		msg1(a, "setMessage:", str_from_id(text));
}

static id installed_ver(id bid) {
	if (!bid || !cstr(str_from_id(bid))[0])
		return 0;
	Class P = objc_getClass("LSApplicationProxy");
	if (!P)
		return 0;
	id (*fn)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
	id proxy = 0;
	if (responds((id)P, "applicationProxyForIdentifier:"))
		proxy = fn(P, sel_registerName("applicationProxyForIdentifier:"), str_from_id(bid));
	if (!proxy)
		return 0;
	id v = responds(proxy, "shortVersionString") ? msg0(proxy, "shortVersionString") : 0;
	if (!v)
		v = responds(proxy, "bundleVersion") ? msg0(proxy, "bundleVersion") : 0;
	return v;
}

static int proxy_matches(id proxy, id bid, id adam) {
	if (!proxy)
		return 0;
	if (bid && cstr(str_from_id(bid))[0]) {
		id b = responds(proxy, "bundleIdentifier") ? msg0(proxy, "bundleIdentifier") : 0;
		if (same_str(str_from_id(b), str_from_id(bid)))
			return 1;
	}
	if (adam && cstr(str_from_id(adam))[0] && responds(proxy, "itemID")) {
		id n = msg0(proxy, "itemID");
		if (same_str(str_from_id(n), str_from_id(adam)))
			return 1;
	}
	return 0;
}

static void announce_done(id self, SEL sel);

static void fire_done(void) {
	if (gDoneShown)
		return;
	id vc = gWatch ? objc_getAssociatedObject(gWatch, &kWatchVC) : 0;
	if (!vc)
		return;
	if (!is_main_thread()) {
		if (gWatch && responds(gWatch, "performSelectorOnMainThread:withObject:waitUntilDone:")) {
			void (*p)(id, SEL, SEL, id, unsigned char) = (void (*)(id, SEL, SEL, id, unsigned char))objc_msgSend;
			p(gWatch, sel_registerName("performSelectorOnMainThread:withObject:waitUntilDone:"), sel_registerName("announce"), 0, 0);
		}
		return;
	}
	gDoneShown = 1;
	gWatchArmed = 0;
	id title = objc_getAssociatedObject(gWatch, &kWatchTitle);
	show_or_update(vc, cstr(str_from_id(title)), loc("Download finished.", "Indirme bitti."));
}

static void announce_done(id self, SEL sel) {
	(void)self;
	(void)sel;
	fire_done();
}

static void watch_tick(id self, SEL sel) {
	if (bounce_main(self, sel, 0))
		return;
	(void)sel;
	if (!gWatchArmed || gDoneShown)
		return;
	{
		id vc = objc_getAssociatedObject(self, &kWatchVC);
		id err = velora_last_error();
		if (vc && err && cstr(str_from_id(err))[0]) {
			gDoneShown = 1;
			gWatchArmed = 0;
			show_or_update(vc, "App Store", err);
			return;
		}
	}
	id bid = objc_getAssociatedObject(self, &kWatchBid);
	Class P = objc_getClass("LSApplicationProxy");
	if (P && bid && cstr(str_from_id(bid))[0] && responds((id)P, "applicationProxyForIdentifier:")) {
		id (*fn)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
		id proxy = fn(P, sel_registerName("applicationProxyForIdentifier:"), str_from_id(bid));
		if (proxy)
			note_progress(proxy);
	}
	if (gDoneShown)
		return;
	id prev = objc_getAssociatedObject(self, &kWatchPrev);
	id now = installed_ver(bid);
	if (!now || !prev || !cstr(str_from_id(prev))[0])
		return;
	if (!same_str(str_from_id(now), str_from_id(prev)) && !same_ver_str(now, prev))
		fire_done();
}

static void note_progress(id proxy) {
	id vc = gWatch ? objc_getAssociatedObject(gWatch, &kWatchVC) : 0;
	if (!vc || !proxy)
		return;
	id title = objc_getAssociatedObject(gWatch, &kWatchTitle);
	const char *t = cstr(str_from_id(title));
	if (!t[0])
		t = "App Store";
	double frac = -1;
	if (responds(proxy, "installProgress")) {
		id prog = msg0(proxy, "installProgress");
		if (prog && responds(prog, "fractionCompleted")) {
			double (*dv)(id, SEL) = (double (*)(id, SEL))objc_msgSend;
			frac = dv(prog, sel_registerName("fractionCompleted"));
		}
	}
	if (frac >= 0.999) {
		fire_done();
		return;
	}
	int p = 0;
	if (frac > 0)
		p = (int)(frac * 100.0 + 0.5);
	if (p > 99)
		p = 99;
	if (!alert_is_up(vc) && objc_getAssociatedObject(vc, &kLiveAlert))
		gAlertClosed = 1;
	if (gAlertClosed)
		return;
	if (p <= 0) {
		if (gLivePct > 0)
			return;
		if (gLivePct == 0)
			return;
		gLivePct = 0;
		show_or_update(vc, t, loc("Waiting for the download to start.", "Indirme baslamasi bekleniyor."));
		return;
	}
	if (p == gLivePct)
		return;
	gLivePct = p;
	show_or_update(vc, t, progress_copy(p));
}

static void apps_did_install(id self, SEL sel, id apps) {
	if (bounce_main(self, sel, apps))
		return;
	(void)sel;
	if (!gWatchArmed || gDoneShown)
		return;
	id bid = objc_getAssociatedObject(self, &kWatchBid);
	id adam = objc_getAssociatedObject(self, &kWatchAdam);
	NSInteger n = ncount(apps);
	for (NSInteger i = 0; i < n; i++) {
		if (proxy_matches(nobj(apps, i), bid, adam)) {
			fire_done();
			return;
		}
	}
}

static void installs_did_change(id self, SEL sel, id apps) {
	if (bounce_main(self, sel, apps))
		return;
	(void)sel;
	if (!gWatchArmed || gDoneShown)
		return;
	id bid = objc_getAssociatedObject(self, &kWatchBid);
	id adam = objc_getAssociatedObject(self, &kWatchAdam);
	NSInteger n = ncount(apps);
	for (NSInteger i = 0; i < n; i++) {
		id p = nobj(apps, i);
		if (!proxy_matches(p, bid, adam))
			continue;
		note_progress(p);
		return;
	}
}

static void apps_did_fail(id self, SEL sel, id apps) {
	if (bounce_main(self, sel, apps))
		return;
	(void)sel;
	(void)apps;
	if (!gWatchArmed || gDoneShown)
		return;
	id vc = objc_getAssociatedObject(self, &kWatchVC);
	if (!vc)
		return;
	gDoneShown = 1;
	gWatchArmed = 0;
	id title = objc_getAssociatedObject(self, &kWatchTitle);
	show_or_update(vc, cstr(str_from_id(title)), loc("Download failed.", "Indirme basarisiz."));
}

static void apps_will_install(id self, SEL sel, id apps) {
	if (bounce_main(self, sel, apps))
		return;
	(void)sel;
	if (!gWatchArmed || gDoneShown)
		return;
	id bid = objc_getAssociatedObject(self, &kWatchBid);
	id adam = objc_getAssociatedObject(self, &kWatchAdam);
	NSInteger n = ncount(apps);
	for (NSInteger i = 0; i < n; i++) {
		id p = nobj(apps, i);
		if (!proxy_matches(p, bid, adam))
			continue;
		note_progress(p);
		return;
	}
}

static void ensure_watch(void) {
	if (gWatch)
		return;
	Class C = objc_getClass("VeloraInstallWatch");
	if (!C) {
		Class super = objc_getClass("NSObject");
		if (!super)
			return;
		C = objc_allocateClassPair(super, "VeloraInstallWatch", 0);
		if (!C)
			return;
		class_addMethod(C, sel_registerName("applicationsDidInstall:"), (IMP)apps_did_install, "v@:@");
		class_addMethod(C, sel_registerName("applicationInstallsDidChange:"), (IMP)installs_did_change, "v@:@");
		class_addMethod(C, sel_registerName("applicationsDidFailToInstall:"), (IMP)apps_did_fail, "v@:@");
		class_addMethod(C, sel_registerName("applicationsWillInstall:"), (IMP)apps_will_install, "v@:@");
		class_addMethod(C, sel_registerName("announce"), (IMP)announce_done, "v@:");
		class_addMethod(C, sel_registerName("tick"), (IMP)watch_tick, "v@:");
		objc_registerClassPair(C);
	}
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	gWatch = msg0(al(C, sel_registerName("alloc")), "init");
	Class LS = objc_getClass("LSApplicationWorkspace");
	id ws = LS ? cls0(LS, "defaultWorkspace") : 0;
	if (gWatch && ws && responds(ws, "addObserver:"))
		msg1(ws, "addObserver:", gWatch);
}

static void arm_install_watch(id self, id spec, const char *title) {
	ensure_watch();
	if (!gWatch)
		return;
	gDoneShown = 0;
	gWatchArmed = 1;
	gLivePct = -1;
	objc_setAssociatedObject(gWatch, &kWatchVC, self, OBJC_ASSOCIATION_RETAIN);
	objc_setAssociatedObject(gWatch, &kWatchTitle, nsstr(title && title[0] ? title : "Velora"), OBJC_ASSOCIATION_RETAIN);
	id bid = 0, adam = 0;
	if (spec && responds(spec, "propertyForKey:")) {
		bid = msg1(spec, "propertyForKey:", nsstr("bundleId"));
		adam = msg1(spec, "propertyForKey:", nsstr("adamId"));
		if (!adam)
			adam = msg1(spec, "propertyForKey:", nsstr("trackId"));
	}
	objc_setAssociatedObject(gWatch, &kWatchBid, str_from_id(bid), OBJC_ASSOCIATION_RETAIN);
	objc_setAssociatedObject(gWatch, &kWatchAdam, str_from_id(adam), OBJC_ASSOCIATION_RETAIN);
	objc_setAssociatedObject(gWatch, &kWatchPrev, installed_ver(bid), OBJC_ASSOCIATION_RETAIN);
	if (responds(gWatch, "performSelector:withObject:afterDelay:")) {
		void (*d)(id, SEL, SEL, id, double) = (void (*)(id, SEL, SEL, id, double))objc_msgSend;
		d(gWatch, sel_registerName("performSelector:withObject:afterDelay:"), sel_registerName("tick"), 0, 2.0);
		d(gWatch, sel_registerName("performSelector:withObject:afterDelay:"), sel_registerName("tick"), 0, 6.0);
		d(gWatch, sel_registerName("performSelector:withObject:afterDelay:"), sel_registerName("tick"), 0, 14.0);
		d(gWatch, sel_registerName("performSelector:withObject:afterDelay:"), sel_registerName("tick"), 0, 28.0);
	}
}

static void show_install_picker(id self, id spec) {
	if (!self || !spec)
		return;
	objc_setAssociatedObject(self, &kPendingSpec, spec, OBJC_ASSOCIATION_RETAIN);
	Class MC = objc_getClass("VeloraInstallMethodController");
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	id vc = MC ? msg0(al(MC, sel_registerName("alloc")), "init") : 0;
	if (!vc)
		return;
	if (responds(vc, "setSpecifier:"))
		msg1(vc, "setSpecifier:", spec);
	objc_setAssociatedObject(vc, &kPendingSpec, spec, OBJC_ASSOCIATION_RETAIN);
	id payload = objc_getAssociatedObject(self, &kPayload);
	if (payload)
		objc_setAssociatedObject(vc, &kPayload, payload, OBJC_ASSOCIATION_RETAIN);
	id nav = responds(self, "navigationController") ? msg0(self, "navigationController") : 0;
	if (!nav && responds(self, "parentViewController")) {
		id parent = msg0(self, "parentViewController");
		if (parent && responds(parent, "navigationController"))
			nav = msg0(parent, "navigationController");
	}
	if (nav && responds(nav, "pushViewController:animated:")) {
		void (*pv)(id, SEL, id, unsigned char) = (void (*)(id, SEL, id, unsigned char))objc_msgSend;
		pv(nav, sel_registerName("pushViewController:animated:"), vc, 1);
		return;
	}
	if (responds(self, "showController:")) {
		msg1(self, "showController:", vc);
		return;
	}
	if (responds(self, "pushController:animate:")) {
		void (*pc)(id, SEL, id, unsigned char) = (void (*)(id, SEL, id, unsigned char))objc_msgSend;
		pc(self, sel_registerName("pushController:animate:"), vc, 1);
	}
}

static void alert_clicked(id self, SEL sel, id alert, NSInteger idx) {
	(void)sel;
	(void)alert;
	id spec = objc_getAssociatedObject(self, &kPendingSpec);
	if (idx == 1)
		begin_install_appstore(self, spec);
	else if (idx == 2)
		begin_install_troll(self, spec);
}

static void copy_ids(id dest, id src) {
	if (!dest || !src || !responds(src, "propertyForKey:"))
		return;
	id adam = msg1(src, "propertyForKey:", nsstr("adamId"));
	if (!adam)
		adam = msg1(src, "propertyForKey:", nsstr("trackId"));
	id ext = msg1(src, "propertyForKey:", nsstr("versionId"));
	id ver = msg1(src, "propertyForKey:", nsstr("version"));
	id bid = msg1(src, "propertyForKey:", nsstr("bundleId"));
	if (adam && cstr(str_from_id(adam))[0])
		setprop(dest, str_from_id(adam), "adamId");
	if (is_apple_ext(ext))
		setprop(dest, str_from_id(ext), "versionId");
	if (ver)
		setprop(dest, str_from_id(ver), "version");
	if (bid)
		setprop(dest, str_from_id(bid), "bundleId");
	id name = msg1(src, "propertyForKey:", nsstr("appName"));
	if (name)
		setprop(dest, str_from_id(name), "appName");
}

static id take_digits(id a, id b) {
	if (is_apple_ext(a))
		return str_from_id(a);
	if (is_apple_ext(b))
		return str_from_id(b);
	return 0;
}

static void fill_from_json(id json, id ver, id *adam, id *ext) {
	if (!json)
		return;
	if ((!*adam || !cstr(str_from_id(*adam))[0]) && responds(json, "objectForKey:")) {
		id t = msg1(json, "objectForKey:", nsstr("trackId"));
		if (t && cstr(str_from_id(t))[0])
			*adam = str_from_id(t);
	}
	if (*ext && is_apple_ext(*ext))
		return;
	id vers = responds(json, "objectForKey:") ? msg1(json, "objectForKey:", nsstr("versions")) : 0;
	NSInteger n = ncount(vers);
	for (NSInteger i = 0; i < n; i++) {
		id row = nobj(vers, i);
		id rv = row ? msg1(row, "objectForKey:", nsstr("version")) : 0;
		if (!same_str(rv, ver) && !same_ver_str(rv, ver))
			continue;
		id rid = take_digits(msg1(row, "objectForKey:", nsstr("externalId")), 0);
		if (!rid)
			rid = take_digits(msg1(row, "objectForKey:", nsstr("versionId")), 0);
		if (!rid)
			rid = take_digits(msg1(row, "objectForKey:", nsstr("verId")), 0);
		if (rid) {
			*ext = rid;
			return;
		}
	}
}

static int spec_is_app_row(id s) {
	id inst, ver;
	if (!s || !responds(s, "propertyForKey:"))
		return 0;
	inst = msg1(s, "propertyForKey:", nsstr("installedVersion"));
	ver = msg1(s, "propertyForKey:", nsstr("version"));
	return inst && cstr(str_from_id(inst))[0] && !(ver && cstr(str_from_id(ver))[0]);
}

static int gather_ids(id self, id spec, id *adam, id *ext, id *ver) {
	*adam = 0;
	*ext = 0;
	*ver = 0;
	id json = objc_getAssociatedObject(self, &kPayload);
	id parent = responds(self, "specifier") ? msg0(self, "specifier") : 0;
	id pending = objc_getAssociatedObject(self, &kPendingSpec);
	id srcs[4];
	srcs[0] = spec;
	srcs[1] = parent;
	srcs[2] = pending;
	srcs[3] = 0;
	for (int i = 0; i < 3; i++) {
		id s = srcs[i];
		if (!s || !responds(s, "propertyForKey:"))
			continue;
		if (!*adam) {
			*adam = msg1(s, "propertyForKey:", nsstr("adamId"));
			if (!*adam)
				*adam = msg1(s, "propertyForKey:", nsstr("trackId"));
		}
		if (spec_is_app_row(s))
			continue;
		if (!*ext) {
			id cand = msg1(s, "propertyForKey:", nsstr("versionId"));
			if (is_apple_ext(cand))
				*ext = cand;
		}
		if (!*ver)
			*ver = msg1(s, "propertyForKey:", nsstr("version"));
	}
	fill_from_json(json, *ver, adam, ext);
	if (!is_apple_ext(*ext))
		*ext = 0;
	return *adam && cstr(str_from_id(*adam))[0] ? 1 : 0;
}

static void finish_appstore(id self, SEL sel) {
	(void)sel;
	id err = velora_last_error();
	if (err && cstr(str_from_id(err))[0]) {
		show_or_update(self, "App Store", err);
		return;
	}
}

static void finish_troll(id self, SEL sel) {
	(void)sel;
	id err = velora_last_error();
	if (err && cstr(str_from_id(err))[0]) {
		show_or_update(self, "TrollStore", err);
		return;
	}
	id url = velora_last_ipa_url();
	if (url && cstr(str_from_id(url))[0]) {
		show_or_update(self, "TrollStore", loc("Opening TrollStore.", "TrollStore aciliyor."));
		velora_open_ipa_in_trollstore(url);
		return;
	}
	show_or_update(self, "TrollStore", loc(
		"No IPA for this build on ARM Store.",
		"ARM Store'da bu surum icin IPA yok."));
}

static void open_troll_later(id self, SEL sel, id url) {
	(void)self;
	(void)sel;
	if (url)
		velora_open_ipa_in_trollstore(url);
}

static void bg_appstore(id self, SEL sel) {
	(void)self;
	(void)sel;
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	Class P = objc_getClass("NSAutoreleasePool");
	id pool = P ? msg0(al(P, sel_registerName("alloc")), "init") : 0;
	id adam = gJobAdam;
	id ext = gJobExt;
	id ver = gJobVer;
	if (gJobName)
		velora_set_app_name(gJobName);
	if (!is_apple_ext(ext))
		ext = velora_resolve_ext(adam, ver);
	velora_set_error(nsstr(""));
	velora_arm_download(adam, ext, ver);
	if (pool)
		msg0(pool, "drain");
	go_main(finish_appstore_main, 0);
}

static void bg_troll(id self, SEL sel) {
	(void)self;
	(void)sel;
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	Class P = objc_getClass("NSAutoreleasePool");
	id pool = P ? msg0(al(P, sel_registerName("alloc")), "init") : 0;
	if (gJobName)
		velora_set_app_name(gJobName);
	velora_arm_troll(gJobAdam, gJobExt, gJobVer);
	velora_run_trollstore();
	if (pool)
		msg0(pool, "drain");
	go_main(finish_troll_main, 0);
}

static void appstore_job(void *ctx) {
	(void)ctx;
	bg_appstore(0, 0);
}

static void troll_job(void *ctx) {
	(void)ctx;
	bg_troll(0, 0);
}

static id gRunner;

static void runner_store(id self, SEL sel) {
	(void)self;
	(void)sel;
	go_bg(appstore_job, 0);
}

static void runner_troll(id self, SEL sel) {
	(void)self;
	(void)sel;
	go_bg(troll_job, 0);
}

static void ensure_runner(void) {
	if (gRunner)
		return;
	Class C = objc_getClass("VeloraJobRunner");
	if (!C) {
		Class super = objc_getClass("NSObject");
		if (!super)
			return;
		C = objc_allocateClassPair(super, "VeloraJobRunner", 0);
		if (!C)
			return;
		class_addMethod(C, sel_registerName("runStore"), (IMP)runner_store, "v@:");
		class_addMethod(C, sel_registerName("runTroll"), (IMP)runner_troll, "v@:");
		class_addMethod(C, sel_registerName("flushAlert"), (IMP)runner_flush, "v@:");
		objc_registerClassPair(C);
	}
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	gRunner = msg0(al(C, sel_registerName("alloc")), "init");
}

static void later(const char *sel, double delay) {
	ensure_runner();
	if (!gRunner)
		return;
	void (*d)(id, SEL, SEL, id, double) = (void (*)(id, SEL, SEL, id, double))objc_msgSend;
	d(gRunner, sel_registerName("performSelector:withObject:afterDelay:"), sel_registerName(sel), 0, delay);
}

static void capture_job(id self, id spec) {
	id adam = 0, ext = 0, ver = 0;
	gather_ids(self, spec, &adam, &ext, &ver);
	gJobAdam = str_from_id(adam);
	gJobExt = is_apple_ext(ext) ? str_from_id(ext) : 0;
	gJobVer = str_from_id(ver);
	id json = objc_getAssociatedObject(self, &kPayload);
	id name = json ? msg1(json, "objectForKey:", nsstr("name")) : 0;
	if (!name && spec && responds(spec, "propertyForKey:"))
		name = msg1(spec, "propertyForKey:", nsstr("appName"));
	gJobName = name ? str_from_id(name) : 0;
	gJobCurrent = json ? str_from_id(msg1(json, "objectForKey:", nsstr("currentVersion"))) : 0;
	gInstallVC = self;
	{
		id bid = json ? msg1(json, "objectForKey:", nsstr("bundleId")) : 0;
		if (!bid && spec && responds(spec, "propertyForKey:"))
			bid = msg1(spec, "propertyForKey:", nsstr("bundleId"));
		if (bid)
			velora_set_bundle_id(str_from_id(bid));
	}
}

static void begin_install_appstore(id self, id spec) {
	id adam = 0, ext = 0, ver = 0;
	if (!gather_ids(self, spec, &adam, &ext, &ver)) {
		show_alert(self, "App Store", loc("This row has no App Store id.", "Bu satirda App Store id yok."));
		return;
	}
	objc_setAssociatedObject(self, &kPendingSpec, spec ? spec : objc_getAssociatedObject(self, &kPendingSpec), OBJC_ASSOCIATION_RETAIN);
	gInstalling = 1;
	gDoneShown = 0;
	gLivePct = -1;
	gAlertClosed = 0;
	cancel_delayed(self);
	capture_job(self, spec);
	if (gJobName)
		velora_set_app_name(gJobName);
	velora_set_error(nsstr(""));
	show_or_update(self, "App Store", loc(
		"Queuing this version with the App Store. Confirm your Apple ID if asked.",
		"Bu surum App Store'a kuyruga aliniyor. Istenirse Apple kimligini onayla."));
	velora_arm_download(gJobAdam, gJobExt, gJobVer);
	arm_install_watch(self, spec, "App Store");
}

static void begin_install_troll(id self, id spec) {
	id adam = 0, ext = 0, ver = 0;
	if (!gather_ids(self, spec, &adam, &ext, &ver)) {
		show_alert(self, "TrollStore", loc("This row has no App Store id.", "Bu satirda App Store id yok."));
		return;
	}
	objc_setAssociatedObject(self, &kPendingSpec, spec ? spec : objc_getAssociatedObject(self, &kPendingSpec), OBJC_ASSOCIATION_RETAIN);
	gInstalling = 1;
	gDoneShown = 0;
	gAlertClosed = 0;
	cancel_delayed(self);
	capture_job(self, spec);
	if (gJobName)
		velora_set_app_name(gJobName);
	velora_set_error(nsstr(""));
	velora_arm_troll(gJobAdam, gJobExt, gJobVer);
	show_or_update(self, "TrollStore", loc(
		"Looking up this version on ARM Store.",
		"Bu surum ARM Store'da araniyor."));
	later("runTroll", 0.2);
}

static void begin_install(id self, id spec) {
	if (!spec || !responds(spec, "propertyForKey:"))
		return;
	show_install_picker(self, spec);
}

static void bg_download(id self, SEL sel) {
	(void)sel;
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	Class P = objc_getClass("NSAutoreleasePool");
	id pool = P ? msg0(al(P, sel_registerName("alloc")), "init") : 0;
	velora_run_download();
	if (pool)
		msg0(pool, "drain");
	(void)self;
}

static void install_version(id self, SEL sel, id spec) {
	(void)sel;
	if (!spec || !responds(spec, "propertyForKey:")) {
		id tv = responds(self, "tableView") ? msg0(self, "tableView") : 0;
		id ip = tv ? msg0(tv, "indexPathForSelectedRow") : 0;
		if (ip && responds(self, "specifierAtIndexPath:"))
			spec = msg1(self, "specifierAtIndexPath:", ip);
	}
	begin_install(self, spec);
}

static void install_version0(id self, SEL sel) {
	id tv = responds(self, "tableView") ? msg0(self, "tableView") : 0;
	id ip = tv ? msg0(tv, "indexPathForSelectedRow") : 0;
	id spec = 0;
	if (ip && responds(self, "specifierAtIndexPath:"))
		spec = msg1(self, "specifierAtIndexPath:", ip);
	if (!spec)
		spec = responds(self, "specifier") ? msg0(self, "specifier") : 0;
	install_version(self, sel, spec);
}

static void history_button(id self, SEL sel, id spec) {
	(void)sel;
	begin_install(self, spec);
}

static char kFetchFlag;
static char kHistSeen;

static void history_apply(id self) {
	Ivar iv = spec_ivar(self);
	if (iv)
		object_setIvar(self, iv, 0);
	if (responds(self, "reloadSpecifiers"))
		msg0(self, "reloadSpecifiers");
}

static void history_bg(id self, SEL sel) {
	(void)sel;
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	Class P = objc_getClass("NSAutoreleasePool");
	id pool = P ? msg0(al(P, sel_registerName("alloc")), "init") : 0;
	id parent = responds(self, "specifier") ? msg0(self, "specifier") : 0;
	id track = parent && responds(parent, "propertyForKey:") ? msg1(parent, "propertyForKey:", nsstr("trackId")) : 0;
	id bid = parent && responds(parent, "propertyForKey:") ? msg1(parent, "propertyForKey:", nsstr("bundleId")) : 0;
	id inst = parent && responds(parent, "propertyForKey:") ? msg1(parent, "propertyForKey:", nsstr("installedVersion")) : 0;
	id ext = parent && responds(parent, "propertyForKey:") ? msg1(parent, "propertyForKey:", nsstr("versionId")) : 0;
	id appn = parent && responds(parent, "propertyForKey:") ? msg1(parent, "propertyForKey:", nsstr("appName")) : 0;
	contribute_one(track, bid, inst, ext);
	queue_fetch(track);
	char url[480];
	const char *base = "https://velorabestweak.com/api/store/lookup?";
	int n = 0;
	while (base[n]) {
		url[n] = base[n];
		n++;
	}
	if (track && cstr(str_from_id(track))[0]) {
		const char *p = "id=";
		int i = 0;
		while (p[i])
			url[n++] = p[i++];
		const char *idstr = cstr(str_from_id(track));
		i = 0;
		while (idstr[i] && n < 300)
			url[n++] = idstr[i++];
	} else if (bid) {
		const char *p = "bundleId=";
		int i = 0;
		while (p[i])
			url[n++] = p[i++];
		const char *b = cstr(bid);
		i = 0;
		while (b[i] && n < 420)
			url[n++] = b[i++];
	}
	if (appn && cstr(appn)[0] && n < 420) {
		const char *p = "&name=";
		int i = 0;
		while (p[i] && n < 430)
			url[n++] = p[i++];
		const char *nm = cstr(appn);
		i = 0;
		while (nm[i] && n < 460) {
			char ch = nm[i++];
			if (ch == ' ')
				url[n++] = '+';
			else
				url[n++] = ch;
		}
	}
	url[n] = 0;
	id json = fetch_json(nsstr(url));
	if (json && responds(json, "mutableCopy"))
		json = msg0(json, "mutableCopy");
	if (!json)
		json = md();
	id merged = ma();
	merge_rows(merged, enders_rows(track));
	merge_rows(merged, qimai_rows(track));
	merge_rows(merged, arm_rows(track));
	merge_rows(merged, itunes_rows(track));
	merge_rows(merged, json ? msg1(json, "objectForKey:", nsstr("versions")) : 0);
	merge_rows(merged, file_cache(track));
	fill_missing_dates(merged);
	normalize_row_dates(merged);
	sort_version_rows(merged);
	if (json && responds(json, "setObject:forKey:")) {
		msg2(json, "setObject:forKey:", merged, nsstr("versions"));
		if (track)
			msg2(json, "setObject:forKey:", str_from_id(track), nsstr("trackId"));
	}
	objc_setAssociatedObject(self, &kPayload, json, OBJC_ASSOCIATION_RETAIN);
	objc_setAssociatedObject(self, &kFetchFlag, nsstr("done"), OBJC_ASSOCIATION_RETAIN);
	if (pool)
		msg0(pool, "drain");
	if (responds(self, "performSelectorOnMainThread:withObject:waitUntilDone:")) {
		void (*pm)(id, SEL, SEL, id, unsigned char) = (void (*)(id, SEL, SEL, id, unsigned char))objc_msgSend;
		pm(self, sel_registerName("performSelectorOnMainThread:withObject:waitUntilDone:"), sel_registerName("fetchAppleVersions"), 0, 0);
	}
}

static void history_fetch_now(id self, SEL sel) {
	(void)sel;
	history_apply(self);
}

static id history_specifiers(id self, SEL sel) {
	(void)sel;
	Ivar iv = spec_ivar(self);
	id specs = iv ? object_getIvar(self, iv) : 0;
	if (specs)
		return specs;
	specs = retained_array();
	id json = objc_getAssociatedObject(self, &kPayload);
	id parent = responds(self, "specifier") ? msg0(self, "specifier") : 0;
	id name = parent && responds(parent, "propertyForKey:") ? msg1(parent, "propertyForKey:", nsstr("label")) : 0;
	if (!name && parent)
		name = msg0(parent, "name");
	msg1(specs, "addObject:", group_spec(name ? cstr(name) : "Versions"));
	if (!json) {
		id wait = named_spec(self, nsstr("Fetching version history…"), 7, 0, 0, 0);
		if (wait)
			msg1(specs, "addObject:", wait);
	} else {
		id current = msg1(json, "objectForKey:", nsstr("currentVersion"));
		id versions = msg1(json, "objectForKey:", nsstr("versions"));
		if (versions && responds(versions, "mutableCopy"))
			versions = msg0(versions, "mutableCopy");
		if (!versions)
			versions = ma();
		id track = json ? msg1(json, "objectForKey:", nsstr("trackId")) : 0;
		id defs = hz_defs();
		if (defs && track) {
			id ck = msg1(nsstr("verCache-"), "stringByAppendingString:", str_from_id(track));
			merge_rows(versions, msg1(defs, "objectForKey:", ck));
		}
		merge_rows(versions, file_cache(track));
		fill_missing_dates(versions);
		normalize_row_dates(versions);
		sort_version_rows(versions);
		id g = group_spec("Current");
		if (current)
			setprop(g, current, "footerText");
		msg1(specs, "addObject:", g);
		id open = action_button(self, nsstr("Open in App Store"), "openStore");
		if (open)
			msg1(specs, "addObject:", open);
		NSInteger n = ncount(versions);
		for (NSInteger i = 0; i < n; i++) {
			id row = nobj(versions, i);
			id ver = msg1(row, "objectForKey:", nsstr("version"));
			id date = format_date(msg1(row, "objectForKey:", nsstr("date")));
			id ext = msg1(row, "objectForKey:", nsstr("externalId"));
			id build = msg1(row, "objectForKey:", nsstr("build"));
			if (!ver)
				continue;
			id bid = 0;
			if (build && cstr(str_from_id(build))[0])
				bid = str_from_id(build);
			else if (ext && cstr(str_from_id(ext))[0])
				bid = str_from_id(ext);
			id foot = 0;
			if (bid && cstr(bid)[0])
				foot = msg1(nsstr("Build "), "stringByAppendingString:", bid);
			if (foot && date && cstr(str_from_id(date))[0]) {
				foot = msg1(foot, "stringByAppendingString:", nsstr(" · "));
				foot = msg1(foot, "stringByAppendingString:", date);
			} else if (!foot && date)
				foot = date;
			id head = group_spec(cstr(str_from_id(ver)));
			if (foot)
				setprop(head, foot, "footerText");
			msg1(specs, "addObject:", head);
			id cell = action_button(self, nsstr("Install"), "installVersion:");
			if (!cell)
				continue;
			if (track)
				setprop(cell, str_from_id(track), "adamId");
			id vid = take_digits(ext, 0);
			if (vid)
				setprop(cell, vid, "versionId");
			setprop(cell, ver, "version");
			id bundle = parent && responds(parent, "propertyForKey:") ? msg1(parent, "propertyForKey:", nsstr("bundleId")) : 0;
			if (bundle)
				setprop(cell, bundle, "bundleId");
			id appn = parent && responds(parent, "propertyForKey:") ? msg1(parent, "propertyForKey:", nsstr("appName")) : 0;
			if (!appn)
				appn = json ? msg1(json, "objectForKey:", nsstr("name")) : 0;
			if (appn)
				setprop(cell, str_from_id(appn), "appName");
			msg1(specs, "addObject:", cell);
		}
		if (n == 0) {
			id none = named_spec(self, nsstr("No history returned"), 7, 0, 0, 0);
			if (none)
				msg1(specs, "addObject:", none);
		}
	}
	if (iv)
		object_setIvar(self, iv, specs);
	id flag = objc_getAssociatedObject(self, &kFetchFlag);
	int busy = flag && same_str(flag, nsstr("busy"));
	if (!json && !busy) {
		objc_setAssociatedObject(self, &kFetchFlag, nsstr("busy"), OBJC_ASSOCIATION_RETAIN);
		Class T = objc_getClass("NSThread");
		if (T) {
			id (*det)(Class, SEL, SEL, id, id) = (id(*)(Class, SEL, SEL, id, id))objc_msgSend;
			det(T, sel_registerName("detachNewThreadSelector:toTarget:withObject:"), sel_registerName("veloraBgFetch"), self, 0);
		}
	}
	return specs;
}

static id file_cache(id adam) {
	id a = str_from_id(adam);
	if (!a || !cstr(a)[0])
		return 0;
	id path = msg1(nsstr("/var/mobile/Library/Caches/com.velora.hz/"), "stringByAppendingString:", a);
	path = msg1(path, "stringByAppendingString:", nsstr(".plist"));
	id (*acf)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
	return acf(objc_getClass("NSArray"), sel_registerName("arrayWithContentsOfFile:"), path);
}

static id method_specifiers(id self, SEL sel) {
	(void)sel;
	Ivar iv = spec_ivar(self);
	id specs = iv ? object_getIvar(self, iv) : 0;
	if (specs)
		return specs;
	specs = retained_array();
	id parent = responds(self, "specifier") ? msg0(self, "specifier") : 0;
	id ver = parent && responds(parent, "propertyForKey:") ? msg1(parent, "propertyForKey:", nsstr("version")) : 0;
	id g = group_spec(ver ? cstr(str_from_id(ver)) : "Install");
	setprop(g, nsstr("App Store downloads this version through Apple. TrollStore opens the ARM Store IPA."), "footerText");
	msg1(specs, "addObject:", g);
	id store = action_button(self, nsstr("App Store"), "installAppStore");
	if (store) {
		setprop(store, nsstr("appstore"), "installMethod");
		copy_ids(store, parent);
		msg1(specs, "addObject:", store);
	}
	id troll = action_button(self, nsstr("TrollStore"), "installTroll");
	if (troll) {
		setprop(troll, nsstr("troll"), "installMethod");
		copy_ids(troll, parent);
		msg1(specs, "addObject:", troll);
	}
	if (iv)
		object_setIvar(self, iv, specs);
	return specs;
}

static void method_store(id self, SEL sel, id spec) {
	(void)sel;
	id parent = responds(self, "specifier") ? msg0(self, "specifier") : 0;
	if (!parent)
		parent = objc_getAssociatedObject(self, &kPendingSpec);
	if (spec && responds(spec, "propertyForKey:") && msg1(spec, "propertyForKey:", nsstr("adamId")))
		parent = spec;
	begin_install_appstore(self, parent);
}

static void method_store0(id self, SEL sel) {
	method_store(self, sel, 0);
}

static void method_troll(id self, SEL sel, id spec) {
	(void)sel;
	id parent = responds(self, "specifier") ? msg0(self, "specifier") : 0;
	if (!parent)
		parent = objc_getAssociatedObject(self, &kPendingSpec);
	if (spec && responds(spec, "propertyForKey:") && msg1(spec, "propertyForKey:", nsstr("adamId")))
		parent = spec;
	begin_install_troll(self, parent);
}

static void method_troll0(id self, SEL sel) {
	method_troll(self, sel, 0);
}

static void method_button(id self, SEL sel, id spec) {
	id method = 0;
	if (spec && responds(spec, "propertyForKey:"))
		method = msg1(spec, "propertyForKey:", nsstr("installMethod"));
	const char *m = cstr(str_from_id(method));
	if (m[0] == 't')
		method_troll(self, sel, spec);
	else
		method_store(self, sel, spec);
}

static void method_button0(id self, SEL sel) {
	method_button(self, sel, 0);
}

static void history_disappear(id self, SEL sel, unsigned char animated) {
	struct objc_super s = { self, objc_getClass("PSListController") };
	((void (*)(struct objc_super *, SEL, unsigned char))objc_msgSendSuper)(&s, sel, animated);
	objc_setAssociatedObject(self, &kHistSeen, nsstr("1"), OBJC_ASSOCIATION_RETAIN);
}

static void history_appear(id self, SEL sel, unsigned char animated) {
	struct objc_super s = { self, objc_getClass("PSListController") };
	((void (*)(struct objc_super *, SEL, unsigned char))objc_msgSendSuper)(&s, sel, animated);
	if (!objc_getAssociatedObject(self, &kHistSeen))
		return;
	if (objc_getAssociatedObject(self, &kPayload))
		return;
	objc_setAssociatedObject(self, &kFetchFlag, 0, OBJC_ASSOCIATION_RETAIN);
	Ivar iv = spec_ivar(self);
	if (iv)
		object_setIvar(self, iv, 0);
	if (responds(self, "reloadSpecifiers"))
		msg0(self, "reloadSpecifiers");
}

void register_velora_versions(void) {
	if (!objc_getClass("PSListController"))
		dlopen("/System/Library/PrivateFrameworks/Preferences.framework/Preferences", RTLD_LAZY);
	Class super = objc_getClass("PSListController");
	if (!super)
		return;
	if (!objc_getClass("VeloraVersionController")) {
		Class cls = objc_allocateClassPair(super, "VeloraVersionController", 0);
		if (cls) {
			class_addMethod(cls, sel_registerName("specifiers"), (IMP)list_specifiers, "@@:");
			class_addMethod(cls, sel_registerName("viewDidLoad"), (IMP)list_loaded, "v@:");
			class_addMethod(cls, sel_registerName("searchBar:textDidChange:"), (IMP)search_changed, "v@:@@");
			class_addMethod(cls, sel_registerName("searchBarSearchButtonClicked:"), (IMP)search_done, "v@:@");
			class_addMethod(cls, sel_registerName("searchBarCancelButtonClicked:"), (IMP)search_done, "v@:@");
			objc_registerClassPair(cls);
		}
	}
	if (!objc_getClass("VeloraHistoryController")) {
		Class cls = objc_allocateClassPair(super, "VeloraHistoryController", 0);
		if (cls) {
			class_addMethod(cls, sel_registerName("specifiers"), (IMP)history_specifiers, "@@:");
			class_addMethod(cls, sel_registerName("fetchAppleVersions"), (IMP)history_fetch_now, "v@:");
			class_addMethod(cls, sel_registerName("openStore"), (IMP)open_store, "v@:");
			class_addMethod(cls, sel_registerName("installVersion:"), (IMP)install_version, "v@:@");
			class_addMethod(cls, sel_registerName("installVersion"), (IMP)install_version0, "v@:");
			class_addMethod(cls, sel_registerName("buttonTapped:"), (IMP)history_button, "v@:@");
			class_addMethod(cls, sel_registerName("veloraBgDownload"), (IMP)bg_download, "v@:");
			class_addMethod(cls, sel_registerName("veloraBgAppStore"), (IMP)bg_appstore, "v@:");
			class_addMethod(cls, sel_registerName("veloraBgTroll"), (IMP)bg_troll, "v@:");
			class_addMethod(cls, sel_registerName("veloraFinishAppStore"), (IMP)finish_appstore, "v@:");
			class_addMethod(cls, sel_registerName("veloraFinishTroll"), (IMP)finish_troll, "v@:");
			class_addMethod(cls, sel_registerName("veloraOpenTroll:"), (IMP)open_troll_later, "v@:@");
			class_addMethod(cls, sel_registerName("veloraBgFetch"), (IMP)history_bg, "v@:");
			class_addMethod(cls, sel_registerName("viewWillAppear:"), (IMP)history_appear, "v@:B");
			class_addMethod(cls, sel_registerName("viewDidDisappear:"), (IMP)history_disappear, "v@:B");
			objc_registerClassPair(cls);
		}
	}
	if (!objc_getClass("VeloraInstallMethodController")) {
		Class cls = objc_allocateClassPair(super, "VeloraInstallMethodController", 0);
		if (cls) {
			class_addMethod(cls, sel_registerName("specifiers"), (IMP)method_specifiers, "@@:");
			class_addMethod(cls, sel_registerName("installAppStore:"), (IMP)method_store, "v@:@");
			class_addMethod(cls, sel_registerName("installAppStore"), (IMP)method_store0, "v@:");
			class_addMethod(cls, sel_registerName("installTroll:"), (IMP)method_troll, "v@:@");
			class_addMethod(cls, sel_registerName("installTroll"), (IMP)method_troll0, "v@:");
			class_addMethod(cls, sel_registerName("buttonTapped:"), (IMP)method_button, "v@:@");
			class_addMethod(cls, sel_registerName("buttonTapped"), (IMP)method_button0, "v@:");
			class_addMethod(cls, sel_registerName("veloraBgDownload"), (IMP)bg_download, "v@:");
			class_addMethod(cls, sel_registerName("veloraBgAppStore"), (IMP)bg_appstore, "v@:");
			class_addMethod(cls, sel_registerName("veloraBgTroll"), (IMP)bg_troll, "v@:");
			class_addMethod(cls, sel_registerName("veloraFinishAppStore"), (IMP)finish_appstore, "v@:");
			class_addMethod(cls, sel_registerName("veloraFinishTroll"), (IMP)finish_troll, "v@:");
			class_addMethod(cls, sel_registerName("veloraOpenTroll:"), (IMP)open_troll_later, "v@:@");
			objc_registerClassPair(cls);
		}
	}
	{
		Class hist = objc_getClass("VeloraHistoryController");
		if (hist) {
			class_addMethod(hist, sel_registerName("veloraBgDownload"), (IMP)bg_download, "v@:");
			class_addMethod(hist, sel_registerName("veloraBgAppStore"), (IMP)bg_appstore, "v@:");
			class_addMethod(hist, sel_registerName("veloraBgTroll"), (IMP)bg_troll, "v@:");
			class_addMethod(hist, sel_registerName("veloraFinishAppStore"), (IMP)finish_appstore, "v@:");
			class_addMethod(hist, sel_registerName("veloraFinishTroll"), (IMP)finish_troll, "v@:");
			class_addMethod(hist, sel_registerName("alertView:clickedButtonAtIndex:"), (IMP)alert_clicked, "v@:@q");
			class_addMethod(hist, sel_registerName("alertView:didDismissWithButtonIndex:"), (IMP)alert_clicked, "v@:@q");
		}
	}
}
