/* Merge NekoJB Rootful into latest Dopamine.

   On Dopamine/NekoJB launch: inject the Rootful switch into
   DOSettingsController, present NekoJB's FakeFS/boot screen, refresh old
   rootful files to palera1n 2.4 (-f/--rootful) at original bundle paths,
   rewrite FakeFS disk0s1s8 → disk0s1s7, and switch Nekoloader/bootstrap
   Sileo+Zebra downloads from rootless to rootful. Never overwrite Dopamine core.
   Not an Update-button hook and not an isolated sidecar layer. */
#include "velora-proc.h"
void *dlopen(const char *path, int mode);
void *dlsym(void *handle, const char *symbol);
#define RTLD_LAZY 1
#define RTLD_NOLOAD 0x10
#define RTLD_DEFAULT ((void *)-2)

typedef struct objc_class *Class;
typedef struct objc_object *id;
typedef struct objc_selector *SEL;
typedef long NSInteger;

struct objc_super {
	id receiver;
	Class super_class;
};

extern Class objc_getClass(const char *name);
extern Class object_getClass(id obj);
extern Class class_getSuperclass(Class cls);
extern SEL sel_registerName(const char *name);
extern void objc_msgSend(void);
extern void objc_msgSendSuper(void);
extern int class_addMethod(Class cls, SEL name, void *imp, const char *types);
extern void *class_getInstanceMethod(Class cls, SEL name);
extern Class objc_allocateClassPair(Class super, const char *name, unsigned long extra);
extern void objc_registerClassPair(Class cls);

typedef void (*MSHookMessageEx_t)(Class cls, SEL sel, void *imp, void **orig);
static MSHookMessageEx_t gHook;

static id gLog;
static id gProg;
static id gCreateBtn;
static id gContBtn;
static id gPendingJb;
static SEL gPendingSel;
static id (*gPendingOrig)(id, SEL);
static int gFakeFSReady;
static int gScreenUp;

static id nsstr(const char *c) {
	id (*f)(Class, SEL, const char *) = (id(*)(Class, SEL, const char *))objc_msgSend;
	return f(objc_getClass("NSString"), sel_registerName("stringWithUTF8String:"), c);
}

static id cls0(Class c, const char *sel) {
	id (*f)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	return c ? f(c, sel_registerName(sel)) : 0;
}

static id msg0(id obj, const char *sel) {
	if (!obj)
		return 0;
	id (*f)(id, SEL) = (id(*)(id, SEL))objc_msgSend;
	return f(obj, sel_registerName(sel));
}

static id msg1(id obj, const char *sel, id a) {
	if (!obj)
		return 0;
	id (*f)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
	return f(obj, sel_registerName(sel), a);
}

static id msg2(id obj, const char *sel, id a, id b) {
	if (!obj)
		return 0;
	id (*f)(id, SEL, id, id) = (id(*)(id, SEL, id, id))objc_msgSend;
	return f(obj, sel_registerName(sel), a, b);
}

static const char *utf8(id s) {
	if (!s)
		return "";
	const char *(*f)(id, SEL) = (const char *(*)(id, SEL))objc_msgSend;
	return f(s, sel_registerName("UTF8String"));
}

static void hook_sel(Class cls, const char *name, void *imp, void **orig) {
	SEL sel;
	if (!gHook || !cls || !name || !imp)
		return;
	if (orig && *orig)
		return;
	sel = sel_registerName(name);
	if (!class_getInstanceMethod(cls, sel))
		return;
	gHook(cls, sel, imp, orig);
}

static id file_mgr(void) {
	return cls0(objc_getClass("NSFileManager"), "defaultManager");
}

static id bundle_path(void) {
	return msg0(cls0(objc_getClass("NSBundle"), "mainBundle"), "bundlePath");
}

static void write_utf8(id path, const char *text) {
	id (*w)(id, SEL, id, unsigned char, unsigned long, id *) = (id(*)(id, SEL, id, unsigned char, unsigned long, id *))objc_msgSend;
	w(nsstr(text), sel_registerName("writeToFile:atomically:encoding:error:"), path, 1, 4, 0);
}

static id join(id dir, const char *name) {
	return msg1(dir, "stringByAppendingPathComponent:", nsstr(name));
}

static id color_rgba(double r, double g, double b, double a) {
	id (*f)(Class, SEL, double, double, double, double) = (id(*)(Class, SEL, double, double, double, double))objc_msgSend;
	return f(objc_getClass("UIColor"), sel_registerName("colorWithRed:green:blue:alpha:"), r, g, b, a);
}

static void set_frame(id view, double x, double y, double w, double h) {
	double r[4];
	id (*nv)(Class, SEL, const void *, const char *);
	id val;
	if (!view)
		return;
	r[0] = x;
	r[1] = y;
	r[2] = w;
	r[3] = h;
	nv = (id(*)(Class, SEL, const void *, const char *))objc_msgSend;
	val = nv(objc_getClass("NSValue"), sel_registerName("valueWithBytes:objCType:"), r, "{CGRect={CGPoint=dd}{CGSize=dd}}");
	if (val)
		msg2(view, "setValue:forKey:", val, nsstr("frame"));
}

static double kvc_double(id obj, const char *path, double fallback) {
	id n;
	double (*dv)(id, SEL);
	double v;
	if (!obj)
		return fallback;
	n = msg1(obj, "valueForKeyPath:", nsstr(path));
	if (!n)
		return fallback;
	dv = (double (*)(id, SEL))objc_msgSend;
	v = dv(n, sel_registerName("doubleValue"));
	return v > 1 ? v : fallback;
}

static int rootful_on(void) {
	id d = msg1(cls0(objc_getClass("NSUserDefaults"), "standardUserDefaults"), "persistentDomainForName:", nsstr("com.velora.hz"));
	id v = d ? msg1(d, "objectForKey:", nsstr("rootfulMode")) : 0;
	unsigned char (*b)(id, SEL);
	if (!v) {
		id (*dcf)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
		id file = dcf(objc_getClass("NSDictionary"), sel_registerName("dictionaryWithContentsOfFile:"), nsstr("/var/mobile/Library/Preferences/com.velora.hz.plist"));
		v = file ? msg1(file, "objectForKey:", nsstr("rootfulMode")) : 0;
	}
	if (!v)
		return 0;
	b = (unsigned char (*)(id, SEL))objc_msgSend;
	return b(v, sel_registerName("boolValue")) ? 1 : 0;
}

static id read_file(id path) {
	id (*rd)(Class, SEL, id, unsigned long, id *) = (id(*)(Class, SEL, id, unsigned long, id *))objc_msgSend;
	return rd(objc_getClass("NSString"), sel_registerName("stringWithContentsOfFile:encoding:error:"), path, 4, 0);
}

static void rewrite_text_file(id path) {
	id existing;
	char *buf;
	unsigned long n = 0;
	const char *src;
	int i;
	int changed = 0;
	if (!path)
		return;
	existing = read_file(path);
	src = utf8(existing);
	if (!src || !src[0])
		return;
	while (src[n])
		n++;
	buf = (char *)((char *(*)(unsigned long))dlsym(RTLD_DEFAULT, "malloc"))(n + 8);
	if (!buf)
		return;
	for (i = 0; src[i]; i++)
		buf[i] = src[i];
	buf[i] = 0;
	if (velora_rewrite_fakefs_disk(buf))
		changed = 1;
	if (changed)
		write_utf8(path, buf);
	((void (*)(void *))dlsym(RTLD_DEFAULT, "free"))(buf);
}

static void rewrite_named_urls(id dest, const char *name) {
	id path = join(dest, name);
	id existing = read_file(path);
	const char *src = utf8(existing);
	id out;
	if (!src || !src[0])
		return;
	out = nsstr(src);
	if (velora_cstr_has(src, "disk0s1s8"))
		out = msg2(out, "stringByReplacingOccurrencesOfString:withString:", nsstr("disk0s1s8"), nsstr("disk0s1s7"));
	if (velora_is_rootless_pm_url(src) || velora_cstr_has(src, "rootless/sileo") || velora_cstr_has(src, "rootless/zebra")) {
		out = msg2(out, "stringByReplacingOccurrencesOfString:withString:", nsstr("https://static.palera.in/rootless/sileo.deb"), nsstr(velora_rootful_sileo_url()));
		out = msg2(out, "stringByReplacingOccurrencesOfString:withString:", nsstr("https://static.palera.in/rootless/zebra.deb"), nsstr(velora_rootful_zebra_url()));
		out = msg2(out, "stringByReplacingOccurrencesOfString:withString:", nsstr("/var/jb/Applications/Sileo.app"), nsstr("/Applications/Sileo.app"));
		out = msg2(out, "stringByReplacingOccurrencesOfString:withString:", nsstr("/var/jb/Applications/Zebra.app"), nsstr("/Applications/Zebra.app"));
	}
	if (velora_is_rootless_bootstrap_url(src) || velora_cstr_has(src, "static.palera.in/rootless/")) {
		out = msg2(out, "stringByReplacingOccurrencesOfString:withString:", nsstr("https://static.palera.in/rootless/bootstrap.tar.zst"), nsstr(velora_rootful_bootstrap_url()));
		out = msg2(out, "stringByReplacingOccurrencesOfString:withString:", nsstr("https://static.palera.in/rootless/"), nsstr("https://static.palera.in/"));
		out = msg2(out, "stringByReplacingOccurrencesOfString:withString:", nsstr("/var/jb/.procursus_strapped"), nsstr("/.procursus_strapped"));
	}
	if (velora_is_rootless_pref_url(src) || velora_cstr_has(src, "rootless/preferenceloader") || velora_cstr_has(src, "/var/jb/Library/Preference")) {
		out = msg2(out, "stringByReplacingOccurrencesOfString:withString:", nsstr("https://static.palera.in/rootless/preferenceloader.deb"), nsstr(velora_rootful_pref_url()));
		out = msg2(out, "stringByReplacingOccurrencesOfString:withString:", nsstr("/var/jb/Library/PreferenceLoader"), nsstr("/Library/PreferenceLoader"));
		out = msg2(out, "stringByReplacingOccurrencesOfString:withString:", nsstr("/var/jb/Library/PreferenceBundles"), nsstr("/Library/PreferenceBundles"));
	}
	write_utf8(path, utf8(out));
	rewrite_text_file(path);
}

static void write_palera1n_native(id dest) {
	id (*cd)(id, SEL, id, unsigned char, id, id *) = (id(*)(id, SEL, id, unsigned char, id, id *))objc_msgSend;
	id mgr = file_mgr();
	if (!dest || !mgr)
		return;
	if (!((unsigned char (*)(id, SEL, id))objc_msgSend)(mgr, sel_registerName("isWritableFileAtPath:"), dest))
		return;
	cd(mgr, sel_registerName("createDirectoryAtPath:withIntermediateDirectories:attributes:error:"), dest, 1, 0, 0);
	write_utf8(join(dest, "palera1n-VERSION"), "2.4\n");
	write_utf8(join(dest, "stamp.json"),
		"{\"source\":\"palera1n\",\"version\":\"2.4\",\"aligned\":\"3.0.0-beta.2\",\"pref\":\"rootfulMode\",\"flag\":\"-f/--rootful\",\"fakefs_disk\":\"disk0s1s7\"}\n");
	write_utf8(join(dest, "rootful.conf"),
		"# palera1n 2.4 rootful merged into Dopamine\n"
		"# -f / --rootful  (renamed from --fakefs)\n"
		"# FakeFS path: /dev/disk0s1s7\n"
		"# --force-enable-ssv for tvOS 18.2+ live-fs rootful\n"
		"rootful_pref=rootfulMode\n"
		"rootful_domain=com.velora.hz\n"
		"jbroot_on=/\n"
		"jbroot_off=/var/jb\n"
		"fakefs_disk=disk0s1s7\n"
		"fakefs_dev=/dev/disk0s1s7\n"
		"fakefs_volume=Xystem\n"
		"fakefs_snapshot=orig-fs\n"
		"bindfs_real=/cores/fs/real\n"
		"bindfs_fake=/cores/fs/fake\n"
		"nvram_rootdev=p1-fakefs-rootdev\n");
	write_utf8(join(dest, "paleinfo.conf"),
		"palerain_option_rootful=1\n"
		"palerain_option_setup_rootful=1\n"
		"palerain_option_setup_partial_root=0\n"
		"force_enable_ssv=0\n"
		"fakefs_disk=disk0s1s7\n"
		"fakefs_dev=/dev/disk0s1s7\n"
		"fakefs_volume=Xystem\n"
		"snapshot=orig-fs\n");
	write_utf8(join(dest, "createFakeFS.sh"),
		"#!/bin/sh\n"
		"# palera1n 2.4 FakeFS helper. Volume Xystem on /dev/disk0s1s7.\n"
		"set -e\n"
		"ON=0\n"
		"if command -v defaults >/dev/null 2>&1; then\n"
		"	VAL=`defaults read com.velora.hz rootfulMode 2>/dev/null || echo 0`\n"
		"	[ \"$VAL\" = \"1\" ] && ON=1\n"
		"fi\n"
		"P=/var/mobile/Library/Preferences/com.velora.hz.plist\n"
		"[ -f \"$P\" ] && grep -q \"<key>rootfulMode</key>\" \"$P\" && grep -A1 \"<key>rootfulMode</key>\" \"$P\" | grep -q \"<true/>\" && ON=1\n"
		"if [ \"$ON\" != \"1\" ]; then\n"
		"	export PALERA1N_ROOTFUL=0\n"
		"	export JBROOT=/var/jb\n"
		"	[ -d /var/jb ] || export JBROOT=/\n"
		"	exit 0\n"
		"fi\n"
		"export PALERA1N_ROOTFUL=1\n"
		"export PALERA1N_FLAG=-f\n"
		"export JBROOT=/\n"
		"export PALERA1N_FAKEFS_VOLUME=Xystem\n"
		"export PALERA1N_SNAPSHOT=orig-fs\n"
		"export PALERA1N_FAKEFS_DISK=disk0s1s7\n"
		"export PALERA1N_FAKEFS_DEV=/dev/disk0s1s7\n"
		"mkdir -p /Library/MobileSubstrate/DynamicLibraries /cores/fs/real /cores/fs/fake\n"
		"exit 0\n");
	write_utf8(join(dest, "loader.json"),
		"{\n"
		"  \"rootful\": {\n"
		"    \"dotfile\": \"/.procursus_strapped\",\n"
		"    \"bootstrap\": \"https://static.palera.in/bootstrap.tar.zst\",\n"
		"    \"preferenceloader\": \"https://static.palera.in/preferenceloader.deb\",\n"
		"    \"preference\": \"/Library/PreferenceLoader\",\n"
		"    \"managers\": [\n"
		"      {\"name\": \"Sileo\", \"uri\": \"https://static.palera.in/sileo.deb\", \"filePath\": \"/Applications/Sileo.app\"},\n"
		"      {\"name\": \"Zebra\", \"uri\": \"https://static.palera.in/zebra.deb\", \"filePath\": \"/Applications/Zebra.app\"}\n"
		"    ]\n"
		"  }\n"
		"}\n");
	write_utf8(join(dest, "bootstrap.conf"),
		"arch=iphoneos-arm\n"
		"dotfile=/.procursus_strapped\n"
		"sileo=https://static.palera.in/sileo.deb\n"
		"zebra=https://static.palera.in/zebra.deb\n"
		"preferenceloader=https://static.palera.in/preferenceloader.deb\n"
		"bootstrap=https://static.palera.in/bootstrap.tar.zst\n"
		"sileo_path=/Applications/Sileo.app\n"
		"zebra_path=/Applications/Zebra.app\n"
		"preference_path=/Library/PreferenceLoader\n");
	rewrite_named_urls(dest, "loader.json");
	rewrite_named_urls(dest, "nekoloader.json");
	rewrite_named_urls(dest, "bootstrap.conf");
	rewrite_named_urls(dest, "bootstrap.json");
	rewrite_named_urls(dest, "config.json");
	rewrite_named_urls(dest, "preferenceloader.json");
	rewrite_named_urls(dest, "createFakeFS.sh");
	rewrite_named_urls(dest, "rootful.conf");
}

static void refresh_old_rootful(void) {
	id bundle = bundle_path();
	id mgr = file_mgr();
	id verp;
	id existing;
	id (*rd)(Class, SEL, id, unsigned long, id *);
	if (!bundle || !mgr)
		return;
	verp = join(bundle, "palera1n-VERSION");
	rd = (id(*)(Class, SEL, id, unsigned long, id *))objc_msgSend;
	existing = rd(objc_getClass("NSString"), sel_registerName("stringWithContentsOfFile:encoding:error:"), verp, 4, 0);
	rewrite_named_urls(bundle, "loader.json");
	rewrite_named_urls(bundle, "nekoloader.json");
	rewrite_named_urls(bundle, "bootstrap.conf");
	rewrite_named_urls(bundle, "bootstrap.json");
	rewrite_named_urls(bundle, "config.json");
	rewrite_named_urls(bundle, "preferenceloader.json");
	if (!velora_rootful_patch_old(utf8(existing)))
		return;
	write_palera1n_native(bundle);
}

static unsigned char read_rootful(id self, SEL sel, id spec) {
	(void)self;
	(void)sel;
	(void)spec;
	return rootful_on() ? 1 : 0;
}

static void set_rootful(id self, SEL sel, id val, id spec) {
	(void)sel;
	(void)spec;
	unsigned char (*bv)(id, SEL) = (unsigned char (*)(id, SEL))objc_msgSend;
	int on = val ? bv(val, sel_registerName("boolValue")) : 0;
	id std = cls0(objc_getClass("NSUserDefaults"), "standardUserDefaults");
	id suite = msg1(cls0(objc_getClass("NSUserDefaults"), "alloc"), "initWithSuiteName:", nsstr("com.velora.hz"));
	id (*setb)(id, SEL, unsigned char, id) = (id(*)(id, SEL, unsigned char, id))objc_msgSend;
	if (suite)
		setb(suite, sel_registerName("setBool:forKey:"), on ? 1 : 0, nsstr("rootfulMode"));
	if (std)
		msg2(std, "setObject:forKey:", on ? nsstr("1") : nsstr("0"), nsstr("rootful"));
	if (suite)
		msg0(suite, "synchronize");
	id (*post)(id, SEL, id, id) = (id(*)(id, SEL, id, id))objc_msgSend;
	post(cls0(objc_getClass("NSNotificationCenter"), "defaultCenter"), sel_registerName("postNotificationName:object:"), nsstr("com.velora.hz/Reload"), 0);
	if (self)
		msg0(self, "reloadSpecifiers");
	if (on)
		refresh_old_rootful();
}

static void set_progress(double v) {
	if (!gProg)
		return;
	void (*sp)(id, SEL, double) = (void (*)(id, SEL, double))objc_msgSend;
	sp(gProg, sel_registerName("setProgress:"), v);
}

static void append_log(const char *line) {
	id cur;
	id next;
	if (!gLog || !line)
		return;
	cur = msg0(gLog, "text");
	if (cur)
		next = msg1(cur, "stringByAppendingString:", nsstr(line));
	else
		next = nsstr(line);
	msg1(gLog, "setText:", next);
}

static void run_create_fakefs(void) {
	id dest = bundle_path();
	write_palera1n_native(dest);
	set_progress(0.35);
	append_log("palera1n 2.4 helpers written.\n");
	append_log("FakeFS disk: /dev/disk0s1s7\n");
	set_progress(0.6);
	append_log("Nekoloader Sileo/Zebra set to rootful.\n");
	append_log("Bootstrap Sileo/Zebra set to rootful.\n");
	set_progress(0.85);
	append_log("Xystem · orig-fs · bindfs /cores/fs/{real,fake}\n");
	gFakeFSReady = 1;
	set_progress(1.0);
	append_log("FakeFS ready. Continue jailbreak.\n");
	if (gContBtn) {
		void (*en)(id, SEL, unsigned char) = (void (*)(id, SEL, unsigned char))objc_msgSend;
		en(gContBtn, sel_registerName("setEnabled:"), 1);
	}
}

static void fakefs_continue(id self, SEL sel, id sender) {
	(void)sel;
	(void)sender;
	gScreenUp = 0;
	{
		void (*dis)(id, SEL, unsigned char, id) = (void (*)(id, SEL, unsigned char, id))objc_msgSend;
		dis(self, sel_registerName("dismissViewControllerAnimated:completion:"), 1, 0);
	}
	if (gPendingJb && gPendingOrig) {
		id t = gPendingJb;
		SEL s = gPendingSel;
		id (*o)(id, SEL) = gPendingOrig;
		gPendingJb = 0;
		gPendingOrig = 0;
		o(t, s);
	}
}

static void fakefs_create(id self, SEL sel, id sender) {
	(void)self;
	(void)sel;
	(void)sender;
	append_log("Creating FakeFS on /dev/disk0s1s7…\n");
	run_create_fakefs();
}

static id make_label(const char *text, double size, id color) {
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	id lab = msg0(al(objc_getClass("UILabel"), sel_registerName("alloc")), "init");
	id (*sf)(Class, SEL, double) = (id(*)(Class, SEL, double))objc_msgSend;
	msg1(lab, "setText:", nsstr(text));
	msg1(lab, "setTextColor:", color);
	msg1(lab, "setFont:", sf(objc_getClass("UIFont"), sel_registerName("systemFontOfSize:"), size));
	{
		void (*nl)(id, SEL, NSInteger) = (void (*)(id, SEL, NSInteger))objc_msgSend;
		nl(lab, sel_registerName("setNumberOfLines:"), 0);
	}
	return lab;
}

static id make_btn(const char *title, id target, const char *action) {
	id (*btn)(Class, SEL, NSInteger) = (id(*)(Class, SEL, NSInteger))objc_msgSend;
	id b = btn(objc_getClass("UIButton"), sel_registerName("buttonWithType:"), 0);
	id (*set)(id, SEL, id, NSInteger) = (id(*)(id, SEL, id, NSInteger))objc_msgSend;
	id (*add)(id, SEL, id, SEL, unsigned long) = (id(*)(id, SEL, id, SEL, unsigned long))objc_msgSend;
	set(b, sel_registerName("setTitle:forState:"), nsstr(title), 0);
	msg1(b, "setBackgroundColor:", color_rgba(0.18, 0.42, 0.96, 1));
	add(b, sel_registerName("addTarget:action:forControlEvents:"), target, sel_registerName(action), 64);
	return b;
}

static void fakefs_load(id self, SEL sel) {
	id view;
	id title;
	id sub;
	id log;
	id prog;
	id create;
	id cont;
	double w;
	double h;
	Class super = class_getSuperclass(object_getClass(self));
	if (super) {
		struct objc_super s = { self, super };
		((void (*)(struct objc_super *, SEL))objc_msgSendSuper)(&s, sel);
	}
	view = msg0(self, "view");
	msg1(view, "setBackgroundColor:", color_rgba(0.05, 0.05, 0.07, 1));
	w = kvc_double(view, "bounds.size.width", 390);
	h = kvc_double(view, "bounds.size.height", 844);
	title = make_label("Creating FakeFS", 28, color_rgba(1, 1, 1, 1));
	sub = make_label("/dev/disk0s1s7 · palera1n 2.4 · Xystem", 13, color_rgba(0.7, 0.7, 0.74, 1));
	set_frame(title, 24, 72, w - 48, 36);
	set_frame(sub, 24, 112, w - 48, 22);
	msg1(view, "addSubview:", title);
	msg1(view, "addSubview:", sub);
	prog = msg0(cls0(objc_getClass("UIProgressView"), "alloc"), "init");
	set_frame(prog, 24, 150, w - 48, 8);
	msg1(view, "addSubview:", prog);
	gProg = prog;
	set_progress(0);
	log = msg0(cls0(objc_getClass("UITextView"), "alloc"), "init");
	set_frame(log, 24, 172, w - 48, h - 280);
	msg1(log, "setBackgroundColor:", color_rgba(0.1, 0.1, 0.12, 1));
	msg1(log, "setTextColor:", color_rgba(0.85, 0.85, 0.88, 1));
	{
		void (*ed)(id, SEL, unsigned char) = (void (*)(id, SEL, unsigned char))objc_msgSend;
		ed(log, sel_registerName("setEditable:"), 0);
	}
	msg1(log, "setText:", nsstr("NekoJB FakeFS / boot screen.\nVolume Xystem on disk0s1s7.\nTap Create FakeFS, then Continue.\n"));
	msg1(view, "addSubview:", log);
	gLog = log;
	create = make_btn("Create FakeFS", self, "onCreate:");
	set_frame(create, 24, h - 96, w - 48, 44);
	msg1(view, "addSubview:", create);
	gCreateBtn = create;
	cont = make_btn("Continue", self, "onContinue:");
	set_frame(cont, 24, h - 44, w - 48, 36);
	msg1(cont, "setBackgroundColor:", color_rgba(0.22, 0.22, 0.25, 1));
	{
		void (*en)(id, SEL, unsigned char) = (void (*)(id, SEL, unsigned char))objc_msgSend;
		en(cont, sel_registerName("setEnabled:"), gFakeFSReady ? 1 : 0);
	}
	msg1(view, "addSubview:", cont);
	gContBtn = cont;
	(void)h;
}

static void ensure_fakefs_cls(void) {
	Class super;
	Class cls;
	if (objc_getClass("VeloraFakeFSController"))
		return;
	super = objc_getClass("UIViewController");
	if (!super)
		return;
	cls = objc_allocateClassPair(super, "VeloraFakeFSController", 0);
	if (!cls)
		return;
	class_addMethod(cls, sel_registerName("viewDidLoad"), (void *)fakefs_load, "v@:");
	class_addMethod(cls, sel_registerName("onCreate:"), (void *)fakefs_create, "v@:@");
	class_addMethod(cls, sel_registerName("onContinue:"), (void *)fakefs_continue, "v@:@");
	objc_registerClassPair(cls);
}

static id key_window(void) {
	id app = cls0(objc_getClass("UIApplication"), "sharedApplication");
	id win = app ? msg0(app, "keyWindow") : 0;
	id wins;
	unsigned long n;
	if (win)
		return win;
	wins = app ? msg0(app, "windows") : 0;
	n = wins ? ((unsigned long (*)(id, SEL))objc_msgSend)(wins, sel_registerName("count")) : 0;
	if (n)
		return ((id (*)(id, SEL, unsigned long))objc_msgSend)(wins, sel_registerName("objectAtIndex:"), 0);
	return 0;
}

static id top_vc(void) {
	id win = key_window();
	id root = win ? msg0(win, "rootViewController") : 0;
	while (root) {
		id presented = msg0(root, "presentedViewController");
		if (!presented)
			break;
		root = presented;
	}
	return root;
}

static void present_fakefs(id from) {
	id vc;
	id host;
	id (*pres)(id, SEL, id, unsigned char, id);
	ensure_fakefs_cls();
	if (gScreenUp)
		return;
	vc = msg0(cls0(objc_getClass("VeloraFakeFSController"), "alloc"), "init");
	if (!vc)
		return;
	host = from ? from : top_vc();
	if (!host)
		return;
	gScreenUp = 1;
	pres = (id (*)(id, SEL, id, unsigned char, id))objc_msgSend;
	pres(host, sel_registerName("presentViewController:animated:completion:"), vc, 1, 0);
}

static void open_fakefs_screen(id self, SEL sel, id val, id spec) {
	(void)sel;
	(void)val;
	(void)spec;
	present_fakefs(self);
}

static id (*orig_startjb)(id, SEL);
static id hook_startjb(id self, SEL sel) {
	if (rootful_on() && !gFakeFSReady) {
		gPendingJb = self;
		gPendingSel = sel;
		gPendingOrig = orig_startjb;
		present_fakefs(self);
		return 0;
	}
	return orig_startjb ? orig_startjb(self, sel) : 0;
}

static id (*orig_runjb)(id, SEL);
static id hook_runjb(id self, SEL sel) {
	if (rootful_on() && !gFakeFSReady) {
		gPendingJb = self;
		gPendingSel = sel;
		gPendingOrig = orig_runjb;
		present_fakefs(top_vc());
		return 0;
	}
	return orig_runjb ? orig_runjb(self, sel) : 0;
}

static id (*orig_specs)(id, SEL);
static id hook_specs(id self, SEL sel) {
	id specs = orig_specs ? orig_specs(self, sel) : 0;
	unsigned long (*cnt)(id, SEL);
	id (*objat)(id, SEL, unsigned long);
	unsigned long n;
	unsigned long i;
	int has_rootful = 0;
	int has_fakefs = 0;
	Class PS;
	id (*named)(Class, SEL, id, id, SEL, SEL, Class, long, Class);
	id mut;
	id (*setp)(id, SEL, id, id);
	id (*nb)(Class, SEL, unsigned char);
	if (!specs)
		return specs;
	cnt = (unsigned long (*)(id, SEL))objc_msgSend;
	objat = (id(*)(id, SEL, unsigned long))objc_msgSend;
	n = cnt(specs, sel_registerName("count"));
	for (i = 0; i < n; i++) {
		id sp = objat(specs, sel_registerName("objectAtIndex:"), i);
		const char *nm = utf8(msg0(sp, "name"));
		if (velora_cstr_eq(nm, "Rootful") || velora_cstr_has(nm, "Rootful"))
			has_rootful = 1;
		if (velora_is_fakefs_screen_title(nm) || velora_cstr_eq(nm, "Create FakeFS"))
			has_fakefs = 1;
	}
	class_addMethod(objc_getClass("DOSettingsController"), sel_registerName("readVeloraRootful:"), (void *)read_rootful, "c@:@");
	class_addMethod(objc_getClass("DOSettingsController"), sel_registerName("setVeloraRootful:specifier:"), (void *)set_rootful, "v@:@@");
	class_addMethod(objc_getClass("DOSettingsController"), sel_registerName("openVeloraFakeFS:specifier:"), (void *)open_fakefs_screen, "v@:@@");
	PS = objc_getClass("PSSpecifier");
	if (!PS)
		return specs;
	named = (id(*)(Class, SEL, id, id, SEL, SEL, Class, long, Class))objc_msgSend;
	mut = msg0(specs, "mutableCopy");
	if (!mut)
		return specs;
	setp = (id(*)(id, SEL, id, id))objc_msgSend;
	nb = (id(*)(Class, SEL, unsigned char))objc_msgSend;
	if (!has_rootful) {
		id rf = named(PS, sel_registerName("preferenceSpecifierNamed:target:set:get:detail:cell:edit:"), nsstr("Rootful"), self, sel_registerName("setVeloraRootful:specifier:"), sel_registerName("readVeloraRootful:"), 0, 6, 0);
		if (rf) {
			setp(rf, sel_registerName("setProperty:forKey:"), nsstr("rootfulMode"), nsstr("key"));
			setp(rf, sel_registerName("setProperty:forKey:"), nb(objc_getClass("NSNumber"), sel_registerName("numberWithBool:"), 1), nsstr("enabled"));
			if (n > 3) {
				id (*ins)(id, SEL, id, unsigned long) = (id(*)(id, SEL, id, unsigned long))objc_msgSend;
				ins(mut, sel_registerName("insertObject:atIndex:"), rf, 3);
			} else {
				id (*add)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
				add(mut, sel_registerName("addObject:"), rf);
			}
		}
	}
	if (!has_fakefs) {
		id ff = named(PS, sel_registerName("preferenceSpecifierNamed:target:set:get:detail:cell:edit:"), nsstr("Create FakeFS"), self, sel_registerName("openVeloraFakeFS:specifier:"), 0, 0, 13, 0);
		if (ff) {
			id (*add)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
			add(mut, sel_registerName("addObject:"), ff);
		}
	}
	return mut;
}

static void resolve_hook(void) {
	const char *paths[] = {
		"/var/jb/usr/lib/libellekit.dylib",
		"/var/jb/usr/lib/libsubstrate.dylib",
		"/usr/lib/libellekit.dylib",
		"/usr/lib/libsubstrate.dylib",
		0,
	};
	int i;
	if (gHook)
		return;
	gHook = (MSHookMessageEx_t)dlsym(RTLD_DEFAULT, "MSHookMessageEx");
	if (gHook)
		return;
	for (i = 0; paths[i]; i++) {
		void *h = dlopen(paths[i], RTLD_NOLOAD | RTLD_LAZY);
		if (!h)
			continue;
		gHook = (MSHookMessageEx_t)dlsym(h, "MSHookMessageEx");
		if (gHook)
			return;
	}
}

void velora_jbupdate_init(void) {
	resolve_hook();
	refresh_old_rootful();
	ensure_fakefs_cls();
	if (!gHook)
		return;
	hook_sel(objc_getClass("DOSettingsController"), "specifiers", (void *)hook_specs, (void **)&orig_specs);
	hook_sel(objc_getClass("DOMainViewController"), "startJailbreak", (void *)hook_startjb, (void **)&orig_startjb);
	hook_sel(objc_getClass("DOJailbreaker"), "run", (void *)hook_runjb, (void **)&orig_runjb);
}
