/* App Store controls. Version download matches AppStore++: one SSPurchase
   with appExtVrsId, plus buy-parameter hooks for the App Store GET button. */
#include "velora-proc.h"
void *dlopen(const char *path, int mode);
void *dlsym(void *handle, const char *symbol);
#define RTLD_LAZY 1
#define RTLD_DEFAULT ((void *)-2)

typedef struct objc_class *Class;
typedef struct objc_object *id;
typedef struct objc_selector *SEL;
typedef void (*IMP)(void);
typedef long NSInteger;

extern Class objc_getClass(const char *name);
extern SEL sel_registerName(const char *name);
extern void objc_msgSend(void);
extern Class objc_allocateClassPair(Class super, const char *name, unsigned long extra);
extern void objc_registerClassPair(Class cls);
extern int class_addMethod(Class cls, SEL name, void *imp, const char *types);

id velora_empty_block(void);

typedef void (*MSHookMessageEx_t)(Class cls, SEL sel, void *imp, void **orig);
static MSHookMessageEx_t storeHook;

static int gBlockUpdates;
static int gBypassAlert;
static int gHideAds;
static int gCellular;

static id nsstr(const char *c) {
	id (*f)(Class, SEL, const char *) = (id(*)(Class, SEL, const char *))objc_msgSend;
	return f(objc_getClass("NSString"), sel_registerName("stringWithUTF8String:"), c);
}

static int streq(id a, const char *b) {
	if (!a)
		return 0;
	unsigned char (*eq)(id, SEL, id) = (unsigned char (*)(id, SEL, id))objc_msgSend;
	return eq(a, sel_registerName("isEqualToString:"), nsstr(b)) ? 1 : 0;
}

static int pref_on(id defs, const char *key) {
	if (!defs)
		return 0;
	unsigned char (*b)(id, SEL, id) = (unsigned char (*)(id, SEL, id))objc_msgSend;
	return b(defs, sel_registerName("boolForKey:"), nsstr(key)) ? 1 : 0;
}

static id msg0(id obj, const char *sel) {
	if (!obj)
		return 0;
	id (*f)(id, SEL) = (id(*)(id, SEL))objc_msgSend;
	return f(obj, sel_registerName(sel));
}

static id msg1(id obj, const char *sel, id a) {
	if (!obj)
		return 0;
	id (*f)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
	return f(obj, sel_registerName(sel), a);
}

static id msg2(id obj, const char *sel, id a, id b) {
	if (!obj)
		return 0;
	id (*f)(id, SEL, id, id) = (id(*)(id, SEL, id, id))objc_msgSend;
	return f(obj, sel_registerName(sel), a, b);
}

static id cls0(Class c, const char *sel) {
	id (*f)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	return c ? f(c, sel_registerName(sel)) : 0;
}

static int store_has(id obj, const char *sel) {
	if (!obj)
		return 0;
	unsigned char (*r)(id, SEL, SEL) = (unsigned char (*)(id, SEL, SEL))objc_msgSend;
	return r(obj, sel_registerName("respondsToSelector:"), sel_registerName(sel)) ? 1 : 0;
}

static id encode_query(id s);
static void hold(id obj);
static int class_has(Class c, const char *sel);
static void enqueue_song(id plist);
static id apple_song_plist(id adam, id ext);
id velora_resolve_ext(id adam, id ver);
id velora_arm_store_page(id adam, id name);
id velora_find_ipa_url(id adam, id ext);
static int is_long_digits(id v);
static int is_direct_ipa_url(id u);
static void clear_pending(void);
static id cache_ext_for_ver(id adam, id ver);
static const char *store_cstr(id s);
static id shared_get(const char *key);
static void shared_set(const char *key, id val);
static void apply_apple_auth(id req, id dsid);
static void capture_apple_session(void);
static void harvest_arm_session(void);
static void start_session_keeper(void);
static id apple_token(void);
static id apple_store_front(void);
static id arm_session_value(void);
static void remember_arm_session(id val);
static void plant_arm_cookie(id value);
static int ping_apple_session(void);
static int ping_arm_session(void);
static id active_ss_account(void);


static id store_str(id v) {
	if (!v)
		return 0;
	if (store_has(v, "UTF8String"))
		return v;
	if (store_has(v, "stringValue"))
		return msg0(v, "stringValue");
	return 0;
}

static int file_pref_on(const char *key) {
	id (*dcf)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
	Class D = objc_getClass("NSDictionary");
	const char *paths[] = {
		"/var/mobile/Library/Preferences/com.velora.hz.plist",
		"/var/jb/var/mobile/Library/Preferences/com.velora.hz.plist",
		"/var/jb/mnt/var/mobile/Library/Preferences/com.velora.hz.plist",
		0,
	};
	int i;
	if (!D || !key)
		return -1;
	for (i = 0; paths[i]; i++) {
		id file = dcf(D, sel_registerName("dictionaryWithContentsOfFile:"), nsstr(paths[i]));
		id v = file ? msg1(file, "objectForKey:", nsstr(key)) : 0;
		if (v) {
			unsigned char (*b)(id, SEL) = (unsigned char (*)(id, SEL))objc_msgSend;
			return b(v, sel_registerName("boolValue")) ? 1 : 0;
		}
	}
	return -1;
}

static void load_store_prefs(void) {
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	id obj = al(objc_getClass("NSUserDefaults"), sel_registerName("alloc"));
	id (*init)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
	id defs = init(obj, sel_registerName("initWithSuiteName:"), nsstr("com.velora.hz"));
	int file_block = file_pref_on("storeBlockUpdates");
	int file_bypass = file_pref_on("bypassUpdateAlert");
	gBlockUpdates = file_block >= 0 ? file_block : pref_on(defs, "storeBlockUpdates");
	gBypassAlert = file_bypass >= 0 ? file_bypass : pref_on(defs, "bypassUpdateAlert");
	gHideAds = pref_on(defs, "storeHideAds");
	gCellular = pref_on(defs, "storeCellular");
}

static int block_store_updates(void) {
	return velora_compat_block_updates(gBlockUpdates, gBypassAlert);
}

static void on_store_reload(void *center, void *obs, void *name, const void *obj, const void *info) {
	(void)center;
	(void)obs;
	(void)name;
	(void)obj;
	(void)info;
	load_store_prefs();
}

extern void *class_getInstanceMethod(Class cls, SEL name);

static void hook1(const char *cls, const char *sel, void *imp, void **orig) {
	if (!storeHook)
		return;
	Class c = objc_getClass(cls);
	if (!c)
		return;
	SEL s = sel_registerName(sel);
	if (!class_getInstanceMethod(c, s))
		return;
	storeHook(c, s, imp, orig);
}

struct Block_layout {
	void *isa;
	int flags;
	int reserved;
	void (*invoke)(void *block, void *a, void *b);
};

static void empty_updates(id self, SEL sel, id block) {
	(void)self;
	(void)sel;
	if (!block)
		return;
	id (*arr)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	id empty = arr(objc_getClass("NSArray"), sel_registerName("array"));
	struct Block_layout *b = (struct Block_layout *)block;
	if (b && b->invoke)
		b->invoke(block, empty, 0);
}

static void (*orig_getUpdates)(id, SEL, id);
static void hook_getUpdates(id self, SEL sel, id block) {
	if (block_store_updates()) {
		empty_updates(self, sel, block);
		return;
	}
	if (orig_getUpdates)
		orig_getUpdates(self, sel, block);
}

static void (*orig_refreshUpdates)(id, SEL, id);
static void hook_refreshUpdates(id self, SEL sel, id block) {
	if (block_store_updates()) {
		empty_updates(self, sel, block);
		return;
	}
	if (orig_refreshUpdates)
		orig_refreshUpdates(self, sel, block);
}

static void (*orig_reloadUpdates)(id, SEL, id);
static void hook_reloadUpdates(id self, SEL sel, id block) {
	if (block_store_updates()) {
		empty_updates(self, sel, block);
		return;
	}
	if (orig_reloadUpdates)
		orig_reloadUpdates(self, sel, block);
}

static void (*orig_reloadServer)(id, SEL, id);
static void hook_reloadServer(id self, SEL sel, id block) {
	if (block_store_updates()) {
		empty_updates(self, sel, block);
		return;
	}
	if (orig_reloadServer)
		orig_reloadServer(self, sel, block);
}

static id (*orig_udObject)(id, SEL, id);
static id hook_udObject(id self, SEL sel, id key) {
	if (gCellular && key && (streq(key, "maximumCellularSize") || streq(key, "kMaximumCellularDownloadSize"))) {
		id (*n)(Class, SEL, long long) = (id(*)(Class, SEL, long long))objc_msgSend;
		return n(objc_getClass("NSNumber"), sel_registerName("numberWithLongLong:"), 1073741824LL);
	}
	return orig_udObject ? orig_udObject(self, sel, key) : 0;
}

static unsigned char (*orig_isDownloadable)(id, SEL);
static unsigned char hook_isDownloadable(id self, SEL sel) {
	if (gCellular)
		return 1;
	return orig_isDownloadable ? orig_isDownloadable(self, sel) : 1;
}

static unsigned char (*orig_cellularAllowed)(id, SEL);
static unsigned char hook_cellularAllowed(id self, SEL sel) {
	if (gCellular)
		return 1;
	return orig_cellularAllowed ? orig_cellularAllowed(self, sel) : 0;
}

static void hide_if_ad(id view) {
	if (!gHideAds || !view)
		return;
	id (*clsMsg)(id, SEL) = (id(*)(id, SEL))objc_msgSend;
	id cname = clsMsg(view, sel_registerName("className"));
	if (!cname)
		cname = clsMsg(clsMsg(view, sel_registerName("class")), sel_registerName("description"));
	if (!cname)
		return;
	unsigned char (*has)(id, SEL, id) = (unsigned char (*)(id, SEL, id))objc_msgSend;
	if (has(cname, sel_registerName("localizedCaseInsensitiveContainsString:"), nsstr("AdView")) ||
	    has(cname, sel_registerName("localizedCaseInsensitiveContainsString:"), nsstr("Advert")) ||
	    has(cname, sel_registerName("localizedCaseInsensitiveContainsString:"), nsstr("AdBanner")) ||
	    has(cname, sel_registerName("localizedCaseInsensitiveContainsString:"), nsstr("SearchAd"))) {
		void (*hid)(id, SEL, unsigned char) = (void (*)(id, SEL, unsigned char))objc_msgSend;
		hid(view, sel_registerName("setHidden:"), 1);
	}
}

static void (*orig_didMove)(id, SEL);
static void hook_didMove(id self, SEL sel) {
	if (orig_didMove)
		orig_didMove(self, sel);
	hide_if_ad(self);
}

static int is_prefs_proc(void);

static int purchase_daemon(void) {
	Class PI = objc_getClass("NSProcessInfo");
	id proc = PI ? cls0(PI, "processInfo") : 0;
	id name = proc ? msg0(proc, "processName") : 0;
	if (streq(name, "itunesstored") || streq(name, "appstored"))
		return 1;
	Class NB = objc_getClass("NSBundle");
	id main = NB ? cls0(NB, "mainBundle") : 0;
	id bid = main ? msg0(main, "bundleIdentifier") : 0;
	if (streq(bid, "com.apple.itunesstored") || streq(bid, "com.apple.appstored"))
		return 1;
	return 0;
}

static char gClaimAdam[48];

static int gPurchaseBusy;
static int gSeenGen;

static int claim_purchase(id adam) {
	const char *a = store_cstr(adam);
	if (!a[0])
		return 0;
	gPurchaseBusy = 1;
	int n = 0;
	while (a[n] && n < 46) {
		gClaimAdam[n] = a[n];
		n++;
	}
	gClaimAdam[n] = 0;
	return 1;
}

static int is_prefs_proc(void) {
	id (*cm)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	id (*im)(id, SEL) = (id(*)(id, SEL))objc_msgSend;
	Class NB = objc_getClass("NSBundle");
	id main = NB ? cm(NB, sel_registerName("mainBundle")) : 0;
	id bid = main ? im(main, sel_registerName("bundleIdentifier")) : 0;
	return streq(bid, "com.apple.Preferences");
}

static int in_store_process(void);

static int can_handle_jobs(void) {
	return in_store_process() || is_prefs_proc();
}

static int in_store_process(void) {
	id (*cm)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	id (*im)(id, SEL) = (id(*)(id, SEL))objc_msgSend;
	Class NB = objc_getClass("NSBundle");
	id main = NB ? cm(NB, sel_registerName("mainBundle")) : 0;
	id bid = main ? im(main, sel_registerName("bundleIdentifier")) : 0;
	if (streq(bid, "com.apple.AppStore") || streq(bid, "com.apple.appstored") || streq(bid, "com.apple.itunesstored") || streq(bid, "com.apple.ios.StoreKitUI"))
		return 1;
	Class PI = objc_getClass("NSProcessInfo");
	id proc = PI ? cm(PI, sel_registerName("processInfo")) : 0;
	id name = proc ? msg0(proc, "processName") : 0;
	if (streq(name, "itunesstored") || streq(name, "appstored"))
		return 1;
	return 0;
}

static id store_defs(void) {
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	id obj = al(objc_getClass("NSUserDefaults"), sel_registerName("alloc"));
	id (*init)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
	return init(obj, sel_registerName("initWithSuiteName:"), nsstr("com.velora.hz"));
}

static long long parse_ll(const char *s) {
	long long v = 0;
	if (!s)
		return 0;
	while (*s >= '0' && *s <= '9') {
		v = v * 10 + (*s - '0');
		s++;
	}
	return v;
}

static int cat(char *b, int n, int cap, const char *s) {
	if (!b || cap < 2)
		return n;
	if (n < 0)
		n = 0;
	while (s && *s && n < cap - 1)
		b[n++] = *s++;
	b[n] = 0;
	return n;
}

static int cookie_key_is(const char *s, int start, int end, const char *key) {
	int k = 0;
	if (!s || !key)
		return 0;
	while (s[start] == ' ' || s[start] == '\t')
		start++;
	while (key[k] && start + k < end && s[start + k] == key[k])
		k++;
	return key[k] == 0 && start + k < end && s[start + k] == '=';
}

static int merge_cookie_jar(char *out, int cap, const char *jar, const char *name, const char *val) {
	int n = 0, wrote = 0;
	const char *s;
	if (!out || cap < 4)
		return 0;
	out[0] = 0;
	if (!name || !name[0] || !val || !val[0]) {
		if (jar && jar[0])
			cat(out, 0, cap, jar);
		return out[0] != 0;
	}
	s = jar ? jar : "";
	while (*s) {
		const char *eop = s;
		int skip;
		while (*eop && *eop != ';')
			eop++;
		skip = cookie_key_is(s, 0, (int)(eop - s), name);
		if (skip) {
			if (!wrote) {
				if (n)
					n = cat(out, n, cap, "; ");
				n = cat(out, n, cap, name);
				n = cat(out, n, cap, "=");
				n = cat(out, n, cap, val);
				wrote = 1;
			}
		} else {
			const char *p = s;
			while (p < eop && (*p == ' ' || *p == '\t'))
				p++;
			if (p < eop) {
				if (n)
					n = cat(out, n, cap, "; ");
				while (p < eop && n < cap - 1)
					out[n++] = *p++;
				out[n] = 0;
			}
		}
		s = *eop ? eop + 1 : eop;
	}
	if (!wrote) {
		if (n)
			n = cat(out, n, cap, "; ");
		n = cat(out, n, cap, name);
		n = cat(out, n, cap, "=");
		n = cat(out, n, cap, val);
	}
	return n > 0;
}

static int extract_cookie_value(char *out, int cap, const char *hdr, const char *name) {
	const char *p;
	int ln = 0;
	if (!out || cap < 2)
		return 0;
	out[0] = 0;
	if (!hdr || !name || !name[0])
		return 0;
	while (name[ln])
		ln++;
	p = hdr;
	while (*p) {
		int i = 0;
		while (*p == ' ' || *p == '\t' || *p == ';' || *p == ',')
			p++;
		if (!*p)
			break;
		while (name[i] && p[i] && ((p[i] | 32) == (name[i] | 32)))
			i++;
		if (i == ln && p[i] == '=') {
			int n = 0;
			p += i + 1;
			while (*p && *p != ';' && *p != ',' && n < cap - 1)
				out[n++] = *p++;
			out[n] = 0;
			return n > 0;
		}
		while (*p && *p != ';' && *p != ',')
			p++;
	}
	return 0;
}

static const char *store_cstr(id s) {
	id t = store_str(s);
	if (!t)
		return "";
	const char *(*f)(id, SEL) = (const char *(*)(id, SEL))objc_msgSend;
	const char *v = f(t, sel_registerName("UTF8String"));
	return v ? v : "";
}

static id plist_data(id obj) {
	id err = 0;
	id (*fn)(Class, SEL, id, NSInteger, NSInteger, id *) = (id(*)(Class, SEL, id, NSInteger, NSInteger, id *))objc_msgSend;
	return fn(objc_getClass("NSPropertyListSerialization"), sel_registerName("dataWithPropertyList:format:options:error:"), obj, 1, 0, &err);
}

static id plist_parse(id data) {
	if (!data)
		return 0;
	id err = 0;
	id (*fn)(Class, SEL, id, NSInteger, void *, id *) = (id(*)(Class, SEL, id, NSInteger, void *, id *))objc_msgSend;
	return fn(objc_getClass("NSPropertyListSerialization"), sel_registerName("propertyListWithData:options:format:error:"), data, 0, 0, &err);
}

static id cookie_header(void) {
	Class ST = objc_getClass("NSHTTPCookieStorage");
	Class CK = objc_getClass("NSHTTPCookie");
	Class UR = objc_getClass("NSURL");
	if (!ST || !CK || !UR)
		return 0;
	id storage = cls0(ST, "sharedHTTPCookieStorage");
	id (*uws)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
	id url = uws(UR, sel_registerName("URLWithString:"), nsstr("https://buy.itunes.apple.com/"));
	if (!storage || !url || !store_has(storage, "cookiesForURL:"))
		return 0;
	id cookies = msg1(storage, "cookiesForURL:", url);
	if (!cookies)
		return 0;
	id (*hdr)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
	id fields = hdr(CK, sel_registerName("requestHeaderFieldsWithCookies:"), cookies);
	if (!fields)
		return 0;
	return msg1(fields, "objectForKey:", nsstr("Cookie"));
}

static void ensure_cache_dir(void) {
	Class FM = objc_getClass("NSFileManager");
	id fm = FM ? cls0(FM, "defaultManager") : 0;
	if (!fm)
		return;
	unsigned char (*mk)(id, SEL, id, unsigned char, id, id *) = (unsigned char (*)(id, SEL, id, unsigned char, id, id *))objc_msgSend;
	if (store_has(fm, "createDirectoryAtPath:withIntermediateDirectories:attributes:error:"))
		mk(fm, sel_registerName("createDirectoryAtPath:withIntermediateDirectories:attributes:error:"), nsstr("/var/mobile/Library/Caches/com.velora.hz"), 1, 0, 0);
}

static id cache_path(id adam) {
	id a = store_str(adam);
	if (!a)
		return 0;
	id dir = nsstr("/var/mobile/Library/Caches/com.velora.hz/");
	id p = msg1(dir, "stringByAppendingString:", a);
	return msg1(p, "stringByAppendingString:", nsstr(".plist"));
}

static void write_ver_cache(id adam, id rows) {
	if (!adam || !rows)
		return;
	ensure_cache_dir();
	id path = cache_path(adam);
	if (path && store_has(rows, "writeToFile:atomically:")) {
		unsigned char (*w)(id, SEL, id, unsigned char) = (unsigned char (*)(id, SEL, id, unsigned char))objc_msgSend;
		w(rows, sel_registerName("writeToFile:atomically:"), path, 1);
	}
	id defs = store_defs();
	if (!defs)
		return;
	id key = msg1(nsstr("verCache-"), "stringByAppendingString:", store_str(adam));
	void (*so)(id, SEL, id, id) = (void (*)(id, SEL, id, id))objc_msgSend;
	so(defs, sel_registerName("setObject:forKey:"), rows, key);
	msg0(defs, "synchronize");
}

static id http_plist(const char *urlc, id body, id dsid) {
	id url = msg1(objc_getClass("NSURL"), "URLWithString:", nsstr(urlc));
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	id req = msg0(al(objc_getClass("NSMutableURLRequest"), sel_registerName("alloc")), "init");
	if (!req || !url)
		return 0;
	msg1(req, "setURL:", url);
	msg1(req, "setHTTPMethod:", nsstr("POST"));
	if (body) {
		void (*sb)(id, SEL, id) = (void (*)(id, SEL, id))objc_msgSend;
		sb(req, sel_registerName("setHTTPBody:"), body);
	}
	id (*sv)(id, SEL, id, id) = (id(*)(id, SEL, id, id))objc_msgSend;
	sv(req, sel_registerName("setValue:forHTTPHeaderField:"), nsstr("application/x-apple-plist"), nsstr("Content-Type"));
	if (store_has(req, "setTimeoutInterval:")) {
		void (*sto)(id, SEL, double) = (void (*)(id, SEL, double))objc_msgSend;
		sto(req, sel_registerName("setTimeoutInterval:"), 25.0);
	}
	apply_apple_auth(req, dsid);
	id resp = 0, err = 0;
	id (*send)(Class, SEL, id, id *, id *) = (id(*)(Class, SEL, id, id *, id *))objc_msgSend;
	id data = send(objc_getClass("NSURLConnection"), sel_registerName("sendSynchronousRequest:returningResponse:error:"), req, &resp, &err);
	return plist_parse(data);
}

static id account_dsid(void) {
	Class C = objc_getClass("SSAccountStore");
	id store = C ? cls0(C, "defaultStore") : 0;
	id acc = 0;
	id dsid = 0;
	if (!C) {
		dlopen("/System/Library/PrivateFrameworks/StoreServices.framework/StoreServices", RTLD_LAZY);
		C = objc_getClass("SSAccountStore");
		store = C ? cls0(C, "defaultStore") : 0;
	}
	if (store && store_has(store, "activeAccount"))
		acc = msg0(store, "activeAccount");
	if (!acc && store && store_has(store, "defaultAccount"))
		acc = msg0(store, "defaultAccount");
	if (acc && store_has(acc, "directoryServicesIdentifier"))
		dsid = msg0(acc, "directoryServicesIdentifier");
	if (!dsid && acc && store_has(acc, "uniqueIdentifier"))
		dsid = msg0(acc, "uniqueIdentifier");
	if (!dsid && acc && store_has(acc, "dsPersonID"))
		dsid = msg0(acc, "dsPersonID");
	dsid = store_str(dsid);
	if (dsid && store_cstr(dsid)[0])
		return dsid;
	return store_str(shared_get("appleDsid"));
}

static id device_guid(void) {
	Class D = objc_getClass("SSDevice");
	id dev = D ? cls0(D, "currentDevice") : 0;
	id g = 0;
	if (dev && store_has(dev, "uniqueIdentifier"))
		g = store_str(msg0(dev, "uniqueIdentifier"));
	if (g)
		return g;
	Class UD = objc_getClass("UIDevice");
	id u = UD ? cls0(UD, "currentDevice") : 0;
	id v = (u && store_has(u, "identifierForVendor")) ? msg0(u, "identifierForVendor") : 0;
	id s = (v && store_has(v, "UUIDString")) ? msg0(v, "UUIDString") : 0;
	if (s) {
		id (*rep)(id, SEL, id, id) = (id(*)(id, SEL, id, id))objc_msgSend;
		s = rep(s, sel_registerName("stringByReplacingOccurrencesOfString:withString:"), nsstr("-"), nsstr(""));
		return s;
	}
	return nsstr("000000000000");
}

static id dict_put(id d, const char *k, id v) {
	if (d && v) {
		void (*so)(id, SEL, id, id) = (void (*)(id, SEL, id, id))objc_msgSend;
		so(d, sel_registerName("setObject:forKey:"), v, nsstr(k));
	}
	return d;
}

static id new_dict(void) {
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	return msg0(al(objc_getClass("NSMutableDictionary"), sel_registerName("alloc")), "init");
}

static id new_array(void) {
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	return msg0(al(objc_getClass("NSMutableArray"), sel_registerName("alloc")), "init");
}

static id as_number(id v) {
	id s = store_str(v);
	const char *c = store_cstr(s);
	if (!c[0])
		return 0;
	long long n = 0;
	int any = 0;
	for (; *c; c++) {
		if (*c < '0' || *c > '9')
			return 0;
		n = n * 10 + (*c - '0');
		any = 1;
	}
	if (!any)
		return 0;
	typedef id (*nwl)(Class, SEL, long long);
	nwl f = (nwl)objc_msgSend;
	return f(objc_getClass("NSNumber"), sel_registerName("numberWithLongLong:"), n);
}

static int hay_ci(id s, const char *n) {
	id t = store_str(s);
	if (!t || !n[0])
		return 0;
	id low = store_has(t, "lowercaseString") ? msg0(t, "lowercaseString") : t;
	const char *c = store_cstr(low);
	int i, j;
	for (i = 0; c[i]; i++) {
		for (j = 0; n[j] && c[i + j] && ((c[i + j] | 32) == (n[j] | 32) || c[i + j] == n[j]); j++)
			;
		if (!n[j])
			return 1;
	}
	return 0;
}

static int is_pad_device(void) {
	Class UD = objc_getClass("UIDevice");
	id u = UD ? cls0(UD, "currentDevice") : 0;
	if (!u || !store_has(u, "userInterfaceIdiom"))
		return 0;
	NSInteger (*ui)(id, SEL) = (NSInteger(*)(id, SEL))objc_msgSend;
	return ui(u, sel_registerName("userInterfaceIdiom")) == 1;
}

static id volume_payload(id adam, id guid, id ext) {
	id d = new_dict();
	dict_put(d, "creditDisplay", nsstr(""));
	dict_put(d, "guid", guid);
	dict_put(d, "salableAdamId", adam);
	dict_put(d, "serialNumber", nsstr("0"));
	id num = as_number(ext);
	if (num) {
		dict_put(d, "externalVersionId", num);
		dict_put(d, "appExtVrsId", num);
	} else if (ext)
		dict_put(d, "externalVersionId", ext);
	return plist_data(d);
}

static id song_meta(id plist) {
	if (!plist)
		return 0;
	id list = msg1(plist, "objectForKey:", nsstr("songList"));
	if (!list)
		list = msg1(plist, "objectForKey:", nsstr("items"));
	NSInteger (*cnt)(id, SEL) = (NSInteger(*)(id, SEL))objc_msgSend;
	if (!list || !store_has(list, "objectAtIndex:"))
		return 0;
	id (*at)(id, SEL, NSInteger) = (id(*)(id, SEL, NSInteger))objc_msgSend;
	id item = at(list, sel_registerName("objectAtIndex:"), 0);
	if (!item)
		return 0;
	id meta = msg1(item, "objectForKey:", nsstr("metadata"));
	return meta ? meta : item;
}

static void enqueue_song(id plist) {
	id list = plist ? msg1(plist, "objectForKey:", nsstr("songList")) : 0;
	if (!list)
		list = plist ? msg1(plist, "objectForKey:", nsstr("items")) : 0;
	NSInteger (*cnt)(id, SEL) = (NSInteger(*)(id, SEL))objc_msgSend;
	if (!list || !store_has(list, "objectAtIndex:"))
		return;
	id (*at)(id, SEL, NSInteger) = (id(*)(id, SEL, NSInteger))objc_msgSend;
	id song = at(list, sel_registerName("objectAtIndex:"), 0);
	if (!song)
		return;
	unsigned char (*rs)(id, SEL, SEL) = (unsigned char (*)(id, SEL, SEL))objc_msgSend;
	Class MD = objc_getClass("SSDownloadMetadata");
	id md = 0;
	if (MD) {
		id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
		id obj = al(MD, sel_registerName("alloc"));
		id (*initd)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
		if (obj && rs(obj, sel_registerName("respondsToSelector:"), sel_registerName("initWithDictionary:")))
			md = initd(obj, sel_registerName("initWithDictionary:"), song);
	}
	Class DL = objc_getClass("SSDownload");
	id dl = 0;
	if (DL && md) {
		id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
		id obj = al(DL, sel_registerName("alloc"));
		id (*initm)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
		if (obj)
			dl = initm(obj, sel_registerName("initWithDownloadMetadata:"), md);
	}
	if (!dl)
		return;
	id (*awo)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
	id arr = awo(objc_getClass("NSArray"), sel_registerName("arrayWithObject:"), dl);
	Class Mgr = objc_getClass("SSDownloadManager");
	id mgr = Mgr ? cls0(Mgr, "softwareDownloadManager") : 0;
	if (!mgr && Mgr)
		mgr = cls0(Mgr, "mediaDownloadManager");
	if (mgr && rs(mgr, sel_registerName("respondsToSelector:"), sel_registerName("addDownload:")))
		msg1(mgr, "addDownload:", dl);
	else if (mgr && rs(mgr, sel_registerName("respondsToSelector:"), sel_registerName("addDownloads:")))
		msg1(mgr, "addDownloads:", arr);
	Class Q = objc_getClass("SSDownloadQueue");
	id q = Q ? cls0(Q, "mediaQueue") : 0;
	if (!q && Q)
		q = cls0(Q, "softwareQueue");
	if (q && rs(q, sel_registerName("respondsToSelector:"), sel_registerName("addDownload:")))
		msg1(q, "addDownload:", dl);
	id kinds = 0;
	if (Q && class_has(Q, "softwareDownloadKinds"))
		kinds = cls0(Q, "softwareDownloadKinds");
	if (Q && kinds) {
		id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
		id obj = al(Q, sel_registerName("alloc"));
		if (obj && rs(obj, sel_registerName("respondsToSelector:"), sel_registerName("initWithDownloadKinds:"))) {
			id (*ik)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
			id qq = ik(obj, sel_registerName("initWithDownloadKinds:"), kinds);
			if (qq) {
				hold(qq);
				if (rs(qq, sel_registerName("respondsToSelector:"), sel_registerName("addDownloads:")))
					msg1(qq, "addDownloads:", arr);
				else if (rs(qq, sel_registerName("respondsToSelector:"), sel_registerName("addDownload:")))
					msg1(qq, "addDownload:", dl);
			}
		}
	}
}

static void run_apple_version_fetch(int resolve_names) {
	dlopen("/System/Library/PrivateFrameworks/StoreServices.framework/StoreServices", RTLD_LAZY);
	id defs = store_defs();
	if (!defs)
		return;
	id (*gf)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
	id adam = gf(defs, sel_registerName("stringForKey:"), nsstr("dlFetchAdam"));
	if (!adam || !store_cstr(adam)[0])
		return;
	id guid = device_guid();
	id dsid = account_dsid();
	id body = volume_payload(adam, guid, 0);
	const char *urls[] = {
		"https://buy.itunes.apple.com/WebObjects/MZFinance.woa/wa/volumeStoreDownloadProduct",
		"https://p25-buy.itunes.apple.com/WebObjects/MZFinance.woa/wa/volumeStoreDownloadProduct",
		"https://p36-buy.itunes.apple.com/WebObjects/MZFinance.woa/wa/volumeStoreDownloadProduct",
		0,
	};
	id plist = 0;
	for (int i = 0; urls[i] && !plist; i++)
		plist = http_plist(urls[i], body, dsid);
	id meta = song_meta(plist);
	id ids = 0;
	if (meta)
		ids = msg1(meta, "objectForKey:", nsstr("softwareVersionExternalIdentifiers"));
	if (!ids && plist)
		ids = msg1(plist, "objectForKey:", nsstr("softwareVersionExternalIdentifiers"));
	if (!ids && meta) {
		id m2 = msg1(meta, "objectForKey:", nsstr("metadata"));
		if (m2)
			ids = msg1(m2, "objectForKey:", nsstr("softwareVersionExternalIdentifiers"));
	}
	if (!ids || !store_has(ids, "objectAtIndex:"))
		return;
	NSInteger (*cnt)(id, SEL) = (NSInteger(*)(id, SEL))objc_msgSend;
	id (*at)(id, SEL, NSInteger) = (id(*)(id, SEL, NSInteger))objc_msgSend;
	NSInteger n = cnt(ids, sel_registerName("count"));
	id out = new_array();
	NSInteger cap = n < 250 ? n : 250;
	for (NSInteger i = 0; i < cap; i++) {
		id ident = at(ids, sel_registerName("objectAtIndex:"), i);
		id identS = store_str(ident);
		if (!identS)
			continue;
		id row = new_dict();
		dict_put(row, "externalId", identS);
		dict_put(row, "build", identS);
		msg1(out, "addObject:", row);
	}
	write_ver_cache(adam, out);
	if (!resolve_names)
		return;
	for (NSInteger i = 0; i < cap; i++) {
		id ident = at(ids, sel_registerName("objectAtIndex:"), i);
		id identS = store_str(ident);
		if (!identS)
			continue;
		id one = http_plist(urls[0], volume_payload(adam, guid, identS), dsid);
		id m2 = song_meta(one);
		id ver = m2 ? msg1(m2, "objectForKey:", nsstr("bundleShortVersionString")) : 0;
		if (!ver)
			continue;
		id row = at(out, sel_registerName("objectAtIndex:"), i);
		if (row)
			dict_put(row, "version", ver);
		if (i % 8 == 0)
			write_ver_cache(adam, out);
	}
	write_ver_cache(adam, out);
}

void velora_run_fetch(void) {
	run_apple_version_fetch(0);
}

extern void *CFNotificationCenterGetDarwinNotifyCenter(void);
extern void CFNotificationCenterAddObserver(void *center, const void *observer, void (*cb)(void *, void *, void *, const void *, const void *), void *name, const void *object, int suspension);
extern void CFNotificationCenterPostNotification(void *center, void *name, const void *obj, const void *info, unsigned char deliverImmediately);
extern int notify_post(const char *name);
extern void CFPreferencesSetAppValue(void *key, const void *value, void *app);
extern unsigned char CFPreferencesAppSynchronize(void *app);
extern void *CFPreferencesCopyAppValue(void *key, void *app);

static id gAppId;
static id gDlNote;
static id gFtNote;

static id live_str(const char *c) {
	id s = nsstr(c);
	return s ? msg0(s, "copy") : 0;
}

static void ensure_ids(void) {
	if (!gAppId)
		gAppId = live_str("com.velora.hz");
	if (!gDlNote)
		gDlNote = live_str("com.velora.hz.download");
	if (!gFtNote)
		gFtNote = live_str("com.velora.hz.fetch");
}

static void shared_set(const char *key, id val) {
	ensure_ids();
	if (!val)
		return;
	id k = live_str(key);
	CFPreferencesSetAppValue(k, val, gAppId);
	CFPreferencesAppSynchronize(gAppId);
	id defs = store_defs();
	if (defs) {
		void (*so)(id, SEL, id, id) = (void (*)(id, SEL, id, id))objc_msgSend;
		so(defs, sel_registerName("setObject:forKey:"), val, nsstr(key));
		msg0(defs, "synchronize");
	}
	id (*dcf)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
	id path = nsstr("/var/mobile/Library/Preferences/com.velora.hz.plist");
	id file = dcf(objc_getClass("NSMutableDictionary"), sel_registerName("dictionaryWithContentsOfFile:"), path);
	if (!file)
		file = new_dict();
	dict_put(file, key, val);
	if (store_has(file, "writeToFile:atomically:")) {
		unsigned char (*w)(id, SEL, id, unsigned char) = (unsigned char (*)(id, SEL, id, unsigned char))objc_msgSend;
		w(file, sel_registerName("writeToFile:atomically:"), path, 1);
		w(file, sel_registerName("writeToFile:atomically:"), nsstr("/tmp/com.velora.hz.dl.plist"), 1);
	}
}

static id shared_get(const char *key) {
	ensure_ids();
	void *v = CFPreferencesCopyAppValue(nsstr(key), gAppId);
	if (v)
		return v;
	id path = nsstr("/var/mobile/Library/Preferences/com.velora.hz.plist");
	id (*dcf)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
	id file = dcf(objc_getClass("NSDictionary"), sel_registerName("dictionaryWithContentsOfFile:"), path);
	id fromf = file ? msg1(file, "objectForKey:", nsstr(key)) : 0;
	if (fromf)
		return fromf;
	file = dcf(objc_getClass("NSDictionary"), sel_registerName("dictionaryWithContentsOfFile:"), nsstr("/tmp/com.velora.hz.dl.plist"));
	fromf = file ? msg1(file, "objectForKey:", nsstr(key)) : 0;
	if (fromf)
		return fromf;
	id defs = store_defs();
	if (!defs)
		return 0;
	id (*gf)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
	return gf(defs, sel_registerName("stringForKey:"), nsstr(key));
}

static id any_str(id v) {
	id s = store_str(v);
	if (s && store_cstr(s)[0] && !streq(s, "(null)"))
		return s;
	if (v && store_has(v, "base64EncodedStringWithOptions:")) {
		id (*b64)(id, SEL, NSInteger) = (id(*)(id, SEL, NSInteger))objc_msgSend;
		s = store_str(b64(v, sel_registerName("base64EncodedStringWithOptions:"), 0));
		if (s && store_cstr(s)[0] && !streq(s, "(null)"))
			return s;
	}
	if (v && store_has(v, "stringValue")) {
		s = store_str(msg0(v, "stringValue"));
		if (s && store_cstr(s)[0] && !streq(s, "(null)"))
			return s;
	}
	return 0;
}

static id acc_sel(id acc, const char *sel) {
	if (!acc || !sel || !sel[0] || !store_has(acc, sel))
		return 0;
	return any_str(msg0(acc, sel));
}

static id active_ss_account(void) {
	Class C = objc_getClass("SSAccountStore");
	id store, acc = 0;
	if (!C) {
		dlopen("/System/Library/PrivateFrameworks/StoreServices.framework/StoreServices", RTLD_LAZY);
		C = objc_getClass("SSAccountStore");
	}
	store = C ? cls0(C, "defaultStore") : 0;
	if (store && store_has(store, "activeAccount"))
		acc = msg0(store, "activeAccount");
	if (!acc && store && store_has(store, "defaultAccount"))
		acc = msg0(store, "defaultAccount");
	if (!acc && store && store_has(store, "accounts")) {
		id list = msg0(store, "accounts");
		if (list && store_has(list, "objectAtIndex:")) {
			NSInteger (*cn)(id, SEL) = (NSInteger(*)(id, SEL))objc_msgSend;
			if (!store_has(list, "count") || cn(list, sel_registerName("count")) > 0) {
				id (*at)(id, SEL, NSInteger) = (id(*)(id, SEL, NSInteger))objc_msgSend;
				acc = at(list, sel_registerName("objectAtIndex:"), 0);
			}
		}
	}
	return acc;
}

static id apple_token(void) {
	id acc = active_ss_account();
	const char *keys[] = {
		"secureToken",
		"passwordEquivalentToken",
		"authenticationToken",
		"hashedPassword",
		"passwordToken",
		0
	};
	int i;
	for (i = 0; acc && keys[i]; i++) {
		id v = acc_sel(acc, keys[i]);
		if (v && store_cstr(v)[0])
			return v;
	}
	return store_str(shared_get("appleToken"));
}

static id apple_store_front(void) {
	id acc = active_ss_account();
	id sf = acc_sel(acc, "storeFrontIdentifier");
	if (!sf)
		sf = acc_sel(acc, "storeFront");
	if (sf && store_cstr(sf)[0])
		return sf;
	return store_str(shared_get("appleStoreFront"));
}

static id apple_cookies(void) {
	id acc = active_ss_account();
	id ck = acc_sel(acc, "cookieHeader");
	if (ck && store_cstr(ck)[0])
		return ck;
	ck = store_str(cookie_header());
	if (ck && store_cstr(ck)[0])
		return ck;
	return store_str(shared_get("appleCookies"));
}

static void capture_apple_session(void) {
	id acc = active_ss_account();
	id dsid = account_dsid();
	id token = apple_token();
	id cookies = apple_cookies();
	id sf = apple_store_front();
	id name = acc_sel(acc, "accountName");
	if (!name)
		name = acc_sel(acc, "identifier");
	if (dsid && store_cstr(dsid)[0])
		shared_set("appleDsid", dsid);
	if (token && store_cstr(token)[0])
		shared_set("appleToken", token);
	if (cookies && store_cstr(cookies)[0])
		shared_set("appleCookies", cookies);
	if (sf && store_cstr(sf)[0])
		shared_set("appleStoreFront", sf);
	if (name && store_cstr(name)[0])
		shared_set("appleAccount", name);
	shared_set("appleSessionOn", nsstr(token && store_cstr(token)[0] && dsid && store_cstr(dsid)[0] ? "1" : (dsid && store_cstr(dsid)[0] ? "1" : "0")));
}

static void apply_apple_auth(id req, id dsid) {
	id (*sv)(id, SEL, id, id) = (id(*)(id, SEL, id, id))objc_msgSend;
	id ds, token, cookies, sf;
	if (!req)
		return;
	capture_apple_session();
	sv(req, sel_registerName("setValue:forHTTPHeaderField:"),
		nsstr("iTunes/12.9.5 (Macintosh; OS X 10.15.7) AppleWebKit/605.1.15"),
		nsstr("User-Agent"));
	ds = dsid ? store_str(dsid) : account_dsid();
	if (ds && store_cstr(ds)[0]) {
		sv(req, sel_registerName("setValue:forHTTPHeaderField:"), ds, nsstr("X-Dsid"));
		sv(req, sel_registerName("setValue:forHTTPHeaderField:"), ds, nsstr("iCloud-DSID"));
	}
	token = apple_token();
	if (token && store_cstr(token)[0])
		sv(req, sel_registerName("setValue:forHTTPHeaderField:"), token, nsstr("X-Token"));
	cookies = apple_cookies();
	if (cookies && store_cstr(cookies)[0])
		sv(req, sel_registerName("setValue:forHTTPHeaderField:"), cookies, nsstr("Cookie"));
	sf = apple_store_front();
	if (sf && store_cstr(sf)[0])
		sv(req, sel_registerName("setValue:forHTTPHeaderField:"), sf, nsstr("X-Apple-Store-Front"));
}

static int apple_token_expired(id plist) {
	id fail, msg;
	if (!plist || !store_has(plist, "objectForKey:"))
		return 0;
	fail = store_str(msg1(plist, "objectForKey:", nsstr("failureType")));
	if (streq(fail, "2034") || streq(fail, "2042"))
		return 1;
	msg = store_str(msg1(plist, "objectForKey:", nsstr("customerMessage")));
	if (msg && (hay_ci(msg, "password has changed") || hay_ci(msg, "sign in") || hay_ci(msg, "log in")))
		return 1;
	return 0;
}

static int ping_apple_session(void) {
	id dsid, guid, d, body, plist;
	capture_apple_session();
	dsid = account_dsid();
	if (!dsid || !store_cstr(dsid)[0])
		return 0;
	guid = device_guid();
	d = new_dict();
	dict_put(d, "guid", guid);
	dict_put(d, "dsPersonId", dsid);
	body = plist_data(d);
	plist = http_plist("https://buy.itunes.apple.com/WebObjects/MZFinance.woa/wa/accountSummary", body, dsid);
	if (apple_token_expired(plist)) {
		capture_apple_session();
		return 0;
	}
	return plist ? 1 : 1;
}

static id arm_session_value(void) {
	id s = store_str(shared_get("armSession"));
	if (s && store_cstr(s)[0])
		return s;
	return 0;
}

static void plant_arm_cookie(id value) {
	Class CK, ST;
	id props, cookie, storage;
	id s = store_str(value);
	if (!s || !store_cstr(s)[0])
		return;
	CK = objc_getClass("NSHTTPCookie");
	ST = objc_getClass("NSHTTPCookieStorage");
	if (!CK || !ST || !class_has(CK, "cookieWithProperties:"))
		return;
	props = new_dict();
	dict_put(props, "NSHTTPCookieName", nsstr("session"));
	dict_put(props, "NSHTTPCookieValue", s);
	dict_put(props, "NSHTTPCookieDomain", nsstr("armconverter.com"));
	dict_put(props, "NSHTTPCookiePath", nsstr("/"));
	dict_put(props, "NSHTTPCookieSecure", nsstr("TRUE"));
	{
		id (*cwp)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
		cookie = cwp(CK, sel_registerName("cookieWithProperties:"), props);
	}
	storage = cls0(ST, "sharedHTTPCookieStorage");
	if (storage && cookie && store_has(storage, "setCookie:"))
		msg1(storage, "setCookie:", cookie);
}

static void remember_arm_session(id val) {
	id s = store_str(val);
	id cur;
	if (!s || !store_cstr(s)[0])
		return;
	cur = arm_session_value();
	if (cur && streq(cur, store_cstr(s))) {
		plant_arm_cookie(s);
		return;
	}
	shared_set("armSession", s);
	plant_arm_cookie(s);
}

static id cookie_named_for_url(const char *urlc, const char *name) {
	Class ST, CK, UR;
	id storage, url, cookies;
	NSInteger n, i;
	if (!urlc || !name)
		return 0;
	ST = objc_getClass("NSHTTPCookieStorage");
	CK = objc_getClass("NSHTTPCookie");
	UR = objc_getClass("NSURL");
	storage = ST ? cls0(ST, "sharedHTTPCookieStorage") : 0;
	url = UR ? msg1((id)UR, "URLWithString:", nsstr(urlc)) : 0;
	if (!storage || !url || !store_has(storage, "cookiesForURL:"))
		return 0;
	cookies = msg1(storage, "cookiesForURL:", url);
	if (!cookies || !store_has(cookies, "objectAtIndex:"))
		return 0;
	n = 0;
	if (store_has(cookies, "count")) {
		NSInteger (*cn)(id, SEL) = (NSInteger(*)(id, SEL))objc_msgSend;
		n = cn(cookies, sel_registerName("count"));
	}
	for (i = 0; i < n && i < 64; i++) {
		id ck, kn, kv;
		id (*at)(id, SEL, NSInteger) = (id(*)(id, SEL, NSInteger))objc_msgSend;
		ck = at(cookies, sel_registerName("objectAtIndex:"), i);
		if (!ck)
			continue;
		kn = store_has(ck, "name") ? store_str(msg0(ck, "name")) : 0;
		if (!streq(kn, name))
			continue;
		kv = store_has(ck, "value") ? store_str(msg0(ck, "value")) : 0;
		if (kv && store_cstr(kv)[0])
			return kv;
	}
	return 0;
}

static void harvest_arm_session(void) {
	id v = cookie_named_for_url("https://armconverter.com/", "session");
	if (!v)
		v = cookie_named_for_url("https://armconverter.com/decryptedappstore/", "session");
	if (v)
		remember_arm_session(v);
	else {
		id saved = arm_session_value();
		if (saved)
			plant_arm_cookie(saved);
	}
}

static void remember_session_from_header(id header) {
	char buf[900];
	if (!extract_cookie_value(buf, 900, store_cstr(store_str(header)), "session"))
		return;
	if (buf[0])
		remember_arm_session(nsstr(buf));
}

static id gSnNote;

static void post_session(void) {
	ensure_ids();
	if (!gSnNote)
		gSnNote = live_str("com.velora.hz.session");
	CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(), gSnNote, 0, 0, 1);
	notify_post("com.velora.hz.session");
}

static void keep_tick(id self, SEL sel);

static void schedule_keep(id self, double sec) {
	if (!self || !store_has(self, "performSelector:withObject:afterDelay:"))
		return;
	{
		void (*d)(id, SEL, SEL, id, double) = (void (*)(id, SEL, SEL, id, double))objc_msgSend;
		d(self, sel_registerName("performSelector:withObject:afterDelay:"), sel_registerName("keepAlive"), 0, sec);
	}
}

static void start_session_keeper(void) {
	static int once;
	Class super, c;
	id keeper;
	if (once)
		return;
	once = 1;
	capture_apple_session();
	harvest_arm_session();
	if (!purchase_daemon() && !in_store_process())
		return;
	super = objc_getClass("NSObject");
	c = objc_getClass("VeloraSessionKeeper");
	if (!c && super) {
		c = objc_allocateClassPair(super, "VeloraSessionKeeper", 0);
		if (c) {
			class_addMethod(c, sel_registerName("keepAlive"), (void *)keep_tick, "v@:");
			objc_registerClassPair(c);
		}
	}
	if (!c)
		return;
	{
		id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
		keeper = msg0(al(c, sel_registerName("alloc")), "init");
	}
	if (!keeper)
		return;
	hold(keeper);
	schedule_keep(keeper, 2.0);
}

static void post_dl(void) {
	ensure_ids();
	CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(), gDlNote, 0, 0, 1);
	notify_post("com.velora.hz.download");
}

static void post_ft(void) {
	ensure_ids();
	CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(), gFtNote, 0, 0, 1);
	notify_post("com.velora.hz.fetch");
}

static id gHold;

static void hold(id obj) {
	if (!obj)
		return;
	if (!gHold)
		gHold = new_array();
	msg1(gHold, "addObject:", obj);
}

static struct velora_block_desc {
	unsigned long reserved;
	unsigned long size;
	const char *signature;
};

static struct velora_block {
	void *isa;
	int flags;
	int reserved;
	void (*invoke)(void *, void *);
	struct velora_block_desc *descriptor;
};

static void velora_block_nop(void *block, void *a) {
	(void)block;
	(void)a;
}

static struct velora_block_desc gNopDesc = { 0, sizeof(struct velora_block), "v16@?0@8" };
static struct velora_block gNopBlock;

id velora_empty_block(void) {
	if (!gNopBlock.isa) {
		void *isa = dlsym(RTLD_DEFAULT, "_NSConcreteGlobalBlock");
		gNopBlock.isa = isa;
		gNopBlock.flags = (1 << 28) | (1 << 30);
		gNopBlock.reserved = 0;
		gNopBlock.invoke = velora_block_nop;
		gNopBlock.descriptor = &gNopDesc;
	}
	return gNopBlock.isa ? (id)&gNopBlock : 0;
}

static int class_has(Class c, const char *sel) {
	if (!c)
		return 0;
	unsigned char (*r)(Class, SEL, SEL) = (unsigned char (*)(Class, SEL, SEL))objc_msgSend;
	return r(c, sel_registerName("respondsToSelector:"), sel_registerName(sel)) ? 1 : 0;
}

static id make_purchase_with(id adam, id ext, const char *pricing) {
	Class SS = objc_getClass("SSPurchase");
	if (!SS)
		return 0;
	const char *a = store_cstr(adam);
	const char *e = store_cstr(ext);
	id guid = device_guid();
	const char *g = store_cstr(guid);
	char params[1200];
	int n = cat(params, 0, 1200, "productType=C&price=0&origPrice=0&pg=default&mt=8&pricingParameters=");
	n = cat(params, n, 1200, pricing && pricing[0] ? pricing : "STDQ");
	n = cat(params, n, 1200, "&hasAskedToFulfillPreorder=true&buyWithoutAuthorization=true&hasDoneAgeCheck=true&salableAdamId=");
	n = cat(params, n, 1200, a);
	n = cat(params, n, 1200, "&tId=");
	n = cat(params, n, 1200, a);
	if (e && e[0]) {
		n = cat(params, n, 1200, "&appExtVrsId=");
		n = cat(params, n, 1200, e);
		n = cat(params, n, 1200, "&softwareVersionExternalId=");
		n = cat(params, n, 1200, e);
		n = cat(params, n, 1200, "&softwareVersionExternalIdentifier=");
		n = cat(params, n, 1200, e);
		n = cat(params, n, 1200, "&externalVersionId=");
		n = cat(params, n, 1200, e);
	}
	if (g && g[0]) {
		n = cat(params, n, 1200, "&guid=");
		n = cat(params, n, 1200, g);
	}
	id pstr = nsstr(params);
	id purchase = 0;
	if (class_has(SS, "purchaseWithBuyParameters:")) {
		id (*pw)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
		purchase = pw(SS, sel_registerName("purchaseWithBuyParameters:"), pstr);
	}
	if (!purchase) {
		id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
		purchase = msg0(al(SS, sel_registerName("alloc")), "init");
		if (purchase && store_has(purchase, "setBuyParameters:"))
			msg1(purchase, "setBuyParameters:", pstr);
	}
	if (!purchase)
		return 0;
	if (store_has(purchase, "setIsRedownload:")) {
		void (*sb)(id, SEL, unsigned char) = (void (*)(id, SEL, unsigned char))objc_msgSend;
		sb(purchase, sel_registerName("setIsRedownload:"), pricing && pricing[0] == 'S' && pricing[3] == 'R' ? 1 : 1);
	}
	id dsid = account_dsid();
	if (dsid && store_has(purchase, "setAccountIdentifier:"))
		msg1(purchase, "setAccountIdentifier:", as_number(dsid) ? as_number(dsid) : dsid);
	if (guid && store_has(purchase, "setUniqueIdentifier:"))
		msg1(purchase, "setUniqueIdentifier:", guid);
	id num = as_number(adam);
	if (num && store_has(purchase, "setItemIdentifier:"))
		msg1(purchase, "setItemIdentifier:", num);
	id vern = as_number(ext);
	if (vern && store_has(purchase, "setSoftwareVersionExternalIdentifier:"))
		msg1(purchase, "setSoftwareVersionExternalIdentifier:", vern);
	Class MD = objc_getClass("SSDownloadMetadata");
	if (MD) {
		id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
		id meta = msg0(al(MD, sel_registerName("alloc")), "init");
		if (meta) {
			if (num && store_has(meta, "setItemIdentifier:"))
				msg1(meta, "setItemIdentifier:", num);
			if (vern && store_has(meta, "setSoftwareVersionExternalIdentifier:"))
				msg1(meta, "setSoftwareVersionExternalIdentifier:", vern);
			if (store_has(meta, "setKind:"))
				msg1(meta, "setKind:", nsstr("software"));
			if (store_has(purchase, "setDownloadMetadata:"))
				msg1(purchase, "setDownloadMetadata:", meta);
			hold(meta);
		}
	}
	return purchase;
}

static id make_purchase(id adam, id ext) {
	return make_purchase_with(adam, ext, "STDQ");
}

static void start_one_purchase(id purchase) {
	if (!purchase)
		return;
	hold(purchase);
	id (*awo)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
	id arr = awo(objc_getClass("NSArray"), sel_registerName("arrayWithObject:"), purchase);
	Class M = objc_getClass("SSPurchaseManager");
	id mgr = 0;
	if (M && class_has(M, "sharedManager"))
		mgr = cls0(M, "sharedManager");
	if (!mgr && M) {
		id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
		mgr = msg0(al(M, sel_registerName("alloc")), "init");
	}
	if (mgr) {
		hold(mgr);
		if (store_has(mgr, "startPurchases:")) {
			msg1(mgr, "startPurchases:", arr);
			return;
		}
		if (store_has(mgr, "startPurchase:withCompletionBlock:")) {
			id blk = velora_empty_block();
			if (blk) {
				id (*sp)(id, SEL, id, id) = (id(*)(id, SEL, id, id))objc_msgSend;
				sp(mgr, sel_registerName("startPurchase:withCompletionBlock:"), purchase, blk);
			}
			return;
		}
	}
	Class PR = objc_getClass("SSPurchaseRequest");
	if (!PR)
		return;
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	id obj = al(PR, sel_registerName("alloc"));
	id req = 0;
	if (obj && store_has(obj, "initWithPurchase:")) {
		id (*ip)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
		req = ip(obj, sel_registerName("initWithPurchase:"), purchase);
	} else if (obj && store_has(obj, "initWithPurchases:")) {
		id (*ip)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
		req = ip(obj, sel_registerName("initWithPurchases:"), arr);
	}
	if (req) {
		hold(req);
		if (store_has(req, "start"))
			msg0(req, "start");
	}
}

static const char *buy_price(id ext) {
	if (ext && store_cstr(ext)[0])
		return "STDRDL";
	if (store_cstr(store_str(shared_get("dlVersion")))[0])
		return "STDRDL";
	return "STDQ";
}

static void try_ss_purchase(id adam, id ext) {
	start_one_purchase(make_purchase_with(adam, ext, buy_price(ext)));
}

static void clear_pending(void) {
	gClaimAdam[0] = 0;
	gPurchaseBusy = 0;
}

static int pair_is(const char *s, const char *end, const char *key) {
	while (*key && s < end && *s == *key) {
		s++;
		key++;
	}
	return *key == 0 && s < end && *s == '=';
}

static int hay_plain(const char *h, const char *n) {
	int i, j;
	if (!h || !n || !n[0])
		return 0;
	for (i = 0; h[i]; i++) {
		for (j = 0; n[j] && h[i + j] && h[i + j] == n[j]; j++)
			;
		if (!n[j])
			return 1;
	}
	return 0;
}

static id rewrite_buy(id params) {
	id adam = store_str(shared_get("dlAdamId"));
	id ext = store_str(shared_get("dlVersionId"));
	const char *a = store_cstr(adam);
	const char *e = store_cstr(ext);
	const char *p = store_cstr(params);
	char out[1400];
	int n = 0;
	int wrote = 0;
	const char *s;
	if (!a[0] || !e[0] || !p[0])
		return params;
	if (!hay_plain(p, a))
		return params;
	s = p;
	while (*s) {
		const char *eop = s;
		int skip;
		while (*eop && *eop != '&')
			eop++;
		skip = pair_is(s, eop, "appExtVrsId") ||
			pair_is(s, eop, "softwareVersionExternalId") ||
			pair_is(s, eop, "externalVersionId") ||
			pair_is(s, eop, "softwareVersionExternalIdentifier");
		if (skip) {
			if (!wrote) {
				if (n)
					n = cat(out, n, 1400, "&");
				n = cat(out, n, 1400, "appExtVrsId=");
				n = cat(out, n, 1400, e);
				wrote = 1;
			}
		} else {
			if (n)
				n = cat(out, n, 1400, "&");
			while (s < eop && n < 1398)
				out[n++] = *s++;
			out[n] = 0;
		}
		s = *eop ? eop + 1 : eop;
	}
	if (!wrote) {
		if (n)
			n = cat(out, n, 1400, "&");
		n = cat(out, n, 1400, "appExtVrsId=");
		n = cat(out, n, 1400, e);
	}
	return nsstr(out);
}

static void (*orig_setBuySS)(id, SEL, id);
static void hook_setBuySS(id self, SEL sel, id params) {
	id r = rewrite_buy(params);
	if (orig_setBuySS)
		orig_setBuySS(self, sel, r ? r : params);
}

static void (*orig_setBuyASD)(id, SEL, id);
static void hook_setBuyASD(id self, SEL sel, id params) {
	id r = rewrite_buy(params);
	if (orig_setBuyASD)
		orig_setBuyASD(self, sel, r ? r : params);
}

static id (*orig_getBuySS)(id, SEL);
static id hook_getBuySS(id self, SEL sel) {
	id p = orig_getBuySS ? orig_getBuySS(self, sel) : 0;
	id r = rewrite_buy(p);
	return r ? r : p;
}

static void bump_dl_gen(void) {
	int g = (int)parse_ll(store_cstr(shared_get("dlGen"))) + 1;
	char tmp[16];
	char b[16];
	int t = 0, n = 0;
	if (g < 1)
		g = 1;
	while (g && t < 15) {
		tmp[t++] = (char)('0' + (g % 10));
		g /= 10;
	}
	while (t)
		b[n++] = tmp[--t];
	b[n] = 0;
	shared_set("dlGen", nsstr(b));
}

static void try_asd_purchase(id adam, id ext) {
	dlopen("/System/Library/PrivateFrameworks/AppStoreDaemon.framework/AppStoreDaemon", RTLD_LAZY);
	Class P = objc_getClass("ASDPurchase");
	if (!P)
		return;
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	Class M = objc_getClass("ASDPurchaseManager");
	id mgr = 0;
	if (M && class_has(M, "sharedManager"))
		mgr = cls0(M, "sharedManager");
	if (!mgr && M && class_has(M, "sharedInstance"))
		mgr = cls0(M, "sharedInstance");
	if (!mgr && M)
		mgr = msg0(al(M, sel_registerName("alloc")), "init");
	if (mgr)
		hold(mgr);
	const char *price = buy_price(ext);
	id purchase = msg0(al(P, sel_registerName("alloc")), "init");
	if (!purchase)
		return;
	id ss = make_purchase_with(adam, ext, price);
	id bp = (ss && store_has(ss, "buyParameters")) ? msg0(ss, "buyParameters") : 0;
	if (!bp) {
		char params[768];
		int n = cat(params, 0, 768, "productType=C&price=0&pricingParameters=");
		n = cat(params, n, 768, price);
		n = cat(params, n, 768, "&salableAdamId=");
		n = cat(params, n, 768, store_cstr(adam));
		if (store_cstr(ext)[0]) {
			n = cat(params, n, 768, "&appExtVrsId=");
			n = cat(params, n, 768, store_cstr(ext));
		}
		bp = nsstr(params);
	}
	if (bp && store_has(purchase, "setBuyParameters:"))
		msg1(purchase, "setBuyParameters:", bp);
	id num = as_number(adam);
	if (num && store_has(purchase, "setItemIdentifier:"))
		msg1(purchase, "setItemIdentifier:", num);
	if (store_has(purchase, "setIsRedownload:")) {
		void (*sb)(id, SEL, unsigned char) = (void (*)(id, SEL, unsigned char))objc_msgSend;
		sb(purchase, sel_registerName("setIsRedownload:"), 1);
	}
	hold(purchase);
	id blk = velora_empty_block();
	if (!mgr)
		return;
	if (store_has(mgr, "processPurchase:withCompletionHandler:")) {
		id (*fn)(id, SEL, id, id) = (id(*)(id, SEL, id, id))objc_msgSend;
		fn(mgr, sel_registerName("processPurchase:withCompletionHandler:"), purchase, blk);
	} else if (store_has(mgr, "startPurchase:withCompletionBlock:")) {
		id (*fn)(id, SEL, id, id) = (id(*)(id, SEL, id, id))objc_msgSend;
		fn(mgr, sel_registerName("startPurchase:withCompletionBlock:"), purchase, blk);
	}
}

static id apple_redownload_plist(id adam, id ext) {
	id guid = device_guid();
	id dsid = account_dsid();
	id d = new_dict();
	dict_put(d, "creditDisplay", nsstr(""));
	dict_put(d, "guid", guid);
	dict_put(d, "salableAdamId", as_number(adam) ? as_number(adam) : adam);
	id num = as_number(ext);
	if (num)
		dict_put(d, "appExtVrsId", num);
	else if (ext)
		dict_put(d, "appExtVrsId", ext);
	id body = plist_data(d);
	id plist = http_plist("https://buy.itunes.apple.com/WebObjects/MZFinance.woa/wa/redownloadProduct", body, dsid);
	if (!plist)
		plist = http_plist("https://p36-buy.itunes.apple.com/WebObjects/MZFinance.woa/wa/redownloadProduct", body, dsid);
	if (!plist)
		plist = http_plist("https://p25-buy.itunes.apple.com/WebObjects/MZFinance.woa/wa/redownloadProduct", body, dsid);
	return plist;
}

static int plist_failed(id plist) {
	if (!plist)
		return 1;
	id fail = msg1(plist, "objectForKey:", nsstr("failureType"));
	if (fail && store_cstr(store_str(fail))[0] && !streq(store_str(fail), "0"))
		return 1;
	id list = msg1(plist, "objectForKey:", nsstr("songList"));
	if (!list)
		list = msg1(plist, "objectForKey:", nsstr("items"));
	if (!list || !store_has(list, "objectAtIndex:"))
		return 1;
	return 0;
}

static void note_plist_error(id plist) {
	if (!plist)
		return;
	id msg = msg1(plist, "objectForKey:", nsstr("customerMessage"));
	if (!msg)
		msg = msg1(plist, "objectForKey:", nsstr("failureMessage"));
	id s = store_str(msg);
	if (s && store_cstr(s)[0])
		shared_set("dlError", s);
}

static void start_pending_purchase(void) {
	int gen;
	if (!purchase_daemon())
		return;
	id adam = store_str(shared_get("dlAdamId"));
	id ext = store_str(shared_get("dlVersionId"));
	id ver = store_str(shared_get("dlVersion"));
	if (!adam || !store_cstr(adam)[0])
		return;
	gen = (int)parse_ll(store_cstr(shared_get("dlGen")));
	if (gen && gen == gSeenGen)
		return;
	if (gen)
		gSeenGen = gen;
	if (!claim_purchase(adam))
		return;
	capture_apple_session();
	dlopen("/System/Library/PrivateFrameworks/StoreServices.framework/StoreServices", RTLD_LAZY);
	dlopen("/System/Library/PrivateFrameworks/iTunesStore.framework/iTunesStore", RTLD_LAZY);
	dlopen("/System/Library/PrivateFrameworks/AppStoreDaemon.framework/AppStoreDaemon", RTLD_LAZY);
	if (!is_long_digits(ext) && ver && store_cstr(ver)[0]) {
		id found = velora_resolve_ext(adam, ver);
		if (is_long_digits(found)) {
			ext = found;
			shared_set("dlVersionId", found);
		}
	}
	if (ver && store_cstr(ver)[0] && !is_long_digits(ext)) {
		shared_set("dlError", nsstr("This build has no App Store version id. Use TrollStore for this exact build."));
		clear_pending();
		return;
	}
	if (objc_getClass("SSPurchase"))
		try_ss_purchase(adam, ext);
	else
		try_asd_purchase(adam, ext);
	shared_set("dlError", nsstr(""));
	clear_pending();
}

static id dict_url(id d) {
	if (!d)
		return 0;
	const char *keys[] = { "URL", "url", "downloadURL", "download-url", "assetURL", "fullSizeURL", 0 };
	for (int i = 0; keys[i]; i++) {
		id u = store_str(msg1(d, "objectForKey:", nsstr(keys[i])));
		if (u && store_cstr(u)[0])
			return u;
	}
	return 0;
}

static id flavor_of(id d) {
	if (!d)
		return 0;
	const char *keys[] = { "flavor", "asset-flavor", "platform", "device-family", "kind", "type", 0 };
	for (int i = 0; keys[i]; i++) {
		id v = msg1(d, "objectForKey:", nsstr(keys[i]));
		if (v)
			return v;
	}
	id info = msg1(d, "objectForKey:", nsstr("asset-info"));
	if (info) {
		id v = msg1(info, "objectForKey:", nsstr("flavor"));
		if (v)
			return v;
	}
	id meta = msg1(d, "objectForKey:", nsstr("metadata"));
	if (meta)
		return flavor_of(meta);
	return 0;
}

static int flavor_pad(id v) {
	return hay_ci(v, "ipad") || streq(store_str(v), "2");
}

static int flavor_phone(id v) {
	return hay_ci(v, "iphone") || hay_ci(v, "ios") || hay_ci(v, "phone") || hay_ci(v, "universal") || streq(store_str(v), "1");
}

static id pick_asset_url(id song, int want_pad) {
	if (!song)
		return 0;
	id assets = msg1(song, "objectForKey:", nsstr("assets"));
	id phone = 0, pad = 0, any = 0;
	NSInteger n = 0;
	if (assets && store_has(assets, "count")) {
		NSInteger (*c)(id, SEL) = (NSInteger(*)(id, SEL))objc_msgSend;
		n = c(assets, sel_registerName("count"));
	}
	id (*at)(id, SEL, NSInteger) = (id(*)(id, SEL, NSInteger))objc_msgSend;
	for (NSInteger i = 0; i < n; i++) {
		id a = at(assets, sel_registerName("objectAtIndex:"), i);
		id u = dict_url(a);
		if (!u)
			u = dict_url(msg1(a, "objectForKey:", nsstr("asset-info")));
		if (!u)
			continue;
		id fl = flavor_of(a);
		if (flavor_pad(fl) || hay_ci(u, "ipad")) {
			if (!pad)
				pad = u;
		} else if (flavor_phone(fl)) {
			if (!phone)
				phone = u;
		} else if (!any)
			any = u;
	}
	id top = dict_url(song);
	id fls = flavor_of(song);
	if (top) {
		if (flavor_pad(fls) || hay_ci(top, "ipad")) {
			if (!pad)
				pad = top;
		} else if (!phone)
			phone = top;
	}
	if (want_pad)
		return pad ? pad : (any ? any : 0);
	if (phone)
		return phone;
	if (any)
		return any;
	return 0;
}

static id song_ipa_url(id plist) {
	id list = plist ? msg1(plist, "objectForKey:", nsstr("songList")) : 0;
	if (!list)
		list = plist ? msg1(plist, "objectForKey:", nsstr("items")) : 0;
	if (!list || !store_has(list, "objectAtIndex:"))
		return 0;
	int want_pad = is_pad_device();
	id (*at)(id, SEL, NSInteger) = (id(*)(id, SEL, NSInteger))objc_msgSend;
	NSInteger (*cnt)(id, SEL) = (NSInteger(*)(id, SEL))objc_msgSend;
	NSInteger n = cnt(list, sel_registerName("count"));
	id fallback = 0;
	for (NSInteger i = 0; i < n; i++) {
		id song = at(list, sel_registerName("objectAtIndex:"), i);
		id u = pick_asset_url(song, want_pad);
		if (!u)
			continue;
		id fl = flavor_of(song);
		if (!want_pad && (flavor_pad(fl) || hay_ci(u, "ipad"))) {
			if (!fallback)
				fallback = u;
			continue;
		}
		return u;
	}
	return fallback;
}

static int looks_ipa_url(id s) {
	id t = store_str(s);
	if (!t)
		return 0;
	if (hay_ci(t, ".ipa"))
		return 1;
	if (hay_ci(t, "iosapps.itunes.apple.com"))
		return 1;
	if (hay_ci(t, "itunes-assets"))
		return 1;
	if (hay_ci(t, "mzstatic.com") && hay_ci(t, "http"))
		return 0;
	return hay_ci(t, "https://") && hay_ci(t, "apple.com") && hay_ci(t, "download");
}

static id find_ipa_value(id obj, int depth) {
	if (!obj || depth > 6)
		return 0;
	if (looks_ipa_url(obj))
		return store_str(obj);
	if (store_has(obj, "objectAtIndex:") && store_has(obj, "count")) {
		NSInteger (*cnt)(id, SEL) = (NSInteger(*)(id, SEL))objc_msgSend;
		id (*at)(id, SEL, NSInteger) = (id(*)(id, SEL, NSInteger))objc_msgSend;
		NSInteger n = cnt(obj, sel_registerName("count"));
		if (n > 80)
			n = 80;
		for (NSInteger i = 0; i < n; i++) {
			id hit = find_ipa_value(at(obj, sel_registerName("objectAtIndex:"), i), depth + 1);
			if (hit)
				return hit;
		}
	}
	if (store_has(obj, "allValues")) {
		id vals = msg0(obj, "allValues");
		return find_ipa_value(vals, depth + 1);
	}
	return 0;
}

static id apple_song_plist(id adam, id ext) {
	id guid = device_guid();
	id dsid = account_dsid();
	id body = volume_payload(adam, guid, ext);
	id plist = http_plist("https://buy.itunes.apple.com/WebObjects/MZFinance.woa/wa/volumeStoreDownloadProduct", body, dsid);
	if (!plist)
		plist = http_plist("https://p25-buy.itunes.apple.com/WebObjects/MZFinance.woa/wa/volumeStoreDownloadProduct", body, dsid);
	if (!plist)
		plist = http_plist("https://p36-buy.itunes.apple.com/WebObjects/MZFinance.woa/wa/volumeStoreDownloadProduct", body, dsid);
	return plist;
}

static int same_ver_str(id a, id b) {
	int pa[8], pb[8];
	int na = 0, nb = 0, n, i, cur, any;
	const char *x = store_cstr(store_str(a));
	const char *y = store_cstr(store_str(b));
	const char *p;
	if (!x[0] || !y[0])
		return 0;
	if (streq(store_str(a), store_cstr(store_str(b))))
		return 1;
	cur = 0;
	any = 0;
	p = x;
	while (*p && na < 8) {
		if (*p >= '0' && *p <= '9') {
			cur = cur * 10 + (*p - '0');
			any = 1;
			p++;
			continue;
		}
		if (any) {
			pa[na++] = cur;
			cur = 0;
			any = 0;
		}
		p++;
	}
	if (any && na < 8)
		pa[na++] = cur;
	cur = 0;
	any = 0;
	p = y;
	while (*p && nb < 8) {
		if (*p >= '0' && *p <= '9') {
			cur = cur * 10 + (*p - '0');
			any = 1;
			p++;
			continue;
		}
		if (any) {
			pb[nb++] = cur;
			cur = 0;
			any = 0;
		}
		p++;
	}
	if (any && nb < 8)
		pb[nb++] = cur;
	if (na < 1 || nb < 1)
		return 0;
	n = na > nb ? na : nb;
	for (i = 0; i < n; i++) {
		int va = i < na ? pa[i] : 0;
		int vb = i < nb ? pb[i] : 0;
		if (va != vb)
			return 0;
	}
	return 1;
}

static id cache_ext_for_ver(id adam, id ver) {
	id path = cache_path(adam);
	id (*acf)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
	id rows = path ? acf(objc_getClass("NSArray"), sel_registerName("arrayWithContentsOfFile:"), path) : 0;
	NSInteger n = 0;
	if (rows && store_has(rows, "count")) {
		NSInteger (*c)(id, SEL) = (NSInteger(*)(id, SEL))objc_msgSend;
		n = c(rows, sel_registerName("count"));
	}
	id (*at)(id, SEL, NSInteger) = (id(*)(id, SEL, NSInteger))objc_msgSend;
	for (NSInteger i = 0; i < n; i++) {
		id row = at(rows, sel_registerName("objectAtIndex:"), i);
		id rv = row ? msg1(row, "objectForKey:", nsstr("version")) : 0;
		id ext = row ? msg1(row, "objectForKey:", nsstr("externalId")) : 0;
		if (same_ver_str(rv, ver) && is_long_digits(ext))
			return store_str(ext);
	}
	return 0;
}

static id enders_ext_for_ver(id adam, id ver) {
	if (!adam || !ver)
		return 0;
	const char *regions[] = { "us", "gb", "tr", "de", 0 };
	for (int r = 0; regions[r]; r++) {
		char url[420];
		int n = 0;
		const char *a = "https://cdn.jsdelivr.net/gh/enderspearl184/app-versions@main/app_data/";
		while (a[n]) {
			url[n] = a[n];
			n++;
		}
		const char *reg = regions[r];
		int i = 0;
		while (reg[i])
			url[n++] = reg[i++];
		url[n++] = '/';
		const char *idc = store_cstr(adam);
		i = 0;
		while (idc[i] && n < 400)
			url[n++] = idc[i++];
		const char *z = ".json";
		i = 0;
		while (z[i])
			url[n++] = z[i++];
		url[n] = 0;
		id (*uws)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
		id nsurl = uws(objc_getClass("NSURL"), sel_registerName("URLWithString:"), nsstr(url));
		if (!nsurl)
			continue;
		id resp = 0, err = 0;
		id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
		id req = msg0(al(objc_getClass("NSMutableURLRequest"), sel_registerName("alloc")), "init");
		if (!req)
			continue;
		msg1(req, "setURL:", nsurl);
		msg1(req, "setHTTPMethod:", nsstr("GET"));
		id (*send)(Class, SEL, id, id *, id *) = (id(*)(Class, SEL, id, id *, id *))objc_msgSend;
		id data = send(objc_getClass("NSURLConnection"), sel_registerName("sendSynchronousRequest:returningResponse:error:"), req, &resp, &err);
		if (!data)
			continue;
		id jsonerr = 0;
		id (*js)(Class, SEL, id, NSInteger, id *) = (id(*)(Class, SEL, id, NSInteger, id *))objc_msgSend;
		id arr = js(objc_getClass("NSJSONSerialization"), sel_registerName("JSONObjectWithData:options:error:"), data, 0, &jsonerr);
		if (!arr || !store_has(arr, "count"))
			continue;
		NSInteger (*cnt)(id, SEL) = (NSInteger(*)(id, SEL))objc_msgSend;
		id (*at)(id, SEL, NSInteger) = (id(*)(id, SEL, NSInteger))objc_msgSend;
		NSInteger c = cnt(arr, sel_registerName("count"));
		for (NSInteger k = 0; k < c; k++) {
			id rec = at(arr, sel_registerName("objectAtIndex:"), k);
			id name = rec ? msg1(rec, "objectForKey:", nsstr("version_name")) : 0;
			id vid = rec ? msg1(rec, "objectForKey:", nsstr("version_id")) : 0;
			if (same_ver_str(name, ver) && store_cstr(store_str(vid))[0])
				return store_str(vid);
		}
	}
	return 0;
}

static int is_long_digits(id v) {
	const char *c = store_cstr(store_str(v));
	int n = 0;
	if (!c[0])
		return 0;
	for (; *c; c++) {
		if (*c < '0' || *c > '9')
			return 0;
		n++;
	}
	return n >= 8;
}

static id http_get_data(const char *urlc) {
	if (!urlc || !urlc[0])
		return 0;
	id (*uws)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
	id nsurl = uws(objc_getClass("NSURL"), sel_registerName("URLWithString:"), nsstr(urlc));
	if (!nsurl)
		return 0;
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	id req = msg0(al(objc_getClass("NSMutableURLRequest"), sel_registerName("alloc")), "init");
	if (!req)
		return 0;
	msg1(req, "setURL:", nsurl);
	msg1(req, "setHTTPMethod:", nsstr("GET"));
	id (*sv)(id, SEL, id, id) = (id(*)(id, SEL, id, id))objc_msgSend;
	sv(req, sel_registerName("setValue:forHTTPHeaderField:"), nsstr("Mozilla/5.0"), nsstr("User-Agent"));
	sv(req, sel_registerName("setValue:forHTTPHeaderField:"), nsstr("application/json,text/html,*/*"), nsstr("Accept"));
	if (store_has(req, "setTimeoutInterval:")) {
		void (*sto)(id, SEL, double) = (void (*)(id, SEL, double))objc_msgSend;
		sto(req, sel_registerName("setTimeoutInterval:"), 8.0);
	}
	id resp = 0, err = 0;
	id (*send)(Class, SEL, id, id *, id *) = (id(*)(Class, SEL, id, id *, id *))objc_msgSend;
	return send(objc_getClass("NSURLConnection"), sel_registerName("sendSynchronousRequest:returningResponse:error:"), req, &resp, &err);
}

static id http_json(const char *urlc) {
	id data = http_get_data(urlc);
	if (!data)
		return 0;
	id jsonerr = 0;
	id (*js)(Class, SEL, id, NSInteger, id *) = (id(*)(Class, SEL, id, NSInteger, id *))objc_msgSend;
	return js(objc_getClass("NSJSONSerialization"), sel_registerName("JSONObjectWithData:options:error:"), data, 0, &jsonerr);
}

static id web_lookup(id adam, id ver) {
	char url[1200];
	int n = cat(url, 0, 1200, "https://velorabestweak.com/api/store/lookup?id=");
	n = cat(url, n, 1200, store_cstr(adam));
	if (ver && store_cstr(ver)[0]) {
		n = cat(url, n, 1200, "&version=");
		n = cat(url, n, 1200, store_cstr(ver));
	}
	id name = store_str(shared_get("dlName"));
	if (name && store_cstr(name)[0]) {
		id enc = encode_query(name);
		n = cat(url, n, 1200, "&name=");
		n = cat(url, n, 1200, store_cstr(enc ? enc : name));
	}
	return http_json(url);
}

static id web_ext_for_ver(id adam, id ver) {
	id json = web_lookup(adam, ver);
	if (!json)
		return 0;
	id resolved = msg1(json, "objectForKey:", nsstr("resolved"));
	id ext = resolved ? msg1(resolved, "objectForKey:", nsstr("externalId")) : 0;
	if (is_long_digits(ext))
		return store_str(ext);
	id vers = msg1(json, "objectForKey:", nsstr("versions"));
	NSInteger n = 0;
	if (vers && store_has(vers, "count")) {
		NSInteger (*c)(id, SEL) = (NSInteger(*)(id, SEL))objc_msgSend;
		n = c(vers, sel_registerName("count"));
	}
	id (*at)(id, SEL, NSInteger) = (id(*)(id, SEL, NSInteger))objc_msgSend;
	for (NSInteger i = 0; i < n; i++) {
		id row = at(vers, sel_registerName("objectAtIndex:"), i);
		id rv = row ? msg1(row, "objectForKey:", nsstr("version")) : 0;
		id rid = row ? msg1(row, "objectForKey:", nsstr("externalId")) : 0;
		if (!rid)
			rid = row ? msg1(row, "objectForKey:", nsstr("versionId")) : 0;
		if (!rid)
			rid = row ? msg1(row, "objectForKey:", nsstr("verId")) : 0;
		if (same_ver_str(rv, ver) && is_long_digits(rid))
			return store_str(rid);
	}
	return 0;
}

static id web_ipa_for_ver(id adam, id ver) {
	id json = web_lookup(adam, ver);
	id resolved = json ? msg1(json, "objectForKey:", nsstr("resolved")) : 0;
	id url = resolved ? store_str(msg1(resolved, "objectForKey:", nsstr("ipaUrl"))) : 0;
	if (url && store_cstr(url)[0])
		return url;
	return 0;
}

static id web_ipa_direct(id adam, id ver) {
	char url[1200];
	int n = cat(url, 0, 1200, "https://velorabestweak.com/api/store/ipa?format=json&id=");
	n = cat(url, n, 1200, store_cstr(adam));
	if (ver && store_cstr(ver)[0]) {
		n = cat(url, n, 1200, "&version=");
		n = cat(url, n, 1200, store_cstr(ver));
	}
	{
		id bid = store_str(shared_get("dlBundleId"));
		if (bid && store_cstr(bid)[0]) {
			n = cat(url, n, 1200, "&bundleId=");
			n = cat(url, n, 1200, store_cstr(bid));
		}
	}
	id name = store_str(shared_get("dlName"));
	if (name && store_cstr(name)[0]) {
		id enc = encode_query(name);
		n = cat(url, n, 1200, "&name=");
		n = cat(url, n, 1200, store_cstr(enc ? enc : name));
	}
	id json = http_json(url);
	id u = json ? store_str(msg1(json, "objectForKey:", nsstr("ipaUrl"))) : 0;
	if (!u || !is_direct_ipa_url(u))
		u = json ? store_str(msg1(json, "objectForKey:", nsstr("downloadUrl"))) : 0;
	if (u && store_cstr(u)[0])
		return u;
	return 0;
}

id velora_resolve_ext(id adam, id ver) {
	if (!adam)
		return 0;
	id hit = cache_ext_for_ver(adam, ver);
	if (is_long_digits(hit))
		return hit;
	hit = web_ext_for_ver(adam, ver);
	if (is_long_digits(hit))
		return hit;
	hit = enders_ext_for_ver(adam, ver);
	if (is_long_digits(hit))
		return hit;
	if (!in_store_process())
		return 0;
	dlopen("/System/Library/PrivateFrameworks/StoreServices.framework/StoreServices", RTLD_LAZY);
	id plist = apple_song_plist(adam, 0);
	id meta = song_meta(plist);
	id ids = 0;
	if (meta)
		ids = msg1(meta, "objectForKey:", nsstr("softwareVersionExternalIdentifiers"));
	if (!ids && plist)
		ids = msg1(plist, "objectForKey:", nsstr("softwareVersionExternalIdentifiers"));
	if (!ids || !store_has(ids, "objectAtIndex:"))
		return 0;
	NSInteger (*cnt)(id, SEL) = (NSInteger(*)(id, SEL))objc_msgSend;
	id (*at)(id, SEL, NSInteger) = (id(*)(id, SEL, NSInteger))objc_msgSend;
	NSInteger n = cnt(ids, sel_registerName("count"));
	if (n < 1 || !ver || !store_cstr(store_str(ver))[0])
		return 0;
	{
		NSInteger i;
		NSInteger seen = 0;
		for (i = n - 1; i >= 0 && seen < 24; i--, seen++) {
			id ident = store_str(at(ids, sel_registerName("objectAtIndex:"), i));
			if (!is_long_digits(ident))
				continue;
			id one = apple_song_plist(adam, ident);
			id m2 = song_meta(one);
			id vs = m2 ? msg1(m2, "objectForKey:", nsstr("bundleShortVersionString")) : 0;
			if (same_ver_str(vs, ver))
				return ident;
		}
	}
	return 0;
}

static void arm_slug(char *out, int cap, const char *name) {
	int n = 0, dash = 0;
	if (!out || cap < 4)
		return;
	if (!name)
		name = "";
	while (*name && n < cap - 1) {
		unsigned char ch = (unsigned char)*name++;
		if (ch >= 'A' && ch <= 'Z')
			ch = (unsigned char)(ch + 32);
		if ((ch >= 'a' && ch <= 'z') || (ch >= '0' && ch <= '9')) {
			out[n++] = (char)ch;
			dash = 0;
		} else if (n && !dash) {
			out[n++] = '-';
			dash = 1;
		}
	}
	while (n > 0 && out[n - 1] == '-')
		n--;
	if (!n) {
		out[0] = 'a';
		out[1] = 'p';
		out[2] = 'p';
		n = 3;
	}
	out[n] = 0;
}

id velora_arm_store_page(id adam, id name) {
	const char *idc = store_cstr(adam);
	if (!idc[0])
		return 0;
	char slug[96];
	arm_slug(slug, 96, store_cstr(name));
	char buf[360];
	int n = cat(buf, 0, 360, "https://armconverter.com/store/us/app/");
	n = cat(buf, n, 360, slug);
	n = cat(buf, n, 360, "/id");
	cat(buf, n, 360, idc);
	return nsstr(buf);
}

id velora_find_ipa_url(id adam, id ext) {
	(void)ext;
	if (!adam)
		return 0;
	id ver = store_str(shared_get("dlVersion"));
	id web = web_ipa_for_ver(adam, ver);
	if (web && store_cstr(web)[0])
		return store_str(web);
	id direct = web_ipa_direct(adam, ver);
	if (direct && store_cstr(direct)[0])
		return store_str(direct);
	return velora_arm_store_page(adam, store_str(shared_get("dlName")));
}

static id encode_query(id s) {
	if (!s)
		return 0;
	if (store_has(s, "stringByAddingPercentEncodingWithAllowedCharacters:")) {
		id set = cls0(objc_getClass("NSCharacterSet"), "alphanumericCharacterSet");
		id extra = msg0(objc_getClass("NSMutableCharacterSet"), 0);
		(void)extra;
		id (*enc)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
		id out = enc(s, sel_registerName("stringByAddingPercentEncodingWithAllowedCharacters:"), set);
		if (out)
			return out;
	}
	if (store_has(s, "stringByAddingPercentEscapesUsingEncoding:")) {
		id (*enc)(id, SEL, unsigned long) = (id(*)(id, SEL, unsigned long))objc_msgSend;
		return enc(s, sel_registerName("stringByAddingPercentEscapesUsingEncoding:"), 4);
	}
	return s;
}

static void open_nsurl_now(id nsurl) {
	if (!nsurl)
		return;
	id app = cls0(objc_getClass("UIApplication"), "sharedApplication");
	if (!app)
		return;
	id opts = cls0(objc_getClass("NSDictionary"), "dictionary");
	if (store_has(app, "openURL:options:completionHandler:")) {
		void (*op)(id, SEL, id, id, id) = (void (*)(id, SEL, id, id, id))objc_msgSend;
		op(app, sel_registerName("openURL:options:completionHandler:"), nsurl, opts, 0);
		return;
	}
	if (store_has(app, "openURL:"))
		msg1(app, "openURL:", nsurl);
}

static void runner_open(id self, SEL sel, id url) {
	(void)self;
	(void)sel;
	open_nsurl_now(url);
}

static id url_runner(void) {
	static id runner;
	if (runner)
		return runner;
	Class c = objc_getClass("VeloraURLRunner");
	if (!c) {
		Class super = objc_getClass("NSObject");
		c = super ? objc_allocateClassPair(super, "VeloraURLRunner", 0) : 0;
		if (c) {
			class_addMethod(c, sel_registerName("openURL:"), (void *)runner_open, "v@:@");
			objc_registerClassPair(c);
		}
	}
	if (!c)
		return 0;
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	runner = msg0(al(c, sel_registerName("alloc")), "init");
	hold(runner);
	return runner;
}

static void open_nsurl(id nsurl) {
	if (!nsurl)
		return;
	Class T = objc_getClass("NSThread");
	unsigned char (*ismain)(Class, SEL) = (unsigned char (*)(Class, SEL))objc_msgSend;
	if (!T || ismain(T, sel_registerName("isMainThread"))) {
		open_nsurl_now(nsurl);
		return;
	}
	id r = url_runner();
	if (r && store_has(r, "performSelectorOnMainThread:withObject:waitUntilDone:")) {
		hold(nsurl);
		void (*pm)(id, SEL, SEL, id, unsigned char) = (void (*)(id, SEL, SEL, id, unsigned char))objc_msgSend;
		pm(r, sel_registerName("performSelectorOnMainThread:withObject:waitUntilDone:"),
			sel_registerName("openURL:"), nsurl, 0);
		return;
	}
	open_nsurl_now(nsurl);
}

static int bundle_installed(const char *bid) {
	Class LS = objc_getClass("LSApplicationWorkspace");
	id ws = LS ? cls0(LS, "defaultWorkspace") : 0;
	if (!ws)
		return 0;
	if (store_has(ws, "applicationIsInstalled:")) {
		unsigned char (*ok)(id, SEL, id) = (unsigned char (*)(id, SEL, id))objc_msgSend;
		if (ok(ws, sel_registerName("applicationIsInstalled:"), nsstr(bid)))
			return 1;
	}
	return 0;
}

int velora_trollstore_ok(void) {
	return 1;
}

static id encode_url_query(id s) {
	const char *in;
	char buf[1600];
	int n = 0;
	static const char *hex = "0123456789ABCDEF";
	in = store_cstr(s);
	if (!in[0])
		return 0;
	while (*in && n < 1550) {
		unsigned char ch = (unsigned char)*in++;
		if ((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z') || (ch >= '0' && ch <= '9') || ch == '-' || ch == '_' || ch == '.' || ch == '~')
			buf[n++] = (char)ch;
		else {
			buf[n++] = '%';
			buf[n++] = hex[ch >> 4];
			buf[n++] = hex[ch & 15];
		}
	}
	buf[n] = 0;
	return nsstr(buf);
}

static void open_trollstore_ipa(id ipaUrl) {
	id enc = encode_url_query(store_str(ipaUrl));
	if (!enc)
		return;
	id schemes[3];
	int s;
	schemes[0] = msg1(nsstr("apple-magnifier://install?url="), "stringByAppendingString:", enc);
	schemes[1] = msg1(nsstr("trollstore://install?url="), "stringByAppendingString:", enc);
	schemes[2] = 0;
	for (s = 0; schemes[s]; s++) {
		id (*uws)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
		id nsurl = uws(objc_getClass("NSURL"), sel_registerName("URLWithString:"), schemes[s]);
		if (nsurl)
			open_nsurl_now(nsurl);
	}
	int (*spawn)(int *, const char *, const void *, const void *, char *const *, char *const *) =
		(int (*)(int *, const char *, const void *, const void *, char *const *, char *const *))dlsym(RTLD_DEFAULT, "posix_spawn");
	int (*acc)(const char *, int) = (int (*)(const char *, int))dlsym(RTLD_DEFAULT, "access");
	char **env = (char **)dlsym(RTLD_DEFAULT, "environ");
	if (!spawn)
		return;
	const char *bins[] = {
		"/var/jb/usr/bin/uiopen",
		"/usr/bin/uiopen",
		"/var/jb/usr/bin/open",
		"/usr/bin/open",
		0,
	};
	int i;
	for (s = 0; schemes[s]; s++) {
		const char *u = store_cstr(schemes[s]);
		if (!u || !u[0])
			continue;
		for (i = 0; bins[i]; i++) {
			int pid = 0;
			char *argv[3];
			if (acc && acc(bins[i], 0) != 0)
				continue;
			argv[0] = (char *)bins[i];
			argv[1] = (char *)u;
			argv[2] = 0;
			if (spawn(&pid, bins[i], 0, 0, argv, env) == 0)
				return;
		}
	}
}

static void apply_store_headers(id req, id dsid) {
	apply_apple_auth(req, dsid);
}

static void apply_arm_headers(id req) {
	id (*sv)(id, SEL, id, id) = (id(*)(id, SEL, id, id))objc_msgSend;
	Class ST, CK, UR;
	id storage, url, cookies, fields, jar, session;
	char merged[1400];
	harvest_arm_session();
	sv(req, sel_registerName("setValue:forHTTPHeaderField:"),
		nsstr("Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1"),
		nsstr("User-Agent"));
	sv(req, sel_registerName("setValue:forHTTPHeaderField:"), nsstr("https://armconverter.com"), nsstr("Origin"));
	sv(req, sel_registerName("setValue:forHTTPHeaderField:"), nsstr("https://armconverter.com/decryptedappstore"), nsstr("Referer"));
	sv(req, sel_registerName("setValue:forHTTPHeaderField:"), nsstr("application/json,text/plain,*/*"), nsstr("Accept"));
	ST = objc_getClass("NSHTTPCookieStorage");
	CK = objc_getClass("NSHTTPCookie");
	UR = objc_getClass("NSURL");
	storage = ST ? cls0(ST, "sharedHTTPCookieStorage") : 0;
	url = UR ? msg1((id)UR, "URLWithString:", nsstr("https://armconverter.com/")) : 0;
	jar = 0;
	if (storage && url && store_has(storage, "cookiesForURL:") && CK && class_has(CK, "requestHeaderFieldsWithCookies:")) {
		cookies = msg1(storage, "cookiesForURL:", url);
		if (cookies) {
			id (*hdr)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
			fields = hdr(CK, sel_registerName("requestHeaderFieldsWithCookies:"), cookies);
			jar = fields ? msg1(fields, "objectForKey:", nsstr("Cookie")) : 0;
		}
	}
	session = arm_session_value();
	merged[0] = 0;
	if (session && store_cstr(session)[0])
		merge_cookie_jar(merged, 1400, store_cstr(jar), "session", store_cstr(session));
	else if (jar && store_cstr(jar)[0])
		cat(merged, 0, 1400, store_cstr(jar));
	if (merged[0])
		sv(req, sel_registerName("setValue:forHTTPHeaderField:"), nsstr(merged), nsstr("Cookie"));
}

static volatile int gIpaDone;
static volatile int gIpaOk;
static id gIpaDestPath;
static id gIpaDestURL;
static id gIpaToken;

static int file_is_ipa_path(id path) {
	if (!path)
		return 0;
	id (*fh)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
	id h = fh(objc_getClass("NSFileHandle"), sel_registerName("fileHandleForReadingAtPath:"), path);
	if (!h)
		return 0;
	id (*rd)(id, SEL, unsigned long) = (id(*)(id, SEL, unsigned long))objc_msgSend;
	id d = store_has(h, "readDataOfLength:") ? rd(h, sel_registerName("readDataOfLength:"), 4) : 0;
	if (store_has(h, "closeFile"))
		msg0(h, "closeFile");
	if (!d || !store_has(d, "length") || !store_has(d, "bytes"))
		return 0;
	NSInteger (*ln)(id, SEL) = (NSInteger(*)(id, SEL))objc_msgSend;
	if (ln(d, sel_registerName("length")) < 2)
		return 0;
	const unsigned char *(*by)(id, SEL) = (const unsigned char *(*)(id, SEL))objc_msgSend;
	const unsigned char *b = by(d, sel_registerName("bytes"));
	return b && b[0] == 'P' && b[1] == 'K';
}

static void ipa_session_finish(id self, SEL sel, id session, id task, id location) {
	(void)self;
	(void)sel;
	(void)session;
	(void)task;
	if (!location || !gIpaDestURL) {
		gIpaOk = 0;
		gIpaDone = 1;
		return;
	}
	id fm = cls0(objc_getClass("NSFileManager"), "defaultManager");
	if (fm && store_has(fm, "removeItemAtURL:error:"))
		msg2(fm, "removeItemAtURL:error:", gIpaDestURL, 0);
	unsigned char ok = 0;
	if (fm && store_has(fm, "copyItemAtURL:toURL:error:")) {
		unsigned char (*cp)(id, SEL, id, id, id *) = (unsigned char (*)(id, SEL, id, id, id *))objc_msgSend;
		ok = cp(fm, sel_registerName("copyItemAtURL:toURL:error:"), location, gIpaDestURL, 0) ? 1 : 0;
	}
	gIpaOk = (ok && file_is_ipa_path(gIpaDestPath)) ? 1 : 0;
	gIpaDone = 1;
}

static void ipa_session_complete(id self, SEL sel, id session, id task, id err) {
	(void)self;
	(void)sel;
	(void)session;
	(void)task;
	if (gIpaDone)
		return;
	if (err)
		gIpaOk = 0;
	gIpaDone = 1;
}

static id ipa_sink(void) {
	static id sink;
	if (sink)
		return sink;
	Class c = objc_getClass("VeloraIpaDL");
	if (!c) {
		Class super = objc_getClass("NSObject");
		c = super ? objc_allocateClassPair(super, "VeloraIpaDL", 0) : 0;
		if (c) {
			class_addMethod(c, sel_registerName("URLSession:downloadTask:didFinishDownloadingToURL:"), (void *)ipa_session_finish, "v@:@@@");
			class_addMethod(c, sel_registerName("URLSession:task:didCompleteWithError:"), (void *)ipa_session_complete, "v@:@@@");
			objc_registerClassPair(c);
		}
	}
	if (!c)
		return 0;
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	sink = msg0(al(c, sel_registerName("alloc")), "init");
	hold(sink);
	return sink;
}

static id ensure_ipa_dir(void) {
	const char *cands[] = {
		"/var/tmp/VeloraDownloads",
		"/tmp/VeloraDownloads",
		0,
	};
	Class FM = objc_getClass("NSFileManager");
	id fm = FM ? cls0(FM, "defaultManager") : 0;
	id empty = cls0(objc_getClass("NSData"), "data");
	int i;
	for (i = 0; cands[i]; i++) {
		id dir = nsstr(cands[i]);
		if (fm && store_has(fm, "createDirectoryAtPath:withIntermediateDirectories:attributes:error:")) {
			unsigned char (*mk)(id, SEL, id, unsigned char, id, id *) = (unsigned char (*)(id, SEL, id, unsigned char, id, id *))objc_msgSend;
			mk(fm, sel_registerName("createDirectoryAtPath:withIntermediateDirectories:attributes:error:"), dir, 1, 0, 0);
		}
		id test = msg1(dir, "stringByAppendingString:", nsstr("/.w"));
		if (empty && store_has(empty, "writeToFile:atomically:")) {
			unsigned char (*w)(id, SEL, id, unsigned char) = (unsigned char (*)(id, SEL, id, unsigned char))objc_msgSend;
			if (w(empty, sel_registerName("writeToFile:atomically:"), test, 1)) {
				if (fm && store_has(fm, "removeItemAtPath:error:"))
					msg2(fm, "removeItemAtPath:error:", test, 0);
				return dir;
			}
		}
	}
	return nsstr("/tmp");
}

static int stream_ipa(id urlstr, id path) {
	if (!urlstr || !path)
		return 0;
	gIpaDone = 0;
	gIpaOk = 0;
	gIpaDestPath = store_str(path);
	hold(gIpaDestPath);
	id (*fu)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
	gIpaDestURL = fu(objc_getClass("NSURL"), sel_registerName("fileURLWithPath:"), gIpaDestPath);
	if (gIpaDestURL)
		hold(gIpaDestURL);
	id (*uws)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
	id url = uws(objc_getClass("NSURL"), sel_registerName("URLWithString:"), urlstr);
	if (!url)
		return 0;
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	id req = msg0(al(objc_getClass("NSMutableURLRequest"), sel_registerName("alloc")), "init");
	if (!req)
		return 0;
	msg1(req, "setURL:", url);
	msg1(req, "setHTTPMethod:", nsstr("GET"));
	if (store_has(req, "setTimeoutInterval:")) {
		void (*sto)(id, SEL, double) = (void (*)(id, SEL, double))objc_msgSend;
		sto(req, sel_registerName("setTimeoutInterval:"), 1800.0);
	}
	apply_arm_headers(req);
	if (store_has(req, "setValue:forHTTPHeaderField:")) {
		id (*sv)(id, SEL, id, id) = (id(*)(id, SEL, id, id))objc_msgSend;
		sv(req, sel_registerName("setValue:forHTTPHeaderField:"), nsstr("*/*"), nsstr("Accept"));
		if (gIpaToken && store_cstr(gIpaToken)[0]) {
			sv(req, sel_registerName("setValue:forHTTPHeaderField:"), gIpaToken, nsstr("Token"));
			sv(req, sel_registerName("setValue:forHTTPHeaderField:"), gIpaToken, nsstr("X-Token"));
		}
	}
	id sink = ipa_sink();
	if (!sink)
		return 0;
	Class SC = objc_getClass("NSURLSessionConfiguration");
	Class SS = objc_getClass("NSURLSession");
	if (!SC || !SS)
		return 0;
	id config = cls0(SC, "defaultSessionConfiguration");
	if (!config)
		return 0;
	id (*mk)(Class, SEL, id, id, id) = (id(*)(Class, SEL, id, id, id))objc_msgSend;
	id session = mk(SS, sel_registerName("sessionWithConfiguration:delegate:delegateQueue:"), config, sink, 0);
	if (!session)
		return 0;
	hold(session);
	id task = 0;
	if (store_has(session, "downloadTaskWithRequest:"))
		task = msg1(session, "downloadTaskWithRequest:", req);
	if (!task)
		return 0;
	msg0(task, "resume");
	int spins = 0;
	while (!gIpaDone && spins < 9600) {
		void (*sl)(Class, SEL, double) = (void (*)(Class, SEL, double))objc_msgSend;
		sl(objc_getClass("NSThread"), sel_registerName("sleepForTimeInterval:"), 0.25);
		spins++;
	}
	if (!gIpaDone && store_has(task, "cancel"))
		msg0(task, "cancel");
	if (store_has(session, "finishTasksAndInvalidate"))
		msg0(session, "finishTasksAndInvalidate");
	if (!gIpaOk) {
		id fm = cls0(objc_getClass("NSFileManager"), "defaultManager");
		if (fm && gIpaDestPath && store_has(fm, "removeItemAtPath:error:"))
			msg2(fm, "removeItemAtPath:error:", gIpaDestPath, 0);
		{
			id resp = 0, err = 0;
			id (*send)(Class, SEL, id, id *, id *) = (id(*)(Class, SEL, id, id *, id *))objc_msgSend;
			id data = send(objc_getClass("NSURLConnection"), sel_registerName("sendSynchronousRequest:returningResponse:error:"), req, &resp, &err);
			if (data && store_has(data, "writeToFile:atomically:")) {
				unsigned char (*w)(id, SEL, id, unsigned char) = (unsigned char (*)(id, SEL, id, unsigned char))objc_msgSend;
				if (w(data, sel_registerName("writeToFile:atomically:"), path, 1) && file_is_ipa_path(path))
					return 1;
			}
		}
		return 0;
	}
	return 1;
}

void velora_open_ipa_in_trollstore(id ipaUrl) {
	open_trollstore_ipa(ipaUrl);
}

void velora_open_arm_page(id adam) {
	id url = velora_arm_store_page(adam, store_str(shared_get("dlName")));
	if (!url)
		return;
	id (*uws)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
	open_nsurl(uws(objc_getClass("NSURL"), sel_registerName("URLWithString:"), url));
}

id velora_last_error(void) {
	return store_str(shared_get("dlError"));
}

void velora_set_error(id msg) {
	shared_set("dlError", msg ? store_str(msg) : nsstr(""));
}

id velora_last_ipa_url(void) {
	return store_str(shared_get("dlIpaUrl"));
}

static int is_direct_ipa_url(id u) {
	if (!u || !store_cstr(u)[0])
		return 0;
	if (hay_ci(u, ".ipa"))
		return 1;
	if (hay_ci(u, "/decryptedappstore/download/"))
		return 1;
	if (hay_ci(u, "iosapps.itunes.apple.com"))
		return 1;
	return 0;
}

static id itunes_bundle_id(id adam) {
	char url[220];
	int n;
	id json, results, rec, bid;
	NSInteger nres = 0;
	if (!adam || !store_cstr(adam)[0])
		return 0;
	n = cat(url, 0, 220, "https://itunes.apple.com/lookup?id=");
	n = cat(url, n, 220, store_cstr(adam));
	cat(url, n, 220, "&entity=software");
	json = http_json(url);
	if (!json)
		return 0;
	results = msg1(json, "objectForKey:", nsstr("results"));
	if (!results || !store_has(results, "objectAtIndex:"))
		return 0;
	if (store_has(results, "count")) {
		NSInteger (*c)(id, SEL) = (NSInteger(*)(id, SEL))objc_msgSend;
		nres = c(results, sel_registerName("count"));
	}
	if (nres < 1)
		return 0;
	{
		id (*at)(id, SEL, NSInteger) = (id(*)(id, SEL, NSInteger))objc_msgSend;
		rec = at(results, sel_registerName("objectAtIndex:"), 0);
	}
	if (!rec)
		return 0;
	bid = msg1(rec, "objectForKey:", nsstr("bundleId"));
	return bid && store_cstr(bid)[0] ? store_str(bid) : 0;
}

static id arm_http(const char *urlc, const char *method) {
	id nsurl, req, data;
	id (*uws)(Class, SEL, id);
	id (*al)(Class, SEL);
	id resp = 0, err = 0;
	id (*send)(Class, SEL, id, id *, id *);
	if (!urlc || !urlc[0])
		return 0;
	uws = (id(*)(Class, SEL, id))objc_msgSend;
	nsurl = uws(objc_getClass("NSURL"), sel_registerName("URLWithString:"), nsstr(urlc));
	if (!nsurl)
		return 0;
	al = (id(*)(Class, SEL))objc_msgSend;
	req = msg0(al(objc_getClass("NSMutableURLRequest"), sel_registerName("alloc")), "init");
	if (!req)
		return 0;
	msg1(req, "setURL:", nsurl);
	msg1(req, "setHTTPMethod:", nsstr(method && method[0] ? method : "GET"));
	if (store_has(req, "setTimeoutInterval:")) {
		void (*sto)(id, SEL, double) = (void (*)(id, SEL, double))objc_msgSend;
		sto(req, sel_registerName("setTimeoutInterval:"), 25.0);
	}
	apply_arm_headers(req);
	send = (id(*)(Class, SEL, id, id *, id *))objc_msgSend;
	data = send(objc_getClass("NSURLConnection"), sel_registerName("sendSynchronousRequest:returningResponse:error:"), req, &resp, &err);
	if (resp && store_has(resp, "allHeaderFields")) {
		id fields = msg0(resp, "allHeaderFields");
		id sc = fields ? msg1(fields, "objectForKey:", nsstr("Set-Cookie")) : 0;
		if (!sc && fields)
			sc = msg1(fields, "objectForKey:", nsstr("set-cookie"));
		if (sc)
			remember_session_from_header(sc);
	}
	return data;
}

static id arm_json(const char *urlc, const char *method) {
	id data = arm_http(urlc, method);
	id jsonerr = 0;
	id (*js)(Class, SEL, id, NSInteger, id *);
	if (!data)
		return 0;
	js = (id(*)(Class, SEL, id, NSInteger, id *))objc_msgSend;
	return js(objc_getClass("NSJSONSerialization"), sel_registerName("JSONObjectWithData:options:error:"), data, 0, &jsonerr);
}

static int arm_login_blocked(id obj) {
	id flag, err;
	if (!obj || !store_has(obj, "objectForKey:"))
		return 0;
	flag = msg1(obj, "objectForKey:", nsstr("loginRequired"));
	if (flag) {
		if (store_has(flag, "boolValue")) {
			unsigned char (*b)(id, SEL) = (unsigned char (*)(id, SEL))objc_msgSend;
			if (b(flag, sel_registerName("boolValue")))
				return 1;
		}
		if (streq(store_str(flag), "true") || streq(store_str(flag), "1"))
			return 1;
	}
	err = store_str(msg1(obj, "objectForKey:", nsstr("error")));
	if (err && (hay_ci(err, "log in") || hay_ci(err, "login") || hay_ci(err, "token is required") || hay_ci(err, "forbidden") || hay_ci(err, "please log")))
		return 1;
	return 0;
}

static int ping_arm_session(void) {
	id obj, name, igid, err;
	harvest_arm_session();
	obj = arm_json("https://armconverter.com/decryptedappstore/user/info", "GET");
	if (!obj)
		return arm_session_value() ? 1 : 0;
	if (arm_login_blocked(obj))
		return 0;
	err = store_str(msg1(obj, "objectForKey:", nsstr("error")));
	if (err && store_cstr(err)[0])
		return 0;
	name = store_str(msg1(obj, "objectForKey:", nsstr("name")));
	if (!name)
		name = store_str(msg1(obj, "objectForKey:", nsstr("username")));
	igid = store_str(msg1(obj, "objectForKey:", nsstr("igid")));
	if (name && store_cstr(name)[0])
		shared_set("armUserName", name);
	if ((name && store_cstr(name)[0]) || (igid && store_cstr(igid)[0])) {
		shared_set("armSessionOn", nsstr("1"));
		return 1;
	}
	return 0;
}

static void keep_tick(id self, SEL sel) {
	(void)sel;
	capture_apple_session();
	ping_apple_session();
	harvest_arm_session();
	ping_arm_session();
	schedule_keep(self, 480.0);
}

static int arm_confirms_version(id adam, id ver) {
	char url[320];
	int n;
	id obj, list;
	NSInteger c, i;
	int saw = 0;
	if (!adam || !store_cstr(adam)[0])
		return 0;
	n = cat(url, 0, 320, "https://armconverter.com/decryptedappstore/versions/");
	n = cat(url, n, 320, store_cstr(adam));
	cat(url, n, 320, "/0?country=us");
	obj = arm_json(url, "POST");
	if (!obj || arm_login_blocked(obj)) {
		harvest_arm_session();
		obj = arm_json(url, "POST");
	}
	if (!obj || arm_login_blocked(obj))
		return 1;
	list = store_has(obj, "objectForKey:") ? msg1(obj, "objectForKey:", nsstr("versions")) : 0;
	if (!list)
		return 1;
	if (store_has(list, "count")) {
		NSInteger (*cn)(id, SEL) = (NSInteger(*)(id, SEL))objc_msgSend;
		c = cn(list, sel_registerName("count"));
	} else
		c = 0;
	if (c <= 0)
		return 1;
	if (!ver || !store_cstr(ver)[0])
		return 1;
	for (i = 0; i < c && i < 120; i++) {
		id rec, rv;
		id (*at)(id, SEL, NSInteger) = (id(*)(id, SEL, NSInteger))objc_msgSend;
		rec = at(list, sel_registerName("objectAtIndex:"), i);
		if (!rec || !store_has(rec, "objectForKey:"))
			continue;
		saw = 1;
		rv = msg1(rec, "objectForKey:", nsstr("ver"));
		if (!rv)
			rv = msg1(rec, "objectForKey:", nsstr("shortVer"));
		if (!rv)
			rv = msg1(rec, "objectForKey:", nsstr("version"));
		if (same_ver_str(rv, ver))
			return 1;
	}
	return saw ? 0 : 1;
}

static id arm_prepare_token(id adam, id bid, id ver) {
	char url[900];
	int n;
	id info, prep, token, avail;
	if (!adam || !store_cstr(adam)[0] || !bid || !store_cstr(bid)[0] || !ver || !store_cstr(ver)[0])
		return 0;
	n = cat(url, 0, 900, "https://armconverter.com/decryptedappstore/download/");
	n = cat(url, n, 900, store_cstr(adam));
	n = cat(url, n, 900, "/");
	n = cat(url, n, 900, store_cstr(bid));
	n = cat(url, n, 900, "/");
	n = cat(url, n, 900, store_cstr(ver));
	cat(url, n, 900, "/info");
	info = arm_json(url, "GET");
	if (info && arm_login_blocked(info)) {
		harvest_arm_session();
		ping_arm_session();
		info = arm_json(url, "GET");
	}
	if (info && arm_login_blocked(info))
		return 0;
	if (info && store_has(info, "objectForKey:")) {
		avail = msg1(info, "objectForKey:", nsstr("available"));
		if (avail && store_has(avail, "boolValue")) {
			unsigned char (*b)(id, SEL) = (unsigned char (*)(id, SEL))objc_msgSend;
			if (!b(avail, sel_registerName("boolValue")))
				return 0;
		}
	}
	n = cat(url, 0, 900, "https://armconverter.com/decryptedappstore/download/");
	n = cat(url, n, 900, store_cstr(adam));
	n = cat(url, n, 900, "/");
	n = cat(url, n, 900, store_cstr(bid));
	n = cat(url, n, 900, "/");
	n = cat(url, n, 900, store_cstr(ver));
	cat(url, n, 900, "/prepare");
	prep = arm_json(url, "POST");
	if (prep && arm_login_blocked(prep)) {
		harvest_arm_session();
		ping_arm_session();
		prep = arm_json(url, "POST");
	}
	if (!prep || arm_login_blocked(prep) || !store_has(prep, "objectForKey:"))
		return 0;
	token = store_str(msg1(prep, "objectForKey:", nsstr("token")));
	if (token && store_cstr(token)[0] && !streq(token, "null"))
		return token;
	return 0;
}

static id arm_ipa_download_url(id adam, id bid, id ver) {
	char buf[800];
	int n;
	if (!adam || !store_cstr(adam)[0] || !bid || !store_cstr(bid)[0])
		return 0;
	n = cat(buf, 0, 800, "https://armconverter.com/decryptedappstore/download/");
	n = cat(buf, n, 800, store_cstr(adam));
	n = cat(buf, n, 800, "/");
	n = cat(buf, n, 800, store_cstr(bid));
	if (ver && store_cstr(ver)[0]) {
		n = cat(buf, n, 800, "/");
		cat(buf, n, 800, store_cstr(ver));
	}
	return nsstr(buf);
}

void velora_run_trollstore(void) {
	id adam = store_str(shared_get("dlAdamId"));
	id ver = store_str(shared_get("dlVersion"));
	id bid = store_str(shared_get("dlBundleId"));
	id url, dir, path, fileURL, token;
	shared_set("dlIpaUrl", nsstr(""));
	gIpaToken = 0;
	if (!adam || !store_cstr(adam)[0]) {
		shared_set("dlError", nsstr("Missing App Store id."));
		return;
	}
	if (!bid || !store_cstr(bid)[0])
		bid = itunes_bundle_id(adam);
	if ((!bid || !store_cstr(bid)[0])) {
		id json = web_lookup(adam, ver);
		id resolved = json ? msg1(json, "objectForKey:", nsstr("bundleId")) : 0;
		if (resolved && store_cstr(resolved)[0])
			bid = store_str(resolved);
	}
	if (bid && store_cstr(bid)[0])
		shared_set("dlBundleId", bid);
	if (!bid || !store_cstr(bid)[0]) {
		shared_set("dlError", nsstr("Could not find this app on ARM Store."));
		return;
	}
	if (!ver || !store_cstr(ver)[0]) {
		shared_set("dlError", nsstr("Pick a version in history first."));
		return;
	}
	if (!arm_confirms_version(adam, ver)) {
		shared_set("dlError", nsstr("This version is not in ARM Store history."));
		return;
	}
	url = arm_ipa_download_url(adam, bid, ver);
	if (!url)
		url = web_ipa_direct(adam, ver);
	if (!is_direct_ipa_url(url)) {
		shared_set("dlError", nsstr("ARM Store did not return an IPA for this version."));
		return;
	}
	if (ver && store_cstr(ver)[0])
		token = arm_prepare_token(adam, bid, ver);
	else
		token = 0;
	gIpaToken = token;
	if (token && store_cstr(token)[0] && url && store_cstr(url)[0]) {
		char buf[1600];
		int n = cat(buf, 0, 1600, store_cstr(url));
		n = cat(buf, n, 1600, "?token=");
		{
			id enc = encode_query(token);
			cat(buf, n, 1600, store_cstr(enc ? enc : token));
		}
		url = nsstr(buf);
	}
	dir = ensure_ipa_dir();
	path = msg1(dir, "stringByAppendingString:", nsstr("/"));
	path = msg1(path, "stringByAppendingString:", store_str(adam));
	if (ver && store_cstr(ver)[0]) {
		path = msg1(path, "stringByAppendingString:", nsstr("_"));
		path = msg1(path, "stringByAppendingString:", store_str(ver));
	}
	path = msg1(path, "stringByAppendingString:", nsstr(".ipa"));
	if (!stream_ipa(url, path)) {
		gIpaToken = 0;
		if (!arm_session_value())
			shared_set("dlError", nsstr("ARM Store session expired. Paste your session cookie in Settings."));
		else
			shared_set("dlError", nsstr("ARM Store IPA download failed."));
		return;
	}
	gIpaToken = 0;
	{
		id (*fu)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
		fileURL = fu(objc_getClass("NSURL"), sel_registerName("fileURLWithPath:"), path);
	}
	if (fileURL && store_has(fileURL, "absoluteString"))
		shared_set("dlIpaUrl", store_str(msg0(fileURL, "absoluteString")));
	else
		shared_set("dlIpaUrl", store_str(path));
	shared_set("dlError", nsstr(""));
}

void velora_run_download(void) {
	dlopen("/System/Library/PrivateFrameworks/StoreServices.framework/StoreServices", RTLD_LAZY);
	start_pending_purchase();
}

void velora_open_appstore(id adam) {
	char buf[128];
	const char *pre = "itms-apps://apps.apple.com/app/id";
	int n = 0;
	while (pre[n]) {
		buf[n] = pre[n];
		n++;
	}
	const char *a = store_cstr(adam);
	while (*a && n < 120)
		buf[n++] = *a++;
	buf[n] = 0;
	id (*uws)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
	id url = uws(objc_getClass("NSURL"), sel_registerName("URLWithString:"), nsstr(buf));
	id app = cls0(objc_getClass("UIApplication"), "sharedApplication");
	if (app && url && store_has(app, "openURL:"))
		msg1(app, "openURL:", url);
	Class LS = objc_getClass("LSApplicationWorkspace");
	id ws = LS ? cls0(LS, "defaultWorkspace") : 0;
	if (ws && store_has(ws, "openApplicationWithBundleID:"))
		msg1(ws, "openApplicationWithBundleID:", nsstr("com.apple.AppStore"));
}

void velora_set_download_ids(id adam, id ext, id ver) {
	if (!adam)
		return;
	id a = store_str(adam);
	id e = store_str(ext);
	id v = store_str(ver);
	if (a)
		shared_set("dlAdamId", a);
	shared_set("dlVersionId", (e && store_cstr(e)[0]) ? e : nsstr(""));
	shared_set("dlVersion", (v && store_cstr(v)[0]) ? v : nsstr(""));
}

void velora_set_app_name(id name) {
	id n = store_str(name);
	if (n && store_cstr(n)[0])
		shared_set("dlName", n);
}

void velora_set_bundle_id(id bid) {
	id b = store_str(bid);
	if (b && store_cstr(b)[0])
		shared_set("dlBundleId", b);
}

void velora_arm_download(id adam, id ext, id ver) {
	velora_set_download_ids(adam, ext, ver);
	shared_set("dlMode", nsstr("appstore"));
	bump_dl_gen();
	post_dl();
}

void velora_arm_troll(id adam, id ext, id ver) {
	velora_set_download_ids(adam, ext, ver);
	shared_set("dlMode", nsstr("troll"));
}

static void run_pending_purchase(void *ctx) {
	(void)ctx;
	start_pending_purchase();
}

static void on_download_note(void *obs, void *center, void *name, const void *obj, const void *info) {
	(void)obs;
	(void)center;
	(void)name;
	(void)obj;
	(void)info;
	id mode = store_str(shared_get("dlMode"));
	if (mode && store_cstr(mode)[0] == 't')
		return;
	if (!purchase_daemon())
		return;
	{
		void *async = dlsym(RTLD_DEFAULT, "dispatch_async_f");
		void *gq = dlsym(RTLD_DEFAULT, "dispatch_get_global_queue");
		if (async && gq) {
			typedef void *(*gq_t)(long, unsigned long);
			typedef void (*daf_t)(void *, void *, void (*)(void *));
			void *q = ((gq_t)gq)(0, 0);
			if (q) {
				((daf_t)async)(q, 0, run_pending_purchase);
				return;
			}
		}
	}
	start_pending_purchase();
}

static void on_fetch_note(void *obs, void *center, void *name, const void *obj, const void *info) {
	(void)obs;
	(void)center;
	(void)name;
	(void)obj;
	(void)info;
	run_apple_version_fetch(1);
}

static void on_session_note(void *obs, void *center, void *name, const void *obj, const void *info) {
	(void)obs;
	(void)center;
	(void)name;
	(void)obj;
	(void)info;
	harvest_arm_session();
	capture_apple_session();
	if (purchase_daemon() || in_store_process())
		ping_arm_session();
}

static void install_download_observer(void) {
	static int once;
	if (once)
		return;
	once = 1;
	ensure_ids();
	if (!gSnNote)
		gSnNote = live_str("com.velora.hz.session");
	CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), (const void *)0x564c5241, on_download_note, gDlNote, 0, 4);
	CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), (const void *)0x564c5242, on_fetch_note, gFtNote, 0, 4);
	CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), (const void *)0x564c5243, on_session_note, gSnNote, 0, 4);
	CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), (const void *)0x564c5244, on_store_reload, live_str("com.velora.hz/Reload"), 0, 4);
}

void velora_store_init(void) {
	static int once;
	if (once)
		return;
	once = 1;
	ensure_ids();
	load_store_prefs();
	ipa_sink();
	start_session_keeper();
	if (can_handle_jobs())
		install_download_observer();
	if (!in_store_process())
		return;
	const char *paths[] = {
		"/var/jb/usr/lib/libellekit.dylib",
		"/var/jb/usr/lib/libsubstrate.dylib",
		"/usr/lib/libellekit.dylib",
		"/usr/lib/libsubstrate.dylib",
		"/usr/lib/libhooker.dylib",
		"/var/jb/usr/lib/libhooker.dylib",
		0,
	};
	void *h = 0;
	for (int i = 0; paths[i] && !h; i++)
		h = dlopen(paths[i], RTLD_LAZY);
	if (h)
		storeHook = (MSHookMessageEx_t)dlsym(h, "MSHookMessageEx");
	if (!storeHook)
		storeHook = (MSHookMessageEx_t)dlsym(RTLD_DEFAULT, "MSHookMessageEx");
	if (!storeHook)
		return;
	hook1("SSPurchase", "setBuyParameters:", (void *)hook_setBuySS, (void **)&orig_setBuySS);
	hook1("SSPurchase", "buyParameters", (void *)hook_getBuySS, (void **)&orig_getBuySS);
	hook1("ASDPurchase", "setBuyParameters:", (void *)hook_setBuyASD, (void **)&orig_setBuyASD);
	hook1("ASDUpdatesService", "getUpdatesWithCompletionBlock:", (void *)hook_getUpdates, (void **)&orig_getUpdates);
	hook1("ASDUpdatesService", "refreshUpdatesWithCompletionBlock:", (void *)hook_refreshUpdates, (void **)&orig_refreshUpdates);
	hook1("ASDUpdatesService", "reloadFromServerWithCompletionBlock:", (void *)hook_reloadServer, (void **)&orig_reloadServer);
	hook1("SSSoftwareUpdatesStore", "reloadUpdatesWithCompletionBlock:", (void *)hook_reloadUpdates, (void **)&orig_reloadUpdates);
	if (gCellular) {
		hook1("NSUserDefaults", "objectForKey:", (void *)hook_udObject, (void **)&orig_udObject);
		hook1("SSDownloadPolicy", "isDownloadable", (void *)hook_isDownloadable, (void **)&orig_isDownloadable);
		hook1("SSDownloadPolicy", "allowCellular", (void *)hook_cellularAllowed, (void **)&orig_cellularAllowed);
	}
	if (gHideAds)
		hook1("UIView", "didMoveToWindow", (void *)hook_didMove, (void **)&orig_didMove);
}
