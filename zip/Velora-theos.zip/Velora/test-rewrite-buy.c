/* Host test for AppStore++ buy-parameter rewrite. */
#include <stdio.h>
#include <string.h>

static int cat(char *b, int n, int cap, const char *s) {
	if (!b || cap < 2)
		return n;
	if (n < 0)
		n = 0;
	while (s && *s && n < cap - 1)
		b[n++] = *s++;
	b[n] = 0;
	return n;
}

static int pair_is(const char *s, const char *end, const char *key) {
	while (*key && s < end && *s == *key) {
		s++;
		key++;
	}
	return *key == 0 && s < end && *s == '=';
}

static int hay_plain(const char *h, const char *n) {
	int i, j;
	if (!h || !n || !n[0])
		return 0;
	for (i = 0; h[i]; i++) {
		for (j = 0; n[j] && h[i + j] && h[i + j] == n[j]; j++)
			;
		if (!n[j])
			return 1;
	}
	return 0;
}

static void rewrite(const char *p, const char *a, const char *e, char *out, int cap) {
	int n = 0;
	int wrote = 0;
	const char *s;
	out[0] = 0;
	if (!a[0] || !e[0] || !p[0] || !hay_plain(p, a)) {
		cat(out, 0, cap, p);
		return;
	}
	s = p;
	while (*s) {
		const char *eop = s;
		int skip;
		while (*eop && *eop != '&')
			eop++;
		skip = pair_is(s, eop, "appExtVrsId") ||
			pair_is(s, eop, "softwareVersionExternalId") ||
			pair_is(s, eop, "externalVersionId") ||
			pair_is(s, eop, "softwareVersionExternalIdentifier");
		if (skip) {
			if (!wrote) {
				if (n)
					n = cat(out, n, cap, "&");
				n = cat(out, n, cap, "appExtVrsId=");
				n = cat(out, n, cap, e);
				wrote = 1;
			}
		} else {
			if (n)
				n = cat(out, n, cap, "&");
			while (s < eop && n < cap - 1)
				out[n++] = *s++;
			out[n] = 0;
		}
		s = *eop ? eop + 1 : eop;
	}
	if (!wrote) {
		if (n)
			n = cat(out, n, cap, "&");
		n = cat(out, n, cap, "appExtVrsId=");
		n = cat(out, n, cap, e);
	}
}

static int fail;

static void expect(const char *got, const char *want, const char *name) {
	if (strcmp(got, want) != 0) {
		printf("FAIL %s\n  got  %s\n  want %s\n", name, got, want);
		fail++;
	} else
		printf("ok %s\n", name);
}

int main(void) {
	char out[1400];
	rewrite("productType=C&salableAdamId=544007664&price=0", "544007664", "999", out, 1400);
	expect(out, "productType=C&salableAdamId=544007664&price=0&appExtVrsId=999", "append missing");
	rewrite("productType=C&salableAdamId=544007664&appExtVrsId=1&price=0", "544007664", "999", out, 1400);
	expect(out, "productType=C&salableAdamId=544007664&appExtVrsId=999&price=0", "replace existing");
	rewrite("productType=C&salableAdamId=1&price=0", "544007664", "999", out, 1400);
	expect(out, "productType=C&salableAdamId=1&price=0", "unrelated adam unchanged");
	rewrite("appExtVrsId=1&salableAdamId=544007664&softwareVersionExternalId=2", "544007664", "999", out, 1400);
	expect(out, "appExtVrsId=999&salableAdamId=544007664", "collapse duplicate version keys");
	if (fail)
		return 1;
	printf("ok\n");
	return 0;
}
