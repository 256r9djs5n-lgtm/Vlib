#!/usr/bin/env python3
"""NekoJB rootful is merged into latest Dopamine; old files auto-update to palera1n 2.4."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
src = (ROOT / "velora-jbupdate.c").read_text(encoding="utf-8")
inj = (ROOT / "velora-inject.c").read_text(encoding="utf-8")
proc = (ROOT / "velora-proc.c").read_text(encoding="utf-8")
hdr = (ROOT / "velora-proc.h").read_text(encoding="utf-8")
plist = (ROOT / "Velora.plist").read_text(encoding="utf-8")
dev = (ROOT / "layout/Library/PreferenceLoader/Preferences/VeloraDevice.plist").read_text(encoding="utf-8")
pack = Path("/workspace/scripts/pack-nekojb-ipa.py").read_text(encoding="utf-8")
fail = 0


def check(cond, name):
    global fail
    if not cond:
        print("FAIL", name)
        fail += 1
    else:
        print("ok", name)


check("void velora_jbupdate_init" in src, "jbupdate init")
check("DOUpdateViewController" not in src, "does not hook the Update screen")
check("DOActionMenuButton" not in src, "does not hook the Update button")
check("buttonWithAction:chevron:" not in src, "does not wrap Update button factory")
check("localizedStringForKey:value:table:" not in src, "does not retitle Update")
check("updateJailbreakFromTIPA:" not in src, "does not hook TIPA update")
check("snapshot_rootful" not in src, "does not snapshot as an overlay")
check("DOSettingsController" in src, "injects Rootful into Dopamine settings")
check("Rootful" in src, "Rootful specifier title")
check("refresh_old_rootful" in src, "auto-updates old rootful to palera1n")
check("palera1n" in src, "palera1n 2.4 refresh")
check("createFakeFS.sh" in src, "writes palera1n helper at native name")
check("palera1n-VERSION" in src, "native palera1n version stamp")
check("Xystem" in src, "palera1n 2.4 Xystem volume")
check("orig-fs" in src, "palera1n orig-fs snapshot")
check("disk0s1s7" in src, "FakeFS path is disk0s1s7")
check("disk0s1s8" in src, "rewrites old disk0s1s8")
check("VeloraFakeFSController" in src, "NekoJB FakeFS/boot screen class")
check("Creating FakeFS" in src, "FakeFS screen title")
check("Create FakeFS" in src, "Create FakeFS settings button")
check("startJailbreak" in src, "hooks Dopamine jailbreak start for FakeFS screen")
check("loader.json" in src, "writes nekoloader config")
check("static.palera.in/sileo.deb" in src, "rootful Sileo URL")
check("static.palera.in/zebra.deb" in src, "rootful Zebra URL")
check("static.palera.in/bootstrap.tar.zst" in src, "rootful bootstrap URL")
check("/var/jb/Applications/Sileo.app" in src, "rewrites rootless Sileo path")
check("static.palera.in/preferenceloader.deb" in src, "rootful PreferenceLoader URL")
check("/var/jb/Library/PreferenceLoader" in src, "rewrites rootless PreferenceLoader path")
check("patch_nested_tipa" in pack, "packer unpacks nested nekoloader.tipa")
check("preferenceloader" in pack, "packer ships PreferenceLoader")
check("Fix-Tree" in pack, "cmd unpacks nested loader tipa")
check("disk0s1s7" in pack, "packer FakeFS disk0s1s7")
check("velora_is_dopamine_core" in src or "Dopamine core" in src, "does not overwrite Dopamine core")
check("velora_jbupdate_init" in inj, "injector starts jbupdate")
check("velora_is_jbapp_bid" in inj, "only Dopamine/NekoJB run jbupdate")
check("com.opa334.Dopamine" in plist, "filter includes Dopamine")
check("xyz.hhls.nekojb" in plist, "filter includes NekoJB")
check("rootfulMode" not in dev, "Velora device settings has no Rootful")
check("merged into the latest Dopamine" not in dev, "device settings no longer describe the merge")
check("velora_is_jbapp_bid" in hdr, "header exports jbapp matcher")
check("NekoJB-Fixed-IPA.cmd" in pack, "cmd packer still exists")
check("refresh_old_rootful_bytes" in pack, "packer auto-updates old rootful text")
check("--fakefs" in pack and "--rootful" in pack, "packer rewrites old fakefs flag")
check("not an in-app Update hook" in pack or "not an Update-button" in pack, "packer is a merge, not an Update hook")

cc = subprocess.run(
    ["gcc", "-o", "/tmp/test-safe-proc-jbup", str(ROOT / "test-safe-proc.c"), str(ROOT / "velora-proc.c")],
    capture_output=True,
    text=True,
)
check(cc.returncode == 0, "safe-proc with jbupdate helpers compiles")
if cc.returncode != 0:
    print(cc.stderr)
else:
    run = subprocess.run(["/tmp/test-safe-proc-jbup"], capture_output=True, text=True)
    check(run.returncode == 0 and "ok" in run.stdout, "safe-proc jbupdate cases pass")
    if run.returncode != 0:
        print(run.stdout, run.stderr)

if fail:
    print(fail, "failed")
    sys.exit(1)
print("ok")
