#include "velora-proc.h"

int velora_cstr_eq(const char *a, const char *b) {
	if (!a || !b)
		return 0;
	while (*a && *a == *b) {
		a++;
		b++;
	}
	return *a == *b;
}

int velora_cstr_has(const char *s, const char *n) {
	if (!s || !n || !*n)
		return 0;
	for (; *s; s++) {
		const char *a = s, *b = n;
		while (*a && *b && *a == *b) {
			a++;
			b++;
		}
		if (!*b)
			return 1;
	}
	return 0;
}

int velora_cstr_end(const char *s, const char *n) {
	int ls = 0, ln = 0;
	if (!s || !n)
		return 0;
	while (s[ls])
		ls++;
	while (n[ln])
		ln++;
	if (ln > ls)
		return 0;
	return velora_cstr_eq(s + ls - ln, n);
}

int velora_is_store_bid(const char *bid) {
	if (velora_cstr_eq(bid, "com.apple.itunesstored"))
		return 1;
	if (velora_cstr_eq(bid, "com.apple.appstored"))
		return 1;
	if (velora_cstr_eq(bid, "com.apple.AppStore"))
		return 1;
	if (velora_cstr_eq(bid, "com.apple.ios.StoreKitUI"))
		return 1;
	return 0;
}

int velora_is_prefs_bid(const char *bid) {
	return velora_cstr_eq(bid, "com.apple.Preferences");
}

int velora_is_springboard_bid(const char *bid) {
	return velora_cstr_eq(bid, "com.apple.springboard");
}

int velora_is_helper_path(const char *path) {
	if (!path || !path[0])
		return 0;
	if (velora_cstr_has(path, ".appex"))
		return 1;
	if (velora_cstr_has(path, "/PlugIns/"))
		return 1;
	if (velora_cstr_has(path, "/Extensions/"))
		return 1;
	if (velora_cstr_has(path, ".xpc/"))
		return 1;
	if (velora_cstr_has(path, "/XPCServices/"))
		return 1;
	if (velora_cstr_end(path, ".xpc"))
		return 1;
	return 0;
}

int velora_is_helper_bid(const char *bid) {
	if (!bid || !bid[0])
		return 1;
	if (velora_cstr_has(bid, "WebKit"))
		return 1;
	if (velora_cstr_has(bid, "WebContent"))
		return 1;
	if (velora_cstr_end(bid, ".appex") || velora_cstr_end(bid, ".xpc"))
		return 1;
	if (velora_cstr_has(bid, "ViewService"))
		return 1;
	if (velora_cstr_has(bid, "Spotlight"))
		return 1;
	if (velora_cstr_has(bid, "TextInput"))
		return 1;
	if (velora_cstr_has(bid, "FileProvider"))
		return 1;
	if (velora_cstr_has(bid, "QuickLook"))
		return 1;
	if (velora_cstr_has(bid, "Widget"))
		return 1;
	if (velora_cstr_has(bid, "NotificationContent"))
		return 1;
	if (velora_cstr_has(bid, "BroadcastUpload"))
		return 1;
	if (velora_cstr_has(bid, "AuthenticationServices"))
		return 1;
	if (velora_cstr_has(bid, "PluginKit"))
		return 1;
	if (velora_cstr_has(bid, "ExtensionKit"))
		return 1;
	if (velora_cstr_has(bid, "Intents"))
		return 1;
	if (velora_cstr_has(bid, "UIService"))
		return 1;
	if (velora_cstr_has(bid, "PosterKit"))
		return 1;
	if (velora_cstr_eq(bid, "com.apple.SafariViewService"))
		return 1;
	if (velora_cstr_eq(bid, "com.apple.AuthKitUI"))
		return 1;
	if (velora_cstr_eq(bid, "com.apple.SharingViewService"))
		return 1;
	if (velora_cstr_eq(bid, "com.apple.ScreenshotServicesService"))
		return 1;
	if (velora_cstr_eq(bid, "com.apple.InCallService"))
		return 1;
	if (velora_cstr_eq(bid, "com.apple.CoreAuthUI"))
		return 1;
	if (velora_cstr_eq(bid, "com.apple.GameOverlayUI"))
		return 1;
	if (velora_cstr_eq(bid, "com.apple.ContactsUI.LimitedAccessPromptView"))
		return 1;
	if (velora_cstr_eq(bid, "com.apple.WebKit.Networking"))
		return 1;
	if (velora_cstr_eq(bid, "com.apple.WebKit.GPU"))
		return 1;
	return 0;
}

int velora_is_helper_prog(const char *prog) {
	if (!prog || !prog[0])
		return 0;
	if (velora_is_helper_bid(prog))
		return 1;
	if (velora_cstr_end(prog, ".appex") || velora_cstr_end(prog, ".xpc"))
		return 1;
	if (velora_cstr_has(prog, "WebContent") || velora_cstr_has(prog, "WebKit"))
		return 1;
	if (velora_cstr_has(prog, "ViewService") || velora_cstr_has(prog, "Widget"))
		return 1;
	return 0;
}

int velora_skip_inject(const char *bid, const char *path) {
	if (velora_is_helper_bid(bid))
		return 1;
	if (velora_is_helper_path(path))
		return 1;
	return 0;
}

unsigned long long velora_pack_hud(int hud, int tel, int corner) {
	if (corner < 0)
		corner = 0;
	if (corner > 3)
		corner = 3;
	return 0x80ull | (hud ? 1ull : 0ull) | (tel ? 2ull : 0ull) | (((unsigned long long)corner) << 2);
}

int velora_hud_state_valid(unsigned long long s) {
	return (s & 0x80ull) ? 1 : 0;
}

int velora_hud_from_state(unsigned long long s) {
	return (s & 1ull) ? 1 : 0;
}

int velora_tel_from_state(unsigned long long s) {
	return (s & 2ull) ? 1 : 0;
}

int velora_corner_from_state(unsigned long long s) {
	return (int)((s >> 2) & 3ull);
}

int velora_is_unsafe_hud_window(const char *cls) {
	if (!cls || !cls[0])
		return 1;
	if (velora_cstr_eq(cls, "VeloraHUDWindow"))
		return 1;
	if (velora_cstr_has(cls, "Keyboard"))
		return 1;
	if (velora_cstr_has(cls, "TextEffects"))
		return 1;
	if (velora_cstr_has(cls, "StatusBar"))
		return 1;
	if (velora_cstr_has(cls, "UIText"))
		return 1;
	return 0;
}

static char fold_ch(char c) {
	if (c >= 'A' && c <= 'Z')
		return (char)(c + 32);
	return c;
}

int velora_cstr_has_ci(const char *s, const char *n) {
	if (!s || !n || !*n)
		return 0;
	for (; *s; s++) {
		const char *a = s, *b = n;
		while (*a && *b && fold_ch(*a) == fold_ch(*b)) {
			a++;
			b++;
		}
		if (!*b)
			return 1;
	}
	return 0;
}

int velora_is_update_alert(const char *title, const char *msg) {
	const char *t = title ? title : "";
	const char *m = msg ? msg : "";
	if (velora_cstr_has_ci(t, "needs to be updated") || velora_cstr_has_ci(m, "needs to be updated"))
		return 1;
	if (velora_cstr_has_ci(t, "developer of this app needs to update") || velora_cstr_has_ci(m, "developer of this app needs to update"))
		return 1;
	if (velora_cstr_has_ci(t, "to work with this version of ios") || velora_cstr_has_ci(m, "to work with this version of ios"))
		return 1;
	if (velora_cstr_has(t, "g\xC3\xBCncellenmesi gerekiyor") || velora_cstr_has(m, "g\xC3\xBCncellenmesi gerekiyor"))
		return 1;
	if (velora_cstr_has_ci(t, "guncellenmesi gerekiyor") || velora_cstr_has_ci(m, "guncellenmesi gerekiyor"))
		return 1;
	if (velora_cstr_has_ci(t, "ncellenmesi gerekiyor") || velora_cstr_has_ci(m, "ncellenmesi gerekiyor"))
		return 1;
	return 0;
}

int velora_jb_path(const char *p) {
	if (!p || !p[0])
		return 0;
	if (velora_cstr_has(p, "/var/jb") || velora_cstr_has(p, "/private/preboot") || velora_cstr_has(p, "/.jbroot"))
		return 1;
	if (velora_cstr_has(p, "/cores/binpack") || velora_cstr_has(p, "/cores/.jbctl") || velora_cstr_has(p, "/var/binpack"))
		return 1;
	if (velora_cstr_has(p, "/jbin/") || velora_cstr_has(p, "/jb/") || velora_cstr_has(p, "/var/Liy") || velora_cstr_has(p, "/.procursus_strapped"))
		return 1;
	if (velora_cstr_has(p, "MobileSubstrate") || velora_cstr_has(p, "TweakInject") || velora_cstr_has(p, "TweakLoader"))
		return 1;
	if (velora_cstr_has(p, "libellekit") || velora_cstr_has(p, "libsubstitute") || velora_cstr_has(p, "libhooker.dylib"))
		return 1;
	if (velora_cstr_has(p, "CydiaSubstrate") || velora_cstr_has(p, "SubstrateLoader") || velora_cstr_has(p, "ellekit"))
		return 1;
	if (velora_cstr_has(p, "Cydia.app") || velora_cstr_has(p, "Sileo.app") || velora_cstr_has(p, "Zebra.app"))
		return 1;
	if (velora_cstr_has(p, "Filza.app") || velora_cstr_has(p, "NewTerm") || velora_cstr_has(p, "Dopamine.app"))
		return 1;
	if (velora_cstr_has(p, "/etc/apt") || velora_cstr_has(p, "/var/lib/apt") || velora_cstr_has(p, "/var/cache/apt"))
		return 1;
	if (velora_cstr_has(p, "/var/lib/cydia") || velora_cstr_has(p, "/usr/libexec/cydia") || velora_cstr_has(p, "/var/log/apt"))
		return 1;
	if (velora_cstr_has(p, "/usr/bin/ssh") || velora_cstr_has(p, "/usr/sbin/sshd") || velora_cstr_has(p, "/etc/ssh/sshd_config"))
		return 1;
	if (velora_cstr_has(p, "/bin/bash") || velora_cstr_eq(p, "/bin/sh") || velora_cstr_has(p, "/usr/bin/apt") || velora_cstr_has(p, "/usr/bin/dpkg"))
		return 1;
	if (velora_cstr_has(p, "PreferenceLoader") || velora_cstr_has(p, "Cephei.framework") || velora_cstr_has(p, "libjailbreak"))
		return 1;
	if (velora_cstr_has(p, "FridaGadget") || velora_cstr_has(p, "frida-server") || velora_cstr_has(p, "frida-agent") || velora_cstr_has(p, "cycript"))
		return 1;
	if (velora_cstr_has(p, "systemhook.dylib") || velora_cstr_has(p, "libinjector") || velora_cstr_has(p, "/usr/lib/TweakInject.dylib"))
		return 1;
	if (velora_cstr_has(p, "/.bootstrapped") || velora_cstr_has(p, "/.installed_") || velora_cstr_has(p, "/.file"))
		return 1;
	if (velora_cstr_has(p, "checkra1n") || velora_cstr_has(p, "unc0ver") || velora_cstr_has(p, "palera1n"))
		return 1;
	if (velora_cstr_has(p, "Procursus") || velora_cstr_has(p, "roothide") || velora_cstr_has(p, "XinaA15") || velora_cstr_has(p, "Fugu15"))
		return 1;
	if (velora_cstr_has(p, "/private/var/stash") || velora_cstr_has(p, "/var/tmp/cydia.log") || velora_cstr_has(p, "/tmp/cydia.log"))
		return 1;
	if (velora_cstr_has(p, "/usr/bin/ldid") || velora_cstr_has(p, "SBSettings") || velora_cstr_has(p, "me.jjolano.shadow"))
		return 1;
	if (velora_cstr_has(p, "A-Bypass") || velora_cstr_has(p, "FlyJB") || velora_cstr_has(p, "LibertyLite") || velora_cstr_has(p, "Choicy"))
		return 1;
	if (velora_cstr_has(p, "/Library/TweakInject") || velora_cstr_has(p, "/usr/lib/TweakInject"))
		return 1;
	if (velora_cstr_has(p, "substitute-inserter") || velora_cstr_has(p, "cynject") || velora_cstr_has(p, "libsubstrate"))
		return 1;
	if (velora_cstr_has(p, "ABPattern") || velora_cstr_has(p, "ABDYLD") || velora_cstr_has(p, "ABSubLoader"))
		return 1;
	if (velora_cstr_has(p, "/.cydia_no_stash") || velora_cstr_has(p, "/var/lib/dpkg"))
		return 1;
	if (velora_cstr_has(p, "Icy.app") || velora_cstr_has(p, "MxTube.app") || velora_cstr_has(p, "RockApp.app") || velora_cstr_has(p, "blackra1n"))
		return 1;
	if (velora_cstr_has(p, "FakeCarrier") || velora_cstr_has(p, "WinterBoard") || velora_cstr_has(p, "IntelliScreen") || velora_cstr_has(p, "FlyJB.app"))
		return 1;
	if (velora_cstr_has(p, "palera1nLoader") || velora_cstr_has(p, "libblackjack") || velora_cstr_has(p, "SSLKillSwitch"))
		return 1;
	if (velora_cstr_has(p, "SubstrateInserter") || velora_cstr_has(p, "SubstrateBootstrap") || velora_cstr_has(p, "pspawn_payload"))
		return 1;
	if (velora_cstr_has(p, "rocketbootstrap") || velora_cstr_has(p, "weeloader") || velora_cstr_has(p, "vnodebypass"))
		return 1;
	if (velora_cstr_has(p, "HideJB") || velora_cstr_has(p, "iHide") || velora_cstr_has(p, "TrollStore") || velora_cstr_has(p, "TrollHelper"))
		return 1;
	if (velora_cstr_has(p, "/usr/lib/frida") || velora_cstr_has(p, "/usr/lib/substrate") || velora_cstr_has(p, "/usr/lib/tweaks"))
		return 1;
	if (velora_cstr_eq(p, "/dev/kmem") || velora_cstr_eq(p, "/dev/mem") || velora_cstr_has(p, "libkrw"))
		return 1;
	if (velora_cstr_has(p, "LibertyPref") || velora_cstr_has(p, "ShadowPreferences") || velora_cstr_has(p, "ABypassPrefs") || velora_cstr_has(p, "FlyJBPrefs"))
		return 1;
	if (velora_cstr_has(p, "BawAppie") || velora_cstr_has(p, "com.ikey.bbot") || velora_cstr_has(p, "Cydia.Startup"))
		return 1;
	if (velora_cstr_has(p, "sftp-server") || velora_cstr_has(p, "ssh-keysign") || velora_cstr_has(p, "Veency") || velora_cstr_has(p, "roothideinit"))
		return 1;
	if (velora_cstr_has(p, "Electra.app") || velora_cstr_has(p, "Chimera.app") || velora_cstr_has(p, "Taurine.app") || velora_cstr_has(p, "Odyssey.app"))
		return 1;
	if (velora_cstr_has(p, "dumpdecrypted") || velora_cstr_has(p, "debugserver") || velora_cstr_has(p, "/etc/alternatives") || velora_cstr_has(p, "/usr/bin/uicache"))
		return 1;
	if (velora_cstr_has(p, "AppSync") || velora_cstr_has(p, "frida-gadget") || velora_cstr_has(p, "UnSub"))
		return 1;
	if (velora_cstr_has(p, "saurik") || velora_cstr_has(p, "Cydia"))
		return 1;
	if (velora_cstr_has(p, "/usr/share/jailbreak") || velora_cstr_has(p, "amfid_payload") || velora_cstr_has(p, "libcycript"))
		return 1;
	if (velora_cstr_has(p, "Velora.dylib") || velora_cstr_has(p, "Velora.plist") || velora_cstr_has(p, "com.velora.hz"))
		return 1;
	return 0;
}

int velora_jb_scheme(const char *u) {
	if (!u || !u[0])
		return 0;
	if (velora_cstr_has_ci(u, "cydia://") || velora_cstr_has_ci(u, "sileo://") || velora_cstr_has_ci(u, "zbra://"))
		return 1;
	if (velora_cstr_has_ci(u, "zebra://") || velora_cstr_has_ci(u, "filza://") || velora_cstr_has_ci(u, "activator://"))
		return 1;
	if (velora_cstr_has_ci(u, "undecimus://") || velora_cstr_has_ci(u, "palera1n://") || velora_cstr_has_ci(u, "dopamine://"))
		return 1;
	if (velora_cstr_has_ci(u, "installer://") || velora_cstr_has_ci(u, "santander://") || velora_cstr_has_ci(u, "newterm://"))
		return 1;
	if (velora_cstr_has_ci(u, "apptapp://") || velora_cstr_has_ci(u, "package://"))
		return 1;
	if (velora_cstr_has_ci(u, "trollstore://") || velora_cstr_has_ci(u, "apple-magnifier://") || velora_cstr_has_ci(u, "troll://"))
		return 1;
	if (velora_cstr_has_ci(u, "icleaner://") || velora_cstr_has_ci(u, "icleanerpro://") || velora_cstr_has_ci(u, "mterminal://"))
		return 1;
	if (velora_cstr_has_ci(u, "xina://") || velora_cstr_has_ci(u, "electra://") || velora_cstr_has_ci(u, "chimera://"))
		return 1;
	if (velora_cstr_has_ci(u, "odyssey://") || velora_cstr_has_ci(u, "taurine://") || velora_cstr_has_ci(u, "fugu://"))
		return 1;
	return 0;
}

int velora_jb_env(const char *name) {
	if (!name || !name[0])
		return 0;
	if (velora_cstr_has(name, "DYLD_INSERT") || velora_cstr_has(name, "DYLD_FORCE") || velora_cstr_has(name, "DYLD_SHARED_REGION"))
		return 1;
	if (velora_cstr_has(name, "_MSSafeMode") || velora_cstr_has(name, "_SafeMode") || velora_cstr_has(name, "Substitute"))
		return 1;
	if (velora_cstr_has(name, "JBINJECT") || velora_cstr_has(name, "CYDIASUBSTRATE") || velora_cstr_has(name, "ELLEKIT"))
		return 1;
	if (velora_cstr_eq(name, "Cydia") || velora_cstr_has(name, "SUBSTRATE") || velora_cstr_has(name, "LIBHOOKER"))
		return 1;
	return 0;
}

int velora_jb_cmd(const char *cmd) {
	if (!cmd || !cmd[0])
		return 0;
	if (velora_jb_path(cmd))
		return 1;
	if (velora_cstr_has(cmd, "cydia") || velora_cstr_has(cmd, "sileo") || velora_cstr_has(cmd, "dpkg"))
		return 1;
	if (velora_cstr_has(cmd, "apt-get") || velora_cstr_has(cmd, "apt-key") || velora_cstr_has(cmd, "ldid"))
		return 1;
	if (velora_cstr_has(cmd, "sshd") || velora_cstr_has(cmd, "cycript") || velora_cstr_has(cmd, "frida"))
		return 1;
	if (velora_cstr_has(cmd, "uicache") || velora_cstr_has(cmd, "jailbreak") || velora_cstr_has(cmd, "substrate"))
		return 1;
	return 0;
}

int velora_jb_class(const char *n) {
	if (!n || !n[0])
		return 0;
	if (velora_cstr_eq(n, "ShadowRuleset") || velora_cstr_eq(n, "ShadowSettings") || velora_cstr_eq(n, "ShadowService"))
		return 1;
	if (velora_cstr_eq(n, "ABypass") || velora_cstr_eq(n, "ABWindow") || velora_cstr_eq(n, "ABypass2"))
		return 1;
	if (velora_cstr_eq(n, "FlyJB") || velora_cstr_eq(n, "FlyJBX") || velora_cstr_eq(n, "UnSub"))
		return 1;
	if (velora_cstr_eq(n, "Liberty") || velora_cstr_eq(n, "Choicy") || velora_cstr_eq(n, "HideJB") || velora_cstr_eq(n, "VnodeBypass"))
		return 1;
	if (velora_cstr_eq(n, "Hestia") || velora_cstr_eq(n, "iHide") || velora_cstr_eq(n, "FLEXManager") || velora_cstr_eq(n, "FridaGadget"))
		return 1;
	if (velora_cstr_eq(n, "SubstrateLoader") || velora_cstr_eq(n, "Cydia") || velora_cstr_has(n, "Cycript"))
		return 1;
	return 0;
}

int velora_jb_write_path(const char *p) {
	if (!p || !p[0])
		return 0;
	if (velora_cstr_eq(p, "/") || velora_cstr_eq(p, "/private") || velora_cstr_eq(p, "/private/") || velora_cstr_eq(p, "/root") || velora_cstr_eq(p, "/jb"))
		return 1;
	if (velora_cstr_eq(p, "/var") || velora_cstr_eq(p, "/var/") || velora_cstr_eq(p, "/private/var") || velora_cstr_eq(p, "/private/var/"))
		return 1;
	if (velora_jb_path(p))
		return 1;
	return 0;
}

int velora_jb_stash_path(const char *p) {
	if (!p || !p[0])
		return 0;
	if (velora_cstr_eq(p, "/Applications") || velora_cstr_eq(p, "/Library/Ringtones") || velora_cstr_eq(p, "/Library/Wallpaper"))
		return 1;
	if (velora_cstr_eq(p, "/usr/include") || velora_cstr_eq(p, "/usr/libexec") || velora_cstr_eq(p, "/usr/share") || velora_cstr_eq(p, "/usr/arm-apple-darwin9"))
		return 1;
	return 0;
}

int velora_jb_syscall_path_slot(int n) {
	switch (n) {
	case 5:
	case 33:
	case 58:
	case 157:
	case 188:
	case 190:
	case 216:
	case 277:
	case 279:
	case 280:
	case 284:
	case 338:
	case 340:
	case 345:
		return 1;
	case 463:
	case 466:
	case 469:
	case 470:
	case 473:
		return 2;
	default:
		return 0;
	}
}

int velora_jb_syscall_special(int n) {
	if (n == 2 || n == 66)
		return 1;
	if (n == 26)
		return 2;
	if (n == 39)
		return 3;
	if (n == 169)
		return 4;
	return 0;
}

int velora_jb_rasp_kind(const char *name) {
	if (!name || !name[0])
		return 0;
	while (*name == '_')
		name++;
	if (velora_cstr_eq(name, "GetHackingDetected"))
		return 2;
	if (velora_cstr_eq(name, "GetAppSealingHackingDetected"))
		return 2;
	if (velora_cstr_eq(name, "Unity_GetAppSealingHackingDetected"))
		return 2;
	if (velora_cstr_eq(name, "Unity_IsAbnormalEnvironmentDetected"))
		return 1;
	if (velora_cstr_eq(name, "IsAbnormalEnvironmentDetected"))
		return 1;
	if (velora_cstr_eq(name, "AppSealing_IsAbnormalEnvironmentDetected"))
		return 1;
	return 0;
}

int velora_jb_rasp_sym(const char *name) {
	return velora_jb_rasp_kind(name) != 0;
}

int velora_jb_debug_port(int port) {
	if (port == 27042 || port == 27043 || port == 27047)
		return 1;
	if (port == 23946 || port == 4444)
		return 1;
	return 0;
}

int velora_jb_proc_name(const char *name) {
	if (!name || !name[0])
		return 0;
	if (velora_cstr_has_ci(name, "frida") || velora_cstr_has_ci(name, "cycript"))
		return 1;
	if (velora_cstr_has_ci(name, "debugserver") || velora_cstr_has_ci(name, "gdbserver"))
		return 1;
	if (velora_cstr_has_ci(name, "cynject") || velora_cstr_has_ci(name, "sslkill"))
		return 1;
	if (velora_cstr_eq(name, "substrate") || velora_cstr_has_ci(name, "ellekitd"))
		return 1;
	return 0;
}

int velora_jb_loopback_debug(const unsigned char *sa, unsigned int len) {
	unsigned short port;
	int i, zero;
	if (!sa || len < 8)
		return 0;
	port = (unsigned short)(((unsigned int)sa[2] << 8) | sa[3]);
	if (sa[1] == 2) {
		if (sa[4] == 127 && sa[5] == 0 && sa[6] == 0 && sa[7] == 1)
			return velora_jb_debug_port((int)port);
		return 0;
	}
	if (sa[1] == 30 && len >= 24) {
		zero = 1;
		for (i = 8; i < 23; i++) {
			if (sa[i]) {
				zero = 0;
				break;
			}
		}
		if (zero && sa[23] == 1)
			return velora_jb_debug_port((int)port);
	}
	return 0;
}

int velora_jb_rasp_alert(const char *title, const char *msg) {
	const char *t = title ? title : "";
	const char *m = msg ? msg : "";
	if (velora_cstr_has_ci(t, "detected tampering") || velora_cstr_has_ci(m, "detected tampering"))
		return 1;
	if (velora_cstr_has_ci(t, "resigning of this app") || velora_cstr_has_ci(m, "resigning of this app"))
		return 1;
	if (velora_cstr_has_ci(t, "debugging or similar") || velora_cstr_has_ci(m, "debugging or similar"))
		return 1;
	if (velora_cstr_has_ci(m, "cannot be used with a debugging"))
		return 1;
	if (velora_cstr_has_ci(t, "abnormal environment") || velora_cstr_has_ci(m, "abnormal environment"))
		return 1;
	if (velora_cstr_has(m, "REF: 6917") || velora_cstr_has(m, "REF: 6919"))
		return 1;
	if (velora_cstr_has(m, "REF:6917") || velora_cstr_has(m, "REF:6919"))
		return 1;
	if (velora_cstr_has_ci(m, "to protect you, the app will close"))
		return 1;
	return 0;
}

int velora_jb_scrub_procbuf(char *buf, unsigned long n) {
	static const char *needles[] = {
		"frida",
		"cycript",
		"debugserver",
		"gdbserver",
		"cynject",
		"sslkill",
		0,
	};
	unsigned long i;
	int hits = 0;
	int nidx;
	if (!buf || n == 0)
		return 0;
	for (nidx = 0; needles[nidx]; nidx++) {
		const char *nd = needles[nidx];
		int ln = 0;
		while (nd[ln])
			ln++;
		if ((unsigned long)ln > n)
			continue;
		for (i = 0; i + (unsigned long)ln <= n; i++) {
			int k = 0;
			while (k < ln && fold_ch(buf[i + (unsigned long)k]) == fold_ch(nd[k]))
				k++;
			if (k == ln) {
				int j;
				for (j = 0; j < ln; j++)
					buf[i + (unsigned long)j] = 'x';
				hits++;
				i += (unsigned long)(ln - 1);
			}
		}
	}
	return hits;
}

unsigned long long velora_compat_alert_type(int bypass_on, unsigned long long type) {
	if (bypass_on)
		return 0;
	return type;
}

int velora_compat_launch_prohibited(int bypass_on, int orig) {
	if (bypass_on)
		return 0;
	return orig ? 1 : 0;
}

int velora_compat_block_updates(int store_block, int bypass_on) {
	return (store_block || bypass_on) ? 1 : 0;
}

int velora_compat_skip_show(int bypass_on) {
	return bypass_on ? 1 : 0;
}

int velora_compat_alert_item(const char *cls) {
	if (!cls || !cls[0])
		return 0;
	if (velora_cstr_has(cls, "LaunchNotify"))
		return 1;
	if (velora_cstr_has(cls, "LaunchBlocked"))
		return 1;
	if (velora_cstr_has(cls, "LaunchProhibited"))
		return 1;
	if (velora_cstr_has(cls, "CompatibilityAlert"))
		return 1;
	if (velora_cstr_has(cls, "LaunchAlertItem"))
		return 1;
	return 0;
}

int velora_compat_pref_combine(int file_on, int file_known, int cf_on, int cf_known, int def_on) {
	if (file_known && file_on)
		return 1;
	if (cf_known && cf_on)
		return 1;
	if (def_on)
		return 1;
	if (file_known)
		return 0;
	if (cf_known)
		return 0;
	return 0;
}

int velora_compat_state(int bypass_on, int orig) {
	if (!bypass_on)
		return orig;
	if (orig == 0 || orig >= 2)
		return 1;
	return orig;
}

int velora_compat_class_hook(const char *nm) {
	if (!nm || !nm[0])
		return 0;
	if (velora_cstr_has(nm, "LaunchAlert"))
		return 1;
	if (velora_cstr_has(nm, "LaunchNotify"))
		return 1;
	if (velora_cstr_has(nm, "CompatibilityAlert"))
		return 1;
	return 0;
}

int velora_is_jbapp_bid(const char *bid) {
	if (!bid || !bid[0])
		return 0;
	if (velora_cstr_has_ci(bid, "dopamine") && !velora_cstr_has_ci(bid, "trollstore"))
		return 1;
	if (velora_cstr_has_ci(bid, "nekojb") || velora_cstr_has_ci(bid, "neko-jb"))
		return 1;
	if (velora_cstr_eq(bid, "xyz.hhls.nekojb") || velora_cstr_eq(bid, "xyz.hhls.NekoJB"))
		return 1;
	if (velora_cstr_eq(bid, "com.opa334.Dopamine"))
		return 1;
	return 0;
}

int velora_is_jbapp_path(const char *path) {
	if (!path || !path[0])
		return 0;
	if (velora_cstr_has(path, "Dopamine.app") || velora_cstr_has(path, "/Dopamine"))
		return 1;
	if (velora_cstr_has(path, "NekoJB.app") || velora_cstr_has(path, "nekoJB.app"))
		return 1;
	return 0;
}

int velora_is_jb_update_url(const char *url) {
	if (!url || !url[0])
		return 0;
	if (velora_cstr_has(url, "apple-magnifier://install")) {
		if (velora_cstr_has(url, "Dopamine") || velora_cstr_has(url, "dopamine") || velora_cstr_has(url, "nekojb") || velora_cstr_has(url, "NekoJB"))
			return 1;
		if (velora_cstr_has(url, "opa334") || velora_cstr_has(url, "ellekit.space"))
			return 1;
		return 0;
	}
	if (velora_cstr_has(url, "github.com/opa334/Dopamine"))
		return 1;
	if (velora_cstr_has(url, "ellekit.space/dopamine"))
		return 1;
	if (velora_cstr_has(url, "nekojb.hhls.xyz"))
		return 1;
	return 0;
}

int velora_is_jb_update_key(const char *key) {
	if (!key)
		return 0;
	if (velora_cstr_eq(key, "Button_Update"))
		return 1;
	if (velora_cstr_eq(key, "Button_Update_Environment"))
		return 1;
	return 0;
}

int velora_is_jb_update_id(const char *ident) {
	if (!ident || !ident[0])
		return 0;
	if (velora_cstr_eq(ident, "update"))
		return 1;
	if (velora_cstr_eq(ident, "Button_Update") || velora_cstr_eq(ident, "Button_Update_Environment"))
		return 1;
	return 0;
}

int velora_update_title_needs_tag(const char *title) {
	if (!title || !title[0])
		return 1;
	if (velora_cstr_has(title, "Rootful") || velora_cstr_has(title, "rootful"))
		return 0;
	return 1;
}

int velora_is_rootful_rel(const char *rel) {
	if (!rel || !rel[0])
		return 0;
	if (velora_cstr_has_ci(rel, "velora-rootful") || velora_cstr_has_ci(rel, "velora-jbupdate"))
		return 1;
	if (velora_cstr_has_ci(rel, "rootful"))
		return 1;
	if (velora_cstr_has_ci(rel, "fakefs") || velora_cstr_has_ci(rel, "fake-fs") || velora_cstr_has_ci(rel, "fake_fs"))
		return 1;
	if (velora_cstr_has_ci(rel, "bindfs") || velora_cstr_has_ci(rel, "bind_fs"))
		return 1;
	if (velora_cstr_has_ci(rel, "createfakefs") || velora_cstr_has_ci(rel, "jbroot"))
		return 1;
	if (velora_cstr_has_ci(rel, "palera1n") || velora_cstr_has_ci(rel, "nekoloader") || velora_cstr_has_ci(rel, "orig-fs"))
		return 1;
	if (velora_cstr_has_ci(rel, "paleinfo") || velora_cstr_has_ci(rel, "p1ctl") || velora_cstr_has_ci(rel, "xystem"))
		return 1;
	if (velora_cstr_has_ci(rel, "loader.json") || velora_cstr_has_ci(rel, "sileo.deb") || velora_cstr_has_ci(rel, "zebra.deb"))
		return 1;
	if (velora_cstr_has_ci(rel, "bootstrap.tar") || velora_cstr_has_ci(rel, "bootstrap-ssh") || velora_cstr_has_ci(rel, "bootstrap.conf"))
		return 1;
	if (velora_cstr_has_ci(rel, "preferenceloader") || velora_is_nested_loader_ipa(rel))
		return 1;
	return 0;
}

int velora_is_dopamine_core(const char *rel) {
	const char *base;
	int i;
	if (!rel || !rel[0])
		return 0;
	base = rel;
	for (i = 0; rel[i]; i++) {
		if (rel[i] == '/' || rel[i] == '\\')
			base = rel + i + 1;
	}
	if (velora_cstr_eq(base, "Dopamine") || velora_cstr_eq(base, "Info.plist") || velora_cstr_eq(base, "PkgInfo"))
		return 1;
	if (velora_cstr_eq(base, "basebin.tar") || velora_cstr_eq(base, "basebin.tc") || velora_cstr_eq(base, "basebin.tar.gz"))
		return 1;
	if (velora_cstr_eq(base, "Assets.car"))
		return 1;
	if (velora_cstr_has_ci(rel, "/Frameworks/") || velora_cstr_has_ci(rel, "/Plugins/"))
		return 1;
	if (velora_cstr_has_ci(rel, "_CodeSignature"))
		return 1;
	return 0;
}

int velora_rootful_patch_old(const char *ver) {
	if (!ver || !ver[0])
		return 1;
	if (velora_cstr_has(ver, "palera1n-2.4") || velora_cstr_has(ver, "palera1n-3"))
		return 0;
	if (velora_cstr_eq(ver, "2.4") || velora_cstr_has(ver, "3.0.0-beta"))
		return 0;
	return 1;
}

const char *velora_fakefs_disk(void) {
	return "disk0s1s7";
}

const char *velora_fakefs_dev(void) {
	return "/dev/disk0s1s7";
}

int velora_rewrite_fakefs_disk(char *s) {
	int hits = 0;
	char *p;
	if (!s)
		return 0;
	for (p = s; *p; p++) {
		if (p[0] == 'd' && p[1] == 'i' && p[2] == 's' && p[3] == 'k' &&
			p[4] == '0' && p[5] == 's' && p[6] == '1' && p[7] == 's' && p[8] == '8') {
			p[8] = '7';
			hits++;
		}
	}
	return hits;
}

int velora_is_nested_loader_ipa(const char *rel) {
	const char *base;
	int i;
	if (!rel || !rel[0])
		return 0;
	base = rel;
	for (i = 0; rel[i]; i++) {
		if (rel[i] == '/' || rel[i] == '\\')
			base = rel + i + 1;
	}
	if (!(velora_cstr_end(base, ".tipa") || velora_cstr_end(base, ".ipa") || velora_cstr_end(base, ".zip")
		|| velora_cstr_end(base, ".TIPA") || velora_cstr_end(base, ".IPA") || velora_cstr_end(base, ".ZIP")))
		return 0;
	if (velora_cstr_has_ci(rel, "nekoloader") || velora_cstr_has_ci(rel, "neko-loader") || velora_cstr_has_ci(rel, "neko_loader"))
		return 1;
	if (velora_cstr_has_ci(rel, "palera1nloader") || velora_cstr_has_ci(rel, "palera1n-loader") || velora_cstr_has_ci(rel, "palera1n_loader"))
		return 1;
	if (velora_cstr_eq(base, "loader.tipa") || velora_cstr_eq(base, "loader.ipa") || velora_cstr_eq(base, "loader.zip"))
		return 1;
	return 0;
}

int velora_is_rootless_pm_url(const char *u) {
	if (!u || !u[0])
		return 0;
	if (velora_cstr_has(u, "/rootless/sileo") || velora_cstr_has(u, "rootless/sileo.deb"))
		return 1;
	if (velora_cstr_has(u, "/rootless/zebra") || velora_cstr_has(u, "rootless/zebra.deb"))
		return 1;
	if (velora_cstr_has(u, "/var/jb/Applications/Sileo") || velora_cstr_has(u, "/var/jb/Applications/Zebra"))
		return 1;
	if (velora_cstr_has(u, "rootless") && velora_cstr_has(u, "sileo.deb"))
		return 1;
	if (velora_cstr_has(u, "rootless") && velora_cstr_has(u, "zebra.deb"))
		return 1;
	return 0;
}

int velora_is_rootless_bootstrap_url(const char *u) {
	if (!u || !u[0])
		return 0;
	if (velora_cstr_has(u, "rootless") && velora_cstr_has(u, "bootstrap"))
		return 1;
	if (velora_cstr_has(u, "/var/jb/.procursus_strapped"))
		return 1;
	if (velora_cstr_has(u, "bootstrap-") && velora_cstr_has(u, "rootless"))
		return 1;
	if (velora_cstr_has(u, "static.palera.in/rootless/"))
		return 1;
	return 0;
}

int velora_is_rootless_pref_url(const char *u) {
	if (!u || !u[0])
		return 0;
	if (velora_cstr_has(u, "rootless/preferenceloader") || velora_cstr_has(u, "rootless/preference"))
		return 1;
	if (velora_cstr_has(u, "/var/jb/Library/PreferenceLoader") || velora_cstr_has(u, "/var/jb/Library/PreferenceBundles"))
		return 1;
	if (velora_cstr_has(u, "rootless") && velora_cstr_has(u, "preferenceloader"))
		return 1;
	return 0;
}

const char *velora_rootful_sileo_url(void) {
	return "https://static.palera.in/sileo.deb";
}

const char *velora_rootful_zebra_url(void) {
	return "https://static.palera.in/zebra.deb";
}

const char *velora_rootful_bootstrap_url(void) {
	return "https://static.palera.in/bootstrap.tar.zst";
}

const char *velora_rootful_pref_url(void) {
	return "https://static.palera.in/preferenceloader.deb";
}

const char *velora_rootful_pm_url(const char *u) {
	if (!u)
		return "https://static.palera.in/sileo.deb";
	if (velora_cstr_has(u, "zebra") || velora_cstr_has(u, "Zebra") || velora_cstr_has(u, "zbra"))
		return velora_rootful_zebra_url();
	if (velora_cstr_has(u, "bootstrap") || velora_cstr_has(u, "strap") || velora_cstr_has(u, "procursus"))
		return velora_rootful_bootstrap_url();
	if (velora_cstr_has(u, "preference") || velora_cstr_has(u, "Preference") || velora_cstr_has(u, "prefloader"))
		return velora_rootful_pref_url();
	return velora_rootful_sileo_url();
}

int velora_is_fakefs_screen_title(const char *title) {
	if (!title || !title[0])
		return 0;
	if (velora_cstr_has(title, "Creating FakeFS") || velora_cstr_has(title, "Create FakeFS"))
		return 1;
	if (velora_cstr_has(title, "FakeFS") && (velora_cstr_has(title, "Boot") || velora_cstr_has(title, "Create") || velora_cstr_has(title, "Setup")))
		return 1;
	return 0;
}

