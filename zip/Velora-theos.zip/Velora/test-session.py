#!/usr/bin/env python3
"""Host checks: Apple + ARM sessions persist, refresh, and survive empty/expired cases."""
from pathlib import Path
import re
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
store = (ROOT / "velora-store.c").read_text(encoding="utf-8")
menu = (ROOT / "velora-menu.c").read_text(encoding="utf-8")
plist = (ROOT / "layout/Library/PreferenceLoader/Preferences/VeloraStore.plist").read_text(encoding="utf-8")
fail = 0


def check(cond, name):
    global fail
    if not cond:
        print("FAIL", name)
        fail += 1
    else:
        print("ok", name)


# --- source: Apple session (AppStore++ device account) ---
check("capture_apple_session" in store, "captures Apple session from SSAccount")
check("appleToken" in store and "appleDsid" in store, "persists token + dsid")
check("appleCookies" in store and "appleStoreFront" in store, "persists cookies + storefront")
check("secureToken" in store, "reads SSAccount.secureToken")
check("passwordEquivalentToken" in store, "reads passwordEquivalentToken fallback")
check("X-Token" in store, "sends X-Token on Apple requests")
check("apply_apple_auth" in store, "shared Apple auth header helper")
check("http_plist" in store and "apply_apple_auth(req, dsid)" in store, "plist requests use Apple auth")
check("VeloraSessionKeeper" in store, "background session keeper class")
check("keepAlive" in store, "keeper keepAlive selector")
check("schedule_keep" in store, "reschedules keepalive")
check("480.0" in store, "keepalive interval is 8 minutes")
check("start_session_keeper" in store, "store init starts keeper")
check("failureType" in store and "2034" in store, "detects expired password token")
check("2042" in store, "detects sign-in-required failure")
check('shared_get("appleDsid")' in store, "dsid falls back to persisted session")
check("capture_apple_session();" in store[store.find("static void start_pending_purchase") : store.find("static id dict_url")], "purchase recaptures session")
check("start_pending_purchase" not in store[store.find("void velora_store_init") :], "init still does not auto-purchase")

# --- source: ARM session ---
check("harvest_arm_session" in store, "harvests ARM session cookie")
check("plant_arm_cookie" in store, "plants session into cookie jar")
check("remember_arm_session" in store, "persists ARM session")
check("merge_cookie_jar" in store, "merges session= into Cookie header")
check("extract_cookie_value" in store, "parses Set-Cookie")
check("/decryptedappstore/user/info" in store, "pings ARM user/info to keep session")
check("remember_session_from_header" in store, "refreshes session from Set-Cookie")
check('streq(cur, store_cstr(s))' in store, "does not rewrite identical ARM session")
check("if (!s || !store_cstr(s)[0])" in store[store.find("static void remember_arm_session") : store.find("static id cookie_named_for_url")], "empty ARM session is ignored")
check("ARM Store session expired" in store, "clear error when ARM session is dead")
check("com.velora.hz.session" in store, "Darwin session notify")
check("on_session_note" in store, "store observes session notify")

# cookie merge must not overwrite the whole jar
arm_hdr = store[store.find("static void apply_arm_headers") : store.find("static volatile int gIpaDone")]
check("merge_cookie_jar" in arm_hdr, "ARM headers merge cookies")
check('nsstr("session=")' not in arm_hdr or "merge_cookie_jar" in arm_hdr, "ARM headers do not clobber Cookie with only session=")

# --- no secrets baked in ---
check("iosgods.com/login" not in store, "no iOSGods password login in tweak")
check(not re.search(r'password\s*=\s*"[^"]+"', store), "no hardcoded password")
check("appleIdPassword" not in store and "armPass" not in store, "no Apple/ARM password fields")

# --- Settings UI ---
check("appleAccountName" in menu and "appleSessionStatus" in menu, "menu exposes Apple session status")
check("armSessionStatus" in menu, "menu exposes ARM session status")
check("Device Apple ID" in menu, "fallback Apple ID label")
check("Waiting for App Store" in menu, "unsigned Apple state")
check("Not signed in" in menu, "unsigned ARM state")
check("Signed in (background)" in menu, "active Apple session copy")
check('notify_post("com.velora.hz.session")' in menu, "pasting cookie wakes store daemon")
check("armSession" in plist, "store pane has session field")
check("Paste session cookie" in plist, "session placeholder")
check("appleAccountName" in plist and "appleSessionStatus" in plist, "store pane shows Apple account")
check("armSessionStatus" in plist, "store pane shows ARM status")

# --- host unit tests for cookie helpers ---
src_merge = store[store.find("static int cat(char *b, int n, int cap, const char *s) {") : store.find("static const char *store_cstr(id s) {")]
c = r'''
#include <stdio.h>
#include <string.h>
''' + src_merge + r'''
int main(void) {
	char out[256];
	/* empty jar + session */
	if (!merge_cookie_jar(out, 256, "", "session", "ABC")) return 1;
	if (strcmp(out, "session=ABC")) { fprintf(stderr, "empty %s\n", out); return 2; }
	/* append */
	if (!merge_cookie_jar(out, 256, "a=1; b=2", "session", "XYZ")) return 3;
	if (strcmp(out, "a=1; b=2; session=XYZ")) { fprintf(stderr, "append %s\n", out); return 4; }
	/* replace existing session without dropping others */
	if (!merge_cookie_jar(out, 256, "foo=1; session=OLD; bar=2", "session", "NEW")) return 5;
	if (strcmp(out, "foo=1; session=NEW; bar=2")) { fprintf(stderr, "replace %s\n", out); return 6; }
	/* empty value keeps jar */
	if (!merge_cookie_jar(out, 256, "session=KEEP", "session", "")) return 7;
	if (strcmp(out, "session=KEEP")) { fprintf(stderr, "empty val %s\n", out); return 8; }
	/* null name keeps jar */
	if (!merge_cookie_jar(out, 256, "a=1", 0, "x")) return 9;
	if (strcmp(out, "a=1")) return 10;
	/* extract session from Set-Cookie */
	if (!extract_cookie_value(out, 256, "session=TOK123; Path=/; HttpOnly", "session")) return 11;
	if (strcmp(out, "TOK123")) { fprintf(stderr, "extract %s\n", out); return 12; }
	/* extract case-insensitive, later cookies */
	if (!extract_cookie_value(out, 256, "foo=1; Session=ZZ; bar=2", "session")) return 13;
	if (strcmp(out, "ZZ")) { fprintf(stderr, "ci %s\n", out); return 14; }
	/* missing cookie */
	if (extract_cookie_value(out, 256, "foo=1; bar=2", "session")) return 15;
	/* no crash on nulls */
	if (extract_cookie_value(out, 256, 0, "session")) return 16;
	if (merge_cookie_jar(0, 256, "a", "b", "c")) return 17;
	return 0;
}
'''
td = Path(tempfile.mkdtemp())
srcp = td / "sess.c"
binp = td / "sess"
srcp.write_text(c)
r = subprocess.run(["gcc", "-O0", "-o", str(binp), str(srcp)], capture_output=True, text=True)
check(r.returncode == 0, "cookie helper test compiled")
if r.returncode != 0:
    print(r.stderr[-1500:])
else:
    r2 = subprocess.run([str(binp)], capture_output=True, text=True)
    check(r2.returncode == 0, "cookie merge/extract cases")
    if r2.returncode != 0:
        print("stderr", r2.stderr)

# retry paths
prep = store[store.find("static id arm_prepare_token") : store.find("static id arm_ipa_download_url")]
check(prep.count("harvest_arm_session") >= 2, "prepare retries after loginRequired")
check(prep.count("ping_arm_session") >= 2, "prepare pings ARM session on block")
blocked = store[store.find("static int arm_login_blocked(id obj) {") : store.find("static int ping_arm_session(void) {")]
pingfn = store[store.find("static int ping_arm_session(void) {") : store.find("static void keep_tick(id self, SEL sel) {")]
check("forbidden" in blocked, "403/forbidden counts as logged-out")
check("igid" in pingfn, "ARM ping requires real user payload")
check('shared_set("armSessionOn", nsstr("1"))' in pingfn, "only marks ARM signed-in on user info")
check("error" in pingfn and "return 0" in pingfn, "ARM ping fails closed on error payload")

if fail:
    print(fail, "failed")
    sys.exit(1)
print("ok")
