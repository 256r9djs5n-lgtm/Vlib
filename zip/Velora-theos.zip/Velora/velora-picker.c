/* Settings app picker: AltList when present, otherwise LSApplicationWorkspace + search. */
void *dlopen(const char *path, int mode);
#define RTLD_LAZY 1

typedef struct objc_class *Class;
typedef struct objc_object *id;
typedef struct objc_selector *SEL;
typedef struct objc_ivar *Ivar;
typedef void (*IMP)(void);
typedef long NSInteger;

struct objc_super {
	id receiver;
	Class super_class;
};

extern Class objc_getClass(const char *name);
extern Class object_getClass(id obj);
extern SEL sel_registerName(const char *name);
extern void objc_msgSend(void);
extern void objc_msgSendSuper(void);
extern Class objc_allocateClassPair(Class super, const char *name, unsigned long extra);
extern void objc_registerClassPair(Class cls);
extern int class_addMethod(Class cls, SEL name, IMP imp, const char *types);
extern Ivar class_getInstanceVariable(Class cls, const char *name);
extern id object_getIvar(id obj, Ivar ivar);
extern void object_setIvar(id obj, Ivar ivar, id value);
extern void objc_setAssociatedObject(id object, const void *key, id value, unsigned policy);
extern id objc_getAssociatedObject(id object, const void *key);
extern unsigned char class_respondsToSelector(Class cls, SEL sel);
extern Class class_getSuperclass(Class cls);

#define OBJC_ASSOCIATION_RETAIN 01401

static char kSel, kKey, kDomain, kFilter;
static int gUseAtl;

static id nsstr(const char *c) {
	id (*f)(Class, SEL, const char *) = (id(*)(Class, SEL, const char *))objc_msgSend;
	return f(objc_getClass("NSString"), sel_registerName("stringWithUTF8String:"), c);
}

static id msg0(id obj, const char *sel) {
	if (!obj)
		return 0;
	id (*f)(id, SEL) = (id(*)(id, SEL))objc_msgSend;
	return f(obj, sel_registerName(sel));
}

static id msg1(id obj, const char *sel, id a) {
	if (!obj)
		return 0;
	id (*f)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
	return f(obj, sel_registerName(sel), a);
}

static id msg2(id obj, const char *sel, id a, id b) {
	if (!obj)
		return 0;
	id (*f)(id, SEL, id, id) = (id(*)(id, SEL, id, id))objc_msgSend;
	return f(obj, sel_registerName(sel), a, b);
}

static id cls0(Class c, const char *sel) {
	if (!c)
		return 0;
	id (*f)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	return f(c, sel_registerName(sel));
}

static int streq(id a, const char *b) {
	if (!a)
		return 0;
	unsigned char (*eq)(id, SEL, id) = (unsigned char (*)(id, SEL, id))objc_msgSend;
	return eq(a, sel_registerName("isEqualToString:"), nsstr(b)) ? 1 : 0;
}

static int responds(id obj, const char *sel) {
	if (!obj)
		return 0;
	unsigned char (*r)(id, SEL, SEL) = (unsigned char (*)(id, SEL, SEL))objc_msgSend;
	return r(obj, sel_registerName("respondsToSelector:"), sel_registerName(sel)) ? 1 : 0;
}

static Ivar spec_ivar(id self) {
	Class c = object_getClass(self);
	while (c) {
		Ivar iv = class_getInstanceVariable(c, "_specifiers");
		if (iv)
			return iv;
		c = class_getSuperclass(c);
	}
	return 0;
}

static NSInteger ncount(id arr) {
	if (!arr)
		return 0;
	NSInteger (*c)(id, SEL) = (NSInteger(*)(id, SEL))objc_msgSend;
	return c(arr, sel_registerName("count"));
}

static id nobj(id arr, NSInteger i) {
	id (*f)(id, SEL, NSInteger) = (id(*)(id, SEL, NSInteger))objc_msgSend;
	return f(arr, sel_registerName("objectAtIndex:"), i);
}

static id retained_array(void) {
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	id obj = al(objc_getClass("NSMutableArray"), sel_registerName("alloc"));
	return msg0(obj, "init");
}

static id retained_set(void) {
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	id obj = al(objc_getClass("NSMutableSet"), sel_registerName("alloc"));
	return msg0(obj, "init");
}

static const char *cstr(id s) {
	if (!s || !responds(s, "UTF8String"))
		return "";
	const char *(*f)(id, SEL) = (const char *(*)(id, SEL))objc_msgSend;
	const char *v = f(s, sel_registerName("UTF8String"));
	return v ? v : "";
}

static id spec_prop(id spec, const char *key) {
	if (!spec || !responds(spec, "propertyForKey:"))
		return 0;
	return msg1(spec, "propertyForKey:", nsstr(key));
}

static id suite_defaults(const char *suite) {
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	id obj = al(objc_getClass("NSUserDefaults"), sel_registerName("alloc"));
	id (*init)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
	return init(obj, sel_registerName("initWithSuiteName:"), nsstr(suite));
}

static int text_has(id s, id q) {
	if (!q || !cstr(q)[0])
		return 1;
	if (!s)
		return 0;
	if (responds(s, "localizedCaseInsensitiveContainsString:")) {
		unsigned char (*c)(id, SEL, id) = (unsigned char (*)(id, SEL, id))objc_msgSend;
		return c(s, sel_registerName("localizedCaseInsensitiveContainsString:"), q) ? 1 : 0;
	}
	return 1;
}

static int gFwOnce;

static void load_fw(void) {
	if (gFwOnce)
		return;
	gFwOnce = 1;
	const char *paths[] = {
		"/System/Library/Frameworks/CoreServices.framework/CoreServices",
		"/System/Library/PrivateFrameworks/MobileCoreServices.framework/MobileCoreServices",
		"/Library/Frameworks/AltList.framework/AltList",
		"/var/jb/Library/Frameworks/AltList.framework/AltList",
		"/usr/lib/AltList.framework/AltList",
		"/var/jb/usr/lib/AltList.framework/AltList",
		"/Library/MobileSubstrate/DynamicLibraries/AltList.dylib",
		"/var/jb/Library/MobileSubstrate/DynamicLibraries/AltList.dylib",
		"/usr/lib/TweakInject/AltList.dylib",
		"/var/jb/usr/lib/TweakInject/AltList.dylib",
		0,
	};
	for (int i = 0; paths[i]; i++)
		dlopen(paths[i], RTLD_LAZY);
}

static int proxy_flag(id proxy, const char *sel) {
	if (!proxy || !responds(proxy, sel))
		return 0;
	unsigned char (*b)(id, SEL) = (unsigned char (*)(id, SEL))objc_msgSend;
	return b(proxy, sel_registerName(sel)) ? 1 : 0;
}

static id all_apps(void) {
	load_fw();
	Class LS = objc_getClass("LSApplicationWorkspace");
	id ws = LS ? cls0(LS, "defaultWorkspace") : 0;
	if (!ws)
		return 0;
	const char *sels[] = {
		"allInstalledApplications",
		"allApplications",
		"installedApplications",
		0,
	};
	for (int i = 0; sels[i]; i++) {
		if (!responds(ws, sels[i]))
			continue;
		id arr = msg0(ws, sels[i]);
		if (ncount(arr) > 0)
			return arr;
	}
	return 0;
}

static void add_icon(id spec, id bid) {
	if (!spec || !bid)
		return;
	Class UI = objc_getClass("UIImage");
	if (!UI || !class_respondsToSelector(UI, sel_registerName("_applicationIconImageForBundleIdentifier:format:scale:")))
		return;
	id (*ic)(Class, SEL, id, NSInteger, double) = (id(*)(Class, SEL, id, NSInteger, double))objc_msgSend;
	id img = ic(UI, sel_registerName("_applicationIconImageForBundleIdentifier:format:scale:"), bid, (NSInteger)1, 2.0);
	if (img)
		msg2(spec, "setProperty:forKey:", img, nsstr("iconImage"));
}

static void load_selected(id self) {
	id parent = 0;
	if (responds(self, "specifier"))
		parent = msg0(self, "specifier");
	id key = spec_prop(parent, "key");
	id domain = spec_prop(parent, "defaults");
	if (!key)
		key = nsstr("VeloraEnabledApps");
	if (!domain)
		domain = nsstr("com.apple.UIKit");
	objc_setAssociatedObject(self, &kKey, key, OBJC_ASSOCIATION_RETAIN);
	objc_setAssociatedObject(self, &kDomain, domain, OBJC_ASSOCIATION_RETAIN);
	id defs = suite_defaults(cstr(domain));
	id arr = defs ? msg1(defs, "arrayForKey:", key) : 0;
	if (!arr) {
		id backup = suite_defaults("com.velora.hz");
		arr = backup ? msg1(backup, "arrayForKey:", key) : 0;
	}
	id set = retained_set();
	NSInteger n = ncount(arr);
	for (NSInteger i = 0; i < n; i++)
		msg1(set, "addObject:", nobj(arr, i));
	objc_setAssociatedObject(self, &kSel, set, OBJC_ASSOCIATION_RETAIN);
}

extern int notify_post(const char *name);

static void notify_post_reload(void) {
	notify_post("com.velora.hz/Reload");
}

static void save_selected(id self) {
	id key = objc_getAssociatedObject(self, &kKey);
	id domain = objc_getAssociatedObject(self, &kDomain);
	id set = objc_getAssociatedObject(self, &kSel);
	if (!key)
		return;
	id arr = set ? msg0(set, "allObjects") : retained_array();
	id defs = suite_defaults(cstr(domain));
	if (defs && responds(defs, "setObject:forKey:")) {
		void (*so)(id, SEL, id, id) = (void (*)(id, SEL, id, id))objc_msgSend;
		so(defs, sel_registerName("setObject:forKey:"), arr, key);
		msg0(defs, "synchronize");
	}
	id backup = suite_defaults("com.velora.hz");
	if (backup) {
		void (*so)(id, SEL, id, id) = (void (*)(id, SEL, id, id))objc_msgSend;
		so(backup, sel_registerName("setObject:forKey:"), arr, key);
		msg0(backup, "synchronize");
	}
	notify_post_reload();
}

static id group_spec(const char *title) {
	Class PS = objc_getClass("PSSpecifier");
	if (!PS)
		return 0;
	id (*f)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
	return f(PS, sel_registerName("groupSpecifierWithName:"), nsstr(title));
}

static id switch_spec(id self, id name, id bid) {
	Class PS = objc_getClass("PSSpecifier");
	if (!PS || !name || !bid)
		return 0;
	typedef id (*mk_t)(Class, SEL, id, id, SEL, SEL, id, NSInteger, id);
	mk_t mk = (mk_t)objc_msgSend;
	id spec = mk(PS, sel_registerName("preferenceSpecifierNamed:target:set:get:detail:cell:edit:"),
		name, self, sel_registerName("setVeloraApp:specifier:"), sel_registerName("veloraApp:"),
		(id)0, (NSInteger)6, (id)0);
	if (!spec)
		return 0;
	msg2(spec, "setProperty:forKey:", bid, nsstr("veloraBid"));
	add_icon(spec, bid);
	return spec;
}

static void add_apps(id self, id specs, const char *header, int want_user) {
	id group = group_spec(header);
	if (group)
		msg1(specs, "addObject:", group);
	id all = all_apps();
	NSInteger n = ncount(all);
	id names = retained_array();
	id bids = retained_array();
	id q = objc_getAssociatedObject(self, &kFilter);
	for (NSInteger i = 0; i < n; i++) {
		id proxy = nobj(all, i);
		if (!proxy)
			continue;
		if (proxy_flag(proxy, "isPlaceholder") || proxy_flag(proxy, "isRestricted") || proxy_flag(proxy, "isRemovedSystemApp"))
			continue;
		id bid = responds(proxy, "bundleIdentifier") ? msg0(proxy, "bundleIdentifier") : 0;
		if (!bid)
			continue;
		const char *b = cstr(bid);
		if (!b[0] || streq(bid, "com.apple.springboard"))
			continue;
		int skip = 0;
		for (const char *p = b; *p; p++) {
			if (p[0] == '.' && p[1] == 'a' && p[2] == 'p' && p[3] == 'p' && p[4] == 'e' && p[5] == 'x')
				skip = 1;
		}
		if (skip)
			continue;
		id type = responds(proxy, "applicationType") ? msg0(proxy, "applicationType") : 0;
		int is_user = 1;
		if (type && (streq(type, "System") || streq(type, "Internal")))
			is_user = 0;
		if (is_user != want_user)
			continue;
		id name = responds(proxy, "localizedName") ? msg0(proxy, "localizedName") : 0;
		if (!name)
			name = bid;
		if (!text_has(name, q) && !text_has(bid, q))
			continue;
		msg1(names, "addObject:", name);
		msg1(bids, "addObject:", bid);
	}
	NSInteger m = ncount(names);
	for (NSInteger i = 1; i < m; i++) {
		id nm = nobj(names, i);
		id bd = nobj(bids, i);
		NSInteger j = i;
		while (j > 0) {
			id prev = nobj(names, j - 1);
			NSInteger (*cmp)(id, SEL, id) = (NSInteger(*)(id, SEL, id))objc_msgSend;
			if (cmp(prev, sel_registerName("localizedCaseInsensitiveCompare:"), nm) <= 0)
				break;
			void (*rep)(id, SEL, id, NSInteger) = (void (*)(id, SEL, id, NSInteger))objc_msgSend;
			rep(names, sel_registerName("replaceObjectAtIndex:withObject:"), prev, j);
			rep(bids, sel_registerName("replaceObjectAtIndex:withObject:"), nobj(bids, j - 1), j);
			j--;
		}
		void (*rep)(id, SEL, id, NSInteger) = (void (*)(id, SEL, id, NSInteger))objc_msgSend;
		rep(names, sel_registerName("replaceObjectAtIndex:withObject:"), nm, j);
		rep(bids, sel_registerName("replaceObjectAtIndex:withObject:"), bd, j);
	}
	for (NSInteger i = 0; i < m; i++) {
		id spec = switch_spec(self, nobj(names, i), nobj(bids, i));
		if (spec)
			msg1(specs, "addObject:", spec);
	}
}

static id specifiers_imp(id self, SEL sel) {
	(void)sel;
	Ivar iv = spec_ivar(self);
	id specs = iv ? object_getIvar(self, iv) : 0;
	if (specs && ncount(specs) > 1)
		return specs;
	load_selected(self);
	specs = retained_array();
	add_apps(self, specs, "User", 1);
	add_apps(self, specs, "System", 0);
	if (ncount(specs) < 2) {
		id empty = group_spec("No apps found. Pull back and open this page again.");
		if (empty)
			msg1(specs, "addObject:", empty);
	}
	if (specs) {
		id (*retain)(id, SEL) = (id(*)(id, SEL))objc_msgSend;
		retain(specs, sel_registerName("retain"));
	}
	if (iv)
		object_setIvar(self, iv, specs);
	return specs;
}

static void picker_clear(id self) {
	Ivar iv = spec_ivar(self);
	if (iv)
		object_setIvar(self, iv, 0);
	if (responds(self, "reloadSpecifiers"))
		msg0(self, "reloadSpecifiers");
}

static void call_super_v(id self, SEL sel) {
	Class super = objc_getClass("PSListController");
	if (gUseAtl) {
		Class atl = objc_getClass("ATLApplicationListMultiSelectionController");
		if (atl)
			super = atl;
	}
	struct objc_super s = { self, super };
	((void (*)(struct objc_super *, SEL))objc_msgSendSuper)(&s, sel);
}

static void picker_loaded(id self, SEL sel) {
	call_super_v(self, sel);
	if (gUseAtl)
		return;
	Class SB = objc_getClass("UISearchBar");
	if (!SB)
		return;
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	id bar = msg0(al(SB, sel_registerName("alloc")), "init");
	if (!bar)
		return;
	if (responds(bar, "setDelegate:"))
		msg1(bar, "setDelegate:", self);
	if (responds(bar, "setPlaceholder:"))
		msg1(bar, "setPlaceholder:", nsstr("Search name or bundle"));
	if (responds(bar, "setShowsCancelButton:")) {
		void (*sc)(id, SEL, unsigned char) = (void (*)(id, SEL, unsigned char))objc_msgSend;
		sc(bar, sel_registerName("setShowsCancelButton:"), 1);
	}
	if (responds(bar, "setAutocapitalizationType:")) {
		void (*sa)(id, SEL, NSInteger) = (void (*)(id, SEL, NSInteger))objc_msgSend;
		sa(bar, sel_registerName("setAutocapitalizationType:"), 0);
	}
	id cur = objc_getAssociatedObject(self, &kFilter);
	if (cur && responds(bar, "setText:"))
		msg1(bar, "setText:", cur);
	if (responds(bar, "sizeToFit"))
		msg0(bar, "sizeToFit");
	id tv = 0;
	if (responds(self, "table"))
		tv = msg0(self, "table");
	if (!tv && responds(self, "tableView"))
		tv = msg0(self, "tableView");
	if (tv && responds(tv, "setTableHeaderView:"))
		msg1(tv, "setTableHeaderView:", bar);
}

static void picker_appear(id self, SEL sel, unsigned char animated) {
	struct objc_super s = { self, objc_getClass("PSListController") };
	((void (*)(struct objc_super *, SEL, unsigned char))objc_msgSendSuper)(&s, sel, animated);
	if (gUseAtl)
		return;
	Ivar iv = spec_ivar(self);
	id specs = iv ? object_getIvar(self, iv) : 0;
	if (!specs || ncount(specs) < 2)
		picker_clear(self);
}

static void picker_search(id self, SEL sel, id bar, id text) {
	(void)sel;
	(void)bar;
	objc_setAssociatedObject(self, &kFilter, text, OBJC_ASSOCIATION_RETAIN);
	picker_clear(self);
}

static void picker_search_done(id self, SEL sel, id bar) {
	(void)sel;
	(void)self;
	if (bar && responds(bar, "resignFirstResponder"))
		msg0(bar, "resignFirstResponder");
}

static id getter(id self, SEL sel, id spec) {
	(void)sel;
	id bid = spec_prop(spec, "veloraBid");
	id set = objc_getAssociatedObject(self, &kSel);
	unsigned char on = 0;
	if (set && bid && responds(set, "containsObject:")) {
		unsigned char (*c)(id, SEL, id) = (unsigned char (*)(id, SEL, id))objc_msgSend;
		on = c(set, sel_registerName("containsObject:"), bid);
	}
	id (*nb)(Class, SEL, unsigned char) = (id(*)(Class, SEL, unsigned char))objc_msgSend;
	return nb(objc_getClass("NSNumber"), sel_registerName("numberWithBool:"), on);
}

static void setter(id self, SEL sel, id value, id spec) {
	(void)sel;
	id bid = spec_prop(spec, "veloraBid");
	if (!bid)
		return;
	id set = objc_getAssociatedObject(self, &kSel);
	if (!set) {
		set = retained_set();
		objc_setAssociatedObject(self, &kSel, set, OBJC_ASSOCIATION_RETAIN);
	}
	unsigned char on = 0;
	if (value && responds(value, "boolValue")) {
		unsigned char (*b)(id, SEL) = (unsigned char (*)(id, SEL))objc_msgSend;
		on = b(value, sel_registerName("boolValue"));
	}
	if (on)
		msg1(set, "addObject:", bid);
	else if (responds(set, "removeObject:"))
		msg1(set, "removeObject:", bid);
	save_selected(self);
}

void register_velora_picker(void) {
	load_fw();
	if (!objc_getClass("PSListController"))
		dlopen("/System/Library/PrivateFrameworks/Preferences.framework/Preferences", RTLD_LAZY);
	Class atl = objc_getClass("ATLApplicationListMultiSelectionController");
	Class super = atl ? atl : objc_getClass("PSListController");
	if (!super)
		return;
	gUseAtl = atl ? 1 : 0;
	if (!objc_getClass("VeloraAppPickerController")) {
		Class cls = objc_allocateClassPair(super, "VeloraAppPickerController", 0);
		if (cls)
			objc_registerClassPair(cls);
	}
	Class cls = objc_getClass("VeloraAppPickerController");
	if (!cls)
		return;
	if (!gUseAtl) {
		class_addMethod(cls, sel_registerName("specifiers"), (IMP)specifiers_imp, "@@:");
		class_addMethod(cls, sel_registerName("veloraApp:"), (IMP)getter, "@@:@");
		class_addMethod(cls, sel_registerName("setVeloraApp:specifier:"), (IMP)setter, "v@:@@");
		class_addMethod(cls, sel_registerName("viewDidLoad"), (IMP)picker_loaded, "v@:");
		class_addMethod(cls, sel_registerName("viewWillAppear:"), (IMP)picker_appear, "v@:c");
		class_addMethod(cls, sel_registerName("searchBar:textDidChange:"), (IMP)picker_search, "v@:@@");
		class_addMethod(cls, sel_registerName("searchBarSearchButtonClicked:"), (IMP)picker_search_done, "v@:@");
		class_addMethod(cls, sel_registerName("searchBarCancelButtonClicked:"), (IMP)picker_search_done, "v@:@");
	}
}
