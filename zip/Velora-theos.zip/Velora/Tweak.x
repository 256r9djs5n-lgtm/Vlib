#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>
#import <substrate.h>
#import <mach/mach.h>
#import <mach/mach_host.h>
#import <mach-o/dyld.h>
#import <dlfcn.h>
#import <math.h>

#ifndef __IPHONE_15_0
typedef struct { float minimum; float preferred; float maximum; } CAFrameRateRange;
#endif

@interface SKView : UIView
@property (nonatomic, assign) NSInteger preferredFramesPerSecond;
@end
@interface GLKView : UIView
@property (nonatomic, assign) NSInteger preferredFramesPerSecond;
@end
@interface CCDirector : NSObject
- (void)setAnimationInterval:(double)interval;
- (double)animationInterval;
@end
@interface CADisplay : NSObject
- (NSInteger)maximumFramesPerSecond;
- (NSInteger)maximumFPS;
- (void)setMaximumFPS:(NSInteger)fps;
@end
@interface CAMetalDrawableImp : NSObject
- (void)presentAfterMinimumDuration:(CFTimeInterval)duration;
@end
@interface CAMetalDrawable : NSObject
- (void)presentAfterMinimumDuration:(CFTimeInterval)duration;
- (void)present;
- (void)presentAtTime:(CFTimeInterval)time;
@end
@interface CAMetalLayer (VLR)
@property (assign) CGFloat drawableTimeoutSeconds;
@property (assign) BOOL allowsNextDrawableTimeout;
@end

static BOOL VLREnabled = YES;
static BOOL VLRPromotion = YES;
static BOOL VLRHud = YES;
static BOOL VLRTelemetry = YES;
static double VLRCustomFPS = 0;
static NSInteger VLRHudCorner = 1;
static NSString *VLRAppMode;
static NSMutableSet<NSString *> *VLREnabledApps;
static NSMutableSet<NSString *> *VLRBlacklist;
static BOOL VLRInPanelQuery = NO;
static NSInteger VLRPanelCached = -1;

static void VLRLoadPrefs(void);
static BOOL VLRShouldRun(void);
static void VLRHookUnity(void);
static void VLRForceUnityFPS(void);

static BOOL VLRAppAllowed(void) {
	NSString *bid = [NSBundle mainBundle].bundleIdentifier ?: @"";
	if ([bid isEqualToString:@"com.apple.springboard"]) return NO;
	NSString *mode = VLRAppMode.length ? VLRAppMode : @"all";
	if ([mode isEqualToString:@"enabled"]) {
		if (VLREnabledApps.count == 0) return YES;
		return [VLREnabledApps containsObject:bid];
	}
	if ([mode isEqualToString:@"blacklist"] || [mode isEqualToString:@"disabled"]) return ![VLRBlacklist containsObject:bid];
	return YES;
}

static BOOL VLRShouldRun(void) {
	return VLREnabled && VLRAppAllowed();
}

static NSInteger VLRPanelMax(void) {
	if (VLRPanelCached > 0) return VLRPanelCached;
	VLRInPanelQuery = YES;
	NSInteger v = [UIScreen mainScreen].maximumFramesPerSecond;
	VLRInPanelQuery = NO;
	if (v < 1) v = 60;
	VLRPanelCached = v;
	return v;
}

static NSInteger VLRDesired(void) {
	if (!VLRShouldRun()) return 0;
	NSInteger panel = VLRPanelMax();
	NSInteger cap = VLRPromotion ? panel : MIN((NSInteger)60, panel);
	NSInteger t = (NSInteger)llround(VLRCustomFPS);
	if (t < 1) t = cap;
	if (t > cap) t = cap;
	return t;
}

static BOOL VLRNativeMax(void) {
	NSInteger d = VLRDesired();
	return d > 0 && d >= VLRPanelMax();
}

static NSInteger VLRFrameInterval(void) {
	NSInteger d = VLRDesired();
	if (d < 1) return 1;
	NSInteger iv = (NSInteger)llround((double)VLRPanelMax() / (double)d);
	return iv < 1 ? 1 : iv;
}

static CFTimeInterval VLRFrameDuration(CFTimeInterval fallback) {
	NSInteger d = VLRDesired();
	return d > 0 ? (1.0 / (double)d) : fallback;
}

static float VLRCpuLoad(void) {
	host_cpu_load_info_data_t info;
	mach_msg_type_number_t count = HOST_CPU_LOAD_INFO_COUNT;
	static unsigned long long prev[4];
	if (host_statistics(mach_host_self(), HOST_CPU_LOAD_INFO, (host_info_t)&info, &count) != KERN_SUCCESS) return 0;
	unsigned long long user = info.cpu_ticks[CPU_STATE_USER];
	unsigned long long nice = info.cpu_ticks[CPU_STATE_NICE];
	unsigned long long sys = info.cpu_ticks[CPU_STATE_SYSTEM];
	unsigned long long idle = info.cpu_ticks[CPU_STATE_IDLE];
	unsigned long long total = (user + nice + sys + idle) - (prev[0] + prev[1] + prev[2] + prev[3]);
	unsigned long long busy = (user + nice + sys) - (prev[0] + prev[1] + prev[2]);
	prev[0] = user; prev[1] = nice; prev[2] = sys; prev[3] = idle;
	if (total == 0) return 0;
	return (float)(100.0 * busy / total);
}

static void VLRSetLinkRange(id link, float lo, float pref, float hi) {
	SEL sel = @selector(setPreferredFrameRateRange:);
	if (![link respondsToSelector:sel]) return;
	NSMethodSignature *sig = [link methodSignatureForSelector:sel];
	if (!sig) return;
	NSInvocation *inv = [NSInvocation invocationWithMethodSignature:sig];
	[inv setTarget:link];
	[inv setSelector:sel];
	CAFrameRateRange range = { lo, pref, hi };
	[inv setArgument:&range atIndex:2];
	[inv invoke];
}

static void VLRApplyLink(CADisplayLink *link) {
	if (!link || !VLRShouldRun()) return;
	NSInteger d = VLRDesired();
	if (d < 1) return;
	if ([link respondsToSelector:@selector(setFrameInterval:)]) {
		link.frameInterval = VLRFrameInterval();
	}
	if (VLRNativeMax()) {
		link.preferredFramesPerSecond = 0;
		VLRSetLinkRange(link, 30.f, (float)d, (float)d);
	} else {
		link.preferredFramesPerSecond = d;
		VLRSetLinkRange(link, (float)d, (float)d, (float)d);
	}
}

#pragma mark - HUD

@interface VLRHUDWindow : UIWindow
@end
@implementation VLRHUDWindow
- (BOOL)_ignoresHitTest { return YES; }
- (BOOL)_canAffectStatusBarAppearance { return NO; }
@end

@interface VLRHUDController : NSObject
@property (nonatomic, strong) VLRHUDWindow *window;
@property (nonatomic, strong) UILabel *fpsValue;
@property (nonatomic, strong) UILabel *cpuValue;
@property (nonatomic, strong) UILabel *gpuValue;
@property (nonatomic, strong) UIView *chip;
@property (nonatomic, strong) CADisplayLink *link;
@property (nonatomic, assign) NSInteger frames;
@property (nonatomic, assign) CFTimeInterval stamp;
@property (nonatomic, assign) CFTimeInterval lastFrame;
@property (nonatomic, assign) BOOL building;
+ (instancetype)shared;
- (void)rebuild;
- (void)tick:(CADisplayLink *)link;
@end

@implementation VLRHUDController
+ (instancetype)shared {
	static VLRHUDController *ctl;
	static dispatch_once_t once;
	dispatch_once(&once, ^{ ctl = [VLRHUDController new]; });
	return ctl;
}

- (UILabel *)metricLabel:(CGFloat)y {
	UILabel *l = [[UILabel alloc] initWithFrame:CGRectMake(36, y, 72, 16)];
	l.font = [UIFont monospacedDigitSystemFontOfSize:12 weight:UIFontWeightMedium];
	l.textColor = [UIColor whiteColor];
	l.textAlignment = NSTextAlignmentRight;
	l.text = @"—";
	return l;
}

- (UILabel *)keyLabel:(NSString *)text y:(CGFloat)y {
	UILabel *l = [[UILabel alloc] initWithFrame:CGRectMake(8, y, 28, 16)];
	l.font = [UIFont monospacedDigitSystemFontOfSize:8 weight:UIFontWeightMedium];
	l.textColor = [UIColor colorWithWhite:0.58 alpha:1];
	l.text = text;
	return l;
}

- (UIWindowScene *)activeScene {
	if (@available(iOS 13.0, *)) {
		UIWindowScene *fallback = nil;
		for (UIScene *s in UIApplication.sharedApplication.connectedScenes) {
			if (![s isKindOfClass:[UIWindowScene class]]) continue;
			UIWindowScene *ws = (UIWindowScene *)s;
			if (ws.activationState == UISceneActivationStateForegroundActive) return ws;
			if (!fallback) fallback = ws;
		}
		return fallback;
	}
	return nil;
}

- (void)layoutChip {
	CGFloat h = VLRTelemetry ? 56 : 22;
	self.chip.bounds = CGRectMake(0, 0, 112, h);
	UIWindow *w = self.window;
	if (!w) return;
	CGRect b = w.bounds;
	CGFloat x = 12, y = 54;
	if (VLRHudCorner == 1) x = b.size.width - 124;
	if (VLRHudCorner == 2) y = b.size.height - h - 24;
	if (VLRHudCorner == 3) {
		x = b.size.width - 124;
		y = b.size.height - h - 24;
	}
	self.chip.frame = CGRectMake(x, y, 112, h);
}

- (void)rebuild {
	if (self.building) return;
	self.building = YES;
	if (self.link) {
		[self.link invalidate];
		self.link = nil;
	}
	if (!VLRHud || !VLRShouldRun()) {
		self.window.hidden = YES;
		self.building = NO;
		return;
	}
	if (!self.window) {
		UIWindowScene *scene = nil;
		if (@available(iOS 13.0, *)) scene = [self activeScene];
		if (@available(iOS 13.0, *)) {
			if (!scene) { self.building = NO; return; }
		}
		VLRHUDWindow *win = [[VLRHUDWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
		if (@available(iOS 13.0, *)) {
			if (scene) win.windowScene = scene;
		}
		win.windowLevel = UIWindowLevelStatusBar + 120;
		win.userInteractionEnabled = NO;
		win.backgroundColor = [UIColor clearColor];
		win.hidden = NO;
		UIView *chip = [[UIView alloc] initWithFrame:CGRectMake(12, 54, 112, 22)];
		chip.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.62];
		chip.layer.cornerRadius = 8;
		if (@available(iOS 13.0, *)) chip.layer.cornerCurve = kCACornerCurveContinuous;
		[win addSubview:chip];
		self.chip = chip;
		[chip addSubview:[self keyLabel:@"FPS" y:3]];
		self.fpsValue = [self metricLabel:3];
		[chip addSubview:self.fpsValue];
		[chip addSubview:[self keyLabel:@"CPU" y:20]];
		self.cpuValue = [self metricLabel:20];
		[chip addSubview:self.cpuValue];
		[chip addSubview:[self keyLabel:@"GPU" y:37]];
		self.gpuValue = [self metricLabel:37];
		[chip addSubview:self.gpuValue];
		self.window = win;
	} else if (@available(iOS 13.0, *)) {
		UIWindowScene *scene = [self activeScene];
		if (scene && self.window.windowScene != scene) self.window.windowScene = scene;
	}
	self.cpuValue.hidden = !VLRTelemetry;
	self.gpuValue.hidden = !VLRTelemetry;
	self.window.hidden = NO;
	[self layoutChip];
	self.frames = 0;
	self.stamp = CACurrentMediaTime();
	self.lastFrame = self.stamp;
	self.link = [CADisplayLink displayLinkWithTarget:self selector:@selector(tick:)];
	VLRApplyLink(self.link);
	[self.link addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
	self.building = NO;
}

- (void)tick:(CADisplayLink *)link {
	CFTimeInterval now = CACurrentMediaTime();
	CFTimeInterval frameDt = now - self.lastFrame;
	self.lastFrame = now;
	self.frames += 1;
	CFTimeInterval elapsed = now - self.stamp;
	if (elapsed < 0.25) return;
	double fps = self.frames / elapsed;
	self.frames = 0;
	self.stamp = now;
	UIColor *color;
	if (fps >= 100) color = [UIColor colorWithRed:0.56 green:0.75 blue:0.60 alpha:1];
	else if (fps >= 48) color = [UIColor colorWithWhite:0.95 alpha:1];
	else if (fps >= 20) color = [UIColor colorWithRed:0.77 green:0.65 blue:0.45 alpha:1];
	else color = [UIColor colorWithRed:0.77 green:0.48 blue:0.45 alpha:1];
	self.fpsValue.textColor = color;
	self.fpsValue.text = [NSString stringWithFormat:@"%.1f", fps];
	if (VLRTelemetry) {
		float cpu = VLRCpuLoad();
		NSInteger d = VLRDesired();
		float vsync = d > 0 ? (1.0 / d) : (1.0 / 120.0);
		float gpu = frameDt > 0 ? (float)MIN(100.0, 100.0 * frameDt / vsync) : 0;
		self.cpuValue.text = [NSString stringWithFormat:@"%.0f%%", cpu];
		self.gpuValue.text = [NSString stringWithFormat:@"%.0f%%", gpu];
	}
	[self layoutChip];
	VLRForceUnityFPS();
}
@end

#pragma mark - Info.plist (CADisableMinimumFrameDurationOnPhone)

static id VLRPlistYes(NSString *key, id orig) {
	if (!VLRShouldRun() || !VLRPromotion) return orig;
	if ([key isEqualToString:@"CADisableMinimumFrameDurationOnPhone"] ||
		[key isEqualToString:@"CADisableMinimumFrameDuration"] ||
		[key isEqualToString:@"UIHighFrameRateEnabled"]) {
		return @YES;
	}
	return orig;
}

%hook NSBundle
- (id)objectForInfoDictionaryKey:(NSString *)key {
	return VLRPlistYes(key, %orig);
}
- (NSDictionary *)infoDictionary {
	NSDictionary *orig = %orig;
	if (!VLRShouldRun() || !VLRPromotion || ![orig isKindOfClass:[NSDictionary class]]) return orig;
	NSMutableDictionary *d = [orig mutableCopy];
	d[@"CADisableMinimumFrameDurationOnPhone"] = @YES;
	d[@"CADisableMinimumFrameDuration"] = @YES;
	d[@"UIHighFrameRateEnabled"] = @YES;
	return d;
}
%end

#pragma mark - UIScreen / CADisplay

%hook UIScreen
- (NSInteger)maximumFramesPerSecond {
	NSInteger orig = %orig;
	if (VLRInPanelQuery || !VLRShouldRun()) return orig;
	NSInteger d = VLRDesired();
	return d > orig ? d : orig;
}
%end

%hook CADisplay
- (NSInteger)maximumFramesPerSecond {
	NSInteger orig = %orig;
	if (!VLRShouldRun()) return orig;
	NSInteger d = VLRDesired();
	return d > orig ? d : orig;
}
- (NSInteger)maximumFPS {
	NSInteger orig = %orig;
	if (!VLRShouldRun()) return orig;
	NSInteger d = VLRDesired();
	return d > orig ? d : orig;
}
- (void)setMaximumFPS:(NSInteger)fps {
	%orig(VLRShouldRun() ? VLRDesired() : fps);
}
%end

#pragma mark - CADisplayLink

%hook CADisplayLink

+ (CADisplayLink *)displayLinkWithTarget:(id)target selector:(SEL)sel {
	CADisplayLink *link = %orig;
	if (![target isKindOfClass:%c(VLRHUDController)]) VLRApplyLink(link);
	return link;
}

- (void)setFrameInterval:(NSInteger)interval {
	if (!VLRShouldRun()) { %orig; return; }
	%orig(VLRFrameInterval());
	if ([self respondsToSelector:@selector(setPreferredFramesPerSecond:)])
		self.preferredFramesPerSecond = VLRNativeMax() ? 0 : VLRDesired();
}

- (NSInteger)preferredFramesPerSecond {
	if (!VLRShouldRun()) return %orig;
	return VLRNativeMax() ? 0 : VLRDesired();
}

- (void)setPreferredFramesPerSecond:(NSInteger)fps {
	if (!VLRShouldRun()) { %orig; return; }
	%orig(VLRNativeMax() ? 0 : VLRDesired());
}

- (void)setPreferredFrameRateRange:(CAFrameRateRange)range {
	if (!VLRShouldRun()) { %orig; return; }
	NSInteger d = VLRDesired();
	if (VLRNativeMax()) {
		range.minimum = 30;
		range.preferred = d;
		range.maximum = d;
	} else {
		range.minimum = d;
		range.preferred = d;
		range.maximum = d;
	}
	%orig;
}

- (void)addToRunLoop:(NSRunLoop *)loop forMode:(NSRunLoopMode)mode {
	%orig;
	if (VLRShouldRun()) VLRApplyLink(self);
}

%end

#pragma mark - Metal

%hook CAMetalLayer
- (NSUInteger)maximumDrawableCount {
	return VLRShouldRun() ? 2 : %orig;
}
- (void)setMaximumDrawableCount:(NSUInteger)count {
	%orig(VLRShouldRun() ? 2 : count);
}
- (CFTimeInterval)minimumFrameDuration {
	if (!VLRShouldRun()) return %orig;
	return VLRFrameDuration(%orig);
}
- (void)setPreferredFramesPerSecond:(float)fps {
	if (!VLRShouldRun()) { %orig; return; }
	%orig((float)(VLRNativeMax() ? 0 : VLRDesired()));
}
- (BOOL)allowsNextDrawableTimeout {
	return VLRShouldRun() ? NO : %orig;
}
- (void)setAllowsNextDrawableTimeout:(BOOL)v {
	%orig(VLRShouldRun() ? NO : v);
}
%end

%hook CAMetalDrawable
- (void)presentAfterMinimumDuration:(CFTimeInterval)duration {
	if (!VLRShouldRun()) { %orig; return; }
	%orig(VLRFrameDuration(duration));
}
%end

%hook CAMetalDrawableImp
- (void)presentAfterMinimumDuration:(CFTimeInterval)duration {
	if (!VLRShouldRun()) { %orig; return; }
	%orig(VLRFrameDuration(duration));
}
%end

%hook _MTLCommandBuffer
- (void)presentDrawable:(id)drawable afterMinimumDuration:(CFTimeInterval)minimumDuration {
	if (!VLRShouldRun()) { %orig; return; }
	%orig(drawable, VLRFrameDuration(minimumDuration));
}
%end

%hook MTLIOAccelCommandBuffer
- (void)presentDrawable:(id)drawable afterMinimumDuration:(CFTimeInterval)minimumDuration {
	if (!VLRShouldRun()) { %orig; return; }
	%orig(drawable, VLRFrameDuration(minimumDuration));
}
%end

#pragma mark - SpriteKit / GLKit / Cocos / UIView

%hook SKView
- (NSInteger)preferredFramesPerSecond {
	return VLRShouldRun() ? (VLRNativeMax() ? 0 : VLRDesired()) : %orig;
}
- (void)setPreferredFramesPerSecond:(NSInteger)fps {
	if (!VLRShouldRun()) { %orig; return; }
	%orig(VLRNativeMax() ? 0 : VLRDesired());
}
%end

%hook GLKView
- (NSInteger)preferredFramesPerSecond {
	return VLRShouldRun() ? VLRDesired() : %orig;
}
- (void)setPreferredFramesPerSecond:(NSInteger)fps {
	if (!VLRShouldRun()) { %orig; return; }
	%orig(VLRDesired());
}
%end

%hook CCDirector
- (void)setAnimationInterval:(double)interval {
	if (!VLRShouldRun()) { %orig; return; }
	NSInteger d = VLRDesired();
	%orig(d > 0 ? 1.0 / d : interval);
}
- (double)animationInterval {
	if (!VLRShouldRun()) return %orig;
	NSInteger d = VLRDesired();
	return d > 0 ? 1.0 / d : %orig;
}
%end

%hook UIView
- (void)setPreferredFrameRateRange:(CAFrameRateRange)range {
	if (!VLRShouldRun()) { %orig; return; }
	NSInteger d = VLRDesired();
	if (d < 1) { %orig; return; }
	if (VLRNativeMax()) {
		range.minimum = 30;
		range.preferred = d;
		range.maximum = d;
	} else {
		range.minimum = d;
		range.preferred = d;
		range.maximum = d;
	}
	%orig;
}
%end

#pragma mark - HUD attach

%hook UIWindow
- (void)makeKeyAndVisible {
	%orig;
	if ([self isKindOfClass:%c(VLRHUDWindow)]) return;
	dispatch_async(dispatch_get_main_queue(), ^{
		[[VLRHUDController shared] rebuild];
		VLRForceUnityFPS();
	});
}
- (void)becomeKeyWindow {
	%orig;
	if ([self isKindOfClass:%c(VLRHUDWindow)]) return;
	dispatch_async(dispatch_get_main_queue(), ^{ [[VLRHUDController shared] rebuild]; });
}
%end

%hook UIApplication
- (void)sendEvent:(UIEvent *)event {
	%orig;
	static NSInteger n;
	if ((++n % 12) == 0 && VLRHud && VLRShouldRun()) {
		VLRHUDController *hud = [VLRHUDController shared];
		if (!hud.window || hud.window.hidden) [hud rebuild];
	}
}
%end

%hook UIViewController
- (void)viewDidAppear:(BOOL)animated {
	%orig;
	if (VLRHud && VLRShouldRun()) {
		dispatch_async(dispatch_get_main_queue(), ^{ [[VLRHUDController shared] rebuild]; });
	}
	VLRForceUnityFPS();
}
%end

#pragma mark - Unity (Beat the Boss 4, PvZ2, …)

static void (*VLROrigUnitySetTargetFPS)(int) = NULL;
static void VLRHookUnitySetTargetFPS(int fps) {
	if (VLRShouldRun() && VLROrigUnitySetTargetFPS) {
		NSInteger d = VLRDesired();
		VLROrigUnitySetTargetFPS(d > 0 ? (int)d : fps);
		return;
	}
	if (VLROrigUnitySetTargetFPS) VLROrigUnitySetTargetFPS(fps);
}

static void (*VLROrigUnitySetVSync)(int) = NULL;
static void VLRHookUnitySetVSync(int count) {
	if (VLRShouldRun() && VLROrigUnitySetVSync) {
		VLROrigUnitySetVSync(0);
		return;
	}
	if (VLROrigUnitySetVSync) VLROrigUnitySetVSync(count);
}

static void (*VLROrigIcallSetFPS)(int) = NULL;
static void VLRHookIcallSetFPS(int fps) {
	if (VLRShouldRun() && VLROrigIcallSetFPS) {
		NSInteger d = VLRDesired();
		VLROrigIcallSetFPS(d > 0 ? (int)d : fps);
		return;
	}
	if (VLROrigIcallSetFPS) VLROrigIcallSetFPS(fps);
}

static void (*VLROrigIcallVSync)(int) = NULL;
static void VLRHookIcallVSync(int count) {
	if (VLRShouldRun() && VLROrigIcallVSync) {
		VLROrigIcallVSync(0);
		return;
	}
	if (VLROrigIcallVSync) VLROrigIcallVSync(count);
}

static void VLRTryHook(const char *name, void *repl, void **orig) {
	if (*orig) return;
	void *sym = dlsym(RTLD_DEFAULT, name);
	if (!sym) {
		char buf[96];
		snprintf(buf, sizeof buf, "_%s", name);
		sym = dlsym(RTLD_DEFAULT, buf);
	}
	if (sym) MSHookFunction(sym, repl, orig);
}

static void VLRHookUnityIcalls(void) {
	void *resolve = dlsym(RTLD_DEFAULT, "il2cpp_resolve_icall");
	if (!resolve) resolve = dlsym(RTLD_DEFAULT, "_il2cpp_resolve_icall");
	if (!resolve) return;
	void *(*fn)(const char *) = (void *(*)(const char *))resolve;
	if (!VLROrigIcallSetFPS) {
		const char *fpsNames[] = {
			"UnityEngine.Application::set_targetFrameRate(System.Int32)",
			"UnityEngine.Application::set_targetFrameRate(int)",
			NULL
		};
		for (int i = 0; fpsNames[i]; i++) {
			void *s = fn(fpsNames[i]);
			if (s) {
				MSHookFunction(s, (void *)VLRHookIcallSetFPS, (void **)&VLROrigIcallSetFPS);
				break;
			}
		}
	}
	if (!VLROrigIcallVSync) {
		const char *vsNames[] = {
			"UnityEngine.QualitySettings::set_vSyncCount(System.Int32)",
			"UnityEngine.QualitySettings::set_vSyncCount(int)",
			NULL
		};
		for (int i = 0; vsNames[i]; i++) {
			void *s = fn(vsNames[i]);
			if (s) {
				MSHookFunction(s, (void *)VLRHookIcallVSync, (void **)&VLROrigIcallVSync);
				break;
			}
		}
	}
}

static void VLRHookUnity(void) {
	VLRTryHook("UnitySetTargetFPS", (void *)VLRHookUnitySetTargetFPS, (void **)&VLROrigUnitySetTargetFPS);
	VLRTryHook("UnitySetTargetFrameRate", (void *)VLRHookUnitySetTargetFPS, (void **)&VLROrigUnitySetTargetFPS);
	VLRTryHook("UnitySetVSyncCount", (void *)VLRHookUnitySetVSync, (void **)&VLROrigUnitySetVSync);
	VLRHookUnityIcalls();
}

static void VLRForceUnityFPS(void) {
	if (!VLRShouldRun()) return;
	NSInteger d = VLRDesired();
	if (d < 1) return;
	if (VLROrigUnitySetVSync) VLROrigUnitySetVSync(0);
	if (VLROrigIcallVSync) VLROrigIcallVSync(0);
	if (VLROrigUnitySetTargetFPS) VLROrigUnitySetTargetFPS((int)d);
	if (VLROrigIcallSetFPS) VLROrigIcallSetFPS((int)d);
}

static void VLROnImageAdded(const struct mach_header *mh, intptr_t slide) {
	(void)mh;
	(void)slide;
	VLRHookUnity();
}

#pragma mark - Prefs

static id VLRPref(CFStringRef key) {
	id v = (__bridge_transfer id)CFPreferencesCopyAppValue(key, CFSTR("com.velora.hz"));
	if (v) return v;
	return (__bridge_transfer id)CFPreferencesCopyAppValue(key, CFSTR("com.apple.UIKit"));
}

static void VLRIngest(id val, NSMutableSet<NSString *> *set) {
	if ([val isKindOfClass:[NSArray class]]) {
		for (id x in (NSArray *)val) {
			if ([x isKindOfClass:[NSString class]] && [(NSString *)x length]) [set addObject:x];
		}
	} else if ([val isKindOfClass:[NSDictionary class]]) {
		[(NSDictionary *)val enumerateKeysAndObjectsUsingBlock:^(id k, id obj, BOOL *stop) {
			if ([k isKindOfClass:[NSString class]] && [obj respondsToSelector:@selector(boolValue)] && [obj boolValue]) {
				[set addObject:k];
			}
		}];
	} else if ([val isKindOfClass:[NSString class]]) {
		NSCharacterSet *sep = [NSCharacterSet characterSetWithCharactersInString:@",;\n\t "];
		for (NSString *part in [(NSString *)val componentsSeparatedByCharactersInSet:sep]) {
			NSString *trim = [part stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
			if (trim.length) [set addObject:trim];
		}
	}
}

static void VLRLoadSets(void) {
	if (!VLREnabledApps) VLREnabledApps = [NSMutableSet new];
	if (!VLRBlacklist) VLRBlacklist = [NSMutableSet new];
	[VLREnabledApps removeAllObjects];
	[VLRBlacklist removeAllObjects];
	VLRIngest(VLRPref(CFSTR("enabledApps")), VLREnabledApps);
	VLRIngest(VLRPref(CFSTR("VeloraEnabledApps")), VLREnabledApps);
	VLRIngest(VLRPref(CFSTR("blacklistedApps")), VLRBlacklist);
	VLRIngest(VLRPref(CFSTR("VeloraBlacklistedApps")), VLRBlacklist);
	VLRIngest(VLRPref(CFSTR("VeloraDisabledApps")), VLRBlacklist);
	CFArrayRef keys = CFPreferencesCopyKeyList(CFSTR("com.velora.hz"), kCFPreferencesCurrentUser, kCFPreferencesAnyHost);
	if (!keys) return;
	CFIndex n = CFArrayGetCount(keys);
	for (CFIndex i = 0; i < n; i++) {
		CFStringRef key = CFArrayGetValueAtIndex(keys, i);
		NSString *k = (__bridge NSString *)key;
		id val = VLRPref(key);
		BOOL on = [val respondsToSelector:@selector(boolValue)] ? [val boolValue] : NO;
		if (!on) continue;
		if ([k hasPrefix:@"enabled-"]) [VLREnabledApps addObject:[k substringFromIndex:8]];
		else if ([k hasPrefix:@"blacklist-"]) [VLRBlacklist addObject:[k substringFromIndex:10]];
	}
	CFRelease(keys);
}

static void VLRLoadPrefs(void) {
	CFPreferencesAppSynchronize(CFSTR("com.velora.hz"));
	CFPreferencesAppSynchronize(CFSTR("com.apple.UIKit"));
	id enabled = VLRPref(CFSTR("enabled"));
	id promotion = VLRPref(CFSTR("promotion"));
	id hud = VLRPref(CFSTR("hud"));
	id telemetry = VLRPref(CFSTR("telemetry"));
	id fps = VLRPref(CFSTR("customFPS"));
	id corner = VLRPref(CFSTR("hudCorner"));
	id mode = VLRPref(CFSTR("appMode"));
	if (![mode isKindOfClass:[NSString class]]) mode = VLRPref(CFSTR("VeloraAppMode"));
	VLREnabled = enabled ? [enabled boolValue] : YES;
	VLRPromotion = promotion ? [promotion boolValue] : YES;
	VLRHud = hud ? [hud boolValue] : YES;
	VLRTelemetry = telemetry ? [telemetry boolValue] : YES;
	if ([fps isKindOfClass:[NSNumber class]]) VLRCustomFPS = [fps doubleValue];
	else if ([fps isKindOfClass:[NSString class]]) VLRCustomFPS = [fps doubleValue];
	else VLRCustomFPS = 0;
	if (VLRCustomFPS < 0) VLRCustomFPS = 0;
	if (VLRCustomFPS > 120.0) VLRCustomFPS = 120.0;
	VLRHudCorner = corner ? [corner integerValue] : 1;
	VLRAppMode = [mode isKindOfClass:[NSString class]] ? mode : @"all";
	VLRLoadSets();
	dispatch_async(dispatch_get_main_queue(), ^{
		[[VLRHUDController shared] rebuild];
		VLRForceUnityFPS();
	});
}

static void VLRNotify(CFNotificationCenterRef center, void *observer, CFNotificationName name, const void *object, CFDictionaryRef userInfo) {
	VLRLoadPrefs();
}

%ctor {
	@autoreleasepool {
		NSString *bid = [NSBundle mainBundle].bundleIdentifier ?: @"";
		if ([bid hasPrefix:@"com.apple.springboard"]) return;
		VLRLoadPrefs();
		%init;
		VLRHookUnity();
		_dyld_register_func_for_add_image(VLROnImageAdded);
		CFNotificationCenterAddObserver(
			CFNotificationCenterGetDarwinNotifyCenter(),
			NULL,
			VLRNotify,
			CFSTR("com.velora.hz/Reload"),
			NULL,
			CFNotificationSuspensionBehaviorDeliverImmediately
		);
		[[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationDidBecomeActiveNotification
														  object:nil queue:[NSOperationQueue mainQueue]
													  usingBlock:^(__unused NSNotification *n) {
			[[VLRHUDController shared] rebuild];
			VLRForceUnityFPS();
		}];
		if (@available(iOS 13.0, *)) {
			[[NSNotificationCenter defaultCenter] addObserverForName:UISceneDidActivateNotification
															  object:nil queue:[NSOperationQueue mainQueue]
														  usingBlock:^(__unused NSNotification *n) {
				[[VLRHUDController shared] rebuild];
				VLRForceUnityFPS();
			}];
		}
		dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
			VLRHookUnity();
			VLRForceUnityFPS();
		});
	}
}
