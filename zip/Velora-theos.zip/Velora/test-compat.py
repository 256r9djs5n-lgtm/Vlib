#!/usr/bin/env python3
"""Host checks: “This app needs to be updated” is a real launch bypass, not a hidden sheet."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
compat = (ROOT / "velora-compat.c").read_text(encoding="utf-8")
store = (ROOT / "velora-store.c").read_text(encoding="utf-8")
proc = (ROOT / "velora-proc.c").read_text(encoding="utf-8")
hdr = (ROOT / "velora-proc.h").read_text(encoding="utf-8")
dev = (ROOT / "layout/Library/PreferenceLoader/Preferences/VeloraDevice.plist").read_text(encoding="utf-8")
menu_test = (ROOT / "test-menu.py").read_text(encoding="utf-8")
fail = 0


def check(cond, name):
    global fail
    if not cond:
        print("FAIL", name)
        fail += 1
    else:
        print("ok", name)


check("presentViewController:animated:completion:" not in compat, "does not hook presentViewController")
check("hook_present" not in compat, "no present swallow hook")
check("is_velora_alert" not in compat, "no title-matching alert filter")
check("vc_is_update_alert" not in compat, "does not inspect UIAlertController titles")
check("+ 16" not in compat, "does not poke NSBlock invoke at offset 16")
check("velora_compat_alert_type" in compat, "uses shared type coercion")
check("velora_compat_launch_prohibited" in compat, "uses shared launch-prohibited helper")
check("velora_compat_skip_show" in compat, "uses skip-show helper")
check("showLaunchAlertOfType:forApplication:withCompletionHandler:" in compat, "hooks the SpringBoard show-alert choke point")
check("_showLaunchAlertOfType:forApplication:withCompletionHandler:" in compat, "hooks private show-alert variant")
check("showLaunchAlertOfType:forBundleIdentifier:withCompletionHandler:" in compat, "hooks bundle-id show-alert variant")
check("showLaunchAlertForApplication:withCompletionHandler:" in compat, "hooks application show-alert variant")
check("evaluateForApplication:" in compat, "evaluator still coerced to none")
check("SBApplicationInfo" in compat, "hooks SpringBoard application info")
check("LSApplicationRecord" in compat, "hooks LSApplicationRecord")
check("LSApplicationProxy" in compat, "hooks LSApplicationProxy")
check("FBApplicationInfo" in compat, "hooks FBApplicationInfo")
check("hasDisplayedLaunchAlertForType:" in compat, "marks launch alert already displayed")
check("orig_showLaunch" in compat and "orig_showLaunchPriv" in compat, "separate origs for show-alert variants")
check("orig_proxyLaunch" in compat and "orig_sbInfoLaunch" in compat, "separate origs for launch-prohibited classes")
check('"launchProhibited"' in compat, "hooks iOS 14+ launchProhibited property")
check("orig_sbAppProp" in compat and "orig_sbInfoProp" in compat, "SBApplication and SBApplicationInfo launchProhibited have their own origs")
check("orig_fbProp" in compat and "orig_bundleProp" in compat, "FBApplicationInfo and LSBundleProxy launchProhibited hooked")
check("showLaunchAlertForType:" in compat, "hooks SBApplication showLaunchAlertForType")
check("LSBundleProxy" in compat, "hooks LSBundleProxy launch-prohibited")
check("SBApplication" in compat, "hooks SBApplication launch-prohibited")
check("_isLaunchProhibited" in compat, "hooks private launch-prohibited getter")
check("alertTypeForApplication:" in compat, "evaluator alertType coerced")
check('"showLaunchAlertOfType:forApplication:"' in compat, "bare show-alert variant hooked")
check("gHooked" not in compat, "does not latch hooks after a failed early install")
check("if (orig && *orig)" in compat, "retries only selectors that are not yet hooked")
check("invoke_done" in compat, "launch completion is invoked when the sheet is skipped")
check("activateAlertItem:" not in compat, "does not skip SBAlertItemsController (would freeze)")
check("CFPreferencesCopyAppValue" in compat, "reads bypass from cfprefsd")
check("file_pref_on" in compat, "reads bypass from the plist file first")
check("velora_compat_pref_combine" in compat, "any-true prefs combiner")
check("persistentDomainForName:" in compat, "also reads the suite domain")
check("_LSApplicationState" in compat, "hooks LS application state")
check("compatibilityState" in compat, "hooks LS compatibilityState")
check("canActivateApplication" not in compat, "does not hook FrontBoard canActivate (wrong block ABI froze SpringBoard)")
check("invoke_can_yes" not in compat, "does not guess canActivate result-block ABI")
check("objc_getClassList" not in compat, "does not scan class list (dyld-lock deadlock)")
check("class_getName" not in compat, "does not walk class names from add_image")
check("MSHookFunction" not in compat, "no MSHookFunction in compat (unsafe from add_image)")
check("MSFindSymbol" not in compat, "no MSFindSymbol in compat")
check("MSGetImageByName" not in compat, "no MSGetImageByName in compat")
check("hook_fn_once" not in compat, "no objc_direct function hooks")
check("_objc_direct_method" not in compat, "does not look up objc_direct symbols")
check("hook_launch_alert_classes" not in compat, "does not enumerate LaunchAlert classes")
check("hook_directRecord" not in compat and "orig_directProxy" not in compat, "no objc_direct origs")
check("refresh_on" in compat, "re-reads the toggle at launch time")
check("/var/jb/User/Library/Preferences/com.velora.hz.plist" in compat, "rootless User prefs path")
check("orig_stateLaunch" in compat and "orig_stateProp" in compat, "LS state getters have their own origs")
plist = (ROOT / "Velora.plist").read_text(encoding="utf-8")
check("com.apple.springboard" in plist, "filter includes SpringBoard bundle")
check("com.apple.UIKitCore" in plist, "filter includes UIKitCore")
check("com.apple.FrontBoard" in plist, "filter includes FrontBoard")
inj = (ROOT / "velora-inject.c").read_text(encoding="utf-8")
boot = inj[inj.find("static void boot_late(void *ctx)") : inj.find("static int dispatch_late")]
skip_at = boot.find("velora_skip_inject")
sb_at = boot.find("SpringBoard")
check(sb_at >= 0 and (skip_at < 0 or sb_at < skip_at), "SpringBoard boot_late inits before skip_inject")
init = compat[compat.find("void velora_compat_init") :]
check("install_compat_hooks();" in init, "init always installs hooks")
check("if (gOn)\n\tinstall_compat_hooks" not in init and "if (gOn)\n\t\tinstall_compat_hooks" not in init, "init does not wait for the toggle to install")
check("_dyld_register_func_for_add_image" in compat, "retries hooks when SpringBoard images load")
on_image = compat[compat.find("static void on_image") : compat.find("static void watch_images")]
check("install_compat_hooks();" in on_image, "add_image retries named hook_sel")
check("objc_getClassList" not in on_image, "add_image does not scan classes")
check("MSHookFunction" not in on_image, "add_image does not MSHookFunction")
install = compat[compat.find("static void install_compat_hooks") : compat.find("static void on_reload")]
check("hook_sel(" in install, "install uses named MSHookMessageEx")
check("objc_getClassList" not in install, "install does not scan classes")
check("canActivate" not in install, "install does not hook canActivate")
check("gHookFn" not in install and "hook_fn_once" not in install, "install does not MSHookFunction")
check('msg0(gReloadName, "copy")' in compat, "Darwin reload name is copied")
check("gReloadName" in compat, "keeps a live Darwin name")
check("file_pref_on" in store, "store reads bypass from the plist file")
check('file_pref_on("bypassUpdateAlert")' in store, "sandboxed appstored still sees bypassUpdateAlert")
check('file_pref_on("storeBlockUpdates")' in store, "silent-update block also reads the plist file")
check("hiding" in compat.split("\n")[0].lower() or "not by" in compat[:400].lower(), "comment says this is not hide-the-sheet")
check("freezes" in compat[:800], "comment documents the freeze from swallowing")
check("FrontBoard activation" in compat[:1100] or "dyld-lock" in compat[:1100], "comment documents the 1.5.48 freeze sources")
check("velora_compat_alert_type" in hdr, "header exports type coercion")
check("velora_compat_launch_prohibited" in hdr, "header exports launch-prohibited")
check("velora_compat_block_updates" in hdr, "header exports update-block")
check("velora_compat_skip_show" in hdr, "header exports skip-show")
check("velora_compat_alert_item" in hdr, "header exports alert-item matcher")
check("velora_compat_pref_combine" in hdr, "header exports pref combiner")
check("velora_compat_state" in hdr, "header exports compatibility-state")
check("velora_compat_class_hook" in hdr, "header exports class-name matcher")
check("unsigned long long velora_compat_alert_type" in proc, "type coercion implemented")
check("if (bypass_on)\n\t\treturn 0;" in proc.replace("    ", "\t") or "if (bypass_on)\n\treturn 0;" in proc, "bypass zeros the alert type")
check("gBypassAlert" in store, "store reads bypassUpdateAlert")
check("bypassUpdateAlert" in store, "store prefs include bypass key")
check("block_store_updates" in store, "store gates silent updates")
check("velora_compat_block_updates" in store, "store uses shared update-block helper")
check("orig_reloadUpdates" in store, "reloadUpdates has its own orig")
check("orig_reloadServer" in store, "reloadFromServer has its own orig")
check("orig_getUpdates" in store and "orig_refreshUpdates" in store, "get/refresh have distinct origs")
get_hook = store[store.find("hook1(\"ASDUpdatesService\", \"getUpdatesWithCompletionBlock:\""):]
check("if (gBlockUpdates)" not in get_hook.split("if (gCellular)")[0], "update hooks install even when the toggle is off")
check("on_store_reload" in store, "store reloads prefs on Darwin notify")
check("com.velora.hz/Reload" in store, "store listens for Reload")
check("This app needs to be updated" in dev, "settings still name the iOS alert")
check("installed version is not replaced" in dev, "settings footer says the version is kept")
check("never queued" in dev, "settings say the sheet is never queued")
check('presentViewController:animated:completion:" not in compat' in menu_test, "menu tests require no sheet swallow")
check("showLaunchAlertOfType:forApplication:withCompletionHandler:" in menu_test, "menu tests require show-alert bypass")

src = Path("/tmp/test-compat-logic.c")
src.write_text(
    """
#include "/workspace/tweak/Velora/velora-proc.c"
#include <stdio.h>
int main(void) {
    int fail = 0;
#define E(got, want, name) do { if ((got) != (want)) { printf("FAIL %s got=%d want=%d\\n", name, (int)(got), (int)(want)); fail++; } } while (0)
    E(velora_compat_alert_type(1, 0), 0, "on-zero-stays");
    E(velora_compat_alert_type(1, 1), 0, "on-one-cleared");
    E(velora_compat_alert_type(1, 99), 0, "on-big-cleared");
    E(velora_compat_alert_type(0, 0), 0, "off-zero");
    E(velora_compat_alert_type(0, 3), 3, "off-keeps");
    E(velora_compat_launch_prohibited(1, 1), 0, "on-unblocks");
    E(velora_compat_launch_prohibited(1, 0), 0, "on-already-ok");
    E(velora_compat_launch_prohibited(0, 1), 1, "off-blocks");
    E(velora_compat_launch_prohibited(0, 0), 0, "off-ok");
    E(velora_compat_block_updates(0, 0), 0, "none");
    E(velora_compat_block_updates(1, 0), 1, "store");
    E(velora_compat_block_updates(0, 1), 1, "bypass");
    E(velora_compat_block_updates(1, 1), 1, "both");
    E(velora_compat_pref_combine(1,1,0,1,0), 1, "file-wins-stale-cf");
    E(velora_compat_pref_combine(0,1,1,1,0), 1, "cf-on");
    E(velora_compat_pref_combine(0,1,0,1,0), 0, "all-off");
    E(velora_compat_pref_combine(0,0,0,0,1), 1, "defs-on");
    E(velora_compat_pref_combine(0,0,0,0,0), 0, "none");
    E(velora_compat_state(1, 2), 1, "incompat-to-compat");
    E(velora_compat_state(1, 0), 1, "unknown-to-compat");
    E(velora_compat_state(1, 1), 1, "compat-stays");
    E(velora_compat_state(0, 2), 2, "off-keeps");
    E(velora_compat_class_hook("SBApplicationLaunchAlertService"), 1, "svc");
    E(velora_compat_class_hook("_TtC11SpringBoard17LaunchAlertThing"), 1, "swift");
    E(velora_compat_class_hook("SBIconView"), 0, "not-icon");
    E(velora_compat_alert_item("SBApplicationLaunchAlertItem"), 1, "item");
    E(velora_compat_alert_item("SBApplicationLaunchAlertService"), 0, "not-service");
    E(velora_compat_skip_show(1), 1, "skip-on");
    E(velora_compat_skip_show(0), 0, "skip-off");
    E(velora_compat_alert_item("SBApplicationLaunchAlertItem"), 1, "item");
    E(velora_compat_alert_item("SBApplicationLaunchAlertService"), 0, "not-service");
    E(velora_compat_alert_item("SBLaunchBlockedAlertItem"), 1, "blocked-item");
    E(velora_compat_alert_item("SBUserNotificationAlert"), 0, "not-user");
    if (velora_is_update_alert("This app needs to be updated.", 0) != 1) { puts("FAIL matcher"); fail++; }
    if (fail) { printf("%d failed\\n", fail); return 1; }
    puts("ok");
    return 0;
}
"""
)
cc = subprocess.run(["gcc", "-o", "/tmp/test-compat-logic", str(src)], capture_output=True, text=True)
check(cc.returncode == 0, "compat logic compiles")
if cc.returncode != 0:
    print(cc.stderr)
else:
    run = subprocess.run(["/tmp/test-compat-logic"], capture_output=True, text=True)
    check(run.returncode == 0 and "ok" in run.stdout, "compat logic cases pass")
    if run.returncode != 0:
        print(run.stdout, run.stderr)

if fail:
    print(fail, "failed")
    sys.exit(1)
print("ok")
