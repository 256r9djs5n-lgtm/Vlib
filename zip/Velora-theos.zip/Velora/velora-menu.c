/* Root menu + nested pages for Settings. */
#include "velora-proc.h"
void *dlopen(const char *path, int mode);
void *dlsym(void *handle, const char *symbol);
#define RTLD_DEFAULT ((void *)-2)
#define RTLD_LAZY 1

typedef struct objc_class *Class;
typedef struct objc_object *id;
typedef struct objc_selector *SEL;
typedef struct objc_ivar *Ivar;
typedef void (*IMP)(void);
typedef long NSInteger;

struct objc_super {
	id receiver;
	Class super_class;
};

extern Class objc_getClass(const char *name);
extern Class object_getClass(id obj);
extern SEL sel_registerName(const char *name);
extern void objc_msgSend(void);
extern void objc_msgSendSuper(void);
extern Class objc_allocateClassPair(Class super, const char *name, unsigned long extra);
extern void objc_registerClassPair(Class cls);
extern int class_addMethod(Class cls, SEL name, IMP imp, const char *types);
extern Ivar class_getInstanceVariable(Class cls, const char *name);
extern id object_getIvar(id obj, Ivar ivar);
extern void object_setIvar(id obj, Ivar ivar, id value);
extern Class class_getSuperclass(Class cls);
extern int notify_post(const char *name);
extern int notify_register_check(const char *name, int *out_token);
extern int notify_set_state(int token, unsigned long long state);
extern void *class_replaceMethod(Class cls, SEL name, IMP imp, const char *types);

static id nsstr(const char *c) {
	id (*f)(Class, SEL, const char *) = (id(*)(Class, SEL, const char *))objc_msgSend;
	return f(objc_getClass("NSString"), sel_registerName("stringWithUTF8String:"), c);
}

static id msg0(id obj, const char *sel) {
	if (!obj)
		return 0;
	id (*f)(id, SEL) = (id(*)(id, SEL))objc_msgSend;
	return f(obj, sel_registerName(sel));
}

static id msg1(id obj, const char *sel, id a) {
	if (!obj)
		return 0;
	id (*f)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
	return f(obj, sel_registerName(sel), a);
}

static id msg2(id obj, const char *sel, id a, id b) {
	if (!obj)
		return 0;
	id (*f)(id, SEL, id, id) = (id(*)(id, SEL, id, id))objc_msgSend;
	return f(obj, sel_registerName(sel), a, b);
}

static int responds(id obj, const char *sel) {
	if (!obj)
		return 0;
	unsigned char (*r)(id, SEL, SEL) = (unsigned char (*)(id, SEL, SEL))objc_msgSend;
	return r(obj, sel_registerName("respondsToSelector:"), sel_registerName(sel)) ? 1 : 0;
}

static int streq(id a, const char *b) {
	if (!a)
		return 0;
	unsigned char (*eq)(id, SEL, id) = (unsigned char (*)(id, SEL, id))objc_msgSend;
	return eq(a, sel_registerName("isEqualToString:"), nsstr(b)) ? 1 : 0;
}

static NSInteger ncount(id arr) {
	if (!arr)
		return 0;
	NSInteger (*c)(id, SEL) = (NSInteger(*)(id, SEL))objc_msgSend;
	return c(arr, sel_registerName("count"));
}

static id nobj(id arr, NSInteger i) {
	id (*f)(id, SEL, NSInteger) = (id(*)(id, SEL, NSInteger))objc_msgSend;
	return f(arr, sel_registerName("objectAtIndex:"), i);
}

static id retained_array(void) {
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	return msg0(al(objc_getClass("NSMutableArray"), sel_registerName("alloc")), "init");
}

static const char *cstr(id s) {
	if (!s || !responds(s, "UTF8String"))
		return "";
	const char *(*f)(id, SEL) = (const char *(*)(id, SEL))objc_msgSend;
	const char *v = f(s, sel_registerName("UTF8String"));
	return v ? v : "";
}

static Ivar spec_ivar(id self) {
	Class c = object_getClass(self);
	while (c) {
		Ivar iv = class_getInstanceVariable(c, "_specifiers");
		if (iv)
			return iv;
		c = class_getSuperclass(c);
	}
	return 0;
}

static void call_super_v(id self, SEL sel) {
	Class super = class_getSuperclass(object_getClass(self));
	if (!super)
		return;
	struct objc_super s = { self, super };
	((void (*)(struct objc_super *, SEL))objc_msgSendSuper)(&s, sel);
}

static void call_super_appear(id self, SEL sel, unsigned char animated) {
	Class super = class_getSuperclass(object_getClass(self));
	if (!super)
		return;
	struct objc_super s = { self, super };
	((void (*)(struct objc_super *, SEL, unsigned char))objc_msgSendSuper)(&s, sel, animated);
}

static id suite_name(const char *name) {
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	id obj = al(objc_getClass("NSUserDefaults"), sel_registerName("alloc"));
	id (*init)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
	return init(obj, sel_registerName("initWithSuiteName:"), nsstr(name));
}

static int val_bool(id v, int fb) {
	if (!v)
		return fb;
	if (!responds(v, "boolValue"))
		return fb;
	unsigned char (*b)(id, SEL) = (unsigned char (*)(id, SEL))objc_msgSend;
	return b(v, sel_registerName("boolValue")) ? 1 : 0;
}

static int val_int(id v, int fb) {
	if (!v)
		return fb;
	if (!responds(v, "integerValue"))
		return fb;
	NSInteger (*n)(id, SEL) = (NSInteger(*)(id, SEL))objc_msgSend;
	return (int)n(v, sel_registerName("integerValue"));
}

static void publish_hud_state(id extra_key, id extra_val) {
	id defs = suite_name("com.velora.hz");
	int hud = 1, tel = 1, corner = 1;
	if (defs) {
		hud = val_bool(msg1(defs, "objectForKey:", nsstr("hud")), 1);
		tel = val_bool(msg1(defs, "objectForKey:", nsstr("telemetry")), 1);
		corner = val_int(msg1(defs, "objectForKey:", nsstr("hudCorner")), 1);
	}
	if (extra_key && extra_val) {
		if (streq(extra_key, "hud"))
			hud = val_bool(extra_val, 0);
		else if (streq(extra_key, "telemetry"))
			tel = val_bool(extra_val, 0);
		else if (streq(extra_key, "hudCorner"))
			corner = val_int(extra_val, 1);
	}
	unsigned long long st = velora_pack_hud(hud, tel, corner);
	int tok = 0;
	if (notify_register_check("com.velora.hz/Reload", &tok) == 0)
		notify_set_state(tok, st);
	id uk = suite_name("com.apple.UIKit");
	if (uk) {
		id (*nb)(Class, SEL, unsigned char) = (id(*)(Class, SEL, unsigned char))objc_msgSend;
		id (*ni)(Class, SEL, NSInteger) = (id(*)(Class, SEL, NSInteger))objc_msgSend;
		msg2(uk, "setObject:forKey:", nb(objc_getClass("NSNumber"), sel_registerName("numberWithBool:"), hud ? 1 : 0), nsstr("hud"));
		msg2(uk, "setObject:forKey:", nb(objc_getClass("NSNumber"), sel_registerName("numberWithBool:"), tel ? 1 : 0), nsstr("telemetry"));
		msg2(uk, "setObject:forKey:", ni(objc_getClass("NSNumber"), sel_registerName("numberWithInteger:"), (NSInteger)corner), nsstr("hudCorner"));
		msg0(uk, "synchronize");
	}
	notify_post("com.velora.hz/Reload");
}

static void page_set_pref(id self, SEL sel, id value, id spec) {
	Class super = class_getSuperclass(object_getClass(self));
	if (super) {
		struct objc_super s = { self, super };
		((void (*)(struct objc_super *, SEL, id, id))objc_msgSendSuper)(&s, sel, value, spec);
	}
	id key = spec && responds(spec, "propertyForKey:") ? msg1(spec, "propertyForKey:", nsstr("key")) : 0;
	id uk = suite_name("com.apple.UIKit");
	if (uk && key && value) {
		msg2(uk, "setObject:forKey:", value, key);
		msg0(uk, "synchronize");
	}
	id hz = suite_name("com.velora.hz");
	if (hz && key && value) {
		msg2(hz, "setObject:forKey:", value, key);
		msg0(hz, "synchronize");
	}
	if (streq(key, "armSession"))
		notify_post("com.velora.hz.session");
	publish_hud_state(key, value);
}

static void reload_table(id self) {
	id table = 0;
	if (responds(self, "table"))
		table = msg0(self, "table");
	if (!table && responds(self, "tableView"))
		table = msg0(self, "tableView");
	if (table && responds(table, "reloadData"))
		msg0(table, "reloadData");
}

static NSInteger table_rows(id self) {
	id table = 0;
	if (responds(self, "table"))
		table = msg0(self, "table");
	if (!table && responds(self, "tableView"))
		table = msg0(self, "tableView");
	if (!table)
		return -1;
	if (responds(table, "numberOfSections") && responds(table, "numberOfRowsInSection:")) {
		NSInteger (*ns)(id, SEL) = (NSInteger(*)(id, SEL))objc_msgSend;
		NSInteger (*nr)(id, SEL, NSInteger) = (NSInteger(*)(id, SEL, NSInteger))objc_msgSend;
		NSInteger sec = ns(table, sel_registerName("numberOfSections"));
		NSInteger total = 0;
		NSInteger i;
		for (i = 0; i < sec && i < 32; i++)
			total += nr(table, sel_registerName("numberOfRowsInSection:"), i);
		return total;
	}
	if (responds(table, "numberOfRowsInSection:")) {
		NSInteger (*nr)(id, SEL, NSInteger) = (NSInteger(*)(id, SEL, NSInteger))objc_msgSend;
		return nr(table, sel_registerName("numberOfRowsInSection:"), 0);
	}
	return -1;
}

static void add_m(Class cls, const char *name, IMP imp, const char *types) {
	if (!cls || !name || !imp)
		return;
	class_replaceMethod(cls, sel_registerName(name), imp, types);
}

static void setprop(id spec, id val, const char *key) {
	if (!spec || !val)
		return;
	void (*sp)(id, SEL, id, id) = (void (*)(id, SEL, id, id))objc_msgSend;
	sp(spec, sel_registerName("setProperty:forKey:"), val, nsstr(key));
}

static id dict_get(id d, const char *k) {
	return d ? msg1(d, "objectForKey:", nsstr(k)) : 0;
}

static int cell_type(id name) {
	if (streq(name, "PSGroupCell"))
		return 0;
	if (streq(name, "PSLinkCell"))
		return 1;
	if (streq(name, "PSLinkListCell"))
		return 2;
	if (streq(name, "PSTitleValueCell"))
		return 4;
	if (streq(name, "PSSliderCell"))
		return 5;
	if (streq(name, "PSSwitchCell"))
		return 6;
	if (streq(name, "PSStaticTextCell"))
		return 7;
	if (streq(name, "PSEditTextCell"))
		return 8;
	if (streq(name, "PSSegmentCell"))
		return 9;
	if (streq(name, "PSButtonCell"))
		return 13;
	return 1;
}

static void copy_keys(id spec, id entry) {
	const char *keys[] = {
		"defaults", "key", "default", "PostNotification", "validValues", "validTitles",
		"min", "max", "showValue", "placeholder", "keyboard", "isDecimalPad",
		"footerText", "enabled", "isSegmented", "icon", "sections", "useSearchBar",
		"showIdentifiersAsSubtitle", "defaultApplicationSwitchValue",
		"includeIdentifiersInSearch", "alphabeticIndexingEnabled",
		"hideSearchBarWhileScrolling", "isController", "bundle", 0
	};
	for (int i = 0; keys[i]; i++) {
		id v = dict_get(entry, keys[i]);
		if (v)
			setprop(spec, v, keys[i]);
	}
}

static id make_specifier(id self, id entry) {
	Class PS = objc_getClass("PSSpecifier");
	if (!PS || !entry)
		return 0;
	id cell = dict_get(entry, "cell");
	id label = dict_get(entry, "label");
	if (!label)
		label = dict_get(entry, "key");
	if (streq(cell, "PSGroupCell")) {
		id (*g)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
		id spec = g(PS, sel_registerName("groupSpecifierWithName:"), label ? label : nsstr(""));
		id footer = dict_get(entry, "footerText");
		if (footer)
			setprop(spec, footer, "footerText");
		return spec;
	}
	int type = cell_type(cell);
	id detailName = dict_get(entry, "detail");
	Class detailCls = 0;
	if (detailName)
		detailCls = objc_getClass(cstr(detailName));
	if (detailCls)
		type = 1;
	id target = self;
	SEL setter = 0;
	SEL getter = 0;
	id getName = dict_get(entry, "get");
	id setName = dict_get(entry, "set");
	id action = dict_get(entry, "action");
	if (getName)
		getter = sel_registerName(cstr(getName));
	if (setName)
		setter = sel_registerName(cstr(setName));
	if (type != 0 && type != 1 && type != 2 && type != 7 && type != 13) {
		if (!getter)
			getter = sel_registerName("readPreferenceValue:");
		if (!setter)
			setter = sel_registerName("setPreferenceValue:specifier:");
	}
	typedef id (*mk_t)(Class, SEL, id, id, SEL, SEL, Class, NSInteger, id);
	mk_t mk = (mk_t)objc_msgSend;
	id spec = mk(PS, sel_registerName("preferenceSpecifierNamed:target:set:get:detail:cell:edit:"),
		label ? label : nsstr(""), target, setter, getter, detailCls, (NSInteger)type, (id)0);
	if (!spec)
		return 0;
	copy_keys(spec, entry);
	id values = dict_get(entry, "validValues");
	id titles = dict_get(entry, "validTitles");
	if (values) {
		setprop(spec, values, "values");
		setprop(spec, values, "validValues");
	}
	if (titles) {
		setprop(spec, titles, "validTitles");
		setprop(spec, titles, "shortTitles");
	}
	if (values && titles && responds(spec, "setValues:titles:")) {
		void (*sv)(id, SEL, id, id) = (void (*)(id, SEL, id, id))objc_msgSend;
		sv(spec, sel_registerName("setValues:titles:"), values, titles);
	}
	if (detailCls) {
		id (*nb)(Class, SEL, unsigned char) = (id(*)(Class, SEL, unsigned char))objc_msgSend;
		setprop(spec, nb(objc_getClass("NSNumber"), sel_registerName("numberWithBool:"), 1), "isController");
		setprop(spec, (id)detailCls, "detail");
		if (responds(spec, "setDetailControllerClass:")) {
			void (*sd)(id, SEL, Class) = (void (*)(id, SEL, Class))objc_msgSend;
			sd(spec, sel_registerName("setDetailControllerClass:"), detailCls);
		}
	}
	if (type == 13 && action) {
		setprop(spec, action, "action");
		if (responds(spec, "setButtonAction:")) {
			void (*ba)(id, SEL, SEL) = (void (*)(id, SEL, SEL))objc_msgSend;
			ba(spec, sel_registerName("setButtonAction:"), sel_registerName(cstr(action)));
		}
	}
	return spec;
}

static id convert_items(id self, id items) {
	id out = retained_array();
	NSInteger n = ncount(items);
	for (NSInteger i = 0; i < n; i++) {
		id one = make_specifier(self, nobj(items, i));
		if (one)
			msg1(out, "addObject:", one);
	}
	if (ncount(out) == 0) {
		id (*g)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
		id grp = g(objc_getClass("PSSpecifier"), sel_registerName("groupSpecifierWithName:"), nsstr("Velora"));
		if (grp)
			msg1(out, "addObject:", grp);
	}
	return out;
}

static id load_named_items(const char *file) {
	const char *roots[] = {
		"/Library/PreferenceLoader/Preferences/",
		"/var/jb/Library/PreferenceLoader/Preferences/",
		0
	};
	id (*contents)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
	id (*join)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
	for (int i = 0; roots[i]; i++) {
		id path = join(nsstr(roots[i]), sel_registerName("stringByAppendingString:"), nsstr(file));
		id dict = contents(objc_getClass("NSDictionary"), sel_registerName("dictionaryWithContentsOfFile:"), path);
		id items = dict ? dict_get(dict, "items") : 0;
		if (items)
			return items;
	}
	return 0;
}

static const char *file_for_spec(id spec) {
	id name = 0;
	if (spec && responds(spec, "name"))
		name = msg0(spec, "name");
	if (!name && spec && responds(spec, "propertyForKey:"))
		name = msg1(spec, "propertyForKey:", nsstr("label"));
	if (streq(name, "FPS Unlocker"))
		return "VeloraFPS.plist";
	if (streq(name, "Device Settings"))
		return "VeloraDevice.plist";
	if (streq(name, "App Store"))
		return "VeloraStore.plist";
	if (streq(name, "Jailbreak Bypass"))
		return "VeloraJB.plist";
	id key = spec && responds(spec, "propertyForKey:") ? msg1(spec, "propertyForKey:", nsstr("key")) : 0;
	if (streq(key, "VeloraPageFPS"))
		return "VeloraFPS.plist";
	if (streq(key, "VeloraPageDevice"))
		return "VeloraDevice.plist";
	if (streq(key, "VeloraPageStore"))
		return "VeloraStore.plist";
	if (streq(key, "VeloraPageJB"))
		return "VeloraJB.plist";
	return "VeloraFPS.plist";
}

static id load_plist_items(void) {
	const char *paths[] = {
		"/Library/PreferenceLoader/Preferences/Velora.plist",
		"/var/jb/Library/PreferenceLoader/Preferences/Velora.plist",
		0
	};
	id (*contents)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
	for (int i = 0; paths[i]; i++) {
		id dict = contents(objc_getClass("NSDictionary"), sel_registerName("dictionaryWithContentsOfFile:"), nsstr(paths[i]));
		id items = dict ? dict_get(dict, "items") : 0;
		if (items)
			return items;
	}
	return 0;
}

static id fallback_menu(id self) {
	id out = retained_array();
	id (*g)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
	Class PS = objc_getClass("PSSpecifier");
	Class page = objc_getClass("VeloraPageController");
	id grp = g(PS, sel_registerName("groupSpecifierWithName:"), nsstr("Options"));
	if (grp)
		msg1(out, "addObject:", grp);
	const char *keys[] = {"VeloraPageFPS", "VeloraPageDevice", "VeloraPageStore", "VeloraPageJB", 0};
	const char *labs[] = {"FPS Unlocker", "Device Settings", "App Store", "Jailbreak Bypass", 0};
	id (*nb)(Class, SEL, unsigned char) = (id(*)(Class, SEL, unsigned char))objc_msgSend;
	id yes = nb(objc_getClass("NSNumber"), sel_registerName("numberWithBool:"), 1);
	for (int i = 0; labs[i]; i++) {
		typedef id (*mk_t)(Class, SEL, id, id, SEL, SEL, Class, NSInteger, id);
		mk_t mk = (mk_t)objc_msgSend;
		id spec = mk(PS, sel_registerName("preferenceSpecifierNamed:target:set:get:detail:cell:edit:"),
			nsstr(labs[i]), self, (SEL)0, (SEL)0, page, (NSInteger)1, (id)0);
		if (!spec)
			continue;
		setprop(spec, nsstr(keys[i]), "key");
		setprop(spec, nsstr("com.velora.hz"), "defaults");
		setprop(spec, yes, "isController");
		if (page && responds(spec, "setDetailControllerClass:")) {
			void (*sd)(id, SEL, Class) = (void (*)(id, SEL, Class))objc_msgSend;
			sd(spec, sel_registerName("setDetailControllerClass:"), page);
		}
		msg1(out, "addObject:", spec);
	}
	return out;
}

static id cached_specs(id self, id items) {
	Ivar iv = spec_ivar(self);
	id specs = iv ? object_getIvar(self, iv) : 0;
	if (specs)
		return specs;
	specs = convert_items(self, items);
	if (specs) {
		id (*retain)(id, SEL) = (id(*)(id, SEL))objc_msgSend;
		retain(specs, sel_registerName("retain"));
	}
	if (iv)
		object_setIvar(self, iv, specs);
	return specs ? specs : retained_array();
}

static id menu_specifiers(id self, SEL sel) {
	(void)sel;
	Ivar iv = spec_ivar(self);
	id specs = iv ? object_getIvar(self, iv) : 0;
	if (specs && ncount(specs) > 0)
		return specs;
	id items = load_plist_items();
	specs = convert_items(self, items);
	if (!specs || ncount(specs) < 2)
		specs = fallback_menu(self);
	if (specs) {
		id (*retain)(id, SEL) = (id(*)(id, SEL))objc_msgSend;
		retain(specs, sel_registerName("retain"));
	}
	if (iv)
		object_setIvar(self, iv, specs);
	return specs ? specs : retained_array();
}

static id page_specifiers(id self, SEL sel) {
	(void)sel;
	Ivar iv = spec_ivar(self);
	id specs = iv ? object_getIvar(self, iv) : 0;
	if (specs && ncount(specs) > 0)
		return specs;
	id parent = responds(self, "specifier") ? msg0(self, "specifier") : 0;
	id items = load_named_items(file_for_spec(parent));
	if (!items && parent && responds(parent, "propertyForKey:"))
		items = msg1(parent, "propertyForKey:", nsstr("items"));
	specs = convert_items(self, items);
	if (specs) {
		id (*retain)(id, SEL) = (id(*)(id, SEL))objc_msgSend;
		retain(specs, sel_registerName("retain"));
	}
	if (iv)
		object_setIvar(self, iv, specs);
	return specs ? specs : retained_array();
}

static id device_model(id self, SEL sel) {
	(void)self;
	(void)sel;
	id dev = 0;
	id (*f)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	dev = f(objc_getClass("UIDevice"), sel_registerName("currentDevice"));
	id name = msg0(dev, "localizedModel");
	return name ? name : nsstr("—");
}

static id device_version(id self, SEL sel) {
	(void)self;
	(void)sel;
	id (*f)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	id dev = f(objc_getClass("UIDevice"), sel_registerName("currentDevice"));
	id v = msg0(dev, "systemVersion");
	return v ? v : nsstr("—");
}

static id device_name(id self, SEL sel) {
	(void)self;
	(void)sel;
	id (*f)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	id dev = f(objc_getClass("UIDevice"), sel_registerName("currentDevice"));
	id n = msg0(dev, "name");
	return n ? n : nsstr("—");
}

static id pref_file_str(const char *key) {
	id (*dcf)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
	const char *paths[] = {
		"/var/mobile/Library/Preferences/com.velora.hz.plist",
		"/tmp/com.velora.hz.dl.plist",
		0
	};
	int i;
	for (i = 0; paths[i]; i++) {
		id file = dcf(objc_getClass("NSDictionary"), sel_registerName("dictionaryWithContentsOfFile:"), nsstr(paths[i]));
		id v = file ? msg1(file, "objectForKey:", nsstr(key)) : 0;
		if (v && responds(v, "UTF8String") && cstr(v)[0])
			return v;
	}
	return 0;
}

static id pref_live_str(const char *key) {
	id defs = suite_name("com.velora.hz");
	id v = defs ? msg1(defs, "objectForKey:", nsstr(key)) : 0;
	if (v && responds(v, "UTF8String") && cstr(v)[0])
		return v;
	return pref_file_str(key);
}

static id apple_account_name(id self, SEL sel) {
	id v;
	(void)self;
	(void)sel;
	v = pref_live_str("appleAccount");
	if (v)
		return v;
	return nsstr("Device Apple ID");
}

static id apple_session_status(id self, SEL sel) {
	id tok, ds, on;
	(void)self;
	(void)sel;
	tok = pref_live_str("appleToken");
	ds = pref_live_str("appleDsid");
	on = pref_live_str("appleSessionOn");
	if (tok && cstr(tok)[0])
		return nsstr("Signed in (background)");
	if (ds && cstr(ds)[0])
		return nsstr("Signed in");
	if (on && (streq(on, "1") || streq(on, "true")))
		return nsstr("Signed in");
	return nsstr("Waiting for App Store");
}

static id arm_session_status(id self, SEL sel) {
	id n, s;
	(void)self;
	(void)sel;
	n = pref_live_str("armUserName");
	if (n)
		return n;
	s = pref_live_str("armSession");
	if (s && cstr(s)[0])
		return nsstr("Session saved");
	return nsstr("Not signed in");
}

static void velora_respring(id self, SEL sel) {
	(void)self;
	(void)sel;
	int (*sys)(const char *) = (int (*)(const char *))dlsym(RTLD_DEFAULT, "system");
	if (!sys)
		return;
	if (sys("sbreload") == 0)
		return;
	if (sys("/var/jb/usr/bin/sbreload") == 0)
		return;
	if (sys("/usr/bin/sbreload") == 0)
		return;
	sys("killall -9 SpringBoard");
	sys("/var/jb/usr/bin/killall -9 SpringBoard");
	sys("/usr/bin/killall -9 SpringBoard");
}

static void velora_reset(id self, SEL sel) {
	(void)sel;
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	id obj = al(objc_getClass("NSUserDefaults"), sel_registerName("alloc"));
	id (*init)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
	id defs = init(obj, sel_registerName("initWithSuiteName:"), nsstr("com.velora.hz"));
	if (defs && responds(defs, "removePersistentDomainForName:")) {
		msg1(defs, "removePersistentDomainForName:", nsstr("com.velora.hz"));
		msg0(defs, "synchronize");
	}
	publish_hud_state(0, 0);
	if (responds(self, "reloadSpecifiers"))
		msg0(self, "reloadSpecifiers");
}

static void rebuild_specs(id self, id (*getter)(id, SEL)) {
	Ivar iv = spec_ivar(self);
	if (iv)
		object_setIvar(self, iv, 0);
	if (responds(self, "reloadSpecifiers")) {
		msg0(self, "reloadSpecifiers");
		return;
	}
	if (getter)
		getter(self, sel_registerName("specifiers"));
	reload_table(self);
}

static void ensure_menu_visible(id self) {
	id specs = menu_specifiers(self, sel_registerName("specifiers"));
	NSInteger rows = table_rows(self);
	if (specs && ncount(specs) >= 2 && rows != 0)
		return;
	rebuild_specs(self, menu_specifiers);
}

static void ensure_page_visible(id self) {
	id specs = page_specifiers(self, sel_registerName("specifiers"));
	NSInteger rows = table_rows(self);
	if (specs && ncount(specs) >= 1 && rows != 0)
		return;
	rebuild_specs(self, page_specifiers);
}

static void menu_did_load(id self, SEL sel) {
	call_super_v(self, sel);
	menu_specifiers(self, sel_registerName("specifiers"));
}

static void page_did_load(id self, SEL sel) {
	call_super_v(self, sel);
	page_specifiers(self, sel_registerName("specifiers"));
}

static void menu_appear(id self, SEL sel, unsigned char animated) {
	call_super_appear(self, sel, animated);
	ensure_menu_visible(self);
}

static void page_appear(id self, SEL sel, unsigned char animated) {
	call_super_appear(self, sel, animated);
	ensure_page_visible(self);
}

static void menu_did_appear(id self, SEL sel, unsigned char animated) {
	call_super_appear(self, sel, animated);
	ensure_menu_visible(self);
}

static void page_did_appear(id self, SEL sel, unsigned char animated) {
	call_super_appear(self, sel, animated);
	ensure_page_visible(self);
}

static int velora_page_title(id name) {
	return streq(name, "FPS Unlocker") || streq(name, "Device Settings") || streq(name, "App Store") || streq(name, "Jailbreak Bypass");
}

static int velora_pane_kind(id self) {
	Class cls = object_getClass(self);
	if (cls == objc_getClass("VeloraRootListController") || cls == objc_getClass("VeloraMenuController"))
		return 1;
	if (cls == objc_getClass("VeloraPageController"))
		return 2;
	id spec = responds(self, "specifier") ? msg0(self, "specifier") : 0;
	id name = spec && responds(spec, "name") ? msg0(spec, "name") : 0;
	if (streq(name, "Velora"))
		return 1;
	if (velora_page_title(name))
		return 2;
	return 0;
}

static int velora_entry_ours(id entry, id title) {
	if (streq(title, "Velora"))
		return 1;
	if (entry && streq(dict_get(entry, "label"), "Velora"))
		return 1;
	return 0;
}

static id velora_root_specifier(id self) {
	Class PS = objc_getClass("PSSpecifier");
	Class root = objc_getClass("VeloraRootListController");
	if (!PS)
		return 0;
	typedef id (*mk_t)(Class, SEL, id, id, SEL, SEL, Class, NSInteger, id);
	mk_t mk = (mk_t)objc_msgSend;
	id spec = mk(PS, sel_registerName("preferenceSpecifierNamed:target:set:get:detail:cell:edit:"),
		nsstr("Velora"), self, (SEL)0, (SEL)0, root, (NSInteger)1, (id)0);
	if (!spec)
		return 0;
	id (*nb)(Class, SEL, unsigned char) = (id(*)(Class, SEL, unsigned char))objc_msgSend;
	setprop(spec, nb(objc_getClass("NSNumber"), sel_registerName("numberWithBool:"), 1), "isController");
	setprop(spec, nsstr("com.velora.hz"), "defaults");
	setprop(spec, nsstr("Velora.png"), "icon");
	if (root && responds(spec, "setDetailControllerClass:")) {
		void (*sd)(id, SEL, Class) = (void (*)(id, SEL, Class))objc_msgSend;
		sd(spec, sel_registerName("setDetailControllerClass:"), root);
	}
	return spec;
}

typedef void (*MSH_t)(Class, SEL, IMP, IMP *);
static MSH_t velora_msh(void) {
	return (MSH_t)dlsym(RTLD_DEFAULT, "MSHookMessageEx");
}

static id (*orig_from_entry)(id, SEL, id, id, id);
static id hook_from_entry(id self, SEL sel, id entry, id path, id title) {
	if (velora_entry_ours(entry, title)) {
		id spec = velora_root_specifier(self);
		if (spec) {
			id out = retained_array();
			msg1(out, "addObject:", spec);
			return out;
		}
	}
	if (orig_from_entry)
		return orig_from_entry(self, sel, entry, path, title);
	return 0;
}

static id (*orig_pl_specs)(id, SEL);
static id hook_pl_specs(id self, SEL sel) {
	int kind = velora_pane_kind(self);
	if (kind == 1)
		return menu_specifiers(self, sel);
	if (kind == 2)
		return page_specifiers(self, sel);
	if (orig_pl_specs)
		return orig_pl_specs(self, sel);
	return 0;
}

static void (*orig_pl_appear)(id, SEL, unsigned char);
static void hook_pl_appear(id self, SEL sel, unsigned char animated) {
	if (orig_pl_appear)
		orig_pl_appear(self, sel, animated);
	else
		call_super_appear(self, sel, animated);
	int kind = velora_pane_kind(self);
	if (kind == 1)
		ensure_menu_visible(self);
	if (kind == 2)
		ensure_page_visible(self);
}

extern void *class_getInstanceMethod(Class cls, SEL name);

static int gFromEntryHooked;
static int gPlHooked;

static void hook_pl_once(void) {
	MSH_t h = velora_msh();
	Class ps;
	Class pl;
	SEL from;
	if (!h)
		return;
	ps = objc_getClass("PSListController");
	from = sel_registerName("specifiersFromEntry:sourcePreferenceLoaderBundlePath:title:");
	if (!gFromEntryHooked && ps && class_getInstanceMethod(ps, from)) {
		h(ps, from, (IMP)hook_from_entry, (IMP *)&orig_from_entry);
		gFromEntryHooked = 1;
	}
	pl = objc_getClass("PLCustomListController");
	if (!gPlHooked && pl) {
		h(pl, sel_registerName("specifiers"), (IMP)hook_pl_specs, (IMP *)&orig_pl_specs);
		h(pl, sel_registerName("viewDidAppear:"), (IMP)hook_pl_appear, (IMP *)&orig_pl_appear);
		gPlHooked = 1;
	}
}

void register_velora_menu(void) {
	if (!objc_getClass("PSListController"))
		dlopen("/System/Library/PrivateFrameworks/Preferences.framework/Preferences", RTLD_LAZY);
	Class super = objc_getClass("PSListController");
	if (!super)
		return;
	if (!objc_getClass("VeloraMenuController")) {
		Class cls = objc_allocateClassPair(super, "VeloraMenuController", 0);
		if (cls)
			objc_registerClassPair(cls);
	}
	if (!objc_getClass("VeloraRootListController")) {
		Class cls = objc_allocateClassPair(super, "VeloraRootListController", 0);
		if (cls)
			objc_registerClassPair(cls);
	}
	if (!objc_getClass("VeloraPageController")) {
		Class cls = objc_allocateClassPair(super, "VeloraPageController", 0);
		if (cls)
			objc_registerClassPair(cls);
	}
	Class menu = objc_getClass("VeloraMenuController");
	Class root = objc_getClass("VeloraRootListController");
	Class page = objc_getClass("VeloraPageController");
	if (menu) {
		add_m(menu, "specifiers", (IMP)menu_specifiers, "@@:");
		add_m(menu, "viewDidLoad", (IMP)menu_did_load, "v@:");
		add_m(menu, "viewWillAppear:", (IMP)menu_appear, "v@:B");
		add_m(menu, "viewDidAppear:", (IMP)menu_did_appear, "v@:B");
		add_m(menu, "setPreferenceValue:specifier:", (IMP)page_set_pref, "v@:@@");
	}
	if (root) {
		add_m(root, "specifiers", (IMP)menu_specifiers, "@@:");
		add_m(root, "viewDidLoad", (IMP)menu_did_load, "v@:");
		add_m(root, "viewWillAppear:", (IMP)menu_appear, "v@:B");
		add_m(root, "viewDidAppear:", (IMP)menu_did_appear, "v@:B");
		add_m(root, "setPreferenceValue:specifier:", (IMP)page_set_pref, "v@:@@");
	}
	if (page) {
		add_m(page, "specifiers", (IMP)page_specifiers, "@@:");
		add_m(page, "viewDidLoad", (IMP)page_did_load, "v@:");
		add_m(page, "viewWillAppear:", (IMP)page_appear, "v@:B");
		add_m(page, "viewDidAppear:", (IMP)page_did_appear, "v@:B");
		add_m(page, "setPreferenceValue:specifier:", (IMP)page_set_pref, "v@:@@");
		add_m(page, "deviceModel", (IMP)device_model, "@@:");
		add_m(page, "deviceVersion", (IMP)device_version, "@@:");
		add_m(page, "deviceName", (IMP)device_name, "@@:");
		add_m(page, "appleAccountName", (IMP)apple_account_name, "@@:");
		add_m(page, "appleSessionStatus", (IMP)apple_session_status, "@@:");
		add_m(page, "armSessionStatus", (IMP)arm_session_status, "@@:");
		add_m(page, "respring", (IMP)velora_respring, "v@:");
		add_m(page, "resetPrefs", (IMP)velora_reset, "v@:");
	}
	hook_pl_once();
}
