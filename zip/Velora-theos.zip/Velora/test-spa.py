#!/usr/bin/env python3
"""Single-window site: login lives on /, no hard navigations, repo tab stays in-page."""
from pathlib import Path
import sys

ROOT = Path("/workspace")
fail = 0


def check(cond, name):
    global fail
    if not cond:
        print("FAIL", name)
        fail += 1
    else:
        print("ok", name)


index = (ROOT / "src/routes/index.tsx").read_text(encoding="utf-8")
login = (ROOT / "src/routes/login.tsx").read_text(encoding="utf-8")
verify = (ROOT / "src/routes/verify.tsx").read_text(encoding="utf-8")
require = (ROOT / "src/components/require-access.tsx").read_text(encoding="utf-8")
email = (ROOT / "src/components/email-auth-form.tsx").read_text(encoding="utf-8")
studio = (ROOT / "src/components/studio.tsx").read_text(encoding="utf-8")
frame = (ROOT / "src/components/auth-frame.tsx").read_text(encoding="utf-8")
account = (ROOT / "src/components/account-bar.tsx").read_text(encoding="utf-8")
vpanel = (ROOT / "src/components/verify-panel.tsx").read_text(encoding="utf-8")
gates = (ROOT / "src/lib/auth/gates.tsx").read_text(encoding="utf-8")

check('createFileRoute("/")' in index, "home route is /")
check("RequireAccess" in index, "home gates in-place")
check("Studio" in index, "home still hosts studio")
check('createFileRoute("/login")' in login, "login.tsx still exists for auth wiring")
check('Navigate to="/"' in login, "/login bounces to / without a full reload")
check("window.location" not in login, "/login has no hard navigation")
check('createFileRoute("/verify")' in verify, "verify.tsx still exists")
check('Navigate to="/"' in verify, "/verify bounces to / without a full reload")
check("window.location" not in verify, "/verify has no hard navigation")
check("EmailAuthForm" in require, "unsigned visitors see login on /")
check("VerifyPanel" in require, "unverified visitors see the code on /")
check("Navigate" not in require, "require-access does not change the path")
check("RedirectToSignIn" not in require, "require-access does not send people to /login")
check("window.location.assign" not in email, "email form stays in the same window")
check("/verify" not in email, "email form does not send people to /verify")
check("window.location.assign" not in vpanel, "verify panel stays in the same window")
check('signOut("/")' in vpanel, "other-email signs out to /")
check('signOut("/")' in account, "account bar signs out to /")
check('href="/repo"' in frame, "login chrome opens /repo")
check('value="repo"' in studio, "repo is an in-page tab")
check("window.location.assign" not in studio, "studio tabs do not refresh the page")
check('SIGN_IN_PATH = "/login"' in gates, "auth gates file is untouched")

if fail:
    print(fail, "failed")
    sys.exit(1)
print("ok")
