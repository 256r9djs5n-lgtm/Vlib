#!/usr/bin/env python3
"""Host checks: Pixel Gun 3D AppSealing RASP is handled inside Jailbreak Bypass."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
jb = (ROOT / "velora-jb.c").read_text(encoding="utf-8")
proc = (ROOT / "velora-proc.c").read_text(encoding="utf-8")
hdr = (ROOT / "velora-proc.h").read_text(encoding="utf-8")
plist = (ROOT / "layout/Library/PreferenceLoader/Preferences/VeloraJB.plist").read_text(encoding="utf-8")
compat = (ROOT / "velora-compat.c").read_text(encoding="utf-8")
inj = (ROOT / "velora-inject.c").read_text(encoding="utf-8")
fail = 0


def check(cond, name):
    global fail
    if not cond:
        print("FAIL", name)
        fail += 1
    else:
        print("ok", name)


check("velora_jb_rasp_sym" in hdr and "velora_jb_rasp_sym" in proc, "rasp symbol helper exported")
check("velora_jb_rasp_kind" in hdr and "velora_jb_rasp_kind" in proc, "rasp kind helper exported")
check("velora_jb_debug_port" in hdr, "debug-port helper exported")
check("velora_jb_loopback_debug" in hdr, "loopback helper exported")
check("velora_jb_proc_name" in hdr, "proc-name helper exported")
check("velora_jb_rasp_alert" in hdr, "rasp-alert helper exported")
check("velora_jb_scrub_procbuf" in hdr, "procbuf helper exported")
check("Unity_IsAbnormalEnvironmentDetected" in proc, "int-zero export listed")
check("GetHackingDetected" in proc, "string-NO export listed")
check("hook_rasp_zero" in jb and "return 0;" in jb[jb.find("static int hook_rasp_zero(void) {") : jb.find("static int hook_rasp_zero(void) {") + 80], "RASP int stub returns 0")
check('return "NO"' in jb, "RASP string stub returns NO")
check("velora_jb_rasp_kind(name)" in jb[jb.find("static void *hook_dlsym") : jb.find("static void *hook_dlsym") + 900], "dlsym intercepts AppSealing P/Invoke")
check("hook_rasp_exports" not in jb, "does not MSHookFunction AppSealing C exports")
check("hook_sym_once" not in jb, "does not inline-hook late AppSealing images")
check("jb_on_image" not in jb, "no add_image rehook of AppSealing .text")
check('hook_sym("isatty"' not in jb, "does not hook isatty")
check("presentViewController:animated:completion:" not in jb, "jb does not swallow presentViewController")
check("orig_jbPresent" not in jb, "no dismiss-after-present RASP hook")
check("presentViewController:animated:completion:" not in compat, "compat still does not swallow sheets")
check("hook_present" not in compat, "compat has no present hook")
check("AppSealingInterface" in jb, "hooks AppSealing ObjC interface")
check("hook_cls_str_no" in jb, "GetHackingDetected returns NSString NO")
check("hook_cls_bool" in jb and "IsAbnormalEnvironmentDetected" in jb, "abnormal-environment class bool stays 0")
check("IOSJailbreakDetector" in jb, "hooks GuardingPear detector")
check('hook_sym("exit"' not in jb and 'hook_sym("abort"' not in jb, "does not no-op process kill")
check('hook_sym("kill"' not in jb, "does not hook kill")
check("27042" in proc and "27043" in proc, "Frida default ports listed")
check("REF: 6917" in proc and "REF: 6919" in proc, "PG3D support codes matched")
check("detected tampering" in proc, "PG3D tamper dialog matched")
check("debugging or similar" in proc, "PG3D debugger dialog matched")
check("needs to be updated" not in proc[proc.find("int velora_jb_rasp_alert") : proc.find("int velora_jb_scrub_procbuf")], "RASP matcher ignores iOS update alert")
check("protected_proc" in jb and "org.coolstar.Sileo" in jb, "Sileo stays excluded")
check("com.apple.springboard" in jb, "SpringBoard stays excluded")
check("velora_jb_init" in inj, "injector still starts jb bypass")
boot = inj[inj.find("static void velora_app_boot") : inj.find("static void velora_boost")]
check("velora_jb_init();" in boot, "jb init still in app boot")
sb = inj[inj.find('velora_cstr_eq(p, "SpringBoard")') :]
check("velora_jb_init" not in sb.split("return;")[0], "SpringBoard ctor does not start jb bypass")
check("AppSealing" in plist and "Pixel Gun" in plist, "settings name the PG3D method")
check("cubic.games" in plist, "settings mention the splash freeze")
check("jbBypass" in plist, "still the same Jailbreak Bypass toggle")
check('velora_cstr_has(p, "tweak")' not in proc[proc.find("int velora_jb_path") : proc.find("int velora_jb_scheme")], "no generic tweak path hide")
check("+ 16" not in jb, "does not poke NSBlock invoke")
check("ECONNREFUSED" not in jb or "*e = 61" in jb, "connect fail uses ECONNREFUSED")
check("not patched" in plist.lower() or "is not patched" in plist, "settings say AppSealing code is not patched")

src = Path("/tmp/test-pg3d-logic.c")
src.write_text(
    r"""
#include "/workspace/tweak/Velora/velora-proc.c"
#include <stdio.h>
#include <string.h>
int main(void) {
    int fail = 0;
#define E(got, want, name) do { if ((int)(got) != (int)(want)) { printf("FAIL %s got=%d want=%d\n", name, (int)(got), (int)(want)); fail++; } } while (0)
    E(velora_jb_rasp_sym("Unity_IsAbnormalEnvironmentDetected"), 1, "unity");
    E(velora_jb_rasp_sym("_IsAbnormalEnvironmentDetected"), 1, "uscore");
    E(velora_jb_rasp_kind("Unity_IsAbnormalEnvironmentDetected"), 1, "kind-int");
    E(velora_jb_rasp_kind("GetHackingDetected"), 2, "kind-str");
    E(velora_jb_rasp_kind("Unity_GetAppSealingHackingDetected"), 2, "kind-unity-str");
    E(velora_jb_rasp_kind("UnitySendMessage"), 0, "not-send");
    E(velora_jb_rasp_sym("UnitySendMessage"), 0, "not-send-sym");
    E(velora_jb_rasp_sym("IsJailbroken"), 0, "not-generic-jb-sym");
    E(velora_jb_debug_port(27042), 1, "frida");
    E(velora_jb_debug_port(443), 0, "https");
    E(velora_jb_proc_name("frida"), 1, "frida-proc");
    E(velora_jb_proc_name("SpringBoard"), 0, "sb");
    E(velora_jb_proc_name("Pixel Gun 3D"), 0, "pg3d");
    {
        unsigned char sa[8] = {16, 2, 0x69, 0xA2, 127, 0, 0, 1};
        unsigned char bad[8] = {16, 2, 0x01, 0xBB, 127, 0, 0, 1};
        unsigned char wan[8] = {16, 2, 0x69, 0xA2, 1, 1, 1, 1};
        E(velora_jb_loopback_debug(sa, 8), 1, "lo-frida");
        E(velora_jb_loopback_debug(bad, 8), 0, "lo-https");
        E(velora_jb_loopback_debug(wan, 8), 0, "wan-frida");
    }
    E(velora_jb_rasp_alert(0, "detected tampering or resigning of this app"), 1, "tamper");
    E(velora_jb_rasp_alert(0, "cannot be used with a debugging or similar tool"), 1, "dbg");
    E(velora_jb_rasp_alert("This app needs to be updated.", 0), 0, "not-update");
    E(velora_jb_rasp_alert("Velora", "Waiting for the download to start."), 0, "not-wait");
    {
        char b[32];
        memcpy(b, "xxfridaxx", 10);
        E(velora_jb_scrub_procbuf(b, 9) > 0, 1, "scrub");
        E(velora_cstr_has(b, "frida"), 0, "gone");
    }
    if (fail) { printf("%d failed\n", fail); return 1; }
    puts("ok");
    return 0;
}
"""
)
cc = subprocess.run(["gcc", "-O0", "-o", "/tmp/test-pg3d-logic", str(src)], capture_output=True, text=True)
check(cc.returncode == 0, "pg3d helper compiles")
if cc.returncode != 0:
    print(cc.stderr)
else:
    run = subprocess.run(["/tmp/test-pg3d-logic"], capture_output=True, text=True)
    check(run.returncode == 0 and "ok" in run.stdout, "pg3d helper cases pass")
    if run.returncode != 0:
        print(run.stdout, run.stderr)

if fail:
    print(fail, "failed")
    sys.exit(1)
print("ok")
