#!/usr/bin/env python3
from pathlib import Path
import sys

v = Path(__file__).resolve().parent.joinpath("velora-versions.c").read_text()
lookup = Path("/workspace/src/routes/api/store/lookup.ts").read_text()
store = Path("/workspace/src/lib/store-versions.ts").read_text()
fail = 0

def check(cond, name):
    global fail
    if not cond:
        print("FAIL", name)
        fail += 1
    else:
        print("ok", name)

check("sort_version_rows" in v, "client sorts version rows")
check("normalize_row_dates" in v, "client normalizes dates")
check("month_token" in v, "client parses month names")
check("janfebmarapr" in v, "month table")
check("idRows" not in lookup, "server does not split id rows")
check("sortVersions" in lookup, "server sorts versions")
check("sortVersions" in store, "sortVersions helper")
check('s.includes(".")' in store, "stem fill requires two components")
check(v.count("sort_version_rows(") >= 3, "sort after both merges")
check("exchangeObjectAtIndex:withObjectAtIndex:" in v, "in-place sort")
check("arm_rows" in v, "client fetches ARM Store versions")
check("decrypt_rows" not in v, "decrypt.day rows gone")
check("decrypt.day" not in v, "no decrypt.day in history")
check("armconverter.com/decryptedappstore/versions/" in v, "ARM versions endpoint")
check("armStoreHistory" in lookup, "server merges ARM Store history")
check("decrypt-day" not in lookup, "lookup does not import decrypt-day")
check("arm-store" in lookup, "lookup imports arm-store")
check("decrypt.day" not in lookup, "lookup has no decrypt.day")
check("spec_is_app_row" in v, "skips installed-app parent version id")
check("take_digits(ext, 0)" in v, "history versionId is Apple id only")
check("take_digits(ext, build)" not in v, "build number is not used as appExtVrsId")
check("arm_req_headers" in v, "ARM history request sends session")
check('nsstr("Origin")' in v, "ARM history Origin header")
ba = v[v.find("static void begin_install_appstore(id self, id spec) {") : v.find("static void begin_install_troll(id self, id spec) {")]
check("velora_resolve_ext" not in ba, "appstore tap does not HTTP-resolve")
check("NSURLConnection" not in ba, "appstore tap has no NSURLConnection")
check("velora_arm_download" in ba, "appstore tap still queues daemon")
wt = v[v.find("static void watch_tick(id self, SEL sel) {") : v.find("static void note_progress(id proxy) {")]
check("velora_last_error" in wt, "watch surfaces missing-id error")
check("gAlertClosed = 0" not in wt, "watch does not unlatch dismissed alert")
check("show_alert(" not in wt, "watch does not present a second alert")
check("show_or_update" in wt, "watch updates the live alert")

s = Path("/workspace/tweak/Velora/velora-store.c").read_text()
check('shared_set("dlVersionId", (e && store_cstr(e)[0]) ? e : nsstr(""))' in s, "clears stale version id")
pending = s[s.find("static void start_pending_purchase") : s.find("static id dict_url")]
check("This build has no App Store version id" in pending, "daemon refuses purchase without Apple ext")
check("velora_resolve_ext" in pending, "daemon resolves Apple ext before purchase")
check("try_ss_purchase(adam, ext);" in pending, "daemon starts SSPurchase")
check("else" in pending, "ASD is fallback only")
check("try_asd_purchase(adam, ext);" in pending, "ASD fallback present")
check("is_apple_ext" in v, "history requires Apple-length version ids")
check("n >= 8" in s[s.find("static int is_long_digits") : s.find("static id http_get_data")], "Apple ext ids are 8+ digits")
check('rid = row ? msg1(row, "objectForKey:", nsstr("build")) : 0;' not in s, "build number is not used as appExtVrsId")
check('dict_put(row, "version", identS);' not in s, "apple cache does not fake version names from ids")
check("softwareVersionExternalIdentifier=" in s[s.find("static id make_purchase_with") : s.find("static id make_purchase(")], "purchase sends Apple's long version key")
check("Pick a version in history first." in s, "troll refuses unversioned latest")
check("buy_price" in s and "STDRDL" in s[s.find("static const char *buy_price") : s.find("static void try_ss_purchase")], "history redownload uses STDRDL")
check("seen < 24" in s, "purchase path scans a short Apple identifier list")
check("seen < 80" not in s, "purchase path does not scan 120 Apple ids")
if fail:
    sys.exit(1)
print("ok")
