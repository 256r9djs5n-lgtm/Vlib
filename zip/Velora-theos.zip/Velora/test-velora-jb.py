#!/usr/bin/env python3
"""Vel0ra Jailbreak IPA: unc0ver-style palera1n loader, TrollStore MH_EXECUTE."""
from __future__ import annotations

import struct
import sys
import zipfile
from pathlib import Path

ROOT = Path("/workspace")
fail = 0


def check(cond, name):
    global fail
    if not cond:
        print("FAIL", name)
        fail += 1
    else:
        print("ok", name)


app_c = (ROOT / "tweak/VeloraJB/velora-jbapp.c").read_text(encoding="utf-8")
info = (ROOT / "tweak/VeloraJB/Info.plist").read_text(encoding="utf-8")
loader = (ROOT / "tweak/VeloraJB/loader.json").read_text(encoding="utf-8")
helper = (ROOT / "tweak/VeloraJB/createFakeFS.sh").read_text(encoding="utf-8")
packer = (ROOT / "scripts/pack-velora-jb-ipa.py").read_text(encoding="utf-8")
managers = (ROOT / "src/lib/repo-managers.ts").read_text(encoding="utf-8")
i18n = (ROOT / "src/lib/i18n.ts").read_text(encoding="utf-8")
index = (ROOT / "public/repo/index.html").read_text(encoding="utf-8")
panel = (ROOT / "src/components/repo-panel.tsx").read_text(encoding="utf-8")

check("unc0ver-style" in app_c, "app is unc0ver-style")
check("Rootful" in app_c, "settings Rootful switch")
check("onRootful:" in app_c, "rootful action")
check("Cydia" in app_c and "Sileo" in app_c and "Zebra" in app_c, "Cydia Sileo Zebra")
check("Installer" in app_c and "Saily" in app_c, "Installer and Saily")
check("sudo password" in app_c, "asks sudo password")
check("alpine" in app_c, "default alpine password")
check("disk0s1s7" in app_c, "FakeFS disk0s1s7")
check("disk0s1s8" not in app_c, "no disk0s1s8 in app")
check("Create FakeFS" in app_c, "Create FakeFS button")
check("static.palera.in/sileo.deb" in app_c, "rootful Sileo URL")
check("static.palera.in/zebra.deb" in app_c, "rootful Zebra URL")
check("static.palera.in/bootstrap-1700.tar.zst" in app_c, "rootful bootstrap 1700")
check("apt.procurs.us/bootstraps" in app_c, "rootless bootstrap")
check("onPickManager:" in app_c, "package manager picker")
check("onPassContinue:" in app_c, "password continue")
check("computer-free 14.3" in app_c, "computer-free range")
check("class_replaceMethod" in app_c, "replaces viewDidLoad so the UI actually loads")
check("initWithFrame:" in app_c, "window has a real frame")
check("NSHomeDirectory" in app_c, "stages files in Documents not the signed bundle")
check("bootstrap-1800.tar.zst" in app_c, "uses bundled iOS 15 bootstrap")
check("sileo-rootful.deb" in app_c, "uses bundled Sileo")
check("LaunchScreen" in info, "has a launch storyboard")
check("fetch_assets" in packer, "packer embeds palera1n payloads")
check("MH_EXECUTE" in packer or "filetype != 2" in packer, "packer requires MH_EXECUTE")
check("LC_LOAD_DYLINKER" in packer, "packer keeps dylinker")
check("0x0E" in packer, "packer checks dylinker cmd")
check("Does not ship NekoJB" in packer, "does not redistribute NekoJB")
check("com.velora.jailbreak" in info, "bundle id")
check("Vel0ra" in info, "display name Vel0ra")
check("14.3" in info, "min iOS 14.3")
check("disk0s1s7" in helper, "helper FakeFS s7")
check("disk0s1s8" not in helper, "helper has no s8")
check("Xystem" in helper, "palera1n Xystem volume")
check("Cydia" in loader and "Sileo" in loader and "Zebra" in loader, "loader managers")
check("Installer" in loader and "Saily" in loader, "loader Installer Saily")
check("disk0s1s7" in loader, "loader fakefs disk")
check("Download Vel0ra Jailbreak" in managers, "site button label")
check("Vel0ra-Jailbreak.ipa" in managers, "site button href is ipa")
check("Download Vel0ra Jailbreak" in i18n, "i18n button")
check("Download Vel0ra Jailbreak" in index, "public repo button")
check("/repo/nekojb/Vel0ra-Jailbreak.ipa" in index, "public repo ipa href")
check("t.downloadNekojb" in panel, "studio repo tab uses i18n")
check("NEKOJB_DOWNLOAD.href" in panel, "studio repo tab href")

ipa = ROOT / "public/repo/nekojb/Vel0ra-Jailbreak.ipa"
check(ipa.is_file(), "IPA exists")
if ipa.is_file():
    raw = ipa.read_bytes()
    check(raw[:2] == b"PK", "IPA is a zip")
    with zipfile.ZipFile(ipa) as z:
        names = z.namelist()
        exe_name = "Payload/Vel0ra.app/Vel0ra"
        check(exe_name in names, "Payload/Vel0ra.app/Vel0ra")
        check("Payload/Vel0ra.app/Info.plist" in names, "Info.plist packed")
        check("Payload/Vel0ra.app/loader.json" in names, "loader.json packed")
        check("Payload/Vel0ra.app/createFakeFS.sh" in names, "createFakeFS.sh packed")
        blob = z.read(exe_name)
        check(blob[:4] == b"\xcf\xfa\xed\xfe", "executable is 64-bit Mach-O")
        filetype = struct.unpack_from("<I", blob, 12)[0]
        check(filetype == 2, "Mach-O is MH_EXECUTE")
        ncmds = struct.unpack_from("<I", blob, 16)[0]
        off = 32
        dylinker = False
        uikit = False
        platform = None
        for _ in range(ncmds):
            cmd, cmdsize = struct.unpack_from("<II", blob, off)
            if cmd == 0x0E:
                dylinker = True
            elif cmd == 0x32:
                platform = struct.unpack_from("<I", blob, off + 8)[0]
            elif cmd in (0x0C, 0x18, 0x80000018):
                noff = struct.unpack_from("<I", blob, off + 8)[0]
                name = blob[off + noff : off + cmdsize].split(b"\0", 1)[0]
                if b"UIKit" in name:
                    uikit = True
            off += cmdsize
        check(dylinker, "executable keeps LC_LOAD_DYLINKER")
        check(uikit, "executable loads UIKit")
        check(platform == 2, "PLATFORM_IOS")
        packed_info = z.read("Payload/Vel0ra.app/Info.plist").decode("utf-8", "replace")
        check("com.velora.jailbreak" in packed_info, "packed bundle id")
        packed_loader = z.read("Payload/Vel0ra.app/loader.json").decode("utf-8", "replace")
        check("static.palera.in/bootstrap-1700.tar.zst" in packed_loader, "packed palera1n bootstrap")
        packed_helper = z.read("Payload/Vel0ra.app/createFakeFS.sh").decode("utf-8", "replace")
        check("disk0s1s7" in packed_helper and "disk0s1s8" not in packed_helper, "packed FakeFS s7")
        check(not any("NekoJB" in n or "Dopamine" in n for n in names), "IPA does not contain NekoJB/Dopamine")
        check(any(n.endswith("bootstrap/bootstrap-1800.tar.zst") for n in names), "bundled palera1n bootstrap-1800")
        check(any(n.endswith("debs/sileo-rootful.deb") for n in names), "bundled Sileo deb")
        check(any(n.endswith("LaunchScreen.storyboard") for n in names), "launch storyboard packed")
    check(ipa.stat().st_size > 8 * 1024 * 1024, "IPA is not a 30KB stub")

if fail:
    print(fail, "failed")
    sys.exit(1)
print("ok velora-jb")
