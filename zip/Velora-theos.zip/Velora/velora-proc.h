/* Process gating used by the injector. No ObjC — host-testable. */
int velora_cstr_eq(const char *a, const char *b);
int velora_cstr_has(const char *s, const char *n);
int velora_cstr_end(const char *s, const char *n);
int velora_is_helper_bid(const char *bid);
int velora_is_helper_path(const char *path);
int velora_is_helper_prog(const char *prog);
int velora_is_store_bid(const char *bid);
int velora_is_prefs_bid(const char *bid);
int velora_is_springboard_bid(const char *bid);
int velora_skip_inject(const char *bid, const char *path);

/* HUD Darwin state: bit7=valid, bit0=hud, bit1=telemetry, bits2-3=corner. */
unsigned long long velora_pack_hud(int hud, int tel, int corner);
int velora_hud_state_valid(unsigned long long s);
int velora_hud_from_state(unsigned long long s);
int velora_tel_from_state(unsigned long long s);
int velora_corner_from_state(unsigned long long s);
int velora_is_unsafe_hud_window(const char *cls);
int velora_cstr_has_ci(const char *s, const char *n);
int velora_is_update_alert(const char *title, const char *msg);
int velora_jb_path(const char *p);
int velora_jb_scheme(const char *u);
int velora_jb_env(const char *name);
int velora_jb_cmd(const char *cmd);
int velora_jb_class(const char *n);
int velora_jb_write_path(const char *p);
int velora_jb_stash_path(const char *p);
int velora_jb_syscall_path_slot(int n);
int velora_jb_syscall_special(int n);

/* Pixel Gun 3D / AppSealing Unity RASP. Host-testable; no generic needles.
   kind: 0 none, 1 int-zero (IsAbnormal…), 2 string-NO (GetHackingDetected). */
int velora_jb_rasp_sym(const char *name);
int velora_jb_rasp_kind(const char *name);
int velora_jb_debug_port(int port);
int velora_jb_proc_name(const char *name);
int velora_jb_loopback_debug(const unsigned char *sa, unsigned int len);
int velora_jb_rasp_alert(const char *title, const char *msg);
int velora_jb_scrub_procbuf(char *buf, unsigned long n);

/* Compatibility bypass: never hide a blocking sheet. Skip the launch-alert
   presentation and allow the binary to start. */
unsigned long long velora_compat_alert_type(int bypass_on, unsigned long long type);
int velora_compat_launch_prohibited(int bypass_on, int orig);
int velora_compat_block_updates(int store_block, int bypass_on);
int velora_compat_skip_show(int bypass_on);
int velora_compat_alert_item(const char *cls);
int velora_compat_pref_combine(int file_on, int file_known, int cf_on, int cf_known, int def_on);
int velora_compat_state(int bypass_on, int orig);
int velora_compat_class_hook(const char *nm);

/* Dopamine / NekoJB: merge Rootful into latest Dopamine, auto-update palera1n. */
int velora_is_jbapp_bid(const char *bid);
int velora_is_jbapp_path(const char *path);
int velora_is_jb_update_url(const char *url);
int velora_is_jb_update_key(const char *key);
int velora_is_jb_update_id(const char *ident);
int velora_update_title_needs_tag(const char *title);
int velora_is_rootful_rel(const char *rel);
int velora_is_dopamine_core(const char *rel);
int velora_rootful_patch_old(const char *ver);

/* FakeFS disk: NekoJB used disk0s1s8; merge uses disk0s1s7. Same length. */
const char *velora_fakefs_disk(void);
const char *velora_fakefs_dev(void);
int velora_rewrite_fakefs_disk(char *s);

/* Nekoloader / bootstrap Sileo+Zebra+PreferenceLoader: rootless URLs become rootful. */
int velora_is_nested_loader_ipa(const char *rel);
int velora_is_rootless_pm_url(const char *u);
int velora_is_rootless_bootstrap_url(const char *u);
int velora_is_rootless_pref_url(const char *u);
const char *velora_rootful_sileo_url(void);
const char *velora_rootful_zebra_url(void);
const char *velora_rootful_bootstrap_url(void);
const char *velora_rootful_pref_url(void);
const char *velora_rootful_pm_url(const char *u);
int velora_is_fakefs_screen_title(const char *title);
