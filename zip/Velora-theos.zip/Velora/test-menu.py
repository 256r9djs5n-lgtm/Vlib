#!/usr/bin/env python3
"""Host checks: Settings pane stays visible, App Store matches AppStore++."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
menu = (ROOT / "velora-menu.c").read_text(encoding="utf-8")
prefs = (ROOT / "prefs-inject.c").read_text(encoding="utf-8")
plist = (ROOT / "layout/Library/PreferenceLoader/Preferences/Velora.plist").read_text(encoding="utf-8")
info = (ROOT / "Preferences/Resources/Info.plist").read_text(encoding="utf-8")
store = (ROOT / "velora-store.c").read_text(encoding="utf-8")
build = Path("/workspace/scripts/build-velora-debs.py").read_text(encoding="utf-8")
fail = 0


def check(cond, name):
    global fail
    if not cond:
        print("FAIL", name)
        fail += 1
    else:
        print("ok", name)


check("<key>bundle</key>" not in plist, "no bundle key so PreferenceLoader cannot drop the row")
check("VeloraRootListController" in plist, "entry still names injected class")
check("FPS Unlocker" in plist, "root items still list FPS page")
check("CFBundleExecutable" not in info, "prefs Info.plist has no executable")
check("NSPrincipalClass" not in info, "prefs Info.plist has no principal class")
check("__attribute__((constructor))" not in prefs, "prefs-inject is not a constructor")
check("specifiers_imp" not in prefs, "competing specifiers_imp gone")
check("loadSpecifiersFromPlistName" not in prefs, "prefs-inject does not load Root.plist")
check("class_replaceMethod" in menu, "menu replaces methods if a stub class exists")
check("ensure_menu_visible" in menu, "re-entry rebuilds empty pane")
check("viewDidAppear:" in menu, "didAppear repairs blank table")
check("fallback_menu" in menu, "hardcoded menu if plist missing")
check("hook_from_entry" in menu, "hooks PreferenceLoader entry so the row always appears")
check("hook_pl_specs" in menu, "hooks PLCustomListController for the Velora pane")
check("specifiersFromEntry:sourcePreferenceLoaderBundlePath:title:" in menu, "hooks PL entry loader")
appear = menu[menu.find("static void menu_appear"): menu.find("static void page_appear")]
check("reload_table(self)" not in appear, "viewWillAppear does not reloadData")
did = menu[menu.find("static void menu_did_load"): menu.find("static void page_did_load")]
check("reload_table(self)" not in did, "viewDidLoad does not reloadData")
check("copy_pref_bundle" in build, "deb still ships preference resources")
copy = build[build.find("def copy_pref_bundle"): build.find("def copy_filter")]
check("stale.unlink()" in copy, "build strips leftover bundle binary")
check("shutil.copy2(dylib, bundle)" not in build, "main() does not duplicate dylib as bundle")
check("<string>Preferences</string>" in (ROOT / "Velora.plist").read_text(encoding="utf-8"), "tweak injects Settings executable")
inj = (ROOT / "velora-inject.c").read_text(encoding="utf-8")
ctor = inj[inj.find("__attribute__((constructor)) static void velora_init") :]
check("register_prefs_now()" in ctor, "Settings constructor registers classes before PreferenceLoader")
check('velora_cstr_eq(p, "itunesstored")' in ctor, "constructor boots itunesstored immediately")
check("boot_late(0)" in ctor, "store daemons do not wait for the main queue")
prefs_ctor = ctor[ctor.find('velora_cstr_eq(p, "Preferences")'):]
check(prefs_ctor.find("register_prefs_now()") >= 0 and prefs_ctor.find("register_prefs_now()") < prefs_ctor.find("dispatch_late()"), "classes exist before async boot")
check("register_prefs_now" in inj, "shared prefs registrar")
check("rewrite_buy" in store and "hook_setBuySS" in store, "AppStore++ buy hooks in store")
check("STDRDL" in store, "redownload pricing still used")
check("appleAccountName" in menu, "Apple account status getter")
check("armSessionStatus" in menu, "ARM session status getter")
check("killall -9 itunesstored" in (ROOT / "DEBIAN/postinst").read_text(), "install restarts itunesstored")
check("killall -9 appstored" in (ROOT / "DEBIAN/postinst").read_text(), "install restarts appstored")
dev = (ROOT / "layout/Library/PreferenceLoader/Preferences/VeloraDevice.plist").read_text(encoding="utf-8")
check("bypassUpdateAlert" in dev, "device settings has update-alert bypass")
check("Bypass update alert" in dev, "device settings bypass label")
check("This app needs to be updated" in dev, "device settings names the iOS alert")
check("rootfulMode" not in dev, "device settings has no Rootful toggle")
check("<string>Rootful</string>" not in dev, "device settings has no Rootful label")
check("palera1n 2.4" not in dev, "device settings does not mention palera1n rootful")
compat = (ROOT / "velora-compat.c").read_text(encoding="utf-8")
check("void velora_compat_init(void)" in compat, "compat init exists")
check("isLaunchProhibited" in compat, "compat unblocks launch-prohibited")
check("evaluateForApplication:" in compat, "compat skips SpringBoard launch evaluator")
check("showLaunchAlertOfType:forApplication:withCompletionHandler:" in compat, "compat coerces launch-alert type to none")
check("presentViewController:animated:completion:" not in compat, "compat does not swallow the blocking sheet")
check("velora_compat_alert_type" in compat, "compat uses shared type coercion")
check("SBApplicationInfo" in compat, "compat hooks SpringBoard app info")
check("LSApplicationRecord" in compat, "compat hooks iOS 15 application records")
check("hasDisplayedLaunchAlertForType:" in compat, "compat marks the launch alert as already handled")
check("bypassUpdateAlert" in compat, "compat reads the device-settings key")
check("com.velora.hz/Reload" in compat, "compat reloads on Darwin notify")
check("velora_compat_init" in inj, "injector starts compat")
check("velora_jb_init" in inj, "injector starts jb bypass")
ctor = inj[inj.find("__attribute__((constructor)) static void velora_init") :]
check('velora_cstr_eq(p, "SpringBoard")' in ctor and "velora_compat_init();" in ctor, "SpringBoard constructor runs compat")
check("install_fps_hooks" not in ctor, "SpringBoard constructor does not install FPS")
boot = inj[inj.find("static void boot_late(void *ctx)") : inj.find("static int dispatch_late")]
check("velora_compat_init();" in boot, "SpringBoard boot_late still inits compat")
check("<string>SpringBoard</string>" in (ROOT / "Velora.plist").read_text(encoding="utf-8"), "tweak injects SpringBoard")
check("com.apple.springboard" in (ROOT / "Velora.plist").read_text(encoding="utf-8"), "tweak filter includes SpringBoard bundle")
check("com.apple.UIKitCore" in (ROOT / "Velora.plist").read_text(encoding="utf-8"), "tweak filter includes UIKitCore")
if fail:
    print(fail, "failed")
    sys.exit(1)
print("ok")
