#!/usr/bin/env python3
"""Host checks: decrypt.day is gone, ARM Store is wired, live page works."""
from pathlib import Path
import re
import subprocess
import sys
import urllib.request

ROOT = Path(__file__).resolve().parent
SRC = ROOT
SITE = Path("/workspace/src")
fail = 0


def check(cond, name):
    global fail
    if not cond:
        print("FAIL", name)
        fail += 1
    else:
        print("ok", name)


versions = (SRC / "velora-versions.c").read_text(encoding="utf-8")
store = (SRC / "velora-store.c").read_text(encoding="utf-8")
lookup = (SITE / "routes/api/store/lookup.ts").read_text(encoding="utf-8")
ipa = (SITE / "routes/api/store/ipa.ts").read_text(encoding="utf-8")
arm = (SITE / "lib/arm-store.ts").read_text(encoding="utf-8")

for label, text in (
    ("versions.c", versions),
    ("store.c", store),
    ("lookup.ts", lookup),
    ("ipa.ts", ipa),
    ("arm-store.ts", arm),
):
    check("decrypt.day" not in text, f"{label} has no decrypt.day")

check((SITE / "lib/decrypt-day.ts").exists() is False, "decrypt-day.ts removed")
check("velora_arm_store_page" in versions and "arm_rows" in versions, "troll/history knows ARM Store")
check("https://armconverter.com/store/us/app/" in store, "store builds ARM Store pages")
check("armconverter.com" in arm and "/store/" in arm, "site ARM helper")
check("from \"@/lib/arm-store\"" in lookup, "lookup uses arm-store")
check("from \"@/lib/arm-store\"" in ipa, "ipa route uses arm-store")
check("armStorePage" in lookup and "armIpaFor" in lookup, "lookup binds ARM page + ipa")
check("armStorePage" in ipa, "ipa route redirects to ARM Store")
check("decrypt-day" not in lookup and "decrypt-day" not in ipa, "api does not import decrypt-day")
check("velora_arm_store_page" in store and "velora_arm_store_page" in versions, "shared ARM page helper")
check("scrape_decrypt_ipa" not in store, "html scrape gone")
check("begin_install_troll" in versions, "troll tap present")
bt = versions[versions.find("static void begin_install_troll(id self, id spec) {") : versions.find("static void begin_install(id self, id spec) {")]
check("later(\"runTroll\"" in bt, "troll tap schedules ARM API job")
check("velora_arm_troll" in bt, "troll tap stores ARM ids")
check("NSURLConnection" not in bt and "openURL" not in bt, "troll tap has no HTTP/URL-open")
check("generalPasteboard" not in bt, "troll tap is not pasteboard")
check("apple-magnifier://install?url=" in store, "TrollStore scheme is apple-magnifier")
check("arm_prepare_token" in store, "ARM prepare token")
check("?token=" in store, "ARM IPA URL includes prepare token")
check('nsstr("X-Token")' in store[store.find("static int stream_ipa") : store.find("void velora_open_ipa_in_trollstore")], "IPA download sends X-Token")
check("merge_cookie_jar" in store, "ARM session cookie merge")
check("/decryptedappstore/user/info" in store, "ARM session keepalive ping")
check("/decryptedappstore/download/" in store, "ARM download API")
check("itunes_bundle_id" in store, "iTunes id lookup for bundle")
ba = versions[versions.find("static void begin_install_appstore(id self, id spec) {") : versions.find("static void begin_install_troll(id self, id spec) {")]
check("velora_arm_download" in ba, "appstore tap still queues Apple download")
check("go_bg" not in ba and "SSPurchase" not in ba, "appstore tap still crash-proof")
check("merge_rows(merged, arm_rows(track))" in versions, "history uses ARM rows")
check("https://armconverter.com/decryptedappstore/versions/" in versions, "ARM versions POST")

slug_c = r"""
#include <stdio.h>
#include <string.h>
static void arm_slug(char *out, int cap, const char *name) {
	int n = 0, dash = 0;
	if (!out || cap < 4) return;
	if (!name) name = "";
	while (*name && n < cap - 1) {
		unsigned char ch = (unsigned char)*name++;
		if (ch >= 'A' && ch <= 'Z') ch = (unsigned char)(ch + 32);
		if ((ch >= 'a' && ch <= 'z') || (ch >= '0' && ch <= '9')) { out[n++] = (char)ch; dash = 0; }
		else if (n && !dash) { out[n++] = '-'; dash = 1; }
	}
	while (n > 0 && out[n - 1] == '-') n--;
	if (!n) { out[0] = 'a'; out[1] = 'p'; out[2] = 'p'; n = 3; }
	out[n] = 0;
}
int main(void) {
	char s[96];
	arm_slug(s, 96, "Beat the Boss 4: Stress-Relief");
	if (strcmp(s, "beat-the-boss-4-stress-relief")) { fprintf(stderr, "slug1 %s\n", s); return 1; }
	arm_slug(s, 96, "YouTube");
	if (strcmp(s, "youtube")) return 2;
	arm_slug(s, 96, "");
	if (strcmp(s, "app")) return 3;
	arm_slug(s, 96, "!!!");
	if (strcmp(s, "app")) return 4;
	return 0;
}
"""
slug_path = Path("/tmp/test-arm-slug.c")
slug_bin = Path("/tmp/test-arm-slug")
slug_path.write_text(slug_c)
r = subprocess.run(["gcc", "-O0", "-o", str(slug_bin), str(slug_path)], capture_output=True, text=True)
check(r.returncode == 0, "slug test compiled")
if r.returncode == 0:
    r2 = subprocess.run([str(slug_bin)], capture_output=True, text=True)
    check(r2.returncode == 0, "slug matches ARM Store paths")
else:
    print(r.stderr)

src_slug = store[store.find("static void arm_slug(char *out, int cap, const char *name) {") : store.find("id velora_arm_store_page(id adam, id name) {")]
check("ch >= 'A' && ch <= 'Z'" in src_slug, "C slug lowercases")
check("out[0] = 'a'" in src_slug, "C slug falls back to app")

try:
    req = urllib.request.Request(
        "https://armconverter.com/store/us/app/youtube/id544007664",
        headers={"User-Agent": "Mozilla/5.0", "Accept": "text/html"},
    )
    with urllib.request.urlopen(req, timeout=20) as resp:
        body = resp.read(8000).decode("utf-8", "replace")
        check(resp.status == 200, "ARM Store YouTube page 200")
        check("ARM Store" in body, "ARM Store HTML title")
        check("decrypt.day" not in body, "ARM page is not decrypt.day")
except Exception as e:
    check(False, f"ARM Store live fetch: {e}")

try:
    req = urllib.request.Request(
        "https://armconverter.com/store/",
        headers={"User-Agent": "Mozilla/5.0", "Accept": "text/html"},
    )
    with urllib.request.urlopen(req, timeout=20) as resp:
        check(resp.status == 200, "ARM Store root 200")
except Exception as e:
    check(False, f"ARM Store root: {e}")

if fail:
    print(fail, "failed")
    sys.exit(1)
print("ok")
