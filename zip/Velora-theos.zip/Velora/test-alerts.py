#!/usr/bin/env python3
"""Host checks for Settings install alerts (1.5.6)."""
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
src = (ROOT / "velora-versions.c").read_text(encoding="utf-8")
store = (ROOT / "velora-store.c").read_bytes()

fail = 0

def check(cond, name):
    global fail
    if not cond:
        print("FAIL", name)
        fail += 1
    else:
        print("ok", name)

check("setMessage:" in src, "setMessage applied on alert")
check("presentedViewController" in src, "stack on presented controller")
check("Download finished." in src, "done copy EN")
check("Indirme bitti." in src, "done copy TR")
check("Waiting for the download to start." in src, "wait copy EN")
check("Indirme baslamasi bekleniyor." in src, "wait copy TR")
check("Downloading " in src, "progress copy EN")
check("Indiriliyor " in src, "progress copy TR")
check("Looking up this version and queuing it with Apple." not in src, "no early queue alert")
check("Apple…" not in src and "TrollStore…" not in src, "no unicode ellipsis in alerts")
check("applicationsDidInstall:" in src, "install observer")
check("applicationInstallsDidChange:" in src, "progress observer")
check("applicationsWillInstall:" in src, "will-install observer")
check("VeloraInstallWatch" in src, "watch class")
check("arm_install_watch" in src, "watch armed after App Store queue")
check("fire_done" in src, "done alert helper")
check("show_or_update" in src, "live alert update")
check("set_live_message" in src, "activate text on live alert")
check("isKindOfClass:" in src, "NSString-safe str_from_id")
check("start_pending_purchase" in store.decode("utf-8", "replace"), "store purchase intact")
check("in_store_process" in store.decode("utf-8", "replace"), "store process gate intact")
check("SSPurchase" in store.decode("utf-8", "replace"), "SSPurchase intact")
check("purchase_daemon" in store.decode("utf-8", "replace"), "single purchase daemon")
check(store.decode("utf-8", "replace").count("try_ss_purchase(adam, ext);") == 1, "ss once")
ss = re.search(r"static void try_ss_purchase[\s\S]+?^static ", store.decode("utf-8", "replace"), re.M)
check(ss is not None and ss.group(0).count("start_one_purchase") == 1, "one SS purchase start")
check("begin_install_appstore" in src and "arm_install_watch(self, spec, \"App Store\")" in src, "appstore arms watch first")

st = store.decode("utf-8", "replace")
run = re.search(r"void velora_run_trollstore\(void\) \{[\s\S]+?^void velora_run_download", st, re.M)
check(run is not None, "run_trollstore present")
if run:
    body = run.group(0)
    check("itunes_bundle_id" in body, "run_trollstore looks up bundle id")
    check("arm_confirms_version" in body, "run_trollstore confirms ARM history")
    check("arm_prepare_token" in body, "run_trollstore prepares ARM download token")
    check("stream_ipa" in body, "run_trollstore downloads IPA via ARM API")
    check("arm_ipa_download_url" in body, "run_trollstore uses ARM download URL")
    check("generalPasteboard" not in body, "run_trollstore does not copy URLs")
    check("is_direct_ipa_url" in body, "only real IPA urls stored")
check("streq(name, \"itunesstored\") || streq(name, \"appstored\")" in st, "purchase daemon includes appstored")
pending = st[st.find("static void start_pending_purchase"):st.find("static id dict_url")]
check("This build has no App Store version id" in pending, "pending refuses latest when version id missing")
check("velora_resolve_ext" in pending, "pending resolves ext before purchase")
check("try_ss_purchase(adam, ext);" in pending, "ss purchase in pending")
check("buy_price" in st, "history uses redownload pricing")
check("try_asd_purchase(adam, ext);" in pending, "asd fallback present")
check("apple_song_plist" not in pending, "pending does not volume-download")
check("enqueue_song" not in pending, "pending does not enqueue song")
check("else" in pending, "asd is else-fallback")
check("SBSOpenSensitiveURLAndUnlock" not in st[st.find("static void open_trollstore_ipa"):st.find("static void apply_store_headers")], "troll does not SBS-open")
check("class_replaceMethod" not in src, "no class_replaceMethod")
ba = src[src.find("static void begin_install_appstore(id self, id spec) {") : src.find("static void begin_install_troll(id self, id spec) {")]
bt = src[src.find("static void begin_install_troll(id self, id spec) {") : src.find("static void begin_install(id self, id spec) {")]
check("detachNewThreadSelector" not in ba and "detachNewThreadSelector" not in bt, "install jobs not NSThread-on-VC")
check("later(\"runStore\"" not in ba, "appstore tap has no delayed purchase")
check("velora_run_trollstore" not in bt, "troll tap does not fetch IPA")
check("go_bg" not in ba and "go_bg" not in bt, "install tap has no go_bg")
check("velora_resolve_ext" not in ba, "appstore tap has no HTTP resolve")
check("NSURLConnection" not in ba, "appstore tap has no NSURLConnection")
check("http_json" not in ba and "web_ext_for_ver" not in ba, "appstore tap has no web lookup")
check(len(ba) > 80 and len(bt) > 80, "tap bodies sliced")
check("action_button(self, nsstr(\"App Store\"), \"installAppStore\")" in src, "appstore action has no colon")
check("action_button(self, nsstr(\"TrollStore\"), \"installTroll\")" in src, "troll action has no colon")
check("generalPasteboard" not in src, "troll no longer copies URL")
check("return is_prefs_proc()" not in st[st.find("static int purchase_daemon"):st.find("static char gClaimAdam")], "prefs does not SSPurchase")
check("posix_spawn" in st[st.find("static void open_trollstore_ipa"):st.find("static void apply_store_headers")], "troll uiopen spawn")
check("apple-magnifier://install?url=" in st, "troll uses apple-magnifier")
check("scrape_decrypt_ipa" not in st, "no decrypt.day html scrape")
check("decrypt.day" not in src, "versions has no decrypt.day")
check("decrypt.day" not in st, "store has no decrypt.day")
bt = src[src.find("static void begin_install_troll(id self, id spec) {") : src.find("static void begin_install(id self, id spec) {")]
check("later(\"runTroll\"" in bt, "troll tap schedules API job")
check("velora_arm_troll" in bt, "troll arms ARM ids")
check("generalPasteboard" not in bt, "troll tap does not copy")
check("openURL" not in bt and "NSURLConnection" not in bt, "troll tap has no HTTP/URL-open")
check("https://armconverter.com/store/us/app/" in st, "store builds ARM Store page")
check("merge_rows(merged, arm_rows(track))" in src, "history merges ARM versions")
check("decrypt_rows" not in src, "decrypt_rows gone")
check("velora_open_decrypt_page" not in src and "velora_open_decrypt_page" not in st, "decrypt.day open helper gone")
check("ARM Store page URL copied" not in src, "page-copy copy gone")
check("/decryptedappstore/download/" in st, "ARM download path present")
check("/prepare" in st, "ARM prepare endpoint present")
check("No IPA for this build on ARM Store" in src, "troll error mentions ARM Store")
check("fopen" not in st, "no libc fopen in store")
note = re.search(r"static void on_download_note[\s\S]+?^static void on_fetch_note", st, re.M)
check(note is not None and "velora_run_trollstore" not in note.group(0), "darwin skip troll download")
check("velora_run_trollstore();" in src, "bg thread finds IPA url")
check("Downloading the IPA" not in bt, "no download alert on tap")
check("performSelectorInBackground" not in bt, "troll tap not inBackground")
check("velora_empty_block" not in src[src.find("static void show_alert"):src.find("static int alert_is_up")], "alert uses nil handler")
check("gAlertClosed" in src, "OK dismiss is latched")
check("viewWillDisappear:" in src, "live alert latches dismiss")
check("bounce_main" in src, "install observers hop to main")
check("VeloraLiveAlert" in src, "custom alert class")
fd = src[src.find("static void fire_done(void) {") : src.find("static void announce_done(id self, SEL sel) {")]
check("gAlertClosed = 0" not in fd, "finished does not re-present after OK")
check("show_or_update" in fd, "finished updates the waiting alert")
np = src[src.find("static void note_progress(id proxy) {") : src.find("static void apps_did_install")]
check("gAlertClosed = 0" not in np, "progress does not re-present after OK")
check("show_or_update" in np, "progress updates the waiting alert")
check("if (gLivePct > 0)" in np, "zero progress does not clobber a live percent")
check("if (gLivePct == 0)" in np, "waiting text is not rewritten on every tick")
check(np.find("if (p <= 0)") < np.find("Waiting for the download to start."), "waiting only before percent starts")
prog = r"""
#include <stdio.h>
static int action(int last, int p) {
	if (p <= 0) {
		if (last > 0) return 0;
		if (last == 0) return 0;
		return 1;
	}
	if (p == last) return 0;
	return 2;
}
int main(void) {
	int f = 0;
	if (action(-1, 0) != 1) { printf("FAIL start waiting\n"); f++; } else printf("ok start waiting\n");
	if (action(0, 0) != 0) { printf("FAIL keep waiting\n"); f++; } else printf("ok keep waiting\n");
	if (action(0, 12) != 2) { printf("FAIL first percent\n"); f++; } else printf("ok first percent\n");
	if (action(12, 0) != 0) { printf("FAIL zero does not revert\n"); f++; } else printf("ok zero does not revert\n");
	if (action(12, 12) != 0) { printf("FAIL same percent\n"); f++; } else printf("ok same percent\n");
	if (action(12, 40) != 2) { printf("FAIL next percent\n"); f++; } else printf("ok next percent\n");
	if (action(40, 0) != 0) { printf("FAIL installed proxy zero\n"); f++; } else printf("ok installed proxy zero\n");
	return f;
}
"""
Path("/tmp/test-progress-hysteresis.c").write_text(prog)
cc = subprocess.run(["gcc", "-o", "/tmp/test-progress-hysteresis", "/tmp/test-progress-hysteresis.c"], capture_output=True, text=True)
check(cc.returncode == 0, "progress hysteresis test compiled")
run = subprocess.run(["/tmp/test-progress-hysteresis"], capture_output=True, text=True)
print(run.stdout, end="")
check(run.returncode == 0, "progress hysteresis cases")
ff = src[src.find("static void apps_did_fail") : src.find("static void apps_will_install")]
check("gAlertClosed = 0" not in ff, "failed does not re-present after OK")
check("show_or_update" in ff, "failed updates the waiting alert")
finb = src[src.find("static void finish_troll(id self, SEL sel) {") : src.find("static void open_troll_later")]
check("velora_open_ipa_in_trollstore" in finb, "finish opens trollstore")
check(finb.find("velora_last_error") < finb.find("velora_open_ipa_in_trollstore"), "errors before open")
check("gAlertClosed = 0" not in finb, "troll finish does not re-present after OK")
check("show_or_update" in finb, "troll finish updates the live alert")
check("Opening TrollStore." in src, "troll open copy EN")
check("TrollStore aciliyor." in src, "troll open copy TR")
arm = re.search(r"void velora_arm_troll[\s\S]+?^static void on_download_note", st, re.M)
check(arm is not None and "post_dl();" not in arm.group(0), "arm troll no darwin post")
check("start_pending_purchase" in st, "store purchase still intact after troll fix")
check(st.count("try_ss_purchase(adam, ext);") == 1, "ss once after troll fix")

# every show_alert call has a non-empty message argument
calls = re.findall(r'show_alert\([^;]+;', src, re.S)
check(len(calls) >= 3, f"enough show_alert calls ({len(calls)})")
for c in calls:
    check("nsstr(\"\")" not in c and ", 0)" not in c.split("show_alert")[-1][:80], "show_alert not empty: " + c.replace("\n", " ")[:70])

# loc() always has both en and tr
locs = re.findall(r'loc\(\s*"([^"]*)"\s*,\s*"([^"]*)"\s*\)', src)
check(len(locs) >= 8, f"localized strings {len(locs)}")
for en, tr in locs:
    check(len(en) > 0 and len(tr) > 0, f"loc non-empty {en[:24]!r}")

check("rewrite_buy" in st, "AppStore++ buy-parameter rewrite")
check("hook_setBuySS" in st, "SSPurchase setBuyParameters hook")
check("hook_getBuySS" in st, "SSPurchase buyParameters hook")
check("hook_setBuyASD" in st, "ASDPurchase setBuyParameters hook")
check("appExtVrsId=" in st[st.find("static id rewrite_buy"):st.find("static void (*orig_setBuySS)")], "rewrite injects appExtVrsId")
check("bump_dl_gen" in st, "download generation dedupes double notify")
init = st[st.find("void velora_store_init"):]
check("start_pending_purchase" not in init, "store init does not auto-purchase leftover ids")
check("setBuyParameters:" in init, "store init installs buy hooks")
ba = src[src.find("static void begin_install_appstore(id self, id spec) {") : src.find("static void begin_install_troll(id self, id spec) {")]
check("show_or_update" in ba, "appstore tap shows alert immediately")
check("Queuing this version with the App Store" in ba, "appstore queue copy EN")
check("Bu surum App Store'a kuyruga aliniyor" in ba, "appstore queue copy TR")
check("velora_arm_download" in ba, "appstore still queues SSPurchase")
check("arm_install_watch" in ba, "appstore still watches progress")
check("capture_apple_session" in st, "Apple session capture")
check("X-Token" in st, "Apple X-Token header")
check("VeloraSessionKeeper" in st, "background session keeper")
check("merge_cookie_jar" in st, "ARM cookie merge")
note_dl = st[st.find("static void on_download_note") : st.find("static void on_fetch_note")]
check("dispatch_get_global_queue" in note_dl, "download note hops off Darwin")
check("purchase_daemon()" in note_dl, "only store daemons purchase")
check("if (gPurchaseBusy)" not in st[st.find("static int claim_purchase(id adam)") : st.find("static int is_prefs_proc(void) {")], "purchase lock cannot stick")
check("velora_empty_block" in st[st.find("static void try_asd_purchase") : st.find("static id apple_redownload_plist")], "ASD completion is not NULL")

if fail:
    print(fail, "failed")
    sys.exit(1)
print("ok")
