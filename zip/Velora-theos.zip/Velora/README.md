# VELORA

Jailbreak tweak for **iOS 14.3–17.0**.

- ProMotion **120 Hz** on supported panels (iPad Pro on 14.3; iPhone 13 Pro and later on iOS 15+)
- On-screen **FPS HUD**
- **Custom FPS lock** — `5.00` applies 5 fps
- CADisplayLink throttle + `preferredFramesPerSecond` (iOS 14) / `preferredFrameRateRange` (iOS 15+)

## Packages

| Deb | Architecture | Jailbreak |
|---|---|---|
| `com.velora.hz_1.0.0_iphoneos-arm.deb` | rootful | checkra1n, unc0ver, Taurine, palera1n rootful |
| `com.velora.hz_1.0.0_iphoneos-arm64.deb` | rootless | Dopamine, palera1n rootless |

Firmware: `>= 14.3` and `<< 17.1`.

Add the live `/repo` URL from the VELORA site in Sileo, Zebra, Cydia, Installer 5, or Saily.

## Build with Theos

```sh
export THEOS=~/theos
cd Velora

# rootful (iOS 14.3+)
make clean
make package

# rootless (iOS 15–17)
make clean
make package THEOS_PACKAGE_SCHEME=rootless
```

Install the resulting `.deb` with Sileo, Zebra, or `dpkg -i`.

Then: **Settings → Velora** → enable, set custom FPS, respring.

## Notes

`CAFrameRateRange` is only messaged when the selector exists (iOS 15+). On 14.3 the tweak uses integer `preferredFramesPerSecond` plus timestamp throttling for fractional values.
