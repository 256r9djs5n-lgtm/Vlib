#!/usr/bin/env python3
"""Host checks: NekoJB packer overwrites Velora into an IPA and ships a .cmd, not a .deb."""
from __future__ import annotations

import io
import json
import sys
import tarfile
import zipfile
from pathlib import Path

ROOT = Path("/workspace")
SCRIPTS = ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))
# Hyphenated module file.
import importlib.util

spec = importlib.util.spec_from_file_location("pack_nekojb_ipa", SCRIPTS / "pack-nekojb-ipa.py")
pack = importlib.util.module_from_spec(spec)
assert spec.loader
spec.loader.exec_module(pack)

fail = 0


def check(cond, name):
    global fail
    if not cond:
        print("FAIL", name)
        fail += 1
    else:
        print("ok", name)


def make_tar(files: dict[str, bytes]) -> bytes:
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w") as t:
        for name, data in files.items():
            info = tarfile.TarInfo(name)
            info.size = len(data)
            t.addfile(info, io.BytesIO(data))
    return buf.getvalue()


def make_ipa(path: Path, extra_app: dict[str, bytes] | None = None) -> Path:
    app = "Payload/NekoJB.app"
    files = {
        f"{app}/Info.plist": b'<?xml version="1.0"?><plist><dict><key>CFBundleIdentifier</key><string>xyz.hhls.nekojb</string></dict></plist>',
        f"{app}/NekoJB": b"FAKEBIN",
        f"{app}/Library/MobileSubstrate/DynamicLibraries/Velora.dylib": b"OLD_DYLIB",
        f"{app}/keep-me.txt": b"stay",
        f"{app}/basebin.tar": make_tar(
            {
                "basebin/hello.txt": b"hello",
                "basebin/Library/MobileSubstrate/DynamicLibraries/Velora.dylib": b"OLD_IN_TAR",
            }
        ),
    }
    if extra_app:
        files.update({f"{app}/{k}": v for k, v in extra_app.items()})
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for name, data in files.items():
            z.writestr(name, data)
    return path


src = Path("/workspace/scripts/pack-nekojb-ipa.py").read_text(encoding="utf-8")
compat_ui = (ROOT / "src/components/repo-panel.tsx").read_text(encoding="utf-8")
managers = (ROOT / "src/lib/repo-managers.ts").read_text(encoding="utf-8")
i18n = (ROOT / "src/lib/i18n.ts").read_text(encoding="utf-8")
index = (ROOT / "public/repo/index.html").read_text(encoding="utf-8")
build = (ROOT / "scripts/build-velora-debs.py").read_text(encoding="utf-8")

check("NekoJB-Fixed-IPA.cmd" in src, "packer ships a .cmd")
check("NekoJB-Fixed.ipa" in src, "packer writes NekoJB-Fixed.ipa")
check("VELORA_NEKOJB_OVERLAY_ZIP" in src, "cmd embeds overlay zip marker")
check("does not ship NekoJB" in src or "Does not ship NekoJB" in src, "does not redistribute NekoJB")
check("merged into" in src.lower() or "merge NekoJB rootful" in src, "packer documents NekoJB+Dopamine merge")
check("palera1n" in src.lower(), "palera1n-updated rootful")
check("is_dopamine_core" in src, "protects Dopamine core from NekoJB overwrite")
check("is_rootful_rel" in src, "classifies NekoJB rootful files")
check("merge_layers" in src, "merges Dopamine + native rootful + Velora")
check("rootfulMode" in src, "rootful pref key in packer")
check("nekojb_rootful_is_old" in src, "detects old NekoJB rootful patch")
check("2.4" in src, "palera1n 2.4")
check("dopamine" in src.lower() and "donor" in src.lower(), "cmd prefers Dopamine as base and NekoJB as donor")
check("refresh_old_rootful_bytes" in src, "auto-updates old rootful files")
check("paleinfo" in src, "copies paleinfo rootful extras")
check("disk0s1s7" in src, "packer FakeFS disk is disk0s1s7")
check("disk0s1s8" in src, "packer rewrites disk0s1s8")
check("static.palera.in/sileo.deb" in src, "rootful Sileo download")
check("static.palera.in/zebra.deb" in src, "rootful Zebra download")
check("static.palera.in/bootstrap.tar.zst" in src, "rootful bootstrap")
check("rootless/sileo" in src, "rewrites Nekoloader rootless Sileo")
check("loader.json" in src, "ships nekoloader config")

check("basebin.tar" not in src or "inject_tar" in src, "injects overlay into bundled tars")
check("NEKOJB_DOWNLOAD" in managers, "repo managers export the NekoJB download")
check("Vel0ra-Jailbreak.ipa" in managers, "managers href is the Vel0ra IPA")
check("Download Vel0ra Jailbreak" in managers, "download label is Download Vel0ra Jailbreak")
check('name: "NekoJB"' in managers, "jailbreak map includes NekoJB")
check("downloadNekojb" in i18n, "i18n has the button key")
check('"Download Vel0ra Jailbreak"' in i18n, "i18n button copy")
check("NEKOJB_DOWNLOAD" in compat_ui, "repo tab uses the NekoJB download")
check("t.downloadNekojb" in compat_ui, "repo tab button uses i18n label")
check("/repo/nekojb/Vel0ra-Jailbreak.ipa" in index, "public repo page links the ipa")
check("downloadNekojb" in index, "public repo page button is i18n-tagged")
check("pack-nekojb-ipa.py" in build, "deb build also writes the NekoJB packer")
check("pack-velora-jb-ipa.py" in build, "deb build also writes the Vel0ra Jailbreak IPA")
check("--build-downloads" in build, "deb build calls packer downloads")

tmp = Path("/tmp/nekojb-test")
tmp.mkdir(exist_ok=True)
ipa = make_ipa(tmp / "nekojb_rootful.ipa")
overlay = {
    "Library/MobileSubstrate/DynamicLibraries/Velora.dylib": b"NEW_DYLIB",
    "Library/MobileSubstrate/DynamicLibraries/Velora.plist": b"FILTER",
    "usr/lib/TweakInject/Velora.dylib": b"NEW_DYLIB",
    "autoinstall/com.velora.hz.deb": b"!<arch>\nNEWDEB",
    "debs/com.velora.hz.deb": b"!<arch>\nNEWDEB",
}
out = tmp / "NekoJB-Fixed.ipa"
pack.pack_ipa(ipa, overlay, out)
check(out.is_file(), "packer wrote an IPA")
check(out.read_bytes()[:2] == b"PK", "output is a zip/ipa")

with zipfile.ZipFile(out) as z:
    names = set(z.namelist())
    check("Payload/NekoJB.app/NekoJB" in names, "keeps the original NekoJB binary")
    check("Payload/NekoJB.app/keep-me.txt" in names, "keeps unrelated files")
    check(
        z.read("Payload/NekoJB.app/Library/MobileSubstrate/DynamicLibraries/Velora.dylib") == b"NEW_DYLIB",
        "overwrites existing dylib in the app",
    )
    check(z.read("Payload/NekoJB.app/keep-me.txt") == b"stay", "does not clobber unrelated files")
    check(
        z.read("Payload/NekoJB.app/autoinstall/com.velora.hz.deb").startswith(b"!<arch>\n"),
        "drops rootful deb into autoinstall",
    )
    tar_blob = z.read("Payload/NekoJB.app/basebin.tar")
inner = pack.inject_tar(tar_blob, {})  # already injected
with tarfile.open(fileobj=io.BytesIO(tar_blob), mode="r:*") as t:
    members = {m.name: t.extractfile(m).read() if m.isfile() else None for m in t.getmembers()}
check(members.get("basebin/hello.txt") == b"hello", "tar keeps original files")
check(
    members.get("basebin/Library/MobileSubstrate/DynamicLibraries/Velora.dylib") == b"NEW_DYLIB",
    "tar overwrites existing dylib",
)
check(
    members.get("Library/MobileSubstrate/DynamicLibraries/Velora.dylib") == b"NEW_DYLIB"
    or members.get("basebin/Library/MobileSubstrate/DynamicLibraries/Velora.dylib") == b"NEW_DYLIB",
    "tar received the overlay dylib",
)

old = make_tar({"basebin/hello.txt": b"hello", "basebin/Library/MobileSubstrate/DynamicLibraries/Velora.dylib": b"OLD"})
new = pack.inject_tar(old, {"Library/MobileSubstrate/DynamicLibraries/Velora.dylib": b"NEW"})
with tarfile.open(fileobj=io.BytesIO(new), mode="r:*") as t:
    got = {
        m.name: t.extractfile(m).read()
        for m in t.getmembers()
        if m.isfile()
    }
check(got.get("basebin/hello.txt") == b"hello", "inject_tar keeps sibling files")
check(got.get("basebin/Library/MobileSubstrate/DynamicLibraries/Velora.dylib") == b"NEW", "inject_tar overwrites under prefix")
check(got.get("Library/MobileSubstrate/DynamicLibraries/Velora.dylib") == b"NEW", "inject_tar also writes at tar root")

paths = pack.write_nekojb_downloads()
cmd = paths["cmd"]
zpath = paths["zip"]
check(cmd.is_file(), "wrote NekoJB-Fixed-IPA.cmd")
check(zpath.is_file(), "wrote NekoJB-Fixed-IPA.zip")
raw = cmd.read_bytes()
check(pack.MARKER in raw, "cmd contains overlay marker")
check(raw.split(pack.MARKER, 1)[1].lstrip(b"\r\n")[:2] == b"PK", "cmd payload is a zip")
check(b"@echo off" in raw[:80], "cmd is a Windows batch file")
check(b"EncodedCommand" in raw, "cmd launches PowerShell packer")
ov = pack.extract_overlay_from_cmd(cmd)
check(any(k.endswith("Velora.dylib") for k in ov), "cmd overlay includes Velora.dylib")
check(
    any(k.endswith("Velora.plist") for k in ov),
    "cmd overlay includes the filter plist",
)
check("autoinstall/com.velora.hz.deb" in ov, "cmd overlay includes the rootful deb")
check(ov["autoinstall/com.velora.hz.deb"].startswith(b"!<arch>\n"), "embedded deb is a real ar archive")
with zipfile.ZipFile(zpath) as z:
    znames = z.namelist()
check("NekoJB-Fixed-IPA.cmd" in znames, "zip contains the cmd")
check("README.txt" in znames, "zip contains the readme")
check(cmd.stat().st_size < 8 * 1024 * 1024, "cmd is a patcher, not a full IPA dump")

# Nested .tipa.zip (Safari often saves it that way)
nested = tmp / "nekojb_rootful.tipa.zip"
inner_ipa = tmp / "inner.ipa"
make_ipa(inner_ipa)
with zipfile.ZipFile(nested, "w") as z:
    z.write(inner_ipa, "nekojb_rootful.tipa")
nested_out = tmp / "from-nested.ipa"
pack.pack_ipa(nested, overlay, nested_out)
with zipfile.ZipFile(nested_out) as z:
    check(
        z.read("Payload/NekoJB.app/Library/MobileSubstrate/DynamicLibraries/Velora.dylib") == b"NEW_DYLIB",
        "nested tipa.zip is unpacked and overwritten",
    )

check("Download Vel0ra Jailbreak" in (ROOT / "public/repo/i18n.js").read_text(encoding="utf-8"), "repo i18n button label")
check("palera1n-VERSION" in ov, "cmd overlay palera1n VERSION")
check(b"2.4" in ov["palera1n-VERSION"], "cmd overlay is palera1n 2.4")
check("createFakeFS.sh" in ov, "cmd overlay palera1n helper at native name")
check("rootfulMode" not in ov.get("Library/PreferenceLoader/Preferences/VeloraDevice.plist", b"").decode("utf-8", "replace"), "cmd overlay Device Settings has no Rootful")
check(not any(k.startswith("velora-rootful/") for k in ov), "cmd overlay is not an isolated velora-rootful layer")

check(pack.is_rootful_rel("fakefs.tar") == 1, "fakefs is rootful")
check(pack.is_rootful_rel("rootful.plist") == 1, "rootful plist is rootful")
check(pack.is_rootful_rel("Assets.car") == 0, "assets are not rootful")
check(pack.is_dopamine_core("Dopamine") == 1, "Dopamine binary is core")
check(pack.is_dopamine_core("Info.plist") == 1, "Info.plist is core")
check(pack.is_dopamine_core("basebin.tar") == 1, "basebin.tar is core")
check(pack.is_dopamine_core("Frameworks/Foo.framework/Foo") == 1, "Frameworks are core")
check(pack.is_dopamine_core("rootful.plist") == 0, "rootful plist is not core")
check(pack.nekojb_rootful_is_old({}) == 1, "empty donor is old")
check(pack.nekojb_rootful_is_old({"a": b"neko 2.0.11"}) == 1, "NekoJB 2.0.11 is old vs palera1n 2.4")
check(pack.nekojb_rootful_is_old({"stamp.json": b'"version": "2.4"'}) == 0, "palera1n 2.4 stamp is current")

dopa_base = {
    "Info.plist": b'<?xml version="1.0"?><plist><dict><key>CFBundleIdentifier</key><string>com.opa334.Dopamine</string></dict></plist>',
    "Dopamine": b"NEW_DOPA",
    "basebin.tar": b"NEW_BASEBIN",
    "keep-dopa.txt": b"dopa-stay",
}
neko_donor = {
    "Info.plist": b"OLD_NEKO_PLIST",
    "Dopamine": b"OLD_NEKO_BIN",
    "NekoJB": b"OLD_NEKOJB",
    "basebin.tar": b"OLD_NEKO_BASEBIN",
    "fakefs.tar": b"FAKEFS",
    "rootful.plist": b"ROOTFUL_TOGGLE",
    "createFakeFS.sh": b"OLD_SCRIPT",
    "bindfs.conf": b"palera1n --fakefs\n",
}
merged = pack.merge_layers(dopa_base, neko_donor, {"Library/MobileSubstrate/DynamicLibraries/Velora.dylib": b"NEW_DYLIB"})
check(merged["Dopamine"] == b"NEW_DOPA", "Dopamine binary not replaced by NekoJB")
check(merged["basebin.tar"] == b"NEW_BASEBIN", "Dopamine basebin not replaced by NekoJB")
check(b"com.opa334.Dopamine" in merged["Info.plist"], "Dopamine Info.plist kept")
check(merged["keep-dopa.txt"] == b"dopa-stay", "Dopamine extra files kept")
check(merged.get("fakefs.tar") == b"FAKEFS", "NekoJB fakefs at original name")
check(merged.get("rootful.plist") == b"ROOTFUL_TOGGLE", "NekoJB Rootful settings at original name")
check(merged.get("createFakeFS.sh") is not None, "fakefs script present")
check(merged.get("createFakeFS.sh") != b"OLD_SCRIPT", "old fakefs script refreshed to palera1n 2.4")
check(b"--rootful" in merged.get("bindfs.conf", b""), "old --fakefs flag auto-updated to --rootful")
check(b"--fakefs" not in merged.get("bindfs.conf", b""), "old --fakefs flag removed")
check("rootful-boot.sh" in merged, "palera1n boot helper merged")
check("paleinfo.conf" in merged, "paleinfo merged")
check(b"Xystem" in merged["createFakeFS.sh"], "palera1n 2.4 Xystem volume")
check(b"disk0s1s7" in merged["createFakeFS.sh"], "FakeFS helper uses disk0s1s7")
check(b"disk0s1s8" not in merged["createFakeFS.sh"], "FakeFS helper does not keep disk0s1s8")
check(b"disk0s1s7" in merged["rootful.conf"], "rootful.conf disk0s1s7")
check("loader.json" in merged, "nekoloader json merged")
check(b"static.palera.in/sileo.deb" in merged["loader.json"], "loader Sileo is rootful")
check(b"static.palera.in/zebra.deb" in merged["loader.json"], "loader Zebra is rootful")
check(b"rootless/sileo" not in merged["loader.json"], "loader has no rootless Sileo")
check("bootstrap.conf" in merged, "bootstrap conf merged")
check(b"iphoneos-arm" in merged["bootstrap.conf"], "bootstrap is rootful arch")
check(b"/Applications/Sileo.app" in merged["bootstrap.conf"], "bootstrap Sileo path is rootful")
check(merged["Dopamine"] != b"OLD_NEKO_BIN", "old NekoJB binary discarded")
check(merged["Library/MobileSubstrate/DynamicLibraries/Velora.dylib"] == b"NEW_DYLIB", "Velora overlay applied")
check("palera1n-VERSION" in merged, "palera1n VERSION present")
check(b"2.4" in merged["palera1n-VERSION"], "palera1n 2.4 version stamp")
check(b"rootfulMode" in merged["stamp.json"], "stamp points at Settings Rootful")
check(b"--rootful" in merged["rootful.conf"], "palera1n 2.4 flag name")
check("createFakeFS.sh" in merged, "rootful helper script at native name")
check(not any(k.startswith("velora-rootful/") for k in merged), "merge does not park an external velora-rootful layer")

fresh_donor = {
    "stamp.json": b'"version": "2.4"',
    "createFakeFS.sh": b"palera1n --rootful /dev/disk0s1s8\n",
    "loader.json": b'{"uri":"https://static.palera.in/rootless/sileo.deb","zebra":"https://static.palera.in/rootless/zebra.deb"}',
    "bootstrap.conf": b"sileo=/var/jb/Applications/Sileo.app\nstrap=/var/jb/.procursus_strapped\n",
}
fresh = pack.merge_layers(dopa_base, fresh_donor, {"Library/MobileSubstrate/DynamicLibraries/Velora.dylib": b"NEW_DYLIB"})
check(b"disk0s1s7" in fresh["createFakeFS.sh"], "current palera1n helper still moves FakeFS to s7")
check(b"disk0s1s8" not in fresh["createFakeFS.sh"], "s8 stripped from current helper")
check(b"rootless/sileo" not in fresh["loader.json"], "Nekoloader Sileo no longer rootless")
check(b"static.palera.in/sileo.deb" in fresh["loader.json"], "Nekoloader Sileo is rootful URL")
check(b"rootless/zebra" not in fresh["loader.json"], "Nekoloader Zebra no longer rootless")
check(b"/Applications/Sileo.app" in fresh["bootstrap.conf"], "bootstrap Sileo path is rootful")
check(b"/.procursus_strapped" in fresh["bootstrap.conf"] and b"/var/jb/.procursus_strapped" not in fresh["bootstrap.conf"], "bootstrap strap is rootful")

dopa_ipa = tmp / "Dopamine.ipa"
with zipfile.ZipFile(dopa_ipa, "w") as z:
    z.writestr("Payload/Dopamine.app/Info.plist", dopa_base["Info.plist"])
    z.writestr("Payload/Dopamine.app/Dopamine", dopa_base["Dopamine"])
    z.writestr("Payload/Dopamine.app/basebin.tar", make_tar({"basebin/hello.txt": b"hello"}))
    z.writestr("Payload/Dopamine.app/keep-dopa.txt", dopa_base["keep-dopa.txt"])
donor_ipa = tmp / "neko-donor.ipa"
with zipfile.ZipFile(donor_ipa, "w") as z:
    z.writestr("Payload/NekoJB.app/Info.plist", neko_donor["Info.plist"])
    z.writestr("Payload/NekoJB.app/Dopamine", neko_donor["Dopamine"])
    z.writestr("Payload/NekoJB.app/basebin.tar", neko_donor["basebin.tar"])
    z.writestr("Payload/NekoJB.app/fakefs.tar", neko_donor["fakefs.tar"])
    z.writestr("Payload/NekoJB.app/rootful.plist", neko_donor["rootful.plist"])
merged_ipa = tmp / "merged-fixed.ipa"
pack.pack_ipa(dopa_ipa, overlay, merged_ipa, donor_ipa=donor_ipa)
with zipfile.ZipFile(merged_ipa) as z:
    check("Payload/Dopamine.app/Dopamine" in z.namelist(), "packed IPA keeps Dopamine.app")
    check(z.read("Payload/Dopamine.app/Dopamine") == b"NEW_DOPA", "packed Dopamine binary intact")
    check("Payload/Dopamine.app/fakefs.tar" in z.namelist(), "packed IPA has fakefs at original name")
    check("Payload/Dopamine.app/palera1n-VERSION" in z.namelist(), "packed IPA has palera1n stamp")
    check(z.read("Payload/Dopamine.app/rootful.plist") == b"ROOTFUL_TOGGLE", "Rootful settings file at original name")
    check(
        z.read("Payload/Dopamine.app/Library/MobileSubstrate/DynamicLibraries/Velora.dylib") == b"NEW_DYLIB",
        "Velora still overwrites into Dopamine app",
    )

dev = (ROOT / "tweak/Velora/layout/Library/PreferenceLoader/Preferences/VeloraDevice.plist").read_text(encoding="utf-8")
check("rootfulMode" not in dev, "Device Settings has no Rootful key")
check("<string>Rootful</string>" not in dev, "Device Settings has no Rootful label")
check("merged into the latest Dopamine" not in dev, "Device Settings no longer describe the NekoJB merge")

# Nested nekoloader.tipa: unpack, rewrite Sileo/Zebra/preference/bootstrap, FakeFS s7.
check(pack.is_nested_loader_ipa("nekoloader.tipa") == 1, "nekoloader.tipa is nested loader")
check(pack.is_nested_loader_ipa("Payload/NekoLoader.app/nekoloader.tipa") == 1, "nested nekoloader path")
check(pack.is_nested_loader_ipa("palera1nLoader.ipa") == 1, "palera1nLoader.ipa is nested loader")
check(pack.is_nested_loader_ipa("loader.tipa") == 1, "loader.tipa is nested loader")
check(pack.is_nested_loader_ipa("random.zip") == 0, "random zip is not nested loader")
check(pack.is_rootful_rel("nekoloader.tipa") == 1, "nekoloader.tipa is rootful")
check(pack.is_rootful_rel("preferenceloader.deb") == 1, "preferenceloader is rootful")

rewritten = pack.rewrite_loader_text(
    "flag --fakefs disk0s1s8 "
    "https://static.palera.in/rootless/sileo.deb "
    "https://static.palera.in/rootless/zebra.deb "
    "https://static.palera.in/rootless/preferenceloader.deb "
    "https://static.palera.in/rootless/bootstrap.tar.zst "
    "/var/jb/Applications/Sileo.app /var/jb/Applications/Zebra.app "
    "/var/jb/Library/PreferenceLoader /var/jb/.procursus_strapped",
    arch=False,
)
check("disk0s1s7" in rewritten and "disk0s1s8" not in rewritten, "text rewrite FakeFS s7")
check("--rootful" in rewritten and "--fakefs" not in rewritten, "text rewrite --rootful")
check("rootless/sileo" not in rewritten, "text rewrite drops rootless Sileo")
check("rootless/zebra" not in rewritten, "text rewrite drops rootless Zebra")
check("rootless/preferenceloader" not in rewritten, "text rewrite drops rootless PreferenceLoader")
check("rootless/bootstrap" not in rewritten, "text rewrite drops rootless bootstrap")
check("/Applications/Sileo.app" in rewritten, "text rewrite Sileo path rootful")
check("/Library/PreferenceLoader" in rewritten, "text rewrite PreferenceLoader path rootful")
check("/.procursus_strapped" in rewritten and "/var/jb/.procursus_strapped" not in rewritten, "text rewrite strap rootful")
arch_fix = pack.rewrite_loader_text("arch=iphoneos-arm64e extra=iphoneos-arm64", arch=True)
check("iphoneos-arme" not in arch_fix, "arm64e does not become iphoneos-arme")
check("iphoneos-arm" in arch_fix and "iphoneos-arm64" not in arch_fix, "arch rewrite is rootful iphoneos-arm")

promoted = pack.rewrite_loader_json_value(
    {
        "rootless": {
            "dotfile": "/var/jb/.procursus_strapped",
            "bootstrap": "https://static.palera.in/rootless/bootstrap.tar.zst",
            "preferenceloader": "https://static.palera.in/rootless/preferenceloader.deb",
            "managers": [
                {"name": "Sileo", "uri": "https://static.palera.in/rootless/sileo.deb", "filePath": "/var/jb/Applications/Sileo.app"},
                {"name": "Zebra", "uri": "https://static.palera.in/rootless/zebra.deb", "filePath": "/var/jb/Applications/Zebra.app"},
            ],
        }
    }
)
check(isinstance(promoted, dict) and "rootful" in promoted, "JSON promotes rootless dict to rootful")
rootful_blob = json.dumps(promoted)
check("rootless/sileo" not in rootful_blob, "promoted JSON has no rootless Sileo")
check("static.palera.in/sileo.deb" in rootful_blob, "promoted JSON Sileo is rootful")
check("static.palera.in/zebra.deb" in rootful_blob, "promoted JSON Zebra is rootful")
check("static.palera.in/preferenceloader.deb" in rootful_blob, "promoted JSON PreferenceLoader is rootful")
check("static.palera.in/bootstrap.tar.zst" in rootful_blob, "promoted JSON bootstrap is rootful")
check("/Applications/Sileo.app" in rootful_blob, "promoted JSON Sileo path is rootful")
check("/var/jb/.procursus_strapped" not in rootful_blob, "promoted JSON strap is rootful")


def make_nested_tipa() -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr(
            "Payload/NekoLoader.app/Info.plist",
            b'<?xml version="1.0"?><plist><dict><key>CFBundleIdentifier</key><string>in.palera.palera1nLoader</string></dict></plist>',
        )
        z.writestr(
            "Payload/NekoLoader.app/loader.json",
            json.dumps(
                {
                    "rootless": {
                        "dotfile": "/var/jb/.procursus_strapped",
                        "bootstrap": "https://static.palera.in/rootless/bootstrap.tar.zst",
                        "preferenceloader": "https://static.palera.in/rootless/preferenceloader.deb",
                        "preference": "/var/jb/Library/PreferenceLoader",
                        "managers": [
                            {
                                "name": "Sileo",
                                "uri": "https://static.palera.in/rootless/sileo.deb",
                                "filePath": "/var/jb/Applications/Sileo.app",
                            },
                            {
                                "name": "Zebra",
                                "uri": "https://static.palera.in/rootless/zebra.deb",
                                "filePath": "/var/jb/Applications/Zebra.app",
                            },
                        ],
                    }
                }
            ).encode()
            + b"\n",
        )
        z.writestr(
            "Payload/NekoLoader.app/bootstrap.conf",
            b"arch=iphoneos-arm64\n"
            b"sileo=https://static.palera.in/rootless/sileo.deb\n"
            b"zebra=https://static.palera.in/rootless/zebra.deb\n"
            b"preferenceloader=https://static.palera.in/rootless/preferenceloader.deb\n"
            b"bootstrap=https://static.palera.in/rootless/bootstrap.tar.zst\n"
            b"sileo_path=/var/jb/Applications/Sileo.app\n"
            b"preference=/var/jb/Library/PreferenceLoader\n"
            b"strap=/var/jb/.procursus_strapped\n"
            b"disk=disk0s1s8\n"
            b"flag=--fakefs\n",
        )
        z.writestr("Payload/NekoLoader.app/config.json", b'{"fakefs":"disk0s1s8","flag":"--fakefs"}\n')
    return buf.getvalue()


nested_tipa = make_nested_tipa()
patched_tipa = pack.refresh_old_rootful_bytes("nekoloader.tipa", nested_tipa)
check(patched_tipa[:2] == b"PK", "patched nekoloader.tipa stays a zip")
check(patched_tipa != nested_tipa, "nested tipa bytes changed")
with zipfile.ZipFile(io.BytesIO(patched_tipa)) as z:
    inner_names = set(z.namelist())
    loader_json = z.read("Payload/NekoLoader.app/loader.json").decode("utf-8")
    boot_conf = z.read("Payload/NekoLoader.app/bootstrap.conf").decode("utf-8")
    cfg = z.read("Payload/NekoLoader.app/config.json").decode("utf-8")
check("Payload/NekoLoader.app/loader.json" in inner_names, "nested tipa keeps loader.json")
check("rootless/sileo" not in loader_json, "nested tipa loader has no rootless Sileo")
check("rootless/zebra" not in loader_json, "nested tipa loader has no rootless Zebra")
check("rootless/preferenceloader" not in loader_json, "nested tipa loader has no rootless PreferenceLoader")
check("rootless/bootstrap" not in loader_json, "nested tipa loader has no rootless bootstrap")
check("https://static.palera.in/sileo.deb" in loader_json, "nested tipa Sileo is rootful")
check("https://static.palera.in/zebra.deb" in loader_json, "nested tipa Zebra is rootful")
check("https://static.palera.in/preferenceloader.deb" in loader_json, "nested tipa PreferenceLoader is rootful")
check("https://static.palera.in/bootstrap.tar.zst" in loader_json, "nested tipa bootstrap is rootful")
check("/Applications/Sileo.app" in loader_json, "nested tipa Sileo path is rootful")
check("/Library/PreferenceLoader" in loader_json, "nested tipa PreferenceLoader path is rootful")
check("/.procursus_strapped" in loader_json and "/var/jb/.procursus_strapped" not in loader_json, "nested tipa strap is rootful")
check("disk0s1s7" in boot_conf and "disk0s1s8" not in boot_conf, "nested tipa bootstrap FakeFS s7")
check("--rootful" in boot_conf and "--fakefs" not in boot_conf, "nested tipa bootstrap --rootful")
check("rootless/" not in boot_conf, "nested tipa bootstrap.conf has no rootless URLs")
check("/Applications/Sileo.app" in boot_conf, "nested tipa bootstrap Sileo path is rootful")
check("/Library/PreferenceLoader" in boot_conf, "nested tipa bootstrap PreferenceLoader path is rootful")
check("disk0s1s7" in cfg and "disk0s1s8" not in cfg, "nested tipa config FakeFS s7")

# merge_layers with only the NekoJB base (no separate donor) still unpacks the tipa.
solo = pack.merge_layers(
    {"nekoloader.tipa": nested_tipa, "keep.txt": b"stay"},
    None,
    {"Library/MobileSubstrate/DynamicLibraries/Velora.dylib": b"NEW_DYLIB"},
)
check(solo["keep.txt"] == b"stay", "solo merge keeps unrelated files")
with zipfile.ZipFile(io.BytesIO(solo["nekoloader.tipa"])) as z:
    solo_loader = z.read("Payload/NekoLoader.app/loader.json")
check(b"rootless/sileo" not in solo_loader, "solo merge nested tipa Sileo is rootful")
check(b"static.palera.in/preferenceloader.deb" in solo_loader, "solo merge nested tipa PreferenceLoader is rootful")

# pack_ipa with NekoJB as the only IPA still rewrites nested nekoloader.tipa.
neko_only = tmp / "neko-with-tipa.ipa"
with zipfile.ZipFile(neko_only, "w") as z:
    z.writestr("Payload/NekoJB.app/Info.plist", b'<?xml version="1.0"?><plist><dict></dict></plist>')
    z.writestr("Payload/NekoJB.app/NekoJB", b"NEKOBIN")
    z.writestr("Payload/NekoJB.app/nekoloader.tipa", nested_tipa)
    z.writestr("Payload/NekoJB.app/createFakeFS.sh", b"palera1n --fakefs /dev/disk0s1s8\n")
neko_only_out = tmp / "neko-with-tipa-fixed.ipa"
pack.pack_ipa(neko_only, overlay, neko_only_out)
with zipfile.ZipFile(neko_only_out) as z:
    packed_tipa = z.read("Payload/NekoJB.app/nekoloader.tipa")
    packed_helper = z.read("Payload/NekoJB.app/createFakeFS.sh")
check(packed_tipa[:2] == b"PK", "packed nested tipa is still a zip")
with zipfile.ZipFile(io.BytesIO(packed_tipa)) as z:
    packed_loader = z.read("Payload/NekoLoader.app/loader.json").decode("utf-8")
    packed_boot = z.read("Payload/NekoLoader.app/bootstrap.conf").decode("utf-8")
check("rootless/" not in packed_loader, "packed nested tipa loader has no rootless leftover")
check("https://static.palera.in/sileo.deb" in packed_loader, "packed nested tipa Sileo rootful")
check("https://static.palera.in/zebra.deb" in packed_loader, "packed nested tipa Zebra rootful")
check("https://static.palera.in/preferenceloader.deb" in packed_loader, "packed nested tipa PreferenceLoader rootful")
check("https://static.palera.in/bootstrap.tar.zst" in packed_loader, "packed nested tipa bootstrap rootful")
check("/Applications/Sileo.app" in packed_loader, "packed nested tipa Sileo path rootful")
check("/Library/PreferenceLoader" in packed_loader, "packed nested tipa PreferenceLoader path rootful")
check("rootless/" not in packed_boot, "packed nested tipa bootstrap has no rootless leftover")
check("disk0s1s7" in packed_boot and "disk0s1s8" not in packed_boot, "packed nested tipa FakeFS s7")
check(b"disk0s1s7" in packed_helper and b"disk0s1s8" not in packed_helper, "packed helper FakeFS s7")

# Dopamine base + NekoJB donor carrying nekoloader.tipa.
donor_tipa_ipa = tmp / "neko-donor-tipa.ipa"
with zipfile.ZipFile(donor_tipa_ipa, "w") as z:
    z.writestr("Payload/NekoJB.app/Info.plist", neko_donor["Info.plist"])
    z.writestr("Payload/NekoJB.app/Dopamine", neko_donor["Dopamine"])
    z.writestr("Payload/NekoJB.app/nekoloader.tipa", nested_tipa)
    z.writestr("Payload/NekoJB.app/rootful.plist", neko_donor["rootful.plist"])
merged_tipa_ipa = tmp / "merged-tipa.ipa"
pack.pack_ipa(dopa_ipa, overlay, merged_tipa_ipa, donor_ipa=donor_tipa_ipa)
with zipfile.ZipFile(merged_tipa_ipa) as z:
    check(z.read("Payload/Dopamine.app/Dopamine") == b"NEW_DOPA", "donor-tipa merge keeps Dopamine")
    merged_nested = z.read("Payload/Dopamine.app/nekoloader.tipa")
with zipfile.ZipFile(io.BytesIO(merged_nested)) as z:
    merged_loader = z.read("Payload/NekoLoader.app/loader.json").decode("utf-8")
check("rootless/" not in merged_loader, "donor nested tipa has no rootless leftover")
check("https://static.palera.in/preferenceloader.deb" in merged_loader, "donor nested tipa PreferenceLoader rootful")

# CMD overlay + EncodedCommand stay within the Windows limit.
ps = pack._powershell_packer()
check("Fix-Tree" in ps, "cmd PowerShell unpacks nested tipa")
check("nekoloader" in ps, "cmd PowerShell matches nekoloader.tipa")
check("preferenceloader" in ps, "cmd PowerShell rewrites PreferenceLoader")
check("disk0s1s7" in ps, "cmd PowerShell FakeFS s7")
check("disk0s1s8" in ps, "cmd PowerShell still searches s8")
encoded = __import__("base64").b64encode(ps.encode("utf-16le"))
check(len(encoded) < 32767, "EncodedCommand under 32767")
check(b"preferenceloader" in ov.get("loader.json", b""), "cmd overlay loader.json has PreferenceLoader")
check(b"static.palera.in/preferenceloader.deb" in ov.get("bootstrap.conf", b""), "cmd overlay bootstrap PreferenceLoader")
check(b"disk0s1s7" in ov.get("createFakeFS.sh", b""), "cmd overlay helper FakeFS s7")
check(b"disk0s1s8" not in ov.get("createFakeFS.sh", b""), "cmd overlay helper has no s8")

if fail:
    print(fail, "failed")
    sys.exit(1)
print("ok")
