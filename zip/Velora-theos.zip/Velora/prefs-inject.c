/* Preference bundle stub.

   Settings classes live in velora-menu.c (injected into Preferences).
   A constructor here used to register VeloraRootListController with
   specifiers that load Root.plist from the wrong bundle path — that
   yields a black/empty Velora pane. Do not run at load. */

void velora_prefs_init(void) {
}
