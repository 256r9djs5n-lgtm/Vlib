/* Velora injector. Loaded by Substrate/ElleKit. */
#include "velora-proc.h"

void *dlopen(const char *path, int mode);
void *dlsym(void *handle, const char *symbol);
const char *getprogname(void);
#define RTLD_LAZY 1
#define RTLD_NOLOAD 0x10
#define RTLD_DEFAULT ((void *)-2)

typedef struct objc_class *Class;
typedef struct objc_object *id;
typedef struct objc_selector *SEL;
typedef long NSInteger;

extern Class objc_getClass(const char *name);
extern Class object_getClass(id obj);
extern SEL sel_registerName(const char *name);
extern void objc_msgSend(void);
extern void *class_getInstanceMethod(Class cls, SEL name);
extern void *objc_autoreleasePoolPush(void);
extern void objc_autoreleasePoolPop(void *pool);
extern Class objc_allocateClassPair(Class super, const char *name, unsigned long extra);
extern void objc_registerClassPair(Class cls);
extern int class_addMethod(Class cls, SEL name, void *imp, const char *types);
extern void *CFNotificationCenterGetDarwinNotifyCenter(void);
extern void CFNotificationCenterAddObserver(void *center, const void *observer, void *cb, const void *name, const void *object, int suspension);
extern void _dyld_register_func_for_add_image(void (*fn)(const void *, long));

typedef void (*MSHookMessageEx_t)(Class cls, SEL sel, void *imp, void **orig);
typedef void (*MSHookFunction_t)(void *symbol, void *replace, void **result);
static MSHookMessageEx_t pMSHookMessageEx;
static MSHookFunction_t pMSHookFunction;
static NSInteger max_fps_cached = -1;
static int gPanelQuery;
static int gFpsOn = 1;
static int gPromotion = 1;
static double gCustomFPS;
static int gFpsHooks;
static int gPrefsLoaded;

typedef struct {
	float minimum;
	float preferred;
	float maximum;
} CAFrameRateRange;

static id nsstr(const char *c) {
	Class C = objc_getClass("NSString");
	if (!C)
		return 0;
	id (*f)(Class, SEL, const char *) = (id(*)(Class, SEL, const char *))objc_msgSend;
	return f(C, sel_registerName("stringWithUTF8String:"), c);
}

static id cls0(Class c, const char *sel) {
	if (!c)
		return 0;
	id (*f)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	return f(c, sel_registerName(sel));
}

static id msg0(id obj, const char *sel) {
	if (!obj)
		return 0;
	id (*f)(id, SEL) = (id(*)(id, SEL))objc_msgSend;
	return f(obj, sel_registerName(sel));
}

static id msg1(id obj, const char *sel, id a) {
	if (!obj)
		return 0;
	id (*f)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
	return f(obj, sel_registerName(sel), a);
}

static const char *utf8(id s) {
	if (!s)
		return "";
	const char *(*f)(id, SEL) = (const char *(*)(id, SEL))objc_msgSend;
	const char *v = f(s, sel_registerName("UTF8String"));
	return v ? v : "";
}

static id main_bundle(void) {
	return cls0(objc_getClass("NSBundle"), "mainBundle");
}

static const char *current_bid_c(void) {
	id main = main_bundle();
	id bid = main ? msg0(main, "bundleIdentifier") : 0;
	return utf8(bid);
}

static const char *current_path_c(void) {
	id main = main_bundle();
	id path = main ? msg0(main, "bundlePath") : 0;
	return utf8(path);
}

static id suite_defaults(const char *suite) {
	Class C = objc_getClass("NSUserDefaults");
	if (!C)
		return 0;
	id (*alloc)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	id obj = alloc(C, sel_registerName("alloc"));
	id (*init)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
	return init(obj, sel_registerName("initWithSuiteName:"), nsstr(suite));
}

static int bundle_in_list(id defs, const char *key, const char *bid) {
	if (!defs || !bid || !bid[0])
		return 0;
	id (*arrfn)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
	id arr = arrfn(defs, sel_registerName("arrayForKey:"), nsstr(key));
	if (!arr)
		return 0;
	unsigned char (*contains)(id, SEL, id) = (unsigned char (*)(id, SEL, id))objc_msgSend;
	return contains(arr, sel_registerName("containsObject:"), nsstr(bid)) ? 1 : 0;
}

static int should_enable(void) {
	const char *bid = current_bid_c();
	if (velora_is_springboard_bid(bid) || velora_skip_inject(bid, current_path_c()))
		return 0;
	id uk = suite_defaults("com.apple.UIKit");
	if (!uk)
		return 1;
	id (*strfn)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
	id mode = strfn(uk, sel_registerName("stringForKey:"), nsstr("VeloraAppMode"));
	const char *m = "all";
	if (mode) {
		const char *s = utf8(mode);
		if (s)
			m = s;
	}
	if (m[0] == 'e')
		return bundle_in_list(uk, "VeloraEnabledApps", bid);
	if (m[0] == 'b' || m[0] == 'd')
		return !bundle_in_list(uk, "VeloraDisabledApps", bid) && !bundle_in_list(uk, "VeloraBlacklistedApps", bid);
	return 1;
}

static NSInteger panel_max(void) {
	if (max_fps_cached > 0)
		return max_fps_cached;
	Class UIScreen = objc_getClass("UIScreen");
	if (!UIScreen)
		return 60;
	id screen = cls0(UIScreen, "mainScreen");
	if (!screen)
		return 60;
	gPanelQuery = 1;
	NSInteger (*msg_int)(id, SEL) = (NSInteger(*)(id, SEL))objc_msgSend;
	NSInteger v = msg_int(screen, sel_registerName("maximumFramesPerSecond"));
	gPanelQuery = 0;
	if (v < 1)
		v = 60;
	max_fps_cached = v;
	return v;
}

static int fps_responds(id obj, const char *sel) {
	if (!obj)
		return 0;
	unsigned char (*r)(id, SEL, SEL) = (unsigned char (*)(id, SEL, SEL))objc_msgSend;
	return r(obj, sel_registerName("respondsToSelector:"), sel_registerName(sel)) ? 1 : 0;
}

static int pref_bool(id defs, const char *key, int fb) {
	if (!defs)
		return fb;
	id (*gf)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
	id v = gf(defs, sel_registerName("objectForKey:"), nsstr(key));
	if (!v)
		return fb;
	unsigned char (*b)(id, SEL) = (unsigned char (*)(id, SEL))objc_msgSend;
	return b(v, sel_registerName("boolValue")) ? 1 : 0;
}

static double pref_double(id defs, const char *key, double fb) {
	if (!defs)
		return fb;
	id (*gf)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
	id v = gf(defs, sel_registerName("objectForKey:"), nsstr(key));
	if (!v)
		return fb;
	double (*d)(id, SEL) = (double (*)(id, SEL))objc_msgSend;
	return d(v, sel_registerName("doubleValue"));
}

static void load_fps_prefs(void) {
	id hz = suite_defaults("com.velora.hz");
	id uk = suite_defaults("com.apple.UIKit");
	id (*dcf)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
	Class D = objc_getClass("NSDictionary");
	id file = 0;
	if (D) {
		const char *paths[] = {
			"/var/mobile/Library/Preferences/com.velora.hz.plist",
			"/var/jb/var/mobile/Library/Preferences/com.velora.hz.plist",
			"/var/jb/mnt/var/mobile/Library/Preferences/com.velora.hz.plist",
			0,
		};
		for (int i = 0; paths[i] && !file; i++)
			file = dcf(D, sel_registerName("dictionaryWithContentsOfFile:"), nsstr(paths[i]));
	}
	if (file) {
		gFpsOn = pref_bool(file, "enabled", 1);
		gPromotion = pref_bool(file, "promotion", 1);
		gCustomFPS = pref_double(file, "customFPS", 0);
	} else {
		gFpsOn = pref_bool(hz, "enabled", pref_bool(uk, "enabled", 1));
		gPromotion = pref_bool(hz, "promotion", pref_bool(uk, "promotion", 1));
		gCustomFPS = pref_double(hz, "customFPS", pref_double(uk, "customFPS", 0));
	}
	if (gCustomFPS < 0)
		gCustomFPS = 0;
	if (gCustomFPS > 120)
		gCustomFPS = 120;
	gPrefsLoaded = 1;
}

static int fps_active(void) {
	if (!gFpsOn)
		return 0;
	if (!gPrefsLoaded)
		return 1;
	return should_enable();
}

static NSInteger desired_fps(void) {
	if (!fps_active())
		return 0;
	NSInteger panel = panel_max();
	NSInteger cap = gPromotion ? panel : (panel < 60 ? panel : 60);
	NSInteger t = 0;
	if (gCustomFPS >= 0.5)
		t = (NSInteger)(gCustomFPS + 0.5);
	if (t < 1)
		t = cap;
	if (t > cap)
		t = cap;
	return t;
}

static int native_max(void) {
	NSInteger d = desired_fps();
	return d > 0 && d >= panel_max();
}

static NSInteger frame_interval(void) {
	NSInteger d = desired_fps();
	if (d < 1)
		return 1;
	NSInteger iv = panel_max() / d;
	return iv < 1 ? 1 : iv;
}

static double frame_duration(double fallback) {
	NSInteger d = desired_fps();
	return d > 0 ? (1.0 / (double)d) : fallback;
}

static void hook_msg(const char *cls_name, const char *sel_name, void *imp, void **orig) {
	if (!pMSHookMessageEx)
		return;
	Class cls = objc_getClass(cls_name);
	if (!cls)
		return;
	SEL sel = sel_registerName(sel_name);
	if (!class_getInstanceMethod(cls, sel))
		return;
	pMSHookMessageEx(cls, sel, imp, orig);
}

static void hook_cls(const char *cls_name, const char *sel_name, void *imp, void **orig) {
	if (!pMSHookMessageEx)
		return;
	Class cls = objc_getClass(cls_name);
	if (!cls)
		return;
	Class meta = object_getClass((id)cls);
	if (!meta)
		return;
	SEL sel = sel_registerName(sel_name);
	if (!class_getInstanceMethod(meta, sel))
		return;
	pMSHookMessageEx(meta, sel, imp, orig);
}

static void apply_range(id link, float lo, float pref, float hi) {
	if (!link || !fps_responds(link, "setPreferredFrameRateRange:"))
		return;
	CAFrameRateRange r;
	r.minimum = lo;
	r.preferred = pref;
	r.maximum = hi;
	void (*f)(id, SEL, CAFrameRateRange) = (void (*)(id, SEL, CAFrameRateRange))objc_msgSend;
	f(link, sel_registerName("setPreferredFrameRateRange:"), r);
}

static void (*orig_setFrameInterval)(id, SEL, NSInteger);
static void (*orig_setPreferredFPS)(id, SEL, NSInteger);
static void (*orig_setRange)(id, SEL, CAFrameRateRange);

static void apply_link(id link) {
	if (!link || !fps_active())
		return;
	NSInteger d = desired_fps();
	if (d < 1)
		return;
	if (orig_setFrameInterval)
		orig_setFrameInterval(link, sel_registerName("setFrameInterval:"), frame_interval());
	else if (fps_responds(link, "setFrameInterval:")) {
		void (*f)(id, SEL, NSInteger) = (void (*)(id, SEL, NSInteger))objc_msgSend;
		f(link, sel_registerName("setFrameInterval:"), frame_interval());
	}
	int nat = native_max();
	if (orig_setPreferredFPS)
		orig_setPreferredFPS(link, sel_registerName("setPreferredFramesPerSecond:"), nat ? 0 : d);
	else if (fps_responds(link, "setPreferredFramesPerSecond:")) {
		void (*f)(id, SEL, NSInteger) = (void (*)(id, SEL, NSInteger))objc_msgSend;
		f(link, sel_registerName("setPreferredFramesPerSecond:"), nat ? 0 : d);
	}
	if (nat)
		apply_range(link, 30.f, (float)d, (float)d);
	else
		apply_range(link, (float)d, (float)d, (float)d);
}

static void hook_setFrameInterval(id self, SEL sel, NSInteger interval) {
	(void)sel;
	if (!fps_active()) {
		if (orig_setFrameInterval)
			orig_setFrameInterval(self, sel, interval);
		return;
	}
	if (orig_setFrameInterval)
		orig_setFrameInterval(self, sel, frame_interval());
	if (orig_setPreferredFPS)
		orig_setPreferredFPS(self, sel_registerName("setPreferredFramesPerSecond:"), native_max() ? 0 : desired_fps());
}

static void hook_setPreferredFPS(id self, SEL sel, NSInteger fps) {
	(void)fps;
	if (!fps_active()) {
		if (orig_setPreferredFPS)
			orig_setPreferredFPS(self, sel, fps);
		return;
	}
	if (orig_setPreferredFPS)
		orig_setPreferredFPS(self, sel, native_max() ? 0 : desired_fps());
}

static NSInteger (*orig_getPreferredFPS)(id, SEL);
static NSInteger hook_getPreferredFPS(id self, SEL sel) {
	if (!fps_active())
		return orig_getPreferredFPS ? orig_getPreferredFPS(self, sel) : 0;
	return native_max() ? 0 : desired_fps();
}

static void hook_setRange(id self, SEL sel, CAFrameRateRange range) {
	if (!fps_active()) {
		if (orig_setRange)
			orig_setRange(self, sel, range);
		return;
	}
	NSInteger d = desired_fps();
	if (d < 1) {
		if (orig_setRange)
			orig_setRange(self, sel, range);
		return;
	}
	if (native_max()) {
		range.minimum = 30;
		range.preferred = (float)d;
		range.maximum = (float)d;
	} else {
		range.minimum = (float)d;
		range.preferred = (float)d;
		range.maximum = (float)d;
	}
	if (orig_setRange)
		orig_setRange(self, sel, range);
}

static id (*orig_dl_create)(Class, SEL, id, SEL);
static id hook_dl_create(Class cls, SEL sel, id target, SEL tsel) {
	id link = orig_dl_create ? orig_dl_create(cls, sel, target, tsel) : 0;
	apply_link(link);
	return link;
}

static void (*orig_addRL)(id, SEL, id, id);
static void hook_addRL(id self, SEL sel, id loop, id mode) {
	if (orig_addRL)
		orig_addRL(self, sel, loop, mode);
	apply_link(self);
}

static NSInteger (*orig_ui_max)(id, SEL);
static NSInteger hook_ui_max(id self, SEL sel) {
	NSInteger orig = orig_ui_max ? orig_ui_max(self, sel) : 60;
	if (gPanelQuery || !fps_active())
		return orig;
	NSInteger d = desired_fps();
	return d > orig ? d : orig;
}

static NSInteger (*orig_ca_max)(id, SEL);
static NSInteger hook_ca_max(id self, SEL sel) {
	NSInteger orig = orig_ca_max ? orig_ca_max(self, sel) : 60;
	if (!fps_active())
		return orig;
	NSInteger d = desired_fps();
	return d > orig ? d : orig;
}

static NSInteger (*orig_ca_maxfps)(id, SEL);
static NSInteger hook_ca_maxfps(id self, SEL sel) {
	NSInteger orig = orig_ca_maxfps ? orig_ca_maxfps(self, sel) : 60;
	if (!fps_active())
		return orig;
	NSInteger d = desired_fps();
	return d > orig ? d : orig;
}

static void (*orig_set_ca_maxfps)(id, SEL, NSInteger);
static void hook_set_ca_maxfps(id self, SEL sel, NSInteger fps) {
	if (orig_set_ca_maxfps)
		orig_set_ca_maxfps(self, sel, fps_active() ? desired_fps() : fps);
}

static unsigned long (*orig_drawable_count)(id, SEL);
static unsigned long hook_drawable_count(id self, SEL sel) {
	if (fps_active())
		return 2;
	return orig_drawable_count ? orig_drawable_count(self, sel) : 3;
}

static void (*orig_set_drawable_count)(id, SEL, unsigned long);
static void hook_set_drawable_count(id self, SEL sel, unsigned long count) {
	if (orig_set_drawable_count)
		orig_set_drawable_count(self, sel, fps_active() ? 2 : count);
}

static double (*orig_min_frame)(id, SEL);
static double hook_min_frame(id self, SEL sel) {
	double orig = orig_min_frame ? orig_min_frame(self, sel) : 0;
	if (!fps_active())
		return orig;
	return frame_duration(orig);
}

static void (*orig_metal_fps)(id, SEL, float);
static void hook_metal_fps(id self, SEL sel, float fps) {
	if (!fps_active()) {
		if (orig_metal_fps)
			orig_metal_fps(self, sel, fps);
		return;
	}
	if (orig_metal_fps)
		orig_metal_fps(self, sel, (float)(native_max() ? 0 : desired_fps()));
}

static unsigned char (*orig_allow_timeout)(id, SEL);
static unsigned char hook_allow_timeout(id self, SEL sel) {
	if (fps_active())
		return 0;
	return orig_allow_timeout ? orig_allow_timeout(self, sel) : 1;
}

static void (*orig_set_allow_timeout)(id, SEL, unsigned char);
static void hook_set_allow_timeout(id self, SEL sel, unsigned char v) {
	if (orig_set_allow_timeout)
		orig_set_allow_timeout(self, sel, fps_active() ? 0 : v);
}

static void (*orig_present_min)(id, SEL, double);
static void hook_present_min(id self, SEL sel, double duration) {
	if (orig_present_min)
		orig_present_min(self, sel, fps_active() ? frame_duration(duration) : duration);
}

static void (*orig_present_min2)(id, SEL, double);
static void hook_present_min2(id self, SEL sel, double duration) {
	if (orig_present_min2)
		orig_present_min2(self, sel, fps_active() ? frame_duration(duration) : duration);
}

static void (*orig_present_draw)(id, SEL, id, double);
static void hook_present_draw(id self, SEL sel, id drawable, double duration) {
	if (orig_present_draw)
		orig_present_draw(self, sel, drawable, fps_active() ? frame_duration(duration) : duration);
}

static void (*orig_present_draw2)(id, SEL, id, double);
static void hook_present_draw2(id self, SEL sel, id drawable, double duration) {
	if (orig_present_draw2)
		orig_present_draw2(self, sel, drawable, fps_active() ? frame_duration(duration) : duration);
}

static NSInteger (*orig_sk_get)(id, SEL);
static NSInteger hook_sk_get(id self, SEL sel) {
	if (!fps_active())
		return orig_sk_get ? orig_sk_get(self, sel) : 0;
	return native_max() ? 0 : desired_fps();
}

static void (*orig_sk_set)(id, SEL, NSInteger);
static void hook_sk_set(id self, SEL sel, NSInteger fps) {
	if (!fps_active()) {
		if (orig_sk_set)
			orig_sk_set(self, sel, fps);
		return;
	}
	if (orig_sk_set)
		orig_sk_set(self, sel, native_max() ? 0 : desired_fps());
}

static NSInteger (*orig_glk_get)(id, SEL);
static NSInteger hook_glk_get(id self, SEL sel) {
	if (!fps_active())
		return orig_glk_get ? orig_glk_get(self, sel) : 0;
	return desired_fps();
}

static void (*orig_glk_set)(id, SEL, NSInteger);
static void hook_glk_set(id self, SEL sel, NSInteger fps) {
	if (!fps_active()) {
		if (orig_glk_set)
			orig_glk_set(self, sel, fps);
		return;
	}
	if (orig_glk_set)
		orig_glk_set(self, sel, desired_fps());
}

static void (*orig_cc_set)(id, SEL, double);
static void hook_cc_set(id self, SEL sel, double interval) {
	if (!fps_active()) {
		if (orig_cc_set)
			orig_cc_set(self, sel, interval);
		return;
	}
	NSInteger d = desired_fps();
	if (orig_cc_set)
		orig_cc_set(self, sel, d > 0 ? 1.0 / (double)d : interval);
}

static double (*orig_cc_get)(id, SEL);
static double hook_cc_get(id self, SEL sel) {
	if (!fps_active())
		return orig_cc_get ? orig_cc_get(self, sel) : 0;
	NSInteger d = desired_fps();
	return d > 0 ? 1.0 / (double)d : (orig_cc_get ? orig_cc_get(self, sel) : 0);
}

static void (*orig_view_range)(id, SEL, CAFrameRateRange);
static void hook_view_range(id self, SEL sel, CAFrameRateRange range) {
	if (!fps_active()) {
		if (orig_view_range)
			orig_view_range(self, sel, range);
		return;
	}
	NSInteger d = desired_fps();
	if (d < 1) {
		if (orig_view_range)
			orig_view_range(self, sel, range);
		return;
	}
	if (native_max()) {
		range.minimum = 30;
		range.preferred = (float)d;
		range.maximum = (float)d;
	} else {
		range.minimum = (float)d;
		range.preferred = (float)d;
		range.maximum = (float)d;
	}
	if (orig_view_range)
		orig_view_range(self, sel, range);
}

static void (*orig_unity_fps)(int);
static int unity_fps_val(void);
static void hook_unity_fps(int fps) {
	if (fps_active() && orig_unity_fps) {
		orig_unity_fps(unity_fps_val());
		return;
	}
	if (orig_unity_fps)
		orig_unity_fps(fps);
}

static void (*orig_unity_vsync)(int);
static void hook_unity_vsync(int count) {
	if (fps_active() && orig_unity_vsync) {
		orig_unity_vsync(0);
		return;
	}
	if (orig_unity_vsync)
		orig_unity_vsync(count);
}

static void (*orig_icall_fps)(int);
static void hook_icall_fps(int fps) {
	if (fps_active() && orig_icall_fps) {
		orig_icall_fps(unity_fps_val());
		return;
	}
	if (orig_icall_fps)
		orig_icall_fps(fps);
}

static void (*orig_icall_vsync)(int);
static void hook_icall_vsync(int count) {
	if (fps_active() && orig_icall_vsync) {
		orig_icall_vsync(0);
		return;
	}
	if (orig_icall_vsync)
		orig_icall_vsync(count);
}

extern unsigned int _dyld_image_count(void);
extern const char *_dyld_get_image_name(unsigned int i);
extern const void *_dyld_get_image_header(unsigned int i);
extern long _dyld_get_image_vmaddr_slide(unsigned int i);

static int unity_fps_val(void) {
	NSInteger d = desired_fps();
	if (d < 1)
		d = panel_max();
	if (d < 30)
		d = 60;
	if (d > 120)
		d = 120;
	return (int)d;
}

static void force_unity_fps(void);
static void hook_unity(void);
static void install_class_fps_hooks(void);

static void hook_unity_sym_addr(void *sym, void *repl, void **orig) {
	if (!sym || *orig)
		return;
	if (!pMSHookFunction)
		pMSHookFunction = (MSHookFunction_t)dlsym(RTLD_DEFAULT, "MSHookFunction");
	if (pMSHookFunction)
		pMSHookFunction(sym, repl, orig);
}

static void try_hook_image_sym(const char *image, const char *name, void *repl, void **orig) {
	if (*orig)
		return;
	void *h = 0;
	if (image)
		h = dlopen(image, RTLD_NOLOAD | RTLD_LAZY);
	void *sym = dlsym(h ? h : RTLD_DEFAULT, name);
	if (!sym) {
		char buf[96];
		int n = 0;
		buf[n++] = '_';
		const char *p = name;
		while (*p && n < 94)
			buf[n++] = *p++;
		buf[n] = 0;
		sym = dlsym(h ? h : RTLD_DEFAULT, buf);
	}
	hook_unity_sym_addr(sym, repl, orig);
}

static int is_adrp_ins(unsigned int ins) {
	return (ins & 0x9F000000u) == 0x90000000u;
}

static int is_add64_ins(unsigned int ins) {
	return (ins & 0xFF800000u) == 0x91000000u;
}

static int is_b_ins(unsigned int ins) {
	return (ins & 0xFC000000u) == 0x14000000u;
}

static unsigned long adrp_addr(unsigned int ins, unsigned long pc) {
	unsigned int immlo = (ins >> 29) & 3u;
	unsigned int immhi = (ins >> 5) & 0x7FFFFu;
	int imm = (int)((immhi << 2) | immlo);
	imm <<= 11;
	imm >>= 11;
	long value = ((long)imm) << 12;
	return (pc & ~0xfffUL) + (unsigned long)value;
}

static unsigned long add_imm12(unsigned int ins) {
	unsigned long imm12 = (ins >> 10) & 0xFFFu;
	if (ins & 0x400000u)
		imm12 <<= 12;
	return imm12;
}

static unsigned long b_addr(unsigned int ins, unsigned long pc) {
	int imm26 = (int)(ins & 0x03FFFFFFu);
	imm26 <<= 6;
	imm26 >>= 6;
	return pc + ((unsigned long)((long)imm26 << 2));
}

static const char *find_bytes(const char *hay, unsigned long n, const char *needle) {
	unsigned long m = 0;
	if (!hay || !needle)
		return 0;
	while (needle[m])
		m++;
	if (!m || n < m)
		return 0;
	for (unsigned long i = 0; i + m <= n; i++) {
		unsigned long j = 0;
		while (j < m && hay[i + j] == needle[j])
			j++;
		if (j == m)
			return hay + i;
	}
	return 0;
}

struct velora_mh64 {
	unsigned int magic, cputype, cpusubtype, filetype, ncmds, sizeofcmds, flags, reserved;
};
struct velora_lc {
	unsigned int cmd, cmdsize;
};
struct velora_seg64 {
	unsigned int cmd, cmdsize;
	char segname[16];
	unsigned long vmaddr, vmsize, fileoff, filesize;
	unsigned int maxprot, initprot, nsects, flags;
};
struct velora_sec64 {
	char sectname[16], segname[16];
	unsigned long addr, size;
	unsigned int offset, align, reloff, nreloc, flags, reserved1, reserved2, reserved3;
};

static void *sect_ptr(const void *mh, long slide, const char *seg, const char *sect, unsigned long *out_size, unsigned long *out_addr) {
	const struct velora_mh64 *h = (const struct velora_mh64 *)mh;
	if (!h || h->magic != 0xfeedfacfu)
		return 0;
	const unsigned char *p = (const unsigned char *)mh + sizeof(struct velora_mh64);
	unsigned int i, j;
	for (i = 0; i < h->ncmds; i++) {
		const struct velora_lc *lc = (const struct velora_lc *)p;
		if (lc->cmd == 0x19) {
			const struct velora_seg64 *sg = (const struct velora_seg64 *)p;
			int match = 1;
			const char *a = sg->segname, *b = seg;
			while (*b) {
				if (*a != *b) {
					match = 0;
					break;
				}
				a++;
				b++;
			}
			if (match) {
				const struct velora_sec64 *sc = (const struct velora_sec64 *)(p + sizeof(struct velora_seg64));
				for (j = 0; j < sg->nsects; j++) {
					int sm = 1;
					const char *sa = sc[j].sectname, *sb = sect;
					while (*sb) {
						if (*sa != *sb) {
							sm = 0;
							break;
						}
						sa++;
						sb++;
					}
					if (sm) {
						if (out_size)
							*out_size = (unsigned long)sc[j].size;
						if (out_addr)
							*out_addr = (unsigned long)sc[j].addr + (unsigned long)slide;
						return (void *)((unsigned long)sc[j].addr + (unsigned long)slide);
					}
				}
			}
		}
		if (!lc->cmdsize)
			break;
		p += lc->cmdsize;
	}
	return 0;
}

static void hook_unity_scan_image(const void *mh, long slide) {
	if (orig_unity_fps)
		return;
	unsigned long csz = 0, caddr = 0, tsz = 0, taddr = 0;
	char *cstr = (char *)sect_ptr(mh, slide, "__TEXT", "__cstring", &csz, &caddr);
	if (!cstr)
		cstr = (char *)sect_ptr(mh, slide, "__TEXT", "__const", &csz, &caddr);
	unsigned int *text = (unsigned int *)sect_ptr(mh, slide, "__TEXT", "__text", &tsz, &taddr);
	if (!cstr || !text || tsz < 8)
		return;
	const char *needles[] = {
		"UnityEngine.Application::set_targetFrameRate(System.Int32)",
		"UnityEngine.Application::set_targetFrameRate",
		"UnitySetTargetFPS",
		0,
	};
	const char *found = 0;
	for (int n = 0; needles[n] && !found; n++)
		found = find_bytes(cstr, csz, needles[n]);
	if (!found)
		return;
	unsigned long str_ad = (unsigned long)found;
	unsigned long limit = tsz / 4;
	if (limit > 4000000u)
		limit = 4000000u;
	for (unsigned long i = 0; i + 3 < limit && !orig_unity_fps; i++) {
		unsigned int ins = text[i];
		unsigned int ins2 = text[i + 1];
		if (!is_adrp_ins(ins) || !is_add64_ins(ins2))
			continue;
		unsigned long pc = taddr + i * 4;
		unsigned long got = adrp_addr(ins, pc) + add_imm12(ins2);
		if (got != str_ad)
			continue;
		unsigned long pc2 = pc + 8;
		unsigned int ins3 = text[i + 2];
		unsigned int ins4 = text[i + 3];
		if (!is_adrp_ins(ins3))
			continue;
		unsigned long fn = adrp_addr(ins3, pc2);
		if (is_add64_ins(ins4))
			fn += add_imm12(ins4);
		if (fn >= taddr && fn < taddr + tsz - 4) {
			unsigned int at = *(unsigned int *)fn;
			if (is_b_ins(at)) {
				unsigned long tgt = b_addr(at, fn);
				if (tgt >= taddr && tgt < taddr + tsz)
					fn = tgt;
			}
			hook_unity_sym_addr((void *)fn, (void *)hook_unity_fps, (void **)&orig_unity_fps);
		}
	}
}

static int is_unity_image(const char *img) {
	if (!img || !img[0])
		return 0;
	if (velora_cstr_has(img, "/System/"))
		return 0;
	if (velora_cstr_has(img, "/usr/lib"))
		return 0;
	return velora_cstr_has(img, "Unity");
}

static void hook_unity_all_images(void) {
	unsigned int n = _dyld_image_count();
	unsigned int i;
	const char *names[] = {
		"UnitySetTargetFPS",
		"UnitySetTargetFrameRate",
		"SetTargetFrameRate",
		"UnitySetVSyncCount",
		0,
	};
	for (i = 0; i < n; i++) {
		const char *img = _dyld_get_image_name(i);
		if (!is_unity_image(img))
			continue;
		int k;
		for (k = 0; names[k]; k++) {
			if (k == 3)
				try_hook_image_sym(img, names[k], (void *)hook_unity_vsync, (void **)&orig_unity_vsync);
			else
				try_hook_image_sym(img, names[k], (void *)hook_unity_fps, (void **)&orig_unity_fps);
		}
		if (!orig_unity_fps)
			hook_unity_scan_image(_dyld_get_image_header(i), _dyld_get_image_vmaddr_slide(i));
	}
}

static void load_unity_framework(void) {
	id main = main_bundle();
	id path = main ? msg0(main, "bundlePath") : 0;
	if (!path)
		return;
	id fw = msg1(path, "stringByAppendingString:", nsstr("/Frameworks/UnityFramework.framework"));
	if (!fw)
		return;
	id fm = cls0(objc_getClass("NSFileManager"), "defaultManager");
	if (fm) {
		unsigned char (*ex)(id, SEL, id) = (unsigned char (*)(id, SEL, id))objc_msgSend;
		if (!ex(fm, sel_registerName("fileExistsAtPath:"), fw))
			return;
	}
	id (*bp)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
	id bundle = bp(objc_getClass("NSBundle"), sel_registerName("bundleWithPath:"), fw);
	if (bundle)
		msg0(bundle, "load");
}

static void (*orig_create_dl)(id, SEL);
static void hook_create_dl(id self, SEL sel) {
	if (orig_create_dl)
		orig_create_dl(self, sel);
	id link = fps_responds(self, "displayLink") ? msg0(self, "displayLink") : 0;
	if (link)
		apply_link(link);
	force_unity_fps();
}

static void hook_unity_app_controller(void) {
	if (!pMSHookMessageEx)
		return;
	hook_msg("UnityAppController", "createDisplayLink", (void *)hook_create_dl, (void **)&orig_create_dl);
	hook_msg("UnityViewControllerBase", "createDisplayLink", (void *)hook_create_dl, (void **)&orig_create_dl);
}

static void hook_unity_icalls(void) {
	unsigned int n = _dyld_image_count();
	unsigned int i;
	for (i = 0; i <= n; i++) {
		const char *img = (i == n) ? 0 : _dyld_get_image_name(i);
		if (i < n && !is_unity_image(img))
			continue;
		void *h = (i == n) ? RTLD_DEFAULT : dlopen(img, RTLD_NOLOAD | RTLD_LAZY);
		void *resolve = dlsym(h ? h : RTLD_DEFAULT, "il2cpp_resolve_icall");
		if (!resolve)
			resolve = dlsym(h ? h : RTLD_DEFAULT, "_il2cpp_resolve_icall");
		if (!resolve)
			resolve = dlsym(h ? h : RTLD_DEFAULT, "mono_lookup_internal_call");
		if (!resolve)
			continue;
		void *(*fn)(const char *) = (void *(*)(const char *))resolve;
		if (!orig_icall_fps) {
			const char *fpsn[] = {
				"UnityEngine.Application::set_targetFrameRate(System.Int32)",
				"UnityEngine.Application::set_targetFrameRate(int)",
				"UnityEngine.Application::set_targetFrameRate(Int32)",
				0,
			};
			int k;
			for (k = 0; fpsn[k] && !orig_icall_fps; k++) {
				void *s = fn(fpsn[k]);
				if (s)
					hook_unity_sym_addr(s, (void *)hook_icall_fps, (void **)&orig_icall_fps);
			}
		}
		if (!orig_icall_vsync) {
			const char *vsn[] = {
				"UnityEngine.QualitySettings::set_vSyncCount(System.Int32)",
				"UnityEngine.QualitySettings::set_vSyncCount(int)",
				"UnityEngine.QualitySettings::set_vSyncCount(Int32)",
				0,
			};
			int k;
			for (k = 0; vsn[k] && !orig_icall_vsync; k++) {
				void *s = fn(vsn[k]);
				if (s)
					hook_unity_sym_addr(s, (void *)hook_icall_vsync, (void **)&orig_icall_vsync);
			}
		}
	}
}

static void hook_unity(void) {
	hook_unity_all_images();
	hook_unity_icalls();
	hook_unity_app_controller();
}

static void force_unity_fps(void) {
	if (!fps_active())
		return;
	int d = unity_fps_val();
	if (orig_unity_vsync)
		orig_unity_vsync(0);
	if (orig_icall_vsync)
		orig_icall_vsync(0);
	if (orig_unity_fps)
		orig_unity_fps(d);
	if (orig_icall_fps)
		orig_icall_fps(d);
}

static void on_image_fps(const void *mh, long slide) {
	(void)mh;
	(void)slide;
}

static void on_fps_reload(void *center, void *obs, void *name, const void *obj, void *info) {
	(void)center;
	(void)obs;
	(void)name;
	(void)obj;
	(void)info;
	load_fps_prefs();
	force_unity_fps();
}

extern void register_velora_picker(void);
extern void register_velora_menu(void);
extern void register_velora_versions(void);
extern void velora_store_init(void);
extern void velora_jb_init(void);
extern void velora_hud_init(void);
extern void velora_compat_init(void);
extern void velora_jbupdate_init(void);

static int is_store_proc(void) {
	if (velora_is_store_bid(current_bid_c()))
		return 1;
	id proc = cls0(objc_getClass("NSProcessInfo"), "processInfo");
	id name = proc ? msg0(proc, "processName") : 0;
	const char *s = utf8(name);
	return velora_cstr_eq(s, "itunesstored") || velora_cstr_eq(s, "appstored");
}

static int is_prefs_proc(void) {
	if (velora_is_prefs_bid(current_bid_c()))
		return 1;
	const char *p = getprogname();
	return velora_cstr_eq(p, "Preferences") || velora_cstr_eq(p, "Settings");
}

static int gPrefsReady;

static void register_prefs_now(void) {
	if (!objc_getClass("PSListController"))
		dlopen("/System/Library/PrivateFrameworks/Preferences.framework/Preferences", RTLD_LAZY);
	register_velora_picker();
	register_velora_menu();
	register_velora_versions();
	if (objc_getClass("VeloraRootListController") && objc_getClass("VeloraHistoryController"))
		gPrefsReady = 1;
}

static void velora_register_prefs_classes(const void *mh, long slide) {
	(void)mh;
	(void)slide;
	if (!is_prefs_proc())
		return;
	if (gPrefsReady && objc_getClass("VeloraRootListController") && objc_getClass("VeloraHistoryController"))
		return;
	register_prefs_now();
}

static int gAllowDlopen;

static MSHookMessageEx_t resolve_msg_hook(void) {
	MSHookMessageEx_t f = (MSHookMessageEx_t)dlsym(RTLD_DEFAULT, "MSHookMessageEx");
	if (!pMSHookFunction)
		pMSHookFunction = (MSHookFunction_t)dlsym(RTLD_DEFAULT, "MSHookFunction");
	if (f && pMSHookFunction)
		return f;
	const char *paths[] = {
		"/var/jb/usr/lib/libellekit.dylib",
		"/var/jb/usr/lib/libsubstrate.dylib",
		"/usr/lib/libellekit.dylib",
		"/usr/lib/libsubstrate.dylib",
		"/usr/lib/libsubstitute.dylib",
		"/var/jb/usr/lib/libsubstitute.dylib",
		"/usr/lib/libhooker.dylib",
		"/var/jb/usr/lib/libhooker.dylib",
		"/usr/lib/TweakInject/libellekit.dylib",
		"/var/jb/usr/lib/TweakInject/libellekit.dylib",
		0,
	};
	for (int i = 0; paths[i]; i++) {
		void *h = dlopen(paths[i], RTLD_NOLOAD | RTLD_LAZY);
		if (!h && gAllowDlopen)
			h = dlopen(paths[i], RTLD_LAZY);
		if (!h)
			continue;
		if (!f)
			f = (MSHookMessageEx_t)dlsym(h, "MSHookMessageEx");
		if (!pMSHookFunction)
			pMSHookFunction = (MSHookFunction_t)dlsym(h, "MSHookFunction");
		if (f)
			return f;
	}
	return f;
}

static void install_class_fps_hooks(void) {
	if (!pMSHookMessageEx)
		pMSHookMessageEx = resolve_msg_hook();
	if (!pMSHookMessageEx)
		return;
	if (!objc_getClass("CADisplayLink"))
		return;
	if (velora_cstr_eq(getprogname(), "SpringBoard") || velora_is_springboard_bid(current_bid_c()))
		return;
	if (!orig_dl_create)
		hook_cls("CADisplayLink", "displayLinkWithTarget:selector:", (void *)hook_dl_create, (void **)&orig_dl_create);
	if (!orig_setFrameInterval)
		hook_msg("CADisplayLink", "setFrameInterval:", (void *)hook_setFrameInterval, (void **)&orig_setFrameInterval);
	if (!orig_setPreferredFPS)
		hook_msg("CADisplayLink", "setPreferredFramesPerSecond:", (void *)hook_setPreferredFPS, (void **)&orig_setPreferredFPS);
	if (!orig_getPreferredFPS)
		hook_msg("CADisplayLink", "preferredFramesPerSecond", (void *)hook_getPreferredFPS, (void **)&orig_getPreferredFPS);
	if (!orig_setRange)
		hook_msg("CADisplayLink", "setPreferredFrameRateRange:", (void *)hook_setRange, (void **)&orig_setRange);
	if (!orig_addRL)
		hook_msg("CADisplayLink", "addToRunLoop:forMode:", (void *)hook_addRL, (void **)&orig_addRL);
	if (!orig_ui_max)
		hook_msg("UIScreen", "maximumFramesPerSecond", (void *)hook_ui_max, (void **)&orig_ui_max);
	if (!orig_ca_max)
		hook_msg("CADisplay", "maximumFramesPerSecond", (void *)hook_ca_max, (void **)&orig_ca_max);
	if (!orig_ca_maxfps)
		hook_msg("CADisplay", "maximumFPS", (void *)hook_ca_maxfps, (void **)&orig_ca_maxfps);
	if (!orig_set_ca_maxfps)
		hook_msg("CADisplay", "setMaximumFPS:", (void *)hook_set_ca_maxfps, (void **)&orig_set_ca_maxfps);
	if (!orig_drawable_count)
		hook_msg("CAMetalLayer", "maximumDrawableCount", (void *)hook_drawable_count, (void **)&orig_drawable_count);
	if (!orig_set_drawable_count)
		hook_msg("CAMetalLayer", "setMaximumDrawableCount:", (void *)hook_set_drawable_count, (void **)&orig_set_drawable_count);
	if (!orig_min_frame)
		hook_msg("CAMetalLayer", "minimumFrameDuration", (void *)hook_min_frame, (void **)&orig_min_frame);
	if (!orig_metal_fps)
		hook_msg("CAMetalLayer", "setPreferredFramesPerSecond:", (void *)hook_metal_fps, (void **)&orig_metal_fps);
	if (!orig_allow_timeout)
		hook_msg("CAMetalLayer", "allowsNextDrawableTimeout", (void *)hook_allow_timeout, (void **)&orig_allow_timeout);
	if (!orig_set_allow_timeout)
		hook_msg("CAMetalLayer", "setAllowsNextDrawableTimeout:", (void *)hook_set_allow_timeout, (void **)&orig_set_allow_timeout);
	if (!orig_present_min)
		hook_msg("CAMetalDrawable", "presentAfterMinimumDuration:", (void *)hook_present_min, (void **)&orig_present_min);
	if (!orig_present_min2)
		hook_msg("CAMetalDrawableImp", "presentAfterMinimumDuration:", (void *)hook_present_min2, (void **)&orig_present_min2);
	if (!orig_present_draw)
		hook_msg("_MTLCommandBuffer", "presentDrawable:afterMinimumDuration:", (void *)hook_present_draw, (void **)&orig_present_draw);
	if (!orig_present_draw2)
		hook_msg("MTLIOAccelCommandBuffer", "presentDrawable:afterMinimumDuration:", (void *)hook_present_draw2, (void **)&orig_present_draw2);
	if (!orig_sk_get)
		hook_msg("SKView", "preferredFramesPerSecond", (void *)hook_sk_get, (void **)&orig_sk_get);
	if (!orig_sk_set)
		hook_msg("SKView", "setPreferredFramesPerSecond:", (void *)hook_sk_set, (void **)&orig_sk_set);
	if (!orig_glk_get)
		hook_msg("GLKView", "preferredFramesPerSecond", (void *)hook_glk_get, (void **)&orig_glk_get);
	if (!orig_glk_set)
		hook_msg("GLKView", "setPreferredFramesPerSecond:", (void *)hook_glk_set, (void **)&orig_glk_set);
	if (!orig_cc_set)
		hook_msg("CCDirector", "setAnimationInterval:", (void *)hook_cc_set, (void **)&orig_cc_set);
	if (!orig_cc_get)
		hook_msg("CCDirector", "animationInterval", (void *)hook_cc_get, (void **)&orig_cc_get);
	if (!orig_view_range)
		hook_msg("UIView", "setPreferredFrameRateRange:", (void *)hook_view_range, (void **)&orig_view_range);
}

static void install_fps_hooks(void) {
	install_class_fps_hooks();
	static int note_once;
	if (!note_once) {
		note_once = 1;
		id name = nsstr("com.velora.hz/Reload");
		if (name) {
			id (*retain)(id, SEL) = (id(*)(id, SEL))objc_msgSend;
			retain(name, sel_registerName("retain"));
			CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), (const void *)0x46505331, (void *)on_fps_reload, name, 0, 4);
		}
	}
}

static int gAppBooted;
static id gBoot;

static int shared_app_ready(void) {
	Class C = objc_getClass("UIApplication");
	if (!C)
		return 0;
	return cls0(C, "sharedApplication") ? 1 : 0;
}

static void velora_app_boot(id self, SEL sel) {
	(void)self;
	(void)sel;
	if (gAppBooted)
		return;
	if (velora_skip_inject(current_bid_c(), current_path_c()))
		return;
	if (!shared_app_ready())
		return;
	gAppBooted = 1;
	velora_compat_init();
	load_fps_prefs();
	if (velora_is_jbapp_bid(current_bid_c()) || velora_is_jbapp_path(current_path_c()))
		velora_jbupdate_init();
	velora_jb_init();
	velora_hud_init();
	install_fps_hooks();
}

static void velora_boost(id self, SEL sel) {
	(void)self;
	(void)sel;
	if (!gAppBooted)
		return;
	load_unity_framework();
	try_hook_image_sym(0, "UnitySetTargetFPS", (void *)hook_unity_fps, (void **)&orig_unity_fps);
	try_hook_image_sym(0, "UnitySetTargetFrameRate", (void *)hook_unity_fps, (void **)&orig_unity_fps);
	try_hook_image_sym(0, "UnitySetVSyncCount", (void *)hook_unity_vsync, (void **)&orig_unity_vsync);
	hook_unity_icalls();
	hook_unity_app_controller();
	if (!orig_unity_fps)
		hook_unity_all_images();
	force_unity_fps();
}

static void velora_app_boot_note(id self, SEL sel, id note) {
	(void)note;
	velora_app_boot(self, sel);
}

static int is_main_thread(void) {
	Class T = objc_getClass("NSThread");
	if (!T)
		return 0;
	unsigned char (*im)(Class, SEL) = (unsigned char (*)(Class, SEL))objc_msgSend;
	return im(T, sel_registerName("isMainThread")) ? 1 : 0;
}

static void boot_on_main(void *ctx) {
	(void)ctx;
	velora_app_boot(0, 0);
}

static int dispatch_boot(void) {
	void *async_f = dlsym(RTLD_DEFAULT, "dispatch_async_f");
	void *mainq = dlsym(RTLD_DEFAULT, "_dispatch_main_q");
	if (!async_f || !mainq)
		return 0;
	typedef void (*daf_t)(void *, void *, void (*)(void *));
	((daf_t)async_f)(mainq, 0, boot_on_main);
	return 1;
}

static void queue_app_boot(void) {
	if (gBoot)
		return;
	Class C = objc_getClass("VeloraAppBoot");
	if (!C) {
		Class super = objc_getClass("NSObject");
		if (!super)
			return;
		C = objc_allocateClassPair(super, "VeloraAppBoot", 0);
		if (!C)
			return;
		class_addMethod(C, sel_registerName("boot"), (void *)velora_app_boot, "v@:");
		class_addMethod(C, sel_registerName("bootNote:"), (void *)velora_app_boot_note, "v@:@");
		class_addMethod(C, sel_registerName("boost"), (void *)velora_boost, "v@:");
		objc_registerClassPair(C);
	}
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	gBoot = msg0(al(C, sel_registerName("alloc")), "init");
	if (!gBoot)
		return;
	id nc = cls0(objc_getClass("NSNotificationCenter"), "defaultCenter");
	if (nc) {
		typedef id (*add_t)(id, SEL, id, SEL, id, id);
		add_t add = (add_t)objc_msgSend;
		add(nc, sel_registerName("addObserver:selector:name:object:"), gBoot, sel_registerName("bootNote:"), nsstr("UIApplicationDidFinishLaunchingNotification"), 0);
		add(nc, sel_registerName("addObserver:selector:name:object:"), gBoot, sel_registerName("bootNote:"), nsstr("UIApplicationDidBecomeActiveNotification"), 0);
	}
	if (!dispatch_boot()) {
		void (*p)(id, SEL, SEL, id, unsigned char) = (void (*)(id, SEL, SEL, id, unsigned char))objc_msgSend;
		p(gBoot, sel_registerName("performSelectorOnMainThread:withObject:waitUntilDone:"), sel_registerName("boot"), 0, 0);
	}
	if (gBoot && fps_responds(gBoot, "performSelector:withObject:afterDelay:")) {
		void (*d)(id, SEL, SEL, id, double) = (void (*)(id, SEL, SEL, id, double))objc_msgSend;
		d(gBoot, sel_registerName("performSelector:withObject:afterDelay:"), sel_registerName("boost"), 0, 1.5);
	}
}

static void boot_late(void *ctx) {
	(void)ctx;
	if (!objc_getClass("NSObject"))
		return;
	void *pool = objc_autoreleasePoolPush();
	const char *bid = current_bid_c();
	const char *path = current_path_c();
	if (velora_is_springboard_bid(bid) || velora_cstr_eq(getprogname(), "SpringBoard")) {
		velora_compat_init();
		if (pool)
			objc_autoreleasePoolPop(pool);
		return;
	}
	if (velora_skip_inject(bid, path)) {
		if (pool)
			objc_autoreleasePoolPop(pool);
		return;
	}
	if (is_store_proc()) {
		velora_store_init();
		if (pool)
			objc_autoreleasePoolPop(pool);
		return;
	}
	if (is_prefs_proc()) {
		if (!objc_getClass("PSListController"))
			dlopen("/System/Library/PrivateFrameworks/Preferences.framework/Preferences", RTLD_LAZY);
		register_prefs_now();
		if (!gPrefsReady)
			_dyld_register_func_for_add_image(velora_register_prefs_classes);
		velora_store_init();
		if (pool)
			objc_autoreleasePoolPop(pool);
		return;
	}
	if (bid && bid[0] == 'c' && bid[1] == 'o' && velora_cstr_has(bid, "com.apple.")) {
		if (pool)
			objc_autoreleasePoolPop(pool);
		return;
	}
	gAllowDlopen = 1;
	queue_app_boot();
	if (pool)
		objc_autoreleasePoolPop(pool);
}

static int dispatch_late(void) {
	void *async_f = dlsym(RTLD_DEFAULT, "dispatch_async_f");
	void *mainq = dlsym(RTLD_DEFAULT, "_dispatch_main_q");
	if (!async_f || !mainq)
		return 0;
	typedef void (*daf_t)(void *, void *, void (*)(void *));
	((daf_t)async_f)(mainq, 0, boot_late);
	return 1;
}

__attribute__((constructor)) static void velora_init(void) {
	static int once;
	if (once)
		return;
	once = 1;
	const char *p = getprogname();
	if (velora_is_helper_prog(p))
		return;
	if (velora_cstr_eq(p, "SpringBoard")) {
		velora_compat_init();
		dispatch_late();
		return;
	}
	if (velora_cstr_eq(p, "backboardd") || velora_cstr_eq(p, "UserEventAgent") || velora_cstr_eq(p, "ReportCrash"))
		return;
	if (velora_cstr_eq(p, "Preferences") || velora_cstr_eq(p, "Settings")) {
		register_prefs_now();
		if (!gPrefsReady)
			_dyld_register_func_for_add_image(velora_register_prefs_classes);
		dispatch_late();
		return;
	}
	if (velora_cstr_eq(p, "itunesstored") || velora_cstr_eq(p, "appstored")) {
		boot_late(0);
		dispatch_late();
		return;
	}
	dispatch_late();
}

