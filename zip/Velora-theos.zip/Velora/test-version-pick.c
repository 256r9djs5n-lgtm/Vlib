/* Host tests: picked version must not collapse to latest. */
#include <stdio.h>
#include <string.h>

static int same_ver_str(const char *x, const char *y) {
	int pa[8], pb[8];
	int na = 0, nb = 0, n, i, cur, any;
	const char *p;
	if (!x || !y || !x[0] || !y[0])
		return 0;
	if (strcmp(x, y) == 0)
		return 1;
	cur = 0;
	any = 0;
	p = x;
	while (*p && na < 8) {
		if (*p >= '0' && *p <= '9') {
			cur = cur * 10 + (*p - '0');
			any = 1;
			p++;
			continue;
		}
		if (any) {
			pa[na++] = cur;
			cur = 0;
			any = 0;
		}
		p++;
	}
	if (any && na < 8)
		pa[na++] = cur;
	cur = 0;
	any = 0;
	p = y;
	while (*p && nb < 8) {
		if (*p >= '0' && *p <= '9') {
			cur = cur * 10 + (*p - '0');
			any = 1;
			p++;
			continue;
		}
		if (any) {
			pb[nb++] = cur;
			cur = 0;
			any = 0;
		}
		p++;
	}
	if (any && nb < 8)
		pb[nb++] = cur;
	if (na < 1 || nb < 1)
		return 0;
	n = na > nb ? na : nb;
	for (i = 0; i < n; i++) {
		int va = i < na ? pa[i] : 0;
		int vb = i < nb ? pb[i] : 0;
		if (va != vb)
			return 0;
	}
	return 1;
}

static int is_digits_id(const char *c) {
	int n = 0;
	if (!c || !c[0])
		return 0;
	for (; *c; c++) {
		if (*c < '0' || *c > '9')
			return 0;
		n++;
	}
	return n >= 5;
}

static int is_apple_ext(const char *c) {
	int n = 0;
	if (!c || !c[0])
		return 0;
	for (; *c; c++) {
		if (*c < '0' || *c > '9')
			return 0;
		n++;
	}
	return n >= 8;
}

static int spec_is_app_row(int has_installed, int has_version) {
	return has_installed && !has_version;
}

static void gather(int *adam, int *ext, int *ver,
	int spec_adam, int spec_ext, int spec_ver, int spec_app,
	int parent_adam, int parent_ext, int parent_ver, int parent_app) {
	*adam = 0;
	*ext = 0;
	*ver = 0;
	if (!*adam)
		*adam = spec_adam;
	if (!spec_app) {
		if (!*ext)
			*ext = spec_ext;
		if (!*ver)
			*ver = spec_ver;
	}
	if (!*adam)
		*adam = parent_adam;
	if (!parent_app) {
		if (!*ext)
			*ext = parent_ext;
		if (!*ver)
			*ver = parent_ver;
	}
}

static int fail;

static void expect_i(int got, int want, const char *name) {
	if (got != want) {
		printf("FAIL %s got %d want %d\n", name, got, want);
		fail++;
	} else
		printf("ok %s\n", name);
}

int main(void) {
	int adam, ext, ver;
	expect_i(same_ver_str("18.2.1", "18.2.1"), 1, "exact");
	expect_i(same_ver_str("18.2.1", "18.2.10"), 0, "not prefix of 18.2.10");
	expect_i(same_ver_str("18.2", "18.2.0"), 1, "trailing zero");
	expect_i(same_ver_str("21.35.3", "21.3"), 0, "not shorter stem");
	expect_i(same_ver_str("1.0", "1.0.0"), 1, "pad zero");
	expect_i(is_digits_id("821786090"), 1, "apple ext id");
	expect_i(is_apple_ext("821786090"), 1, "long apple ext");
	expect_i(is_apple_ext("12345"), 0, "short build is not apple ext");
	expect_i(is_apple_ext("1234567"), 0, "7-digit is not apple ext");
	expect_i(is_apple_ext("12345678"), 1, "8-digit apple ext");
	expect_i(is_digits_id("18.2.1"), 0, "version string is not ext id");
	expect_i(is_digits_id("1234"), 0, "short build is not ext id");
	expect_i(spec_is_app_row(1, 0), 1, "installed app row");
	expect_i(spec_is_app_row(0, 1), 0, "history install row");
	expect_i(spec_is_app_row(1, 1), 0, "row with both is version row");
	gather(&adam, &ext, &ver, 544, 0, 1821, 0, 544, 999999, 0, 1);
	expect_i(adam, 544, "adam from install cell");
	expect_i(ext, 0, "does not inherit installed latest id");
	expect_i(ver, 1821, "keeps picked version");
	gather(&adam, &ext, &ver, 544, 821786090, 1821, 0, 544, 999999, 0, 1);
	expect_i(ext, 821786090, "picked ext wins over installed");
	if (fail)
		return 1;
	printf("ok\n");
	return 0;
}
