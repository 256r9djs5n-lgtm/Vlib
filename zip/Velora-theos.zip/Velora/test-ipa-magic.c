#include <stdio.h>
#include <string.h>
#include <unistd.h>

static int file_is_ipa(const char *path) {
	FILE *f = fopen(path, "rb");
	if (!f)
		return 0;
	unsigned char mag[4];
	unsigned long n = fread(mag, 1, 4, f);
	fclose(f);
	return n >= 2 && mag[0] == 'P' && mag[1] == 'K';
}

int main(void) {
	const char *ipa = "/tmp/velora-test.ipa";
	const char *html = "/tmp/velora-test.html";
	FILE *f = fopen(ipa, "wb");
	if (!f)
		return 1;
	fwrite("PK\x03\x04rest-of-zip", 1, 15, f);
	fclose(f);
	f = fopen(html, "wb");
	if (!f)
		return 1;
	fwrite("<!DOCTYPE html>", 1, 15, f);
	fclose(f);
	if (!file_is_ipa(ipa)) {
		fprintf(stderr, "FAIL real ipa\n");
		return 1;
	}
	if (file_is_ipa(html)) {
		fprintf(stderr, "FAIL html treated as ipa\n");
		return 1;
	}
	if (file_is_ipa("/tmp/no-such-velora-ipa")) {
		fprintf(stderr, "FAIL missing file\n");
		return 1;
	}
	unlink(ipa);
	unlink(html);
	printf("ok ipa magic\n");
	return 0;
}
