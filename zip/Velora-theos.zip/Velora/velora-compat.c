/* Bypass iOS “This app needs to be updated.” by allowing launch — not by
   hiding the blocking sheet. Swallowing presentViewController freezes
   SpringBoard (it waits for a button that never arrives) and the default
   path then replaces the just-installed older build with the latest.

   When the toggle is on we skip showLaunch orig entirely and invoke the
   completion (didShow=NO) so launch continues. launchProhibited is hooked
   on every SpringBoard / LaunchServices class that owns the property,
   including _LSApplicationState.

   Prefs: any source that says ON wins (file first). A stale cfprefsd
   false must not hide a true written by Settings.

   Hooks always install (gOn is checked inside). SpringBoard classes and
   launchProhibited are retried via orig==NULL + add_image so a too-early
   constructor cannot lock us out.

   add_image / ctor are dyld-lock unsafe: named MSHookMessageEx only.
   Never a class-list scan, symbol-find, function-pointer hook, or skip-orig
   FrontBoard activation from this file — those froze SpringBoard. */
#include "velora-proc.h"
void *dlopen(const char *path, int mode);
void *dlsym(void *handle, const char *symbol);
#define RTLD_LAZY 1
#define RTLD_NOLOAD 0x10
#define RTLD_DEFAULT ((void *)-2)

typedef struct objc_class *Class;
typedef struct objc_object *id;
typedef struct objc_selector *SEL;

extern Class objc_getClass(const char *name);
extern Class objc_getMetaClass(const char *name);
extern SEL sel_registerName(const char *name);
extern void objc_msgSend(void);
extern void *class_getInstanceMethod(Class cls, SEL name);
extern void *class_getClassMethod(Class cls, SEL name);
extern void *CFNotificationCenterGetDarwinNotifyCenter(void);
extern void CFNotificationCenterAddObserver(void *center, const void *observer, void *cb, const void *name, const void *object, int suspension);
extern void _dyld_register_func_for_add_image(void (*fn)(const void *, long));

typedef void (*MSHookMessageEx_t)(Class cls, SEL sel, void *imp, void **orig);
static MSHookMessageEx_t gHook;

static int gOn;
static int gWatching;
static int gWatchingImages;
static id gReloadName;

static id nsstr(const char *c) {
	id (*f)(Class, SEL, const char *) = (id(*)(Class, SEL, const char *))objc_msgSend;
	return f(objc_getClass("NSString"), sel_registerName("stringWithUTF8String:"), c);
}

static id msg0(id obj, const char *sel) {
	if (!obj)
		return 0;
	id (*f)(id, SEL) = (id(*)(id, SEL))objc_msgSend;
	return f(obj, sel_registerName(sel));
}

static id msg1(id obj, const char *sel, id a) {
	if (!obj)
		return 0;
	id (*f)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
	return f(obj, sel_registerName(sel), a);
}

static int pref_on_from(id d) {
	if (!d)
		return 0;
	id v = msg1(d, "objectForKey:", nsstr("bypassUpdateAlert"));
	if (!v)
		return 0;
	unsigned char (*b)(id, SEL) = (unsigned char (*)(id, SEL))objc_msgSend;
	return b(v, sel_registerName("boolValue")) ? 1 : 0;
}

static int file_pref_on(int *known) {
	id (*dcf)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
	Class D = objc_getClass("NSDictionary");
	const char *paths[] = {
		"/var/mobile/Library/Preferences/com.velora.hz.plist",
		"/var/jb/var/mobile/Library/Preferences/com.velora.hz.plist",
		"/var/jb/mnt/var/mobile/Library/Preferences/com.velora.hz.plist",
		"/var/jb/User/Library/Preferences/com.velora.hz.plist",
		"/private/var/mobile/Library/Preferences/com.velora.hz.plist",
		0,
	};
	int i;
	if (known)
		*known = 0;
	if (!D)
		return 0;
	for (i = 0; paths[i]; i++) {
		id file = dcf(D, sel_registerName("dictionaryWithContentsOfFile:"), nsstr(paths[i]));
		if (file && msg1(file, "objectForKey:", nsstr("bypassUpdateAlert"))) {
			if (known)
				*known = 1;
			return pref_on_from(file);
		}
	}
	return 0;
}

static int cf_pref_on(int *known) {
	id (*copy)(id, id);
	void (*rel)(id);
	id v;
	unsigned char (*b)(id, SEL);
	int on;
	if (known)
		*known = 0;
	copy = (id (*)(id, id))dlsym(RTLD_DEFAULT, "CFPreferencesCopyAppValue");
	if (!copy)
		return 0;
	v = copy(nsstr("bypassUpdateAlert"), nsstr("com.velora.hz"));
	if (!v)
		return 0;
	if (known)
		*known = 1;
	b = (unsigned char (*)(id, SEL))objc_msgSend;
	on = b(v, sel_registerName("boolValue")) ? 1 : 0;
	rel = (void (*)(id))dlsym(RTLD_DEFAULT, "CFRelease");
	if (rel)
		rel(v);
	return on;
}

static int read_compat_on(void) {
	int file_known = 0, cf_known = 0;
	int file_on = file_pref_on(&file_known);
	int cf_on = cf_pref_on(&cf_known);
	int def_on = 0;
	{
		Class C = objc_getClass("NSUserDefaults");
		id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
		id obj = C ? al(C, sel_registerName("alloc")) : 0;
		id defs = obj ? msg1(obj, "initWithSuiteName:", nsstr("com.velora.hz")) : 0;
		def_on = pref_on_from(defs);
		if (!def_on && C) {
			id std = al(C, sel_registerName("standardUserDefaults"));
			id domain = std ? msg1(std, "persistentDomainForName:", nsstr("com.velora.hz")) : 0;
			def_on = pref_on_from(domain);
		}
	}
	return velora_compat_pref_combine(file_on, file_known, cf_on, cf_known, def_on);
}

static void refresh_on(void) {
	gOn = read_compat_on();
}

struct Block_layout {
	void *isa;
	int flags;
	int reserved;
	void (*invoke)(void *block);
};

/* Completions are either void(^)(void) or void(^)(BOOL didShow). Passing
   didShow=0 is ignored by the void form and means “continue launch” for
   the BOOL form. Never leave the block uninvoked — that freezes SpringBoard. */
static void invoke_done(id block) {
	struct Block_layout *b = (struct Block_layout *)block;
	if (!b || !b->invoke)
		return;
	((void (*)(void *, unsigned char))b->invoke)(block, 0);
}

static unsigned char (*orig_proxyLaunch)(id, SEL);
static unsigned char hook_proxyLaunch(id self, SEL sel) {
	int orig = orig_proxyLaunch ? orig_proxyLaunch(self, sel) : 0;
	refresh_on();
	return (unsigned char)velora_compat_launch_prohibited(gOn, orig);
}

static unsigned char (*orig_recordLaunch)(id, SEL);
static unsigned char hook_recordLaunch(id self, SEL sel) {
	int orig = orig_recordLaunch ? orig_recordLaunch(self, sel) : 0;
	refresh_on();
	return (unsigned char)velora_compat_launch_prohibited(gOn, orig);
}

static unsigned char (*orig_fbLaunch)(id, SEL);
static unsigned char hook_fbLaunch(id self, SEL sel) {
	int orig = orig_fbLaunch ? orig_fbLaunch(self, sel) : 0;
	refresh_on();
	return (unsigned char)velora_compat_launch_prohibited(gOn, orig);
}

static unsigned char (*orig_sbInfoLaunch)(id, SEL);
static unsigned char hook_sbInfoLaunch(id self, SEL sel) {
	int orig = orig_sbInfoLaunch ? orig_sbInfoLaunch(self, sel) : 0;
	refresh_on();
	return (unsigned char)velora_compat_launch_prohibited(gOn, orig);
}

static unsigned char (*orig_sbAppLaunch)(id, SEL);
static unsigned char hook_sbAppLaunch(id self, SEL sel) {
	int orig = orig_sbAppLaunch ? orig_sbAppLaunch(self, sel) : 0;
	refresh_on();
	return (unsigned char)velora_compat_launch_prohibited(gOn, orig);
}

static unsigned char (*orig_bundleLaunch)(id, SEL);
static unsigned char hook_bundleLaunch(id self, SEL sel) {
	int orig = orig_bundleLaunch ? orig_bundleLaunch(self, sel) : 0;
	refresh_on();
	return (unsigned char)velora_compat_launch_prohibited(gOn, orig);
}

static unsigned char (*orig_proxyProp)(id, SEL);
static unsigned char hook_proxyProp(id self, SEL sel) {
	int orig = orig_proxyProp ? orig_proxyProp(self, sel) : 0;
	refresh_on();
	return (unsigned char)velora_compat_launch_prohibited(gOn, orig);
}

static unsigned char (*orig_recordProp)(id, SEL);
static unsigned char hook_recordProp(id self, SEL sel) {
	int orig = orig_recordProp ? orig_recordProp(self, sel) : 0;
	refresh_on();
	return (unsigned char)velora_compat_launch_prohibited(gOn, orig);
}

static unsigned char (*orig_privLaunch)(id, SEL);
static unsigned char hook_privLaunch(id self, SEL sel) {
	int orig = orig_privLaunch ? orig_privLaunch(self, sel) : 0;
	refresh_on();
	return (unsigned char)velora_compat_launch_prohibited(gOn, orig);
}

static unsigned char (*orig_sbAppProp)(id, SEL);
static unsigned char hook_sbAppProp(id self, SEL sel) {
	int orig = orig_sbAppProp ? orig_sbAppProp(self, sel) : 0;
	refresh_on();
	return (unsigned char)velora_compat_launch_prohibited(gOn, orig);
}

static unsigned char (*orig_sbInfoProp)(id, SEL);
static unsigned char hook_sbInfoProp(id self, SEL sel) {
	int orig = orig_sbInfoProp ? orig_sbInfoProp(self, sel) : 0;
	refresh_on();
	return (unsigned char)velora_compat_launch_prohibited(gOn, orig);
}

static unsigned char (*orig_fbProp)(id, SEL);
static unsigned char hook_fbProp(id self, SEL sel) {
	int orig = orig_fbProp ? orig_fbProp(self, sel) : 0;
	refresh_on();
	return (unsigned char)velora_compat_launch_prohibited(gOn, orig);
}

static unsigned char (*orig_bundleProp)(id, SEL);
static unsigned char hook_bundleProp(id self, SEL sel) {
	int orig = orig_bundleProp ? orig_bundleProp(self, sel) : 0;
	refresh_on();
	return (unsigned char)velora_compat_launch_prohibited(gOn, orig);
}

static unsigned char (*orig_sbInfoPriv)(id, SEL);
static unsigned char hook_sbInfoPriv(id self, SEL sel) {
	int orig = orig_sbInfoPriv ? orig_sbInfoPriv(self, sel) : 0;
	refresh_on();
	return (unsigned char)velora_compat_launch_prohibited(gOn, orig);
}

static unsigned char (*orig_sbAppPriv)(id, SEL);
static unsigned char hook_sbAppPriv(id self, SEL sel) {
	int orig = orig_sbAppPriv ? orig_sbAppPriv(self, sel) : 0;
	refresh_on();
	return (unsigned char)velora_compat_launch_prohibited(gOn, orig);
}

static unsigned char (*orig_stateLaunch)(id, SEL);
static unsigned char hook_stateLaunch(id self, SEL sel) {
	int orig = orig_stateLaunch ? orig_stateLaunch(self, sel) : 0;
	refresh_on();
	return (unsigned char)velora_compat_launch_prohibited(gOn, orig);
}

static unsigned char (*orig_stateProp)(id, SEL);
static unsigned char hook_stateProp(id self, SEL sel) {
	int orig = orig_stateProp ? orig_stateProp(self, sel) : 0;
	refresh_on();
	return (unsigned char)velora_compat_launch_prohibited(gOn, orig);
}

static unsigned char (*orig_fbInfoPriv)(id, SEL);
static unsigned char hook_fbInfoPriv(id self, SEL sel) {
	int orig = orig_fbInfoPriv ? orig_fbInfoPriv(self, sel) : 0;
	refresh_on();
	return (unsigned char)velora_compat_launch_prohibited(gOn, orig);
}

static unsigned char (*orig_restricted)(id, SEL);
static unsigned char hook_restricted(id self, SEL sel) {
	refresh_on();
	if (gOn)
		return 0;
	return orig_restricted ? orig_restricted(self, sel) : 0;
}

static unsigned char (*orig_recordRestricted)(id, SEL);
static unsigned char hook_recordRestricted(id self, SEL sel) {
	refresh_on();
	if (gOn)
		return 0;
	return orig_recordRestricted ? orig_recordRestricted(self, sel) : 0;
}

static unsigned char (*orig_stateRestricted)(id, SEL);
static unsigned char hook_stateRestricted(id self, SEL sel) {
	refresh_on();
	if (gOn)
		return 0;
	return orig_stateRestricted ? orig_stateRestricted(self, sel) : 0;
}

static unsigned char (*orig_stateBlocked)(id, SEL);
static unsigned char hook_stateBlocked(id self, SEL sel) {
	refresh_on();
	if (gOn)
		return 0;
	return orig_stateBlocked ? orig_stateBlocked(self, sel) : 0;
}

static long (*orig_compatProxy)(id, SEL);
static long hook_compatProxy(id self, SEL sel) {
	long orig = orig_compatProxy ? orig_compatProxy(self, sel) : 1;
	refresh_on();
	return velora_compat_state(gOn, (int)orig);
}

static long (*orig_compatRecord)(id, SEL);
static long hook_compatRecord(id self, SEL sel) {
	long orig = orig_compatRecord ? orig_compatRecord(self, sel) : 1;
	refresh_on();
	return velora_compat_state(gOn, (int)orig);
}

static long (*orig_compatBundle)(id, SEL);
static long hook_compatBundle(id self, SEL sel) {
	long orig = orig_compatBundle ? orig_compatBundle(self, sel) : 1;
	refresh_on();
	return velora_compat_state(gOn, (int)orig);
}

static unsigned long long (*orig_eval)(id, SEL, id);
static unsigned long long hook_eval(id self, SEL sel, id app) {
	unsigned long long type = orig_eval ? orig_eval(self, sel, app) : 0;
	refresh_on();
	return velora_compat_alert_type(gOn, type);
}

static unsigned long long (*orig_eval2)(id, SEL, id);
static unsigned long long hook_eval2(id self, SEL sel, id app) {
	unsigned long long type = orig_eval2 ? orig_eval2(self, sel, app) : 0;
	refresh_on();
	return velora_compat_alert_type(gOn, type);
}

static unsigned long long (*orig_eval3)(id, SEL, id);
static unsigned long long hook_eval3(id self, SEL sel, id app) {
	unsigned long long type = orig_eval3 ? orig_eval3(self, sel, app) : 0;
	refresh_on();
	return velora_compat_alert_type(gOn, type);
}

static void (*orig_showLaunch)(id, SEL, unsigned long long, id, id);
static void hook_showLaunch(id self, SEL sel, unsigned long long type, id app, id completion) {
	refresh_on();
	if (velora_compat_skip_show(gOn)) {
		invoke_done(completion);
		return;
	}
	type = velora_compat_alert_type(gOn, type);
	if (orig_showLaunch)
		orig_showLaunch(self, sel, type, app, completion);
	else
		invoke_done(completion);
}

static void (*orig_showLaunchPriv)(id, SEL, unsigned long long, id, id);
static void hook_showLaunchPriv(id self, SEL sel, unsigned long long type, id app, id completion) {
	refresh_on();
	if (velora_compat_skip_show(gOn)) {
		invoke_done(completion);
		return;
	}
	type = velora_compat_alert_type(gOn, type);
	if (orig_showLaunchPriv)
		orig_showLaunchPriv(self, sel, type, app, completion);
	else
		invoke_done(completion);
}

static void (*orig_showLaunchBare)(id, SEL, unsigned long long, id);
static void hook_showLaunchBare(id self, SEL sel, unsigned long long type, id app) {
	refresh_on();
	if (velora_compat_skip_show(gOn))
		return;
	type = velora_compat_alert_type(gOn, type);
	if (orig_showLaunchBare)
		orig_showLaunchBare(self, sel, type, app);
}

static void (*orig_showLaunchBid)(id, SEL, unsigned long long, id, id);
static void hook_showLaunchBid(id self, SEL sel, unsigned long long type, id bid, id completion) {
	refresh_on();
	if (velora_compat_skip_show(gOn)) {
		invoke_done(completion);
		return;
	}
	type = velora_compat_alert_type(gOn, type);
	if (orig_showLaunchBid)
		orig_showLaunchBid(self, sel, type, bid, completion);
	else
		invoke_done(completion);
}

static void (*orig_showLaunchApp)(id, SEL, id, id);
static void hook_showLaunchApp(id self, SEL sel, id app, id completion) {
	refresh_on();
	if (velora_compat_skip_show(gOn)) {
		invoke_done(completion);
		return;
	}
	if (orig_showLaunchApp)
		orig_showLaunchApp(self, sel, app, completion);
	else
		invoke_done(completion);
}

static unsigned char (*orig_showForType)(id, SEL, unsigned long long);
static unsigned char hook_showForType(id self, SEL sel, unsigned long long type) {
	refresh_on();
	if (gOn)
		return 0;
	return orig_showForType ? orig_showForType(self, sel, type) : 0;
}

static unsigned char (*orig_hasAlert)(id, SEL, unsigned long long);
static unsigned char hook_hasAlert(id self, SEL sel, unsigned long long type) {
	refresh_on();
	if (gOn)
		return 1;
	return orig_hasAlert ? orig_hasAlert(self, sel, type) : 0;
}

static void hook_sel(Class cls, const char *name, void *imp, void **orig) {
	SEL sel;
	if (!gHook || !cls || !name || !imp)
		return;
	if (orig && *orig)
		return;
	sel = sel_registerName(name);
	if (!class_getInstanceMethod(cls, sel) && !class_getClassMethod(cls, sel))
		return;
	gHook(cls, sel, imp, orig);
}

static void resolve_hookers(void) {
	const char *paths[] = {
		"/var/jb/usr/lib/libellekit.dylib",
		"/var/jb/usr/lib/libsubstrate.dylib",
		"/usr/lib/libellekit.dylib",
		"/usr/lib/libsubstrate.dylib",
		"/usr/lib/libhooker.dylib",
		"/var/jb/usr/lib/libhooker.dylib",
		0,
	};
	int i;
	if (!gHook)
		gHook = (MSHookMessageEx_t)dlsym(RTLD_DEFAULT, "MSHookMessageEx");
	if (gHook)
		return;
	for (i = 0; paths[i]; i++) {
		void *h = dlopen(paths[i], RTLD_NOLOAD | RTLD_LAZY);
		if (!h)
			continue;
		gHook = (MSHookMessageEx_t)dlsym(h, "MSHookMessageEx");
		if (gHook)
			return;
	}
}

static void install_compat_hooks(void) {
	resolve_hookers();
	if (!gHook)
		return;
	hook_sel(objc_getClass("LSApplicationProxy"), "isLaunchProhibited", (void *)hook_proxyLaunch, (void **)&orig_proxyLaunch);
	hook_sel(objc_getClass("LSApplicationProxy"), "launchProhibited", (void *)hook_proxyProp, (void **)&orig_proxyProp);
	hook_sel(objc_getClass("LSApplicationRecord"), "isLaunchProhibited", (void *)hook_recordLaunch, (void **)&orig_recordLaunch);
	hook_sel(objc_getClass("LSApplicationRecord"), "launchProhibited", (void *)hook_recordProp, (void **)&orig_recordProp);
	hook_sel(objc_getClass("LSBundleProxy"), "isLaunchProhibited", (void *)hook_bundleLaunch, (void **)&orig_bundleLaunch);
	hook_sel(objc_getClass("LSBundleProxy"), "launchProhibited", (void *)hook_bundleProp, (void **)&orig_bundleProp);
	hook_sel(objc_getClass("FBApplicationInfo"), "isLaunchProhibited", (void *)hook_fbLaunch, (void **)&orig_fbLaunch);
	hook_sel(objc_getClass("FBApplicationInfo"), "launchProhibited", (void *)hook_fbProp, (void **)&orig_fbProp);
	hook_sel(objc_getClass("FBApplicationInfo"), "_isLaunchProhibited", (void *)hook_fbInfoPriv, (void **)&orig_fbInfoPriv);
	hook_sel(objc_getClass("SBApplicationInfo"), "isLaunchProhibited", (void *)hook_sbInfoLaunch, (void **)&orig_sbInfoLaunch);
	hook_sel(objc_getClass("SBApplicationInfo"), "launchProhibited", (void *)hook_sbInfoProp, (void **)&orig_sbInfoProp);
	hook_sel(objc_getClass("SBApplicationInfo"), "_isLaunchProhibited", (void *)hook_sbInfoPriv, (void **)&orig_sbInfoPriv);
	hook_sel(objc_getClass("SBApplication"), "isLaunchProhibited", (void *)hook_sbAppLaunch, (void **)&orig_sbAppLaunch);
	hook_sel(objc_getClass("SBApplication"), "launchProhibited", (void *)hook_sbAppProp, (void **)&orig_sbAppProp);
	hook_sel(objc_getClass("SBApplication"), "_isLaunchProhibited", (void *)hook_sbAppPriv, (void **)&orig_sbAppPriv);
	hook_sel(objc_getClass("LSApplicationProxy"), "_isLaunchProhibited", (void *)hook_privLaunch, (void **)&orig_privLaunch);
	hook_sel(objc_getClass("_LSApplicationState"), "isLaunchProhibited", (void *)hook_stateLaunch, (void **)&orig_stateLaunch);
	hook_sel(objc_getClass("_LSApplicationState"), "launchProhibited", (void *)hook_stateProp, (void **)&orig_stateProp);
	hook_sel(objc_getClass("LSApplicationProxy"), "isRestricted", (void *)hook_restricted, (void **)&orig_restricted);
	hook_sel(objc_getClass("LSApplicationRecord"), "isRestricted", (void *)hook_recordRestricted, (void **)&orig_recordRestricted);
	hook_sel(objc_getClass("_LSApplicationState"), "isRestricted", (void *)hook_stateRestricted, (void **)&orig_stateRestricted);
	hook_sel(objc_getClass("_LSApplicationState"), "isBlocked", (void *)hook_stateBlocked, (void **)&orig_stateBlocked);
	hook_sel(objc_getClass("LSApplicationProxy"), "compatibilityState", (void *)hook_compatProxy, (void **)&orig_compatProxy);
	hook_sel(objc_getClass("LSApplicationRecord"), "compatibilityState", (void *)hook_compatRecord, (void **)&orig_compatRecord);
	hook_sel(objc_getClass("LSBundleProxy"), "compatibilityState", (void *)hook_compatBundle, (void **)&orig_compatBundle);
	hook_sel(objc_getClass("SBApplicationLaunchAlertEvaluator"), "evaluateForApplication:", (void *)hook_eval, (void **)&orig_eval);
	hook_sel(objc_getClass("SBApplicationLaunchAlertEvaluator"), "alertForApplication:", (void *)hook_eval2, (void **)&orig_eval2);
	hook_sel(objc_getClass("SBApplicationLaunchAlertEvaluator"), "alertTypeForApplication:", (void *)hook_eval3, (void **)&orig_eval3);
	hook_sel(objc_getClass("SBApplicationLaunchAlertService"), "showLaunchAlertOfType:forApplication:withCompletionHandler:", (void *)hook_showLaunch, (void **)&orig_showLaunch);
	hook_sel(objc_getClass("SBApplicationLaunchAlertService"), "_showLaunchAlertOfType:forApplication:withCompletionHandler:", (void *)hook_showLaunchPriv, (void **)&orig_showLaunchPriv);
	hook_sel(objc_getClass("SBApplicationLaunchAlertService"), "showLaunchAlertOfType:forApplication:", (void *)hook_showLaunchBare, (void **)&orig_showLaunchBare);
	hook_sel(objc_getClass("SBApplicationLaunchAlertService"), "showLaunchAlertOfType:forBundleIdentifier:withCompletionHandler:", (void *)hook_showLaunchBid, (void **)&orig_showLaunchBid);
	hook_sel(objc_getClass("SBApplicationLaunchAlertService"), "showLaunchAlertForApplication:withCompletionHandler:", (void *)hook_showLaunchApp, (void **)&orig_showLaunchApp);
	hook_sel(objc_getClass("SBApplication"), "showLaunchAlertForType:", (void *)hook_showForType, (void **)&orig_showForType);
	hook_sel(objc_getClass("SBApplication"), "hasDisplayedLaunchAlertForType:", (void *)hook_hasAlert, (void **)&orig_hasAlert);
}

static void on_reload(void *center, void *obs, void *name, const void *obj, void *info) {
	(void)center;
	(void)obs;
	(void)name;
	(void)obj;
	(void)info;
	gOn = read_compat_on();
	install_compat_hooks();
}

static void watch_reload(void) {
	void *c;
	if (gWatching)
		return;
	c = CFNotificationCenterGetDarwinNotifyCenter();
	if (!c)
		return;
	gWatching = 1;
	gReloadName = nsstr("com.velora.hz/Reload");
	if (gReloadName)
		gReloadName = msg0(gReloadName, "copy");
	if (!gReloadName)
		return;
	CFNotificationCenterAddObserver(c, (const void *)0x434F4D50, (void *)on_reload, gReloadName, 0, 4);
}

static void on_image(const void *mh, long slide) {
	(void)mh;
	(void)slide;
	install_compat_hooks();
}

static void watch_images(void) {
	if (gWatchingImages)
		return;
	gWatchingImages = 1;
	_dyld_register_func_for_add_image(on_image);
}

void velora_compat_init(void) {
	gOn = read_compat_on();
	watch_reload();
	install_compat_hooks();
	watch_images();
}
