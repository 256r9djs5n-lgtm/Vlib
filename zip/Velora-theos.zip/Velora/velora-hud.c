/* On-screen FPS / CPU / GPU HUD. Overlay window + key-window fallback. */
#include "velora-proc.h"
void *dlopen(const char *path, int mode);
void *dlsym(void *handle, const char *symbol);
#define RTLD_LAZY 1
#define RTLD_DEFAULT ((void *)-2)

typedef struct objc_class *Class;
typedef struct objc_object *id;
typedef struct objc_selector *SEL;
typedef void (*IMP)(void);
typedef long NSInteger;
typedef unsigned int mach_port_t;
typedef int integer_t;

extern Class objc_getClass(const char *name);
extern Class object_getClass(id obj);
extern const char *class_getName(Class cls);
extern SEL sel_registerName(const char *name);
extern void objc_msgSend(void);
extern Class objc_allocateClassPair(Class super, const char *name, unsigned long extra);
extern void objc_registerClassPair(Class cls);
extern int class_addMethod(Class cls, SEL name, IMP imp, const char *types);
extern void *class_getInstanceMethod(Class cls, SEL name);
extern id objc_getAssociatedObject(id object, const void *key);
extern void objc_setAssociatedObject(id object, const void *key, id value, unsigned policy);

extern void *CFNotificationCenterGetDarwinNotifyCenter(void);
extern void CFNotificationCenterAddObserver(void *center, const void *observer, void *cb, const void *name, const void *object, int suspension);
extern double CACurrentMediaTime(void);
extern mach_port_t mach_host_self(void);
extern int host_statistics(mach_port_t host, int flavor, integer_t *info, unsigned int *count);
extern int notify_register_check(const char *name, int *out_token);
extern int notify_get_state(int token, unsigned long long *state);
extern unsigned char CFPreferencesAppSynchronize(void *appID);
extern void *CFPreferencesCopyAppValue(void *key, void *appID);
extern void CFRelease(void *cf);

typedef void (*MSHookMessageEx_t)(Class cls, SEL sel, void *imp, void **orig);

static id gWin;
static id gChip;
static id gFps;
static id gCpu;
static id gGpu;
static id gLink;
static id gCtl;
static id gHost;
static int gHud = 1;
static int gTel = 1;
static int gCorner = 1;
static int gFrames;
static int gBusy;
static int gBooted;
static double gStamp;
static double gLast;
static unsigned long long gPrev[4];
static int gEventN;

static id nsstr(const char *c) {
	Class C = objc_getClass("NSString");
	if (!C || !c)
		return 0;
	id (*f)(Class, SEL, const char *) = (id(*)(Class, SEL, const char *))objc_msgSend;
	return f(C, sel_registerName("stringWithUTF8String:"), c);
}

static id msg0(id obj, const char *sel) {
	if (!obj)
		return 0;
	id (*f)(id, SEL) = (id(*)(id, SEL))objc_msgSend;
	return f(obj, sel_registerName(sel));
}

static id msg1(id obj, const char *sel, id a) {
	if (!obj)
		return 0;
	id (*f)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
	return f(obj, sel_registerName(sel), a);
}

static id msg2(id obj, const char *sel, id a, id b) {
	if (!obj)
		return 0;
	id (*f)(id, SEL, id, id) = (id(*)(id, SEL, id, id))objc_msgSend;
	return f(obj, sel_registerName(sel), a, b);
}

static id cls0(Class c, const char *sel) {
	if (!c)
		return 0;
	id (*f)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	return f(c, sel_registerName(sel));
}

static int responds(id obj, const char *sel) {
	if (!obj)
		return 0;
	unsigned char (*r)(id, SEL, SEL) = (unsigned char (*)(id, SEL, SEL))objc_msgSend;
	return r(obj, sel_registerName("respondsToSelector:"), sel_registerName(sel)) ? 1 : 0;
}

static const char *cstr(id s) {
	if (!s || !responds(s, "UTF8String"))
		return "";
	const char *(*f)(id, SEL) = (const char *(*)(id, SEL))objc_msgSend;
	const char *v = f(s, sel_registerName("UTF8String"));
	return v ? v : "";
}

static int streq(id a, const char *b) {
	if (!a)
		return 0;
	unsigned char (*eq)(id, SEL, id) = (unsigned char (*)(id, SEL, id))objc_msgSend;
	return eq(a, sel_registerName("isEqualToString:"), nsstr(b)) ? 1 : 0;
}

static int is_kind(id obj, const char *cls) {
	Class c = objc_getClass(cls);
	if (!obj || !c)
		return 0;
	unsigned char (*ik)(id, SEL, Class) = (unsigned char (*)(id, SEL, Class))objc_msgSend;
	return ik(obj, sel_registerName("isKindOfClass:"), c) ? 1 : 0;
}

static id suite(const char *name) {
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	id obj = al(objc_getClass("NSUserDefaults"), sel_registerName("alloc"));
	id (*init)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
	return init(obj, sel_registerName("initWithSuiteName:"), nsstr(name));
}

static id pref(const char *key) {
	id a = suite("com.velora.hz");
	id v = a ? msg1(a, "objectForKey:", nsstr(key)) : 0;
	if (v)
		return v;
	id b = suite("com.apple.UIKit");
	return b ? msg1(b, "objectForKey:", nsstr(key)) : 0;
}

static int pref_bool(const char *key, int fallback) {
	id v = pref(key);
	if (!v)
		return fallback;
	unsigned char (*b)(id, SEL) = (unsigned char (*)(id, SEL))objc_msgSend;
	return b(v, sel_registerName("boolValue")) ? 1 : 0;
}

static int pref_int(const char *key, int fallback) {
	id v = pref(key);
	if (!v)
		return fallback;
	NSInteger (*n)(id, SEL) = (NSInteger(*)(id, SEL))objc_msgSend;
	return (int)n(v, sel_registerName("integerValue"));
}

static int cf_pref_bool(const char *key, int *out) {
	id kn = nsstr(key);
	id app = nsstr("com.velora.hz");
	if (!kn || !app)
		return 0;
	CFPreferencesAppSynchronize((void *)app);
	void *v = CFPreferencesCopyAppValue((void *)kn, (void *)app);
	if (!v)
		return 0;
	unsigned char (*b)(id, SEL) = (unsigned char (*)(id, SEL))objc_msgSend;
	*out = b((id)v, sel_registerName("boolValue")) ? 1 : 0;
	CFRelease(v);
	return 1;
}

static int cf_pref_int(const char *key, int *out) {
	id kn = nsstr(key);
	id app = nsstr("com.velora.hz");
	if (!kn || !app)
		return 0;
	CFPreferencesAppSynchronize((void *)app);
	void *v = CFPreferencesCopyAppValue((void *)kn, (void *)app);
	if (!v)
		return 0;
	NSInteger (*n)(id, SEL) = (NSInteger(*)(id, SEL))objc_msgSend;
	*out = (int)n((id)v, sel_registerName("integerValue"));
	CFRelease(v);
	return 1;
}

static id hz_plist(void) {
	const char *paths[] = {
		"/var/mobile/Library/Preferences/com.velora.hz.plist",
		"/var/jb/var/mobile/Library/Preferences/com.velora.hz.plist",
		0
	};
	id (*dcf)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
	for (int i = 0; paths[i]; i++) {
		id d = dcf(objc_getClass("NSDictionary"), sel_registerName("dictionaryWithContentsOfFile:"), nsstr(paths[i]));
		if (d)
			return d;
	}
	return 0;
}

static void load_hud_prefs(void) {
	int hud = 1, tel = 1, corner = 1;
	int tok = 0;
	unsigned long long st = 0;
	if (notify_register_check("com.velora.hz/Reload", &tok) == 0 && notify_get_state(tok, &st) == 0 && velora_hud_state_valid(st)) {
		gHud = velora_hud_from_state(st);
		gTel = velora_tel_from_state(st);
		gCorner = velora_corner_from_state(st);
		return;
	}
	int got;
	if (cf_pref_bool("hud", &got))
		hud = got;
	else
		hud = pref_bool("hud", 1);
	if (cf_pref_bool("telemetry", &got))
		tel = got;
	else
		tel = pref_bool("telemetry", 1);
	if (cf_pref_int("hudCorner", &got))
		corner = got;
	else
		corner = pref_int("hudCorner", 1);
	id pl = hz_plist();
	if (pl) {
		id v = msg1(pl, "objectForKey:", nsstr("hud"));
		if (v && responds(v, "boolValue")) {
			unsigned char (*b)(id, SEL) = (unsigned char (*)(id, SEL))objc_msgSend;
			hud = b(v, sel_registerName("boolValue")) ? 1 : 0;
		}
		v = msg1(pl, "objectForKey:", nsstr("telemetry"));
		if (v && responds(v, "boolValue")) {
			unsigned char (*b)(id, SEL) = (unsigned char (*)(id, SEL))objc_msgSend;
			tel = b(v, sel_registerName("boolValue")) ? 1 : 0;
		}
		v = msg1(pl, "objectForKey:", nsstr("hudCorner"));
		if (v && responds(v, "integerValue")) {
			NSInteger (*n)(id, SEL) = (NSInteger(*)(id, SEL))objc_msgSend;
			corner = (int)n(v, sel_registerName("integerValue"));
		}
	}
	gHud = hud;
	gTel = tel;
	gCorner = (corner < 0 || corner > 3) ? 1 : corner;
}

static int bundle_in_list(id defs, const char *key, id bid) {
	if (!defs || !bid)
		return 0;
	id arr = msg1(defs, "arrayForKey:", nsstr(key));
	if (!arr)
		return 0;
	unsigned char (*contains)(id, SEL, id) = (unsigned char (*)(id, SEL, id))objc_msgSend;
	return contains(arr, sel_registerName("containsObject:"), bid) ? 1 : 0;
}

static id current_bid(void) {
	id main = cls0(objc_getClass("NSBundle"), "mainBundle");
	return main ? msg0(main, "bundleIdentifier") : 0;
}

static int hud_allowed(void) {
	id bid = current_bid();
	const char *b = cstr(bid);
	id main = cls0(objc_getClass("NSBundle"), "mainBundle");
	const char *path = cstr(main ? msg0(main, "bundlePath") : 0);
	if (velora_skip_inject(b, path))
		return 0;
	if (streq(bid, "com.apple.springboard") || streq(bid, "com.apple.Preferences"))
		return 0;
	if (streq(bid, "com.apple.itunesstored") || streq(bid, "com.apple.appstored"))
		return 0;
	id uk = suite("com.apple.UIKit");
	id mode = uk ? msg1(uk, "stringForKey:", nsstr("VeloraAppMode")) : 0;
	const char *m = cstr(mode);
	if (m[0] == 'e')
		return bundle_in_list(uk, "VeloraEnabledApps", bid) || bundle_in_list(suite("com.velora.hz"), "VeloraEnabledApps", bid);
	if (m[0] == 'b' || m[0] == 'd')
		return !bundle_in_list(uk, "VeloraDisabledApps", bid) && !bundle_in_list(uk, "VeloraBlacklistedApps", bid);
	return 1;
}

static void set_frame(id view, double x, double y, double w, double h) {
	if (!view)
		return;
	double r[4] = { x, y, w, h };
	id (*nv)(Class, SEL, const void *, const char *) = (id(*)(Class, SEL, const void *, const char *))objc_msgSend;
	id val = nv(objc_getClass("NSValue"), sel_registerName("valueWithBytes:objCType:"), r, "{CGRect={CGPoint=dd}{CGSize=dd}}");
	if (val)
		msg2(view, "setValue:forKey:", val, nsstr("frame"));
}

static double kvc_double(id obj, const char *path, double fallback) {
	if (!obj)
		return fallback;
	id n = msg1(obj, "valueForKeyPath:", nsstr(path));
	if (!n)
		return fallback;
	double (*dv)(id, SEL) = (double (*)(id, SEL))objc_msgSend;
	double v = dv(n, sel_registerName("doubleValue"));
	return v > 1 ? v : fallback;
}

static id color_rgba(double r, double g, double b, double a) {
	id (*f)(Class, SEL, double, double, double, double) = (id(*)(Class, SEL, double, double, double, double))objc_msgSend;
	return f(objc_getClass("UIColor"), sel_registerName("colorWithRed:green:blue:alpha:"), r, g, b, a);
}

static id font_mono(double size) {
	id (*sw)(Class, SEL, double, double) = (id(*)(Class, SEL, double, double))objc_msgSend;
	id f = sw(objc_getClass("UIFont"), sel_registerName("monospacedDigitSystemFontOfSize:weight:"), size, 0.23);
	if (f)
		return f;
	id (*s)(Class, SEL, double) = (id(*)(Class, SEL, double))objc_msgSend;
	return s(objc_getClass("UIFont"), sel_registerName("systemFontOfSize:"), size);
}

static id make_label(double x, double y, double w, double h, double size, id color, const char *text, int right) {
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	id lab = msg0(al(objc_getClass("UILabel"), sel_registerName("alloc")), "init");
	set_frame(lab, x, y, w, h);
	msg1(lab, "setFont:", font_mono(size));
	msg1(lab, "setTextColor:", color);
	if (right) {
		void (*ta)(id, SEL, NSInteger) = (void (*)(id, SEL, NSInteger))objc_msgSend;
		ta(lab, sel_registerName("setTextAlignment:"), 2);
	}
	msg1(lab, "setText:", nsstr(text));
	void (*fit)(id, SEL, unsigned char) = (void (*)(id, SEL, unsigned char))objc_msgSend;
	if (responds(lab, "setAdjustsFontSizeToFitWidth:"))
		fit(lab, sel_registerName("setAdjustsFontSizeToFitWidth:"), 1);
	return lab;
}

static id shared_app(void) {
	Class C = objc_getClass("UIApplication");
	if (!C)
		return 0;
	return cls0(C, "sharedApplication");
}

static int is_main_thread(void) {
	Class T = objc_getClass("NSThread");
	if (!T)
		return 0;
	unsigned char (*im)(Class, SEL) = (unsigned char (*)(Class, SEL))objc_msgSend;
	return im(T, sel_registerName("isMainThread")) ? 1 : 0;
}

static int is_safe_host(id w) {
	if (!w)
		return 0;
	if (is_kind(w, "VeloraHUDWindow"))
		return 0;
	Class c = object_getClass(w);
	const char *n = c ? class_getName(c) : "";
	if (velora_is_unsafe_hud_window(n))
		return 0;
	double level = kvc_double(w, "windowLevel", 0);
	if (level > 0.5)
		return 0;
	return 1;
}

static id host_view(id w) {
	if (!w)
		return 0;
	if (responds(w, "rootViewController")) {
		id rvc = msg0(w, "rootViewController");
		id v = rvc && responds(rvc, "viewIfLoaded") ? msg0(rvc, "viewIfLoaded") : 0;
		if (!v && rvc && responds(rvc, "isViewLoaded")) {
			unsigned char (*iv)(id, SEL) = (unsigned char (*)(id, SEL))objc_msgSend;
			if (iv(rvc, sel_registerName("isViewLoaded")) && responds(rvc, "view"))
				v = msg0(rvc, "view");
		}
		if (v)
			return v;
	}
	return w;
}

static id first_window(void) {
	id app = shared_app();
	if (!app)
		return 0;
	id key = responds(app, "keyWindow") ? msg0(app, "keyWindow") : 0;
	if (is_safe_host(key))
		return key;
	if (responds(app, "windows")) {
		id wins = msg0(app, "windows");
		NSInteger (*c)(id, SEL) = (NSInteger(*)(id, SEL))objc_msgSend;
		NSInteger n = wins ? c(wins, sel_registerName("count")) : 0;
		id (*at)(id, SEL, NSInteger) = (id(*)(id, SEL, NSInteger))objc_msgSend;
		for (NSInteger i = 0; i < n; i++) {
			id w = at(wins, sel_registerName("objectAtIndex:"), i);
			if (is_safe_host(w))
				return w;
		}
	}
	return 0;
}

static id active_scene(void) {
	id app = shared_app();
	if (!app || !responds(app, "connectedScenes"))
		return 0;
	id scenes = msg0(app, "connectedScenes");
	if (!scenes)
		return 0;
	id arr = responds(scenes, "allObjects") ? msg0(scenes, "allObjects") : scenes;
	NSInteger (*c)(id, SEL) = (NSInteger(*)(id, SEL))objc_msgSend;
	NSInteger n = c(arr, sel_registerName("count"));
	id (*at)(id, SEL, NSInteger) = (id(*)(id, SEL, NSInteger))objc_msgSend;
	id fallback = 0;
	for (NSInteger i = 0; i < n; i++) {
		id s = at(arr, sel_registerName("objectAtIndex:"), i);
		if (!is_kind(s, "UIWindowScene"))
			continue;
		if (!fallback)
			fallback = s;
		NSInteger (*st)(id, SEL) = (NSInteger(*)(id, SEL))objc_msgSend;
		if (responds(s, "activationState") && st(s, sel_registerName("activationState")) == 0)
			return s;
	}
	return fallback;
}

static double screen_w(void) {
	id sc = cls0(objc_getClass("UIScreen"), "mainScreen");
	double v = kvc_double(sc, "bounds.size.width", 0);
	if (v > 1)
		return v;
	id w = first_window();
	v = kvc_double(w, "bounds.size.width", 0);
	return v > 1 ? v : 390;
}

static double screen_h(void) {
	id sc = cls0(objc_getClass("UIScreen"), "mainScreen");
	double v = kvc_double(sc, "bounds.size.height", 0);
	if (v > 1)
		return v;
	id w = first_window();
	v = kvc_double(w, "bounds.size.height", 0);
	return v > 1 ? v : 844;
}

static void layout_chip(void) {
	if (!gChip)
		return;
	double h = gTel ? 56 : 22;
	double w = 112;
	double sw = screen_w();
	double sh = screen_h();
	id host = gHost ? gHost : first_window();
	if (host) {
		double hw = kvc_double(host, "bounds.size.width", 0);
		double hh = kvc_double(host, "bounds.size.height", 0);
		if (hw > 1)
			sw = hw;
		if (hh > 1)
			sh = hh;
	}
	double x = 12, y = 54;
	if (gCorner == 1)
		x = sw - w - 12;
	if (gCorner == 2)
		y = sh - h - 24;
	if (gCorner == 3) {
		x = sw - w - 12;
		y = sh - h - 24;
	}
	set_frame(gChip, x, y, w, h);
}

static void hide_bool(id v, int on) {
	if (!v)
		return;
	void (*sh)(id, SEL, unsigned char) = (void (*)(id, SEL, unsigned char))objc_msgSend;
	sh(v, sel_registerName("setHidden:"), on ? 1 : 0);
}

static float cpu_load(void) {
	integer_t info[4];
	unsigned int count = 4;
	if (host_statistics(mach_host_self(), 3, info, &count) != 0)
		return 0;
	unsigned long long user = (unsigned long long)info[0];
	unsigned long long sys = (unsigned long long)info[1];
	unsigned long long idle = (unsigned long long)info[2];
	unsigned long long nice = (unsigned long long)info[3];
	unsigned long long total = (user + nice + sys + idle) - (gPrev[0] + gPrev[1] + gPrev[2] + gPrev[3]);
	unsigned long long busy = (user + nice + sys) - (gPrev[0] + gPrev[1] + gPrev[2]);
	gPrev[0] = user;
	gPrev[1] = nice;
	gPrev[2] = sys;
	gPrev[3] = idle;
	if (total == 0)
		return 0;
	return (float)(100.0 * busy / total);
}

static void put_num(char *buf, int n, double v, int decimals) {
	int neg = v < 0;
	if (neg)
		v = -v;
	int scale = 1;
	for (int i = 0; i < decimals; i++)
		scale *= 10;
	int iv = (int)(v * scale + 0.5);
	int whole = iv / scale;
	int frac = iv % scale;
	int p = 0;
	if (neg && p < n - 1)
		buf[p++] = '-';
	char tmp[16];
	int t = 0;
	if (whole == 0)
		tmp[t++] = '0';
	while (whole > 0 && t < 14) {
		tmp[t++] = (char)('0' + (whole % 10));
		whole /= 10;
	}
	while (t > 0 && p < n - 1)
		buf[p++] = tmp[--t];
	if (decimals > 0 && p < n - 1) {
		buf[p++] = '.';
		int div = scale / 10;
		for (int i = 0; i < decimals && p < n - 1; i++) {
			buf[p++] = (char)('0' + (frac / div) % 10);
			div /= 10;
			if (div < 1)
				div = 1;
		}
	}
	buf[p] = 0;
}

static id fmt_fps(double v) {
	char buf[24];
	put_num(buf, 24, v, 1);
	return nsstr(buf);
}

static id fmt_pct(double v) {
	char buf[24];
	put_num(buf, 24, v, 0);
	int n = 0;
	while (buf[n])
		n++;
	if (n < 22) {
		buf[n++] = '%';
		buf[n] = 0;
	}
	return nsstr(buf);
}

static void stop_link(void);
static void hud_rebuild(void);

static void hud_tick(id self, SEL sel, id link) {
	(void)self;
	(void)sel;
	(void)link;
	if (!gHud || !gFps || !gChip)
		return;
	if (responds(gChip, "superview") && !msg0(gChip, "superview")) {
		stop_link();
		gChip = 0;
		gFps = 0;
		gCpu = 0;
		gGpu = 0;
		return;
	}
	double now = CACurrentMediaTime();
	double dt = now - gLast;
	gLast = now;
	gFrames += 1;
	if (now - gStamp < 0.25)
		return;
	double fps = gFrames / (now - gStamp);
	gFrames = 0;
	gStamp = now;
	id col;
	if (fps >= 100)
		col = color_rgba(0.56, 0.75, 0.60, 1);
	else if (fps >= 48)
		col = color_rgba(0.95, 0.95, 0.95, 1);
	else if (fps >= 20)
		col = color_rgba(0.77, 0.65, 0.45, 1);
	else
		col = color_rgba(0.77, 0.48, 0.45, 1);
	msg1(gFps, "setTextColor:", col);
	msg1(gFps, "setText:", fmt_fps(fps));
	if (gTel) {
		float cpu = cpu_load();
		float gpu = dt > 0 ? (float)(100.0 * dt * 120.0) : 0;
		if (gpu > 100)
			gpu = 100;
		msg1(gCpu, "setText:", fmt_pct(cpu));
		msg1(gGpu, "setText:", fmt_pct(gpu));
	}
	layout_chip();
}

static unsigned char hud_ignores(id self, SEL sel) {
	(void)self;
	(void)sel;
	return 1;
}

static unsigned char hud_nostatus(id self, SEL sel) {
	(void)self;
	(void)sel;
	return 0;
}

static Class ensure_win_class(void) {
	Class c = objc_getClass("VeloraHUDWindow");
	if (c)
		return c;
	Class super = objc_getClass("UIWindow");
	if (!super)
		return 0;
	c = objc_allocateClassPair(super, "VeloraHUDWindow", 0);
	if (!c)
		return 0;
	class_addMethod(c, sel_registerName("_ignoresHitTest"), (IMP)hud_ignores, "c@:");
	class_addMethod(c, sel_registerName("_canAffectStatusBarAppearance"), (IMP)hud_nostatus, "c@:");
	objc_registerClassPair(c);
	return c;
}

static void hud_boot(id self, SEL sel) {
	(void)self;
	(void)sel;
	hud_rebuild();
}

static Class ensure_ctl_class(void) {
	Class c = objc_getClass("VeloraHUDController");
	if (c)
		return c;
	Class super = objc_getClass("NSObject");
	if (!super)
		return 0;
	c = objc_allocateClassPair(super, "VeloraHUDController", 0);
	if (!c)
		return 0;
	class_addMethod(c, sel_registerName("tick:"), (IMP)hud_tick, "v@:@");
	class_addMethod(c, sel_registerName("boot"), (IMP)hud_boot, "v@:");
	class_addMethod(c, sel_registerName("bootNote:"), (IMP)hud_boot, "v@:@");
	objc_registerClassPair(c);
	return c;
}

static void stop_link(void) {
	if (gLink) {
		msg0(gLink, "invalidate");
		gLink = 0;
	}
}

static void hud_teardown(void) {
	stop_link();
	if (gChip && responds(gChip, "removeFromSuperview"))
		msg0(gChip, "removeFromSuperview");
	hide_bool(gWin, 1);
	gChip = 0;
	gFps = 0;
	gCpu = 0;
	gGpu = 0;
	gHost = 0;
}

static void attach_scene(id win, id host) {
	if (!win || !responds(win, "setWindowScene:"))
		return;
	id scene = 0;
	if (host && responds(host, "windowScene"))
		scene = msg0(host, "windowScene");
	if (!scene)
		scene = active_scene();
	if (scene)
		msg1(win, "setWindowScene:", scene);
}

static int win_has_scene(id win) {
	if (!win)
		return 0;
	if (!responds(win, "windowScene"))
		return 1;
	return msg0(win, "windowScene") ? 1 : 0;
}

static void build_chip(id parent) {
	id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	id chip = msg0(al(objc_getClass("UIView"), sel_registerName("alloc")), "init");
	msg1(chip, "setBackgroundColor:", color_rgba(0, 0, 0, 0.62));
	id layer = msg0(chip, "layer");
	if (layer && responds(layer, "setCornerRadius:")) {
		void (*cr)(id, SEL, double) = (void (*)(id, SEL, double))objc_msgSend;
		cr(layer, sel_registerName("setCornerRadius:"), 8);
	}
	if (layer && responds(layer, "setZPosition:")) {
		void (*zp)(id, SEL, double) = (void (*)(id, SEL, double))objc_msgSend;
		zp(layer, sel_registerName("setZPosition:"), 100000);
	}
	void (*ui)(id, SEL, unsigned char) = (void (*)(id, SEL, unsigned char))objc_msgSend;
	ui(chip, sel_registerName("setUserInteractionEnabled:"), 0);
	id muted = color_rgba(0.58, 0.58, 0.58, 1);
	id white = color_rgba(1, 1, 1, 1);
	id kF = make_label(8, 3, 28, 16, 8, muted, "FPS", 0);
	gFps = make_label(36, 3, 68, 16, 12, white, "—", 1);
	id kC = make_label(8, 20, 28, 16, 8, muted, "CPU", 0);
	gCpu = make_label(36, 20, 68, 16, 12, white, "—", 1);
	id kG = make_label(8, 37, 28, 16, 8, muted, "GPU", 0);
	gGpu = make_label(36, 37, 68, 16, 12, white, "—", 1);
	msg1(chip, "addSubview:", kF);
	msg1(chip, "addSubview:", gFps);
	msg1(chip, "addSubview:", kC);
	msg1(chip, "addSubview:", gCpu);
	msg1(chip, "addSubview:", kG);
	msg1(chip, "addSubview:", gGpu);
	msg1(parent, "addSubview:", chip);
	gChip = chip;
}

static void start_link(void) {
	stop_link();
	gFrames = 0;
	gStamp = CACurrentMediaTime();
	gLast = gStamp;
	if (!gCtl)
		return;
	id (*mk)(Class, SEL, id, SEL) = (id(*)(Class, SEL, id, SEL))objc_msgSend;
	gLink = mk(objc_getClass("CADisplayLink"), sel_registerName("displayLinkWithTarget:selector:"), gCtl, sel_registerName("tick:"));
	if (!gLink)
		return;
	if (responds(gLink, "setPreferredFramesPerSecond:")) {
		void (*sf)(id, SEL, NSInteger) = (void (*)(id, SEL, NSInteger))objc_msgSend;
		sf(gLink, sel_registerName("setPreferredFramesPerSecond:"), 0);
	}
	id loop = cls0(objc_getClass("NSRunLoop"), "mainRunLoop");
	id (*add)(id, SEL, id, id) = (id(*)(id, SEL, id, id))objc_msgSend;
	add(gLink, sel_registerName("addToRunLoop:forMode:"), loop, nsstr("kCFRunLoopCommonModes"));
	if (responds(gLink, "setPaused:")) {
		void (*sp)(id, SEL, unsigned char) = (void (*)(id, SEL, unsigned char))objc_msgSend;
		sp(gLink, sel_registerName("setPaused:"), 0);
	}
}

static void hud_rebuild_cb(void *ctx);

static void hud_hop_main(void) {
	void *async_f = dlsym(RTLD_DEFAULT, "dispatch_async_f");
	void *mainq = dlsym(RTLD_DEFAULT, "_dispatch_main_q");
	if (async_f && mainq) {
		typedef void (*daf_t)(void *, void *, void (*)(void *));
		((daf_t)async_f)(mainq, 0, hud_rebuild_cb);
		return;
	}
	if (gCtl) {
		void (*p)(id, SEL, SEL, id, unsigned char) = (void (*)(id, SEL, SEL, id, unsigned char))objc_msgSend;
		p(gCtl, sel_registerName("performSelectorOnMainThread:withObject:waitUntilDone:"), sel_registerName("boot"), 0, 0);
	}
}

static void hud_rebuild(void) {
	if (gBusy)
		return;
	if (!is_main_thread()) {
		hud_hop_main();
		return;
	}
	gBusy = 1;
	load_hud_prefs();
	if (!gHud || !hud_allowed()) {
		hud_teardown();
		gBusy = 0;
		return;
	}
	id win = first_window();
	if (!win) {
		gBusy = 0;
		return;
	}
	id host = host_view(win);
	if (!host) {
		gBusy = 0;
		return;
	}
	Class C = ensure_ctl_class();
	if (!C) {
		gBusy = 0;
		return;
	}
	if (!gCtl) {
		id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
		gCtl = msg0(al(C, sel_registerName("alloc")), "init");
	}
	if (gChip) {
		id sup = responds(gChip, "superview") ? msg0(gChip, "superview") : 0;
		if (sup != host) {
			if (gChip && responds(gChip, "removeFromSuperview"))
				msg0(gChip, "removeFromSuperview");
			gChip = 0;
			gFps = 0;
			gCpu = 0;
			gGpu = 0;
		}
	}
	gHost = host;
	if (!gChip)
		build_chip(host);
	hide_bool(gCpu, !gTel);
	hide_bool(gGpu, !gTel);
	hide_bool(gChip, 0);
	hide_bool(gWin, 1);
	layout_chip();
	start_link();
	gBusy = 0;
	gBooted = 1;
}

static void hud_rebuild_cb(void *ctx) {
	(void)ctx;
	hud_rebuild();
}

static int gInHook;

static void (*orig_mkv)(id, SEL);
static void hook_mkv(id self, SEL sel) {
	if (orig_mkv)
		orig_mkv(self, sel);
	if (is_kind(self, "VeloraHUDWindow"))
		return;
	if (gInHook)
		return;
	gInHook = 1;
	hud_rebuild();
	gInHook = 0;
}

static void (*orig_become)(id, SEL);
static void hook_become(id self, SEL sel) {
	if (orig_become)
		orig_become(self, sel);
	if (is_kind(self, "VeloraHUDWindow"))
		return;
	if (gInHook)
		return;
	gInHook = 1;
	hud_rebuild();
	gInHook = 0;
}

static void (*orig_send)(id, SEL, id);
static void hook_send(id self, SEL sel, id event) {
	if (orig_send)
		orig_send(self, sel, event);
	gEventN += 1;
	if ((gEventN % 18) != 0)
		return;
	if (!gHud || !hud_allowed())
		return;
	if (gInHook)
		return;
	if (!gChip || (gChip && msg0(gChip, "isHidden")))
		hud_rebuild();
}

static void (*orig_appear)(id, SEL, unsigned char);
static void hook_appear(id self, SEL sel, unsigned char animated) {
	if (orig_appear)
		orig_appear(self, sel, animated);
	if (gInHook)
		return;
	if (gHud && hud_allowed())
		hud_rebuild();
}

static void on_reload(void *center, void *obs, void *name, const void *obj, void *info) {
	(void)center;
	(void)obs;
	(void)name;
	(void)obj;
	(void)info;
	hud_hop_main();
}

static void hook_sel(MSHookMessageEx_t hook, const char *cls, const char *sel, void *imp, void **orig) {
	Class c = objc_getClass(cls);
	if (!c || !hook)
		return;
	SEL s = sel_registerName(sel);
	if (!class_getInstanceMethod(c, s))
		return;
	hook(c, s, imp, orig);
}

static void schedule_boot(double delay) {
	if (!gCtl)
		return;
	if (delay <= 0 && is_main_thread()) {
		hud_rebuild();
		return;
	}
	if (delay <= 0) {
		void (*p)(id, SEL, SEL, id, unsigned char) = (void (*)(id, SEL, SEL, id, unsigned char))objc_msgSend;
		p(gCtl, sel_registerName("performSelectorOnMainThread:withObject:waitUntilDone:"), sel_registerName("boot"), 0, 0);
		return;
	}
	void (*d)(id, SEL, SEL, id, double) = (void (*)(id, SEL, SEL, id, double))objc_msgSend;
	d(gCtl, sel_registerName("performSelector:withObject:afterDelay:"), sel_registerName("boot"), 0, delay);
}

void velora_hud_init(void) {
	id bid = current_bid();
	id main = cls0(objc_getClass("NSBundle"), "mainBundle");
	if (velora_skip_inject(cstr(bid), cstr(main ? msg0(main, "bundlePath") : 0)))
		return;
	if (streq(bid, "com.apple.springboard") || streq(bid, "com.apple.Preferences"))
		return;
	if (streq(bid, "com.apple.itunesstored") || streq(bid, "com.apple.appstored"))
		return;
	load_hud_prefs();
	Class C = ensure_ctl_class();
	if (C && !gCtl) {
		id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
		gCtl = msg0(al(C, sel_registerName("alloc")), "init");
	}
	if (gCtl) {
		id nc = cls0(objc_getClass("NSNotificationCenter"), "defaultCenter");
		if (nc && responds(nc, "addObserver:selector:name:object:")) {
			typedef id (*add_t)(id, SEL, id, SEL, id, id);
			add_t add = (add_t)objc_msgSend;
			add(nc, sel_registerName("addObserver:selector:name:object:"), gCtl, sel_registerName("bootNote:"), nsstr("UIApplicationDidBecomeActiveNotification"), 0);
			add(nc, sel_registerName("addObserver:selector:name:object:"), gCtl, sel_registerName("bootNote:"), nsstr("UIApplicationDidFinishLaunchingNotification"), 0);
			add(nc, sel_registerName("addObserver:selector:name:object:"), gCtl, sel_registerName("bootNote:"), nsstr("UIWindowDidBecomeKeyNotification"), 0);
		}
	}
	void *name = 0;
	id nm = nsstr("com.velora.hz/Reload");
	if (nm) {
		msg0(nm, "retain");
		name = (void *)nm;
	}
	if (name)
		CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), (const void *)0x564c52, (void *)on_reload, name, 0, 4);
	schedule_boot(0.35);
	schedule_boot(1.0);
	schedule_boot(2.5);
}
