/* Jailbreak detection bypass for selected apps. Own-device utility.
   Pixel Gun 3D uses AppSealing Unity RASP (Unity_IsAbnormalEnvironmentDetected,
   debugger/cheat-tool, process-list, Frida ports) on top of file/dyld checks.
   Do not MSHookFunction AppSealing C exports — their integrity check then
   freezes the cubic.games splash. Unity IL2CPP P/Invoke is intercepted via
   dlsym instead, which does not patch AppSealing .text. */
#include "velora-proc.h"
void *dlopen(const char *path, int mode);
void *dlsym(void *handle, const char *symbol);
#define RTLD_LAZY 1
#define RTLD_NOLOAD 0x10
#define RTLD_DEFAULT ((void *)-2)

typedef struct objc_class *Class;
typedef struct objc_object *id;
typedef struct objc_selector *SEL;
typedef long NSInteger;

extern Class objc_getClass(const char *name);
extern Class objc_getMetaClass(const char *name);
extern SEL sel_registerName(const char *name);
extern void objc_msgSend(void);
extern void *class_getInstanceMethod(Class cls, SEL name);
extern void *class_getClassMethod(Class cls, SEL name);
extern int *__error(void);

typedef void (*MSHookMessageEx_t)(Class cls, SEL sel, void *imp, void **orig);
typedef void (*MSHookFunction_t)(void *sym, void *hook, void **orig);
static MSHookMessageEx_t jbMsg;
static MSHookFunction_t jbFn;
static void *gUnusedOrig;

struct velora_dl_info {
	const char *dli_fname;
	void *dli_fbase;
	const char *dli_sname;
	void *dli_saddr;
};

static void set_enoent(void) {
	int *e = __error();
	if (e)
		*e = 2;
}

static void hide_symlink_stat(void *b) {
	unsigned short *mode;
	if (!b)
		return;
	mode = (unsigned short *)((char *)b + 4);
	if ((*mode & 0xF000) == 0xA000)
		*mode = (unsigned short)((*mode & ~0xF000) | 0x4000);
}

static id nsstr(const char *c) {
	id (*f)(Class, SEL, const char *) = (id(*)(Class, SEL, const char *))objc_msgSend;
	return f(objc_getClass("NSString"), sel_registerName("stringWithUTF8String:"), c);
}

static id msg0(id obj, const char *sel) {
	if (!obj)
		return 0;
	id (*f)(id, SEL) = (id(*)(id, SEL))objc_msgSend;
	return f(obj, sel_registerName(sel));
}

static id msg1(id obj, const char *sel, id a) {
	if (!obj)
		return 0;
	id (*f)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
	return f(obj, sel_registerName(sel), a);
}

static int streq(id a, const char *b) {
	if (!a)
		return 0;
	unsigned char (*eq)(id, SEL, id) = (unsigned char (*)(id, SEL, id))objc_msgSend;
	return eq(a, sel_registerName("isEqualToString:"), nsstr(b)) ? 1 : 0;
}

static const char *cstr(id s) {
	if (!s)
		return "";
	const char *(*f)(id, SEL) = (const char *(*)(id, SEL))objc_msgSend;
	const char *v = f(s, sel_registerName("UTF8String"));
	return v ? v : "";
}

static id empty_array(void) {
	return msg0((id)objc_getClass("NSArray"), "array");
}

static id current_bid(void) {
	id (*cm)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	id (*im)(id, SEL) = (id(*)(id, SEL))objc_msgSend;
	Class NB = objc_getClass("NSBundle");
	id main = NB ? cm(NB, sel_registerName("mainBundle")) : 0;
	return main ? im(main, sel_registerName("bundleIdentifier")) : 0;
}

static int protected_proc(id bid) {
	if (!bid)
		return 0;
	if (streq(bid, "com.apple.springboard") || streq(bid, "com.apple.Preferences"))
		return 1;
	if (streq(bid, "org.coolstar.SileoStore") || streq(bid, "org.coolstar.Sileo"))
		return 1;
	if (streq(bid, "xyz.willy.Zebra") || streq(bid, "com.saurik.Cydia"))
		return 1;
	if (streq(bid, "com.tigisoftware.Filza") || streq(bid, "ws.hbang.Terminal"))
		return 1;
	if (streq(bid, "com.opa334.TrollStore") || streq(bid, "com.opa334.TrollStoreLite"))
		return 1;
	if (velora_is_jbapp_bid(cstr(bid)))
		return 1;
	return 0;
}

static id plist_get(const char *key) {
	id (*dcf)(Class, SEL, id) = (id(*)(Class, SEL, id))objc_msgSend;
	Class D = objc_getClass("NSDictionary");
	const char *paths[] = {
		"/var/mobile/Library/Preferences/com.velora.hz.plist",
		"/var/jb/var/mobile/Library/Preferences/com.velora.hz.plist",
		"/var/jb/mnt/var/mobile/Library/Preferences/com.velora.hz.plist",
		0,
	};
	int i;
	if (!D)
		return 0;
	for (i = 0; paths[i]; i++) {
		id file = dcf(D, sel_registerName("dictionaryWithContentsOfFile:"), nsstr(paths[i]));
		id v = file ? msg1(file, "objectForKey:", nsstr(key)) : 0;
		if (v)
			return v;
	}
	return 0;
}

static int jb_should_run(void) {
	id bid = current_bid();
	id defs = 0, mode, arr, flag;
	const char *m;
	if (protected_proc(bid))
		return 0;
	flag = plist_get("jbBypass");
	if (!flag) {
		id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
		id obj = al(objc_getClass("NSUserDefaults"), sel_registerName("alloc"));
		id (*init)(id, SEL, id) = (id(*)(id, SEL, id))objc_msgSend;
		defs = init(obj, sel_registerName("initWithSuiteName:"), nsstr("com.velora.hz"));
		if (defs)
			flag = msg1(defs, "objectForKey:", nsstr("jbBypass"));
	}
	if (!flag)
		return 0;
	{
		unsigned char (*b)(id, SEL) = (unsigned char (*)(id, SEL))objc_msgSend;
		if (!b(flag, sel_registerName("boolValue")))
			return 0;
	}
	mode = plist_get("jbMode");
	if (!mode && defs)
		mode = msg1(defs, "stringForKey:", nsstr("jbMode"));
	m = cstr(mode);
	if (!m[0] || m[0] == 'a')
		return 1;
	arr = plist_get("VeloraJBApps");
	if (!arr && defs)
		arr = msg1(defs, "arrayForKey:", nsstr("VeloraJBApps"));
	if (!arr || !bid)
		return 0;
	{
		unsigned char (*contains)(id, SEL, id) = (unsigned char (*)(id, SEL, id))objc_msgSend;
		return contains(arr, sel_registerName("containsObject:"), bid) ? 1 : 0;
	}
}

static id filter_names(id arr, const char *dir) {
	id out;
	NSInteger n, i;
	if (!arr)
		return arr;
	{
		id (*al)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
		out = msg0(al(objc_getClass("NSMutableArray"), sel_registerName("alloc")), "init");
	}
	if (!out)
		return arr;
	{
		NSInteger (*cn)(id, SEL) = (NSInteger(*)(id, SEL))objc_msgSend;
		id (*at)(id, SEL, NSInteger) = (id(*)(id, SEL, NSInteger))objc_msgSend;
		n = cn(arr, sel_registerName("count"));
		for (i = 0; i < n; i++) {
			id name = at(arr, sel_registerName("objectAtIndex:"), i);
			const char *nm, *d;
			id pathish = name;
			id pobj = name ? msg0(name, "path") : 0;
			if (pobj)
				pathish = pobj;
			nm = cstr(pathish);
			if (velora_jb_path(nm))
				continue;
			d = dir ? dir : "";
			if (d[0] && nm[0] && nm[0] != '/') {
				char full[768];
				int k = 0;
				while (d[k] && k < 600) {
					full[k] = d[k];
					k++;
				}
				if (k && full[k - 1] != '/')
					full[k++] = '/';
				while (*nm && k < 766)
					full[k++] = *nm++;
				full[k] = 0;
				if (velora_jb_path(full))
					continue;
			}
			msg1(out, "addObject:", name);
		}
	}
	return out;
}

static unsigned char (*orig_exists)(id, SEL, id);
static unsigned char hook_exists(id self, SEL sel, id path) {
	if (velora_jb_path(cstr(path)))
		return 0;
	return orig_exists ? orig_exists(self, sel, path) : 0;
}

static unsigned char (*orig_existsDir)(id, SEL, id, unsigned char *);
static unsigned char hook_existsDir(id self, SEL sel, id path, unsigned char *isDir) {
	if (velora_jb_path(cstr(path))) {
		if (isDir)
			*isDir = 0;
		return 0;
	}
	return orig_existsDir ? orig_existsDir(self, sel, path, isDir) : 0;
}

static unsigned char (*orig_readable)(id, SEL, id);
static unsigned char hook_readable(id self, SEL sel, id path) {
	if (velora_jb_path(cstr(path)))
		return 0;
	return orig_readable ? orig_readable(self, sel, path) : 0;
}

static unsigned char (*orig_writable)(id, SEL, id);
static unsigned char hook_writable(id self, SEL sel, id path) {
	if (velora_jb_write_path(cstr(path)))
		return 0;
	return orig_writable ? orig_writable(self, sel, path) : 0;
}

static unsigned char (*orig_exec)(id, SEL, id);
static unsigned char hook_exec(id self, SEL sel, id path) {
	if (velora_jb_path(cstr(path)))
		return 0;
	return orig_exec ? orig_exec(self, sel, path) : 0;
}

static id (*orig_attrs)(id, SEL, id, id *);
static id hook_attrs(id self, SEL sel, id path, id *err) {
	if (velora_jb_path(cstr(path))) {
		if (err)
			*err = 0;
		return 0;
	}
	return orig_attrs ? orig_attrs(self, sel, path, err) : 0;
}

static id (*orig_list)(id, SEL, id, id *);
static id hook_list(id self, SEL sel, id path, id *err) {
	if (velora_jb_path(cstr(path))) {
		if (err)
			*err = 0;
		return empty_array();
	}
	return filter_names(orig_list ? orig_list(self, sel, path, err) : 0, cstr(path));
}

static id (*orig_listURL)(id, SEL, id, id, unsigned long, id *);
static id hook_listURL(id self, SEL sel, id url, id keys, unsigned long opts, id *err) {
	id p = url ? msg0(url, "path") : 0;
	if (velora_jb_path(cstr(p))) {
		if (err)
			*err = 0;
		return empty_array();
	}
	return filter_names(orig_listURL ? orig_listURL(self, sel, url, keys, opts, err) : 0, cstr(p));
}

static id (*orig_enumPath)(id, SEL, id);
static id hook_enumPath(id self, SEL sel, id path) {
	if (velora_jb_path(cstr(path)))
		return 0;
	return orig_enumPath ? orig_enumPath(self, sel, path) : 0;
}

static id (*orig_destLink)(id, SEL, id, id *);
static id hook_destLink(id self, SEL sel, id path, id *err) {
	const char *p = cstr(path);
	id r;
	if (velora_jb_path(p) || velora_jb_stash_path(p)) {
		if (err)
			*err = 0;
		return 0;
	}
	r = orig_destLink ? orig_destLink(self, sel, path, err) : 0;
	if (r && velora_jb_path(cstr(r)))
		return 0;
	return r;
}

static id (*orig_contents)(id, SEL, id);
static id hook_contents(id self, SEL sel, id path) {
	if (velora_jb_path(cstr(path)))
		return 0;
	return orig_contents ? orig_contents(self, sel, path) : 0;
}

static id (*orig_next)(id, SEL);
static id hook_next(id self, SEL sel) {
	id obj;
	for (;;) {
		obj = orig_next ? orig_next(self, sel) : 0;
		if (!obj)
			return 0;
		if (!velora_jb_path(cstr(obj)))
			return obj;
	}
}

static unsigned char (*orig_reachable)(id, SEL, id *);
static unsigned char hook_reachable(id self, SEL sel, id *err) {
	id p = msg0(self, "path");
	if (velora_jb_path(cstr(p))) {
		if (err)
			*err = 0;
		return 0;
	}
	return orig_reachable ? orig_reachable(self, sel, err) : 0;
}

static unsigned char (*orig_strWrite)(id, SEL, id, unsigned char, unsigned long, id *);
static unsigned char hook_strWrite(id self, SEL sel, id path, unsigned char atom, unsigned long enc, id *err) {
	if (velora_jb_write_path(cstr(path))) {
		if (err)
			*err = 0;
		return 0;
	}
	return orig_strWrite ? orig_strWrite(self, sel, path, atom, enc, err) : 0;
}

static unsigned char (*orig_dataWrite)(id, SEL, id, unsigned char);
static unsigned char hook_dataWrite(id self, SEL sel, id path, unsigned char atom) {
	if (velora_jb_write_path(cstr(path)))
		return 0;
	return orig_dataWrite ? orig_dataWrite(self, sel, path, atom) : 0;
}

static id (*orig_dataFile)(Class, SEL, id);
static id hook_dataFile(Class self, SEL sel, id path) {
	if (velora_jb_path(cstr(path)))
		return 0;
	return orig_dataFile ? orig_dataFile(self, sel, path) : 0;
}

static id (*orig_dataURL)(Class, SEL, id);
static id hook_dataURL(Class self, SEL sel, id url) {
	id scheme = url ? msg0(url, "scheme") : 0;
	id path = url ? msg0(url, "path") : 0;
	if (streq(scheme, "file") && velora_jb_path(cstr(path)))
		return 0;
	return orig_dataURL ? orig_dataURL(self, sel, url) : 0;
}

static id (*orig_stringFile)(Class, SEL, id, unsigned long, id *);
static id hook_stringFile(Class self, SEL sel, id path, unsigned long enc, id *err) {
	if (velora_jb_path(cstr(path))) {
		if (err)
			*err = 0;
		return 0;
	}
	return orig_stringFile ? orig_stringFile(self, sel, path, enc, err) : 0;
}

static id (*orig_handle)(Class, SEL, id);
static id hook_handle(Class self, SEL sel, id path) {
	if (velora_jb_path(cstr(path)))
		return 0;
	return orig_handle ? orig_handle(self, sel, path) : 0;
}

static unsigned char (*orig_canOpen)(id, SEL, id);
static unsigned char hook_canOpen(id self, SEL sel, id url) {
	id abs = url ? msg0(url, "absoluteString") : 0;
	if (!abs && url)
		abs = msg0(url, "scheme");
	if (velora_jb_scheme(cstr(abs)))
		return 0;
	return orig_canOpen ? orig_canOpen(self, sel, url) : 0;
}

static unsigned char (*orig_openURL)(id, SEL, id);
static unsigned char hook_openURL(id self, SEL sel, id url) {
	id abs = url ? msg0(url, "absoluteString") : 0;
	if (velora_jb_scheme(cstr(abs)))
		return 0;
	return orig_openURL ? orig_openURL(self, sel, url) : 0;
}

static void (*orig_openOpts)(id, SEL, id, id, id);
static void hook_openOpts(id self, SEL sel, id url, id opts, id comp) {
	id abs = url ? msg0(url, "absoluteString") : 0;
	if (velora_jb_scheme(cstr(abs)))
		return;
	if (orig_openOpts)
		orig_openOpts(self, sel, url, opts, comp);
}

static id (*orig_env)(id, SEL);
static id hook_env(id self, SEL sel) {
	id e = orig_env ? orig_env(self, sel) : 0;
	id m, keys;
	NSInteger n, i;
	if (!e)
		return e;
	m = msg0(e, "mutableCopy");
	if (!m)
		return e;
	keys = msg0(e, "allKeys");
	if (!keys)
		return m;
	{
		NSInteger (*cn)(id, SEL) = (NSInteger(*)(id, SEL))objc_msgSend;
		id (*at)(id, SEL, NSInteger) = (id(*)(id, SEL, NSInteger))objc_msgSend;
		n = cn(keys, sel_registerName("count"));
		for (i = 0; i < n; i++) {
			id k = at(keys, sel_registerName("objectAtIndex:"), i);
			if (velora_jb_env(cstr(k)))
				msg1(m, "removeObjectForKey:", k);
		}
	}
	return m;
}

static id (*orig_bundlePath)(Class, SEL, id);
static id hook_bundlePath(Class self, SEL sel, id path) {
	if (velora_jb_path(cstr(path)))
		return 0;
	return orig_bundlePath ? orig_bundlePath(self, sel, path) : 0;
}

static unsigned char (*orig_installed)(id, SEL, id);
static unsigned char hook_installed(id self, SEL sel, id bid) {
	const char *c = cstr(bid);
	if (velora_cstr_has(c, "cydia") || velora_cstr_has(c, "sileo") || velora_cstr_has(c, "zebra") || velora_cstr_has(c, "filza"))
		return 0;
	if (velora_cstr_has(c, "dopamine") || velora_cstr_has(c, "palera1n") || velora_cstr_has(c, "undecimus"))
		return 0;
	if (velora_cstr_has(c, "trollstore") || velora_cstr_has(c, "trollhelper") || velora_cstr_has(c, "icleaner"))
		return 0;
	if (velora_cstr_has(c, "electra") || velora_cstr_has(c, "chimera") || velora_cstr_has(c, "taurine") || velora_cstr_has(c, "odyssey"))
		return 0;
	if (velora_cstr_has(c, "newterm") || velora_cstr_has(c, "activator") || velora_cstr_has(c, "xina"))
		return 0;
	return orig_installed ? orig_installed(self, sel, bid) : 0;
}

static id (*orig_handlers)(id, SEL, id);
static id hook_handlers(id self, SEL sel, id scheme) {
	char buf[80];
	const char *s = cstr(scheme);
	int i = 0;
	if (velora_jb_scheme(s))
		return empty_array();
	while (s[i] && i < 60) {
		buf[i] = s[i];
		i++;
	}
	buf[i++] = ':';
	buf[i++] = '/';
	buf[i++] = '/';
	buf[i] = 0;
	if (velora_jb_scheme(buf))
		return empty_array();
	return orig_handlers ? orig_handlers(self, sel, scheme) : 0;
}

static unsigned char hook_not_jb(id self, SEL sel) {
	(void)self;
	(void)sel;
	return 0;
}

static char *(*orig_getenv)(const char *);
static char *hook_getenv(const char *name) {
	if (velora_jb_env(name))
		return 0;
	return orig_getenv ? orig_getenv(name) : 0;
}

static int (*orig_stat)(const char *, void *);
static int hook_stat(const char *p, void *b) {
	int r;
	if (velora_jb_path(p)) {
		set_enoent();
		return -1;
	}
	r = orig_stat ? orig_stat(p, b) : -1;
	if (r == 0 && velora_jb_stash_path(p))
		hide_symlink_stat(b);
	return r;
}

static int (*orig_lstat)(const char *, void *);
static int hook_lstat(const char *p, void *b) {
	int r;
	if (velora_jb_path(p)) {
		set_enoent();
		return -1;
	}
	r = orig_lstat ? orig_lstat(p, b) : -1;
	if (r == 0 && velora_jb_stash_path(p))
		hide_symlink_stat(b);
	return r;
}

static int (*orig_stat64)(const char *, void *);
static int hook_stat64(const char *p, void *b) {
	int r;
	if (velora_jb_path(p)) {
		set_enoent();
		return -1;
	}
	r = orig_stat64 ? orig_stat64(p, b) : -1;
	if (r == 0 && velora_jb_stash_path(p))
		hide_symlink_stat(b);
	return r;
}

static int (*orig_lstat64)(const char *, void *);
static int hook_lstat64(const char *p, void *b) {
	int r;
	if (velora_jb_path(p)) {
		set_enoent();
		return -1;
	}
	r = orig_lstat64 ? orig_lstat64(p, b) : -1;
	if (r == 0 && velora_jb_stash_path(p))
		hide_symlink_stat(b);
	return r;
}

static int (*orig_fstatat)(int, const char *, void *, int);
static int hook_fstatat(int fd, const char *p, void *b, int flag) {
	if (velora_jb_path(p)) {
		set_enoent();
		return -1;
	}
	return orig_fstatat ? orig_fstatat(fd, p, b, flag) : -1;
}

static int (*orig_access)(const char *, int);
static int hook_access(const char *p, int m) {
	if (velora_jb_path(p) || ((m & 2) && velora_jb_write_path(p))) {
		set_enoent();
		return -1;
	}
	return orig_access ? orig_access(p, m) : -1;
}

static int (*orig_faccessat)(int, const char *, int, int);
static int hook_faccessat(int fd, const char *p, int m, int flag) {
	if (velora_jb_path(p) || ((m & 2) && velora_jb_write_path(p))) {
		set_enoent();
		return -1;
	}
	return orig_faccessat ? orig_faccessat(fd, p, m, flag) : -1;
}

static void *(*orig_fopen)(const char *, const char *);
static void *hook_fopen(const char *p, const char *m) {
	if (velora_jb_path(p) || (m && m[0] == 'w' && velora_jb_write_path(p))) {
		set_enoent();
		return 0;
	}
	return orig_fopen ? orig_fopen(p, m) : 0;
}

static void *(*orig_freopen)(const char *, const char *, void *);
static void *hook_freopen(const char *p, const char *m, void *s) {
	if (velora_jb_path(p) || (m && m[0] == 'w' && velora_jb_write_path(p))) {
		set_enoent();
		return 0;
	}
	return orig_freopen ? orig_freopen(p, m, s) : 0;
}

static int (*orig_open)(const char *, int, int);
static int hook_open(const char *p, int flags, int mode) {
	if (velora_jb_path(p) || ((flags & 0x603) && velora_jb_write_path(p))) {
		set_enoent();
		return -1;
	}
	return orig_open ? orig_open(p, flags, mode) : -1;
}

static int (*orig_openat)(int, const char *, int, int);
static int hook_openat(int fd, const char *p, int flags, int mode) {
	if (velora_jb_path(p) || ((flags & 0x603) && velora_jb_write_path(p))) {
		set_enoent();
		return -1;
	}
	return orig_openat ? orig_openat(fd, p, flags, mode) : -1;
}

static char *(*orig_realpath)(const char *, char *);
static char *hook_realpath(const char *p, char *resolved) {
	char *r;
	if (velora_jb_path(p)) {
		set_enoent();
		return 0;
	}
	r = orig_realpath ? orig_realpath(p, resolved) : 0;
	if (r && velora_jb_path(r)) {
		set_enoent();
		return 0;
	}
	return r;
}

static long (*orig_readlink)(const char *, char *, unsigned long);
static long hook_readlink(const char *p, char *buf, unsigned long sz) {
	if (velora_jb_path(p) || velora_jb_stash_path(p)) {
		set_enoent();
		return -1;
	}
	return orig_readlink ? orig_readlink(p, buf, sz) : -1;
}

static long (*orig_readlinkat)(int, const char *, char *, unsigned long);
static long hook_readlinkat(int fd, const char *p, char *buf, unsigned long sz) {
	if (velora_jb_path(p) || velora_jb_stash_path(p)) {
		set_enoent();
		return -1;
	}
	return orig_readlinkat ? orig_readlinkat(fd, p, buf, sz) : -1;
}

static void *(*orig_opendir)(const char *);
static void *hook_opendir(const char *p) {
	if (velora_jb_path(p)) {
		set_enoent();
		return 0;
	}
	return orig_opendir ? orig_opendir(p) : 0;
}

static int (*orig_statfs)(const char *, void *);
static int hook_statfs(const char *p, void *b) {
	if (velora_jb_path(p)) {
		set_enoent();
		return -1;
	}
	return orig_statfs ? orig_statfs(p, b) : -1;
}

static const char *(*orig_dyld)(unsigned int);
static const char *hook_dyld(unsigned int i) {
	const char *n = orig_dyld ? orig_dyld(i) : 0;
	if (n && velora_jb_path(n))
		return "/usr/lib/system/libsystem_c.dylib";
	return n;
}

static const char **(*orig_copyImages)(unsigned int *);
static const char **hook_copyImages(unsigned int *outCount) {
	const char **names = orig_copyImages ? orig_copyImages(outCount) : 0;
	unsigned int n, w, i;
	if (!names || !outCount)
		return names;
	n = *outCount;
	w = 0;
	for (i = 0; i < n; i++) {
		if (names[i] && velora_jb_path(names[i]))
			continue;
		names[w++] = names[i];
	}
	*outCount = w;
	names[w] = 0;
	return names;
}

static const char *(*orig_classImage)(Class);
static const char *hook_classImage(Class cls) {
	const char *n = orig_classImage ? orig_classImage(cls) : 0;
	if (n && velora_jb_path(n))
		return "/usr/lib/libobjc.A.dylib";
	return n;
}

static Class (*orig_getClass)(const char *);
static Class hook_getClass(const char *name) {
	if (velora_jb_class(name))
		return 0;
	return orig_getClass ? orig_getClass(name) : 0;
}

static Class (*orig_classFromStr)(id);
static Class hook_classFromStr(id name) {
	if (velora_jb_class(cstr(name)))
		return 0;
	return orig_classFromStr ? orig_classFromStr(name) : 0;
}

static void *(*orig_dlopen)(const char *, int);
static void *hook_dlopen(const char *p, int mode) {
	if (p && velora_jb_path(p))
		return 0;
	return orig_dlopen ? orig_dlopen(p, mode) : 0;
}

static int hook_rasp_zero(void);
static const char *hook_rasp_no(void);

static void *(*orig_dlsym)(void *, const char *);
static void *hook_dlsym(void *h, const char *name) {
	int kind;
	if (name) {
		if (velora_cstr_eq(name, "MSHookFunction") || velora_cstr_eq(name, "MSHookMessageEx") || velora_cstr_eq(name, "MSFindSymbol") || velora_cstr_eq(name, "MSGetImageByName"))
			return 0;
		if (velora_cstr_eq(name, "SubHookFunction") || velora_cstr_eq(name, "LHHookFunctions") || velora_cstr_has(name, "gum_interceptor") || velora_cstr_has(name, "frida_"))
			return 0;
		kind = velora_jb_rasp_kind(name);
		if (kind == 2)
			return (void *)hook_rasp_no;
		if (kind == 1)
			return (void *)hook_rasp_zero;
	}
	return orig_dlsym ? orig_dlsym(h, name) : 0;
}

static int (*orig_dladdr)(const void *, struct velora_dl_info *);
static int hook_dladdr(const void *addr, struct velora_dl_info *info) {
	int r = orig_dladdr ? orig_dladdr(addr, info) : 0;
	if (r && info && info->dli_fname && velora_jb_path(info->dli_fname))
		info->dli_fname = "/usr/lib/system/libsystem_c.dylib";
	return r;
}

static int (*orig_fork)(void);
static int hook_fork(void) {
	int *e = __error();
	if (e)
		*e = 1;
	return -1;
}

static int (*orig_vfork)(void);
static int hook_vfork(void) {
	return -1;
}

static int (*orig_getppid)(void);
static int hook_getppid(void) {
	return 1;
}

static int (*orig_ptrace)(int, int, void *, int);
static int hook_ptrace(int req, int pid, void *addr, int data) {
	(void)req;
	(void)pid;
	(void)addr;
	(void)data;
	return 0;
}

static int (*orig_csops)(int, unsigned int, void *, unsigned long);
static int hook_csops(int pid, unsigned int ops, void *useraddr, unsigned long usersize) {
	int r = orig_csops ? orig_csops(pid, ops, useraddr, usersize) : -1;
	if (ops == 0 && useraddr && usersize >= 4 && r == 0) {
		unsigned int *f = (unsigned int *)useraddr;
		*f &= ~0x10000000u;
	}
	return r;
}

static int (*orig_posix_spawn)(void *, const char *, const void *, const void *, char *const *, char *const *);
static int hook_posix_spawn(void *pid, const char *path, const void *fa, const void *attr, char *const *argv, char *const *envp) {
	if (velora_jb_path(path) || velora_jb_cmd(path))
		return 1;
	return orig_posix_spawn ? orig_posix_spawn(pid, path, fa, attr, argv, envp) : 1;
}

static int (*orig_posix_spawnp)(void *, const char *, const void *, const void *, char *const *, char *const *);
static int hook_posix_spawnp(void *pid, const char *path, const void *fa, const void *attr, char *const *argv, char *const *envp) {
	if (velora_jb_path(path) || velora_jb_cmd(path))
		return 1;
	return orig_posix_spawnp ? orig_posix_spawnp(pid, path, fa, attr, argv, envp) : 1;
}

static int (*orig_execve)(const char *, char *const *, char *const *);
static int hook_execve(const char *path, char *const *argv, char *const *envp) {
	if (velora_jb_path(path) || velora_jb_cmd(path)) {
		set_enoent();
		return -1;
	}
	return orig_execve ? orig_execve(path, argv, envp) : -1;
}

static void *(*orig_popen)(const char *, const char *);
static void *hook_popen(const char *cmd, const char *mode) {
	if (velora_jb_cmd(cmd))
		return 0;
	return orig_popen ? orig_popen(cmd, mode) : 0;
}

static int (*orig_system)(const char *);
static int hook_system(const char *cmd) {
	if (velora_jb_cmd(cmd))
		return 127;
	return orig_system ? orig_system(cmd) : 127;
}

static int (*orig_sysctl)(int *, unsigned int, void *, unsigned long *, void *, unsigned long);
static int hook_sysctl(int *name, unsigned int namelen, void *oldp, unsigned long *oldlenp, void *newp, unsigned long newlen) {
	int r = orig_sysctl ? orig_sysctl(name, namelen, oldp, oldlenp, newp, newlen) : -1;
	if (r == 0 && oldp && name && namelen >= 4 && name[0] == 1 && name[1] == 14 && name[2] == 1) {
		unsigned long n = oldlenp ? *oldlenp : 0;
		if (n >= 36) {
			int *flag = (int *)((char *)oldp + 32);
			*flag &= ~0x00000800;
		}
	}
	if (r == 0 && oldp && oldlenp && name && namelen >= 2 && name[0] == 1 && name[1] == 14)
		velora_jb_scrub_procbuf((char *)oldp, *oldlenp);
	return r;
}

static int (*orig_sysctlbyname)(const char *, void *, unsigned long *, void *, unsigned long);
static int hook_sysctlbyname(const char *name, void *oldp, unsigned long *oldlenp, void *newp, unsigned long newlen) {
	int r = orig_sysctlbyname ? orig_sysctlbyname(name, oldp, oldlenp, newp, newlen) : -1;
	if (r == 0 && oldp && name && velora_cstr_eq(name, "kern.bootargs")) {
		char *s = (char *)oldp;
		if (velora_cstr_has(s, "amfi") || velora_cstr_has(s, "cs_enforcement") || velora_cstr_has(s, "out_of_my_way")) {
			s[0] = 0;
			if (oldlenp)
				*oldlenp = 1;
		}
	}
	return r;
}

static long (*orig_syscall)(long, long, long, long, long, long, long, long);
static long hook_syscall(long number, long a1, long a2, long a3, long a4, long a5, long a6, long a7) {
	int slot, spec;
	const char *p;
	spec = velora_jb_syscall_special((int)number);
	if (spec == 1)
		return -1;
	if (spec == 2)
		return 0;
	if (spec == 3)
		return 1;
	if (spec == 4) {
		long r = orig_syscall ? orig_syscall(number, a1, a2, a3, a4, a5, a6, a7) : -1;
		if (r == 0 && a2 == 0 && a3 && a4 >= 4) {
			unsigned int *f = (unsigned int *)a3;
			*f &= ~0x10000000u;
		}
		return r;
	}
	slot = velora_jb_syscall_path_slot((int)number);
	p = slot == 1 ? (const char *)a1 : (slot == 2 ? (const char *)a2 : 0);
	if (p && velora_jb_path(p)) {
		set_enoent();
		return -1;
	}
	if ((number == 59 || number == 244) && (velora_jb_path((const char *)a1) || velora_jb_cmd((const char *)a1)))
		return 1;
	if (number == 98 && velora_jb_loopback_debug((const unsigned char *)a2, (unsigned int)a3)) {
		int *e = __error();
		if (e)
			*e = 61;
		return -1;
	}
	return orig_syscall ? orig_syscall(number, a1, a2, a3, a4, a5, a6, a7) : -1;
}

static int hook_rasp_zero(void) {
	return 0;
}

static const char *hook_rasp_no(void) {
	return "NO";
}

static id hook_hacking_str(id self, SEL sel) {
	(void)self;
	(void)sel;
	return nsstr("NO");
}

static int (*orig_connect)(int, const unsigned char *, unsigned int);
static int hook_connect(int fd, const unsigned char *addr, unsigned int len) {
	if (velora_jb_loopback_debug(addr, len)) {
		int *e = __error();
		if (e)
			*e = 61;
		return -1;
	}
	return orig_connect ? orig_connect(fd, addr, len) : -1;
}

static int (*orig_proc_name)(int, char *, unsigned long);
static int hook_proc_name(int pid, char *buf, unsigned long sz) {
	int n = orig_proc_name ? orig_proc_name(pid, buf, sz) : 0;
	if (n > 0 && buf && velora_jb_proc_name(buf)) {
		if (sz)
			buf[0] = 0;
		return 0;
	}
	return n;
}

static int (*orig_proc_pidpath)(int, char *, unsigned long);
static int hook_proc_pidpath(int pid, char *buf, unsigned long sz) {
	int n = orig_proc_pidpath ? orig_proc_pidpath(pid, buf, sz) : 0;
	if (n > 0 && buf && (velora_jb_path(buf) || velora_jb_proc_name(buf))) {
		if (sz)
			buf[0] = 0;
		return 0;
	}
	return n;
}

static void hook_sel(Class cls, const char *name, void *imp, void **orig) {
	SEL sel;
	if (!jbMsg || !cls || !name || !imp)
		return;
	sel = sel_registerName(name);
	if (!class_getInstanceMethod(cls, sel) && !class_getClassMethod(cls, sel))
		return;
	jbMsg(cls, sel, imp, orig);
}

static void hook_cls_bool(const char *cn, const char *sn) {
	Class c = objc_getClass(cn);
	Class m;
	if (!c || !jbMsg)
		return;
	m = objc_getMetaClass(cn);
	if (m && class_getClassMethod(c, sel_registerName(sn)))
		jbMsg(m, sel_registerName(sn), (void *)hook_not_jb, &gUnusedOrig);
	if (class_getInstanceMethod(c, sel_registerName(sn)))
		jbMsg(c, sel_registerName(sn), (void *)hook_not_jb, &gUnusedOrig);
}

static void hook_cls_str_no(const char *cn, const char *sn) {
	Class c = objc_getClass(cn);
	Class m;
	if (!c || !jbMsg)
		return;
	m = objc_getMetaClass(cn);
	if (m && class_getClassMethod(c, sel_registerName(sn)))
		jbMsg(m, sel_registerName(sn), (void *)hook_hacking_str, &gUnusedOrig);
	if (class_getInstanceMethod(c, sel_registerName(sn)))
		jbMsg(c, sel_registerName(sn), (void *)hook_hacking_str, &gUnusedOrig);
}

static void hook_sym(const char *name, void *imp, void **orig) {
	void *s;
	if (!jbFn || !name || !imp)
		return;
	s = dlsym(RTLD_DEFAULT, name);
	if (s)
		jbFn(s, imp, orig);
}

static void resolve_hooks(void) {
	if (!jbMsg)
		jbMsg = (MSHookMessageEx_t)dlsym(RTLD_DEFAULT, "MSHookMessageEx");
	if (!jbFn)
		jbFn = (MSHookFunction_t)dlsym(RTLD_DEFAULT, "MSHookFunction");
	if (jbMsg && jbFn)
		return;
	{
		const char *libs[] = {
			"/var/jb/usr/lib/libellekit.dylib",
			"/var/jb/usr/lib/libsubstrate.dylib",
			"/usr/lib/libellekit.dylib",
			"/usr/lib/libsubstrate.dylib",
			"/usr/lib/libhooker.dylib",
			"/var/jb/usr/lib/libhooker.dylib",
			0,
		};
		void *h = 0;
		int i;
		for (i = 0; libs[i] && !h; i++)
			h = dlopen(libs[i], RTLD_NOLOAD | RTLD_LAZY);
		if (h) {
			if (!jbMsg)
				jbMsg = (MSHookMessageEx_t)dlsym(h, "MSHookMessageEx");
			if (!jbFn)
				jbFn = (MSHookFunction_t)dlsym(h, "MSHookFunction");
		}
	}
}

void velora_jb_init(void) {
	static int once;
	id bid = current_bid();
	id (*cm)(Class, SEL) = (id(*)(Class, SEL))objc_msgSend;
	id (*im)(id, SEL) = (id(*)(id, SEL))objc_msgSend;
	Class NB = objc_getClass("NSBundle");
	id main = NB ? cm(NB, sel_registerName("mainBundle")) : 0;
	id path = main ? im(main, sel_registerName("bundlePath")) : 0;
	if (velora_skip_inject(cstr(bid), cstr(path)))
		return;
	if (!jb_should_run())
		return;
	if (once)
		return;
	once = 1;
	resolve_hooks();
	if (jbMsg) {
		Class fm = objc_getClass("NSFileManager");
		if (fm) {
			hook_sel(fm, "fileExistsAtPath:", (void *)hook_exists, (void **)&orig_exists);
			hook_sel(fm, "fileExistsAtPath:isDirectory:", (void *)hook_existsDir, (void **)&orig_existsDir);
			hook_sel(fm, "isReadableFileAtPath:", (void *)hook_readable, (void **)&orig_readable);
			hook_sel(fm, "isWritableFileAtPath:", (void *)hook_writable, (void **)&orig_writable);
			hook_sel(fm, "isExecutableFileAtPath:", (void *)hook_exec, (void **)&orig_exec);
			hook_sel(fm, "attributesOfItemAtPath:error:", (void *)hook_attrs, (void **)&orig_attrs);
			hook_sel(fm, "contentsOfDirectoryAtPath:error:", (void *)hook_list, (void **)&orig_list);
			hook_sel(fm, "contentsOfDirectoryAtURL:includingPropertiesForKeys:options:error:", (void *)hook_listURL, (void **)&orig_listURL);
			hook_sel(fm, "enumeratorAtPath:", (void *)hook_enumPath, (void **)&orig_enumPath);
			hook_sel(fm, "destinationOfSymbolicLinkAtPath:error:", (void *)hook_destLink, (void **)&orig_destLink);
			hook_sel(fm, "contentsAtPath:", (void *)hook_contents, (void **)&orig_contents);
		}
		{
			Class en = objc_getClass("NSDirectoryEnumerator");
			if (en)
				hook_sel(en, "nextObject", (void *)hook_next, (void **)&orig_next);
		}
		{
			Class nu = objc_getClass("NSURL");
			if (nu)
				hook_sel(nu, "checkResourceIsReachableAndReturnError:", (void *)hook_reachable, (void **)&orig_reachable);
		}
		{
			Class ns = objc_getClass("NSString");
			if (ns)
				hook_sel(ns, "writeToFile:atomically:encoding:error:", (void *)hook_strWrite, (void **)&orig_strWrite);
		}
		{
			Class ndi = objc_getClass("NSData");
			if (ndi)
				hook_sel(ndi, "writeToFile:atomically:", (void *)hook_dataWrite, (void **)&orig_dataWrite);
		}
		{
			Class nd = objc_getMetaClass("NSData");
			if (nd) {
				hook_sel(nd, "dataWithContentsOfFile:", (void *)hook_dataFile, (void **)&orig_dataFile);
				hook_sel(nd, "dataWithContentsOfURL:", (void *)hook_dataURL, (void **)&orig_dataURL);
			}
		}
		{
			Class ns = objc_getMetaClass("NSString");
			if (ns)
				hook_sel(ns, "stringWithContentsOfFile:encoding:error:", (void *)hook_stringFile, (void **)&orig_stringFile);
		}
		{
			Class nh = objc_getMetaClass("NSFileHandle");
			if (nh)
				hook_sel(nh, "fileHandleForReadingAtPath:", (void *)hook_handle, (void **)&orig_handle);
		}
		{
			Class nb = objc_getMetaClass("NSBundle");
			if (nb)
				hook_sel(nb, "bundleWithPath:", (void *)hook_bundlePath, (void **)&orig_bundlePath);
		}
		{
			Class app = objc_getClass("UIApplication");
			if (app) {
				hook_sel(app, "canOpenURL:", (void *)hook_canOpen, (void **)&orig_canOpen);
				hook_sel(app, "openURL:", (void *)hook_openURL, (void **)&orig_openURL);
				hook_sel(app, "openURL:options:completionHandler:", (void *)hook_openOpts, (void **)&orig_openOpts);
			}
		}
		{
			Class pi = objc_getClass("NSProcessInfo");
			if (pi)
				hook_sel(pi, "environment", (void *)hook_env, (void **)&orig_env);
		}
		{
			Class ls = objc_getClass("LSApplicationWorkspace");
			if (ls) {
				hook_sel(ls, "applicationIsInstalled:", (void *)hook_installed, (void **)&orig_installed);
				hook_sel(ls, "applicationsAvailableForHandlingURLScheme:", (void *)hook_handlers, (void **)&orig_handlers);
			}
		}
		hook_cls_bool("DTTJailbreakDetection", "isJailbroken");
		hook_cls_bool("DTTJailbreakDetection", "isJailBroken");
		hook_cls_bool("IOSSecuritySuite", "amIJailbroken");
		hook_cls_bool("IOSSecuritySuite", "amIDebugged");
		hook_cls_bool("IOSSecuritySuite", "amIReverseEngineered");
		hook_cls_bool("IOSSecuritySuite", "amIRunInEmulator");
		hook_cls_bool("IOSSecuritySuite", "isParentPidUnexpected");
		hook_cls_bool("IOSSecuritySuite", "amIProxied");
		hook_cls_bool("AppsFlyerUtils", "isJailbrokenWithSkipAdvancedJailbreakValidation:");
		hook_cls_bool("AppsFlyerUtils", "isJailbroken");
		hook_cls_bool("GBDeviceInfo", "isJailbroken");
		hook_cls_bool("JailbreakDetection", "isJailbroken");
		hook_cls_bool("JailbreakDetector", "isJailbroken");
		hook_cls_bool("UIDevice", "isJailBroken");
		hook_cls_bool("UIDevice", "isJailbroken");
		hook_cls_bool("JailMonkey", "isJailBroken");
		hook_cls_bool("JailMonkey", "isDebuggedMode");
		hook_cls_bool("RNJailMonkey", "isJailBroken");
		hook_cls_bool("IRoot", "isJailbroken");
		hook_cls_bool("IRoot", "isJailBroken");
		hook_cls_bool("CDVJailbreakDetection", "jailbreakDetection");
		hook_cls_bool("FlutterJailbreakDetectionPlugin", "isJailBroken");
		hook_cls_bool("DXJailbreakDetector", "isJailbroken");
		hook_cls_bool("RelzJailbreakDetection", "isJailbroken");
		hook_cls_bool("DeviceChecker", "isJailbroken");
		hook_cls_bool("RootDetection", "isJailbroken");
		hook_cls_bool("AppSealingInterface", "IsAbnormalEnvironmentDetected");
		hook_cls_bool("AppSealingInterface", "isAbnormalEnvironmentDetected");
		hook_cls_str_no("AppSealingInterface", "GetHackingDetected");
		hook_cls_str_no("AppSealingInterface", "getHackingDetected");
		hook_cls_bool("AppSealing", "IsAbnormalEnvironmentDetected");
		hook_cls_bool("IOSJailbreakDetector", "isJailbroken");
		hook_cls_bool("IOSJailbreakDetector", "IsJailbroken");
	}
	if (jbFn) {
		hook_sym("stat", (void *)hook_stat, (void **)&orig_stat);
		hook_sym("lstat", (void *)hook_lstat, (void **)&orig_lstat);
		hook_sym("stat64", (void *)hook_stat64, (void **)&orig_stat64);
		hook_sym("lstat64", (void *)hook_lstat64, (void **)&orig_lstat64);
		hook_sym("fstatat", (void *)hook_fstatat, (void **)&orig_fstatat);
		hook_sym("access", (void *)hook_access, (void **)&orig_access);
		hook_sym("faccessat", (void *)hook_faccessat, (void **)&orig_faccessat);
		hook_sym("fopen", (void *)hook_fopen, (void **)&orig_fopen);
		hook_sym("freopen", (void *)hook_freopen, (void **)&orig_freopen);
		hook_sym("open", (void *)hook_open, (void **)&orig_open);
		hook_sym("openat", (void *)hook_openat, (void **)&orig_openat);
		hook_sym("realpath", (void *)hook_realpath, (void **)&orig_realpath);
		hook_sym("readlink", (void *)hook_readlink, (void **)&orig_readlink);
		hook_sym("readlinkat", (void *)hook_readlinkat, (void **)&orig_readlinkat);
		hook_sym("opendir", (void *)hook_opendir, (void **)&orig_opendir);
		hook_sym("statfs", (void *)hook_statfs, (void **)&orig_statfs);
		hook_sym("getenv", (void *)hook_getenv, (void **)&orig_getenv);
		hook_sym("_dyld_get_image_name", (void *)hook_dyld, (void **)&orig_dyld);
		hook_sym("objc_copyImageNames", (void *)hook_copyImages, (void **)&orig_copyImages);
		hook_sym("class_getImageName", (void *)hook_classImage, (void **)&orig_classImage);
		hook_sym("NSClassFromString", (void *)hook_classFromStr, (void **)&orig_classFromStr);
		hook_sym("dlopen", (void *)hook_dlopen, (void **)&orig_dlopen);
		hook_sym("dladdr", (void *)hook_dladdr, (void **)&orig_dladdr);
		hook_sym("fork", (void *)hook_fork, (void **)&orig_fork);
		hook_sym("vfork", (void *)hook_vfork, (void **)&orig_vfork);
		hook_sym("getppid", (void *)hook_getppid, (void **)&orig_getppid);
		hook_sym("ptrace", (void *)hook_ptrace, (void **)&orig_ptrace);
		hook_sym("csops", (void *)hook_csops, (void **)&orig_csops);
		hook_sym("posix_spawn", (void *)hook_posix_spawn, (void **)&orig_posix_spawn);
		hook_sym("posix_spawnp", (void *)hook_posix_spawnp, (void **)&orig_posix_spawnp);
		hook_sym("execve", (void *)hook_execve, (void **)&orig_execve);
		hook_sym("popen", (void *)hook_popen, (void **)&orig_popen);
		hook_sym("system", (void *)hook_system, (void **)&orig_system);
		hook_sym("sysctl", (void *)hook_sysctl, (void **)&orig_sysctl);
		hook_sym("sysctlbyname", (void *)hook_sysctlbyname, (void **)&orig_sysctlbyname);
		hook_sym("syscall", (void *)hook_syscall, (void **)&orig_syscall);
		hook_sym("connect", (void *)hook_connect, (void **)&orig_connect);
		hook_sym("proc_name", (void *)hook_proc_name, (void **)&orig_proc_name);
		hook_sym("proc_pidpath", (void *)hook_proc_pidpath, (void **)&orig_proc_pidpath);
		hook_sym("objc_getClass", (void *)hook_getClass, (void **)&orig_getClass);
		hook_sym("dlsym", (void *)hook_dlsym, (void **)&orig_dlsym);
	}
}
